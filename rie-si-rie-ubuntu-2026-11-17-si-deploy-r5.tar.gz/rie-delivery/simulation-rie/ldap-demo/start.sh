#!/bin/sh
# Bootstrap only an empty database, then keep running the real LDAP daemon.
set -eu
config=/run/directory/slapd.conf
if [ ! -f /var/lib/ldap/data.mdb ]; then
    slapadd -f "$config" -l /run/directory/seed.ldif
fi
exec slapd -f "$config" -h 'ldaps://127.0.0.1:1636/' -d 0
