"""Prepare an isolated OpenLDAP fixture and its replaceable OpenWebUI profile.

No password is accepted on the command line or printed. Passwords, CA keys and
rollback files belong to the chosen private instance, never the source tree.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import os
import platform
from pathlib import Path
import secrets
import subprocess
import urllib.error
import urllib.request
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
BASE = 'dc=demo,dc=rie,dc=example'
GROUPS = {'internal': 'RIE-Internes', 'external': 'RIE-Externes'}
ADMIN_GROUP = 'RIE-Administrateurs-Acces'
USERS = [
    {'uid': 'alice.martin', 'name': 'Alice Martin', 'mail': 'alice.martin@numerique.gouv.fr', 'category': 'internal', 'administrator': True},
    {'uid': 'bruno.lecteur', 'name': 'Bruno Lecteur', 'mail': 'bruno.lecteur@numerique.gouv.fr', 'category': 'internal'},
    {'uid': 'eric.durand.ext', 'name': 'Eric Durand', 'mail': 'eric.durand.ext@numerique.gouv.fr', 'category': 'external'},
    {'uid': 'camille.inconnue', 'name': 'Camille Inconnue', 'mail': 'camille.inconnue@numerique.gouv.fr', 'category': 'unclassified'},
]


def write(path, content, mode=0o600):
    """Never replace an existing instance's keys or credentials."""
    descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, mode)
    with os.fdopen(descriptor, 'w') as out:out.write(content)


def password_hash(value):
    salt = secrets.token_bytes(16)
    return '{SSHA}' + base64.b64encode(hashlib.sha1(value.encode() + salt).digest() + salt).decode()


def profile():
    """Only connection/schema parameters change when using a real LDAP server."""
    return {'version': 1, 'environment': 'synthetic', 'host': 'localhost', 'port': 1636,
            'use_tls': True, 'validate_cert': True, 'certificate_path': '/app/backend/data/ldap-demo-ca.crt',
            'search_base': 'ou=people,' + BASE, 'attribute_for_username': 'uid', 'attribute_for_mail': 'mail',
            'attribute_for_groups': 'memberOf', 'app_dn': 'cn=openwebui-reader,ou=services,' + BASE,
            'groups': dict(GROUPS), 'group_base': 'ou=groups,' + BASE,
            'administrator_group_dns': ['cn='+ADMIN_GROUP+',ou=groups,'+BASE]}


def settings(instance):
    value=json.loads((instance / 'directory.json').read_text())
    if value.get('version')!=1 or value.get('use_tls') is not True or value.get('validate_cert') is not True:
        raise ValueError('A version 1 profile with verified LDAPS is required')
    if type(value.get('port')) is not int or not 1<=value['port']<=65535 or not value.get('host') or '://' in value['host']:
        raise ValueError('LDAP host and numeric port required')
    if set(value.get('groups',{}))!={'internal','external'} or not all(value['groups'].values()):
        raise ValueError('Explicit internal and external LDAP groups required')
    return value


def allowed_filter(config):
    def escape(value):
        return ''.join({'\\': r'\5c', '*': r'\2a', '(': r'\28', ')': r'\29', '\x00': r'\00'}.get(c,c) for c in value)
    return '(|' + ''.join('(memberOf=' + escape(config.get('group_dns',{}).get(k,
        'cn='+config['groups'][k]+','+config['group_base'])) + ')' for k in ('internal','external')) + ')'



def run(argv, **kwargs):
    kwargs.setdefault('timeout',60)
    result = subprocess.run(argv, capture_output=True, **kwargs)
    if result.returncode:raise RuntimeError('Command failed; private output deliberately omitted: ' + Path(argv[0]).name)
    return result.stdout


def prepare(instance):
    """Create synthetic credentials and TLS material in one private directory."""
    if instance.exists() and any(instance.iterdir()):raise ValueError('Use a new empty private instance directory')
    instance.mkdir(parents=True, exist_ok=True, mode=0o700)
    instance.chmod(0o700)
    directory = instance / 'directory'; directory.mkdir(mode=0o700)
    private = instance / 'private'; private.mkdir(mode=0o700)
    config = profile()
    accounts = {'root_password': secrets.token_urlsafe(32), 'reader_password': secrets.token_urlsafe(32),
                'users': [{**user, 'password': secrets.token_urlsafe(24)} for user in USERS]}
    write(private/'accounts.json', json.dumps(accounts, indent=2)+'\n')
    write(instance/'directory.json', json.dumps(config, indent=2)+'\n')
    crypto_env={**os.environ,'RANDFILE':str(private/'.rnd')}
    # The CA is private to this directory. Only its public certificate is copied
    # into OpenWebUI; no system trust store is changed.
    run(['openssl','req','-x509','-newkey','rsa:3072','-nodes','-sha256','-days','365',
         '-subj','/CN=DINUM synthetic LDAP CA','-keyout',str(private/'ca.key'),'-out',str(directory/'ca.crt')],env=crypto_env)
    run(['openssl','req','-new','-newkey','rsa:3072','-nodes','-sha256','-subj','/CN=localhost',
         '-keyout',str(directory/'server.key'),'-out',str(private/'server.csr')],env=crypto_env)
    write(private/'server.ext', 'subjectAltName=DNS:localhost,IP:127.0.0.1,IP:::1\nbasicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\n')
    run(['openssl','x509','-req','-in',str(private/'server.csr'),'-CA',str(directory/'ca.crt'),'-CAkey',str(private/'ca.key'),
         '-CAserial',str(private/'ca.srl'),'-CAcreateserial','-days','365','-sha256','-extfile',str(private/'server.ext'),'-out',str(directory/'server.crt')],env=crypto_env)
    for key in (private/'ca.key',directory/'server.key'):key.chmod(0o600)
    root_hash = password_hash(accounts['root_password'])
    reader_dn = config['app_dn']
    slapd = f'''include /etc/ldap/schema/core.schema
include /etc/ldap/schema/cosine.schema
include /etc/ldap/schema/inetorgperson.schema
modulepath /usr/lib/ldap
moduleload back_mdb
moduleload memberof
pidfile /tmp/slapd.pid
argsfile /tmp/slapd.args
TLSCACertificateFile /run/directory/ca.crt
TLSCertificateFile /run/directory/server.crt
TLSCertificateKeyFile /run/directory/server.key
security simple_bind=128
sizelimit 100
timelimit 10
database mdb
maxsize 16777216
suffix "{BASE}"
rootdn "cn=admin,{BASE}"
rootpw {root_hash}
directory /var/lib/ldap
index objectClass eq
index uid,mail eq
overlay memberof
memberof-group-oc groupOfNames
memberof-member-ad member
memberof-memberof-ad memberOf
access to attrs=userPassword
    by anonymous auth
    by * none
access to *
    by dn.exact="{reader_dn}" read
    by * none
'''
    write(directory/'slapd.conf', slapd)
    entries = [f'dn: {BASE}\nobjectClass: top\nobjectClass: dcObject\nobjectClass: organization\no: SI-RIE synthetic directory\ndc: demo']
    for ou in ('people','groups','services'):
        entries.append(f'dn: ou={ou},{BASE}\nobjectClass: organizationalUnit\nou: {ou}')
    entries.append(f'dn: {reader_dn}\nobjectClass: organizationalRole\nobjectClass: simpleSecurityObject\ncn: openwebui-reader\nuserPassword: {password_hash(accounts["reader_password"])}')
    for user in accounts['users']:
        entries.append(f'dn: uid={user["uid"]},ou=people,{BASE}\nobjectClass: inetOrgPerson\nuid: {user["uid"]}\ncn: {user["name"]}\nsn: {user["name"].split()[-1]}\nmail: {user["mail"]}\nuserPassword: {password_hash(user["password"])}')
    for category,name in GROUPS.items():
        for user in accounts['users']:
            if user['category']==category:
                dn='dn: uid='+user['uid']+',ou=people,'+BASE
                entries=[entry+'\nmemberOf: cn='+name+',ou=groups,'+BASE if entry.startswith(dn+'\n') else entry for entry in entries]
    for category, name in GROUPS.items():
        members = '\n'.join('member: uid='+u['uid']+',ou=people,'+BASE for u in USERS if u['category']==category)
        entries.append(f'dn: cn={name},ou=groups,{BASE}\nobjectClass: groupOfNames\ncn: {name}\n{members}')
    admin_members = []
    for user in accounts['users']:
        if user.get('administrator') and user['category'] == 'internal':
            user_dn = 'uid='+user['uid']+',ou=people,'+BASE
            entries = [entry+'\nmemberOf: cn='+ADMIN_GROUP+',ou=groups,'+BASE
                       if entry.startswith('dn: '+user_dn+'\n') else entry for entry in entries]
            admin_members.append('member: '+user_dn)
    entries.append('dn: cn='+ADMIN_GROUP+',ou=groups,'+BASE+'\nobjectClass: groupOfNames\ncn: '+ADMIN_GROUP+'\n'+'\n'.join(admin_members))
    write(directory/'seed.ldif', '\n\n'.join(entries)+'\n')
    volume = 'dinum-ldap-demo-data-' + hashlib.sha256(str(instance).encode()).hexdigest()[:10]
    write(instance/'compose.env', f'LDAP_PLATFORM={"linux/arm64" if platform.machine() in {"arm64","aarch64"} else "linux/amd64"}\nLDAP_PROJECT_NAME={os.getenv("LDAP_PROJECT_NAME","dinum-ldap-demo")}\nLDAP_INSTANCE_DIR={instance}\nLDAP_DATA_VOLUME={volume}\nAPP_UID={os.getuid()}\nAPP_GID={os.getgid()}\n')
    print(json.dumps({'prepared': True, 'instance': str(instance), 'accounts_file': str(private/'accounts.json'), 'passwords_emitted': False}))


def compose(instance):
    env=dict(line.split('=',1) for line in (instance/'compose.env').read_text().splitlines())
    return ['docker','compose','--project-name',env.get('LDAP_PROJECT_NAME','dinum-ldap-demo'),'--project-directory',str(ROOT),
            '--env-file',str(instance/'compose.env'),'--file',str(ROOT/'compose.yaml')]


class NoRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):return None


def webui_request(url, path, payload=None, token=''):
    parsed=urlsplit(url)
    if parsed.scheme not in {'http','https'} or parsed.username or parsed.password or parsed.query or parsed.fragment or (parsed.scheme=='http' and parsed.hostname not in {'127.0.0.1','localhost','::1'}):
        raise ValueError('HTTPS required outside loopback; no embedded URL credentials')
    request = urllib.request.Request(url.rstrip('/')+path, data=json.dumps(payload).encode() if payload is not None else None,
        headers={'Content-Type':'application/json', **({'Authorization':'Bearer '+token} if token else {})})
    try:
        opener = urllib.request.build_opener(NoRedirects(), urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=20) as result:return json.load(result)
    except urllib.error.HTTPError as exc:
        raise RuntimeError('OpenWebUI HTTP '+str(exc.code)+' '+path.split('?')[0]) from None


def configure_webui(instance, url, admin_env):
    """Configure native LDAP while preserving other users and local admin access."""
    config = settings(instance)
    accounts = json.loads((instance/'private/accounts.json').read_text()) if config.get('environment')=='synthetic' else {'users':[]}
    admin = {k.strip():v.strip().strip('"').strip("'") for line in admin_env.read_text().splitlines()
             if '=' in line and not line.lstrip().startswith('#') for k,v in [line.split('=',1)]}
    token = webui_request(url,'/api/v1/auths/signin',{'email':admin['OPENWEBUI_ADMIN_EMAIL'],'password':admin['OPENWEBUI_ADMIN_PASSWORD']})['token']
    before = {name:webui_request(url,'/api/v1/auths/admin/config/ldap'+suffix,token=token)
              for name,suffix in [('enable',''),('server','/server')]}
    if not (instance/'private/webui-before.json').exists():write(instance/'private/webui-before.json',json.dumps(before)+'\n')
    groups = webui_request(url,'/api/v1/groups/',token=token)
    for name in config['groups'].values():
        if name not in {g['name'] for g in groups}:
            webui_request(url,'/api/v1/groups/create',{'name':name,'description':'Groupe LDAP de démonstration SI-RIE','data':{'source':'dinum-ldap-demo'}},token)
    body = {key:config[key] for key in ('host','port','attribute_for_mail','attribute_for_username','app_dn','search_base','use_tls','validate_cert','certificate_path','attribute_for_groups')}
    bind_password=(instance/config['bind_password_file']).read_text().strip() if config.get('bind_password_file') else accounts.get('reader_password','')
    if not bind_password:raise ValueError('Private LDAP bind password file required')
    body.update(label='SI-RIE — LDAP '+config.get('environment',''),app_dn_password=bind_password,
                search_filters=allowed_filter(config),enable_group_management=True,enable_group_creation=False)
    webui_request(url,'/api/v1/auths/admin/config/ldap/server',body,token)
    webui_request(url,'/api/v1/auths/admin/config/ldap',{'enable_ldap':True},token)
    # Export only this connection's private environment fragment. The operator
    # adds it to the existing WebUI deployment; no global file is rewritten here.
    names={'label':'LDAP_SERVER_LABEL','host':'LDAP_SERVER_HOST','port':'LDAP_SERVER_PORT',
           'attribute_for_mail':'LDAP_ATTRIBUTE_FOR_MAIL','attribute_for_username':'LDAP_ATTRIBUTE_FOR_USERNAME',
           'app_dn':'LDAP_APP_DN','app_dn_password':'LDAP_APP_PASSWORD','search_base':'LDAP_SEARCH_BASE',
           'search_filters':'LDAP_SEARCH_FILTER','use_tls':'LDAP_USE_TLS','validate_cert':'LDAP_VALIDATE_CERT',
           'certificate_path':'LDAP_CA_CERT_FILE','enable_group_management':'ENABLE_LDAP_GROUP_MANAGEMENT',
           'enable_group_creation':'ENABLE_LDAP_GROUP_CREATION','attribute_for_groups':'LDAP_ATTRIBUTE_FOR_GROUPS'}
    values={'ENABLE_LDAP':'true',**{names[k]:str(v).lower() if isinstance(v,bool) else str(v) for k,v in body.items() if k in names}}
    if any('\n' in v or '\r' in v for v in values.values()):raise ValueError('Multiline directory settings refused')
    exported=instance/'private/openwebui-ldap.env'
    exported.write_text('\n'.join(k+'='+v for k,v in values.items())+'\n');exported.chmod(0o600)
    # Keep the default pending role and existing administrators unchanged.
    # Explicitly activate only the classified fictional directory accounts.
    activated=[]
    for user in accounts['users'] if config.get('environment')=='synthetic' else []:
        if user['category']=='unclassified':continue
        session=webui_request(url,'/api/v1/auths/ldap',{'user':user['uid'],'password':user['password']})
        if session['email']!=user['mail']:raise RuntimeError('Unexpected LDAP account identity')
        webui_request(url,'/api/v1/users/'+session['id']+'/update',{'role':'user'},token)
        activated.append({'uid':user['uid'],'group':config['groups'][user['category']]})
    print(json.dumps({'ldap_configured':True,'activated_accounts':activated,'other_users_changed':False,'index_acl_enabled':False},ensure_ascii=False))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['prepare','build','start','stop','configure-webui'])
    parser.add_argument('instance',type=Path)
    parser.add_argument('--webui-url',default='http://127.0.0.1:8080')
    parser.add_argument('--admin-env',type=Path)
    args=parser.parse_args();instance=args.instance.expanduser().resolve();os.umask(0o077)
    if args.action=='prepare':prepare(instance)
    elif args.action=='configure-webui':
        if not args.admin_env:parser.error('--admin-env is required')
        configure_webui(instance,args.webui_url,args.admin_env)
    elif args.action=='build':run([*compose(instance),'build'],timeout=300);print('LDAP image built; no directory password was embedded.')
    elif args.action=='start':
        env=dict(line.split('=',1) for line in (instance/'compose.env').read_text().splitlines())
        volume=env['LDAP_DATA_VOLUME']
        probe=subprocess.run(['docker','volume','inspect',volume],capture_output=True)
        if probe.returncode:
            run(['docker','volume','create','--label','com.dinum.migration.scope=local-synthetic-ldap','--label','com.dinum.instance='+str(instance),volume])
            run(['docker','run','--rm','--network','none','--user','0:0','--read-only','--cap-drop','ALL','--cap-add','CHOWN','--cap-add','DAC_OVERRIDE',
                 '--security-opt','no-new-privileges:true','--mount','type=volume,source='+volume+',target=/data,volume-nocopy','--entrypoint','/bin/sh','dinum/ldap-demo:0.1.0','-c',
                 'chmod 0700 /data && chown "$1:$2" /data','init',str(os.getuid()),str(os.getgid())])
        else:
            saved=json.loads(probe.stdout)[0]
            if saved.get('Labels',{}).get('com.dinum.instance')!=str(instance):raise ValueError('Foreign directory volume refused')
        run([*compose(instance),'up','-d','--no-build','--pull','never'],timeout=60);print('LDAP started on LDAPS loopback :1636; existing data preserved.')
    else:run([*compose(instance),'stop'],timeout=60);print('LDAP stopped; private data preserved.')


if __name__=='__main__':main()
