"""Ask Albert for a JSON intent, then validate its mapping locally.

The prompt guides the model but grants no authorization. Deterministic validation
and compilation remain responsible for the fields, operators, periods, and sources
that can actually be used.
"""
from __future__ import annotations

import json
import re
import time
from ipaddress import ip_address
from urllib.parse import urlsplit, urlunsplit
import requests
from datetime import datetime, timezone
from typing import Any

from .config import Settings
from .http import session_for
from .mappings import active_mapping, validate_mapping
from .openwebui_dialogue import period_clarification
from .natural_dates import french_window
from .openwebui_dialogue import question_turns, normalized


def explicit_network_scope(question, catalog):
    """Keep the latest user selector, using approved values rather than fixture names."""
    values={v for item in catalog for v in item.get('concepts',{}).get('network_scope',{}).get('values',[]) if isinstance(v,str)}
    for turn in reversed(question_turns(question)):
        text=normalized(turn)
        found=[]
        for value in values:
            pattern=r'(?<!\w)'+re.escape(normalized(value))+r'(?!\w)'
            for match in re.finditer(pattern,text):
                if not re.search(r'(?:pas|non|au lieu de|plutot que)\s*$',text[:match.start()]):found.append(value)
        selected=set(found)
        if len(selected)>1:raise ValueError('Plusieurs périmètres sont cités : précisez celui à rechercher.')
        if selected:return selected.pop()
        if re.search(r'\b(?:meme|ce|cet|precedent|actuel)\s+(?:perimetre|network_scope|scope)\b',text):continue
        explicit=re.search(r'\b(?:perimetre|network_scope|scope)\s*(?:[:=]\s*)?[«"`\']?([a-z0-9][\w.-]*)',text)
        if explicit and explicit[1] not in {'le','la','de','du','reseau','precedent','actuel','identique'}:
            if values:raise ValueError('Périmètre non reconnu dans les mappings approuvés ; précisez une valeur admise.')
            return explicit[1]
    return None


def apply_scope(proposal,scope):
    if not scope:return proposal
    proposal=dict(proposal)
    if isinstance(proposal.get('equipment_lookup'),dict):
        proposal['equipment_lookup']={**proposal['equipment_lookup'],'scope':{'concept':'network_scope','value':scope}}
    else:
        proposal['filters']=[f for f in proposal.get('filters',[]) if f.get('concept')!='network_scope']+[
            {'concept':'network_scope','operator':'eq','value':scope}]
    if isinstance(proposal.get('hypotheses'),list):
        proposal['hypotheses']=[apply_scope(candidate,scope) if isinstance(candidate,dict) else candidate for candidate in proposal['hypotheses']]
    return proposal


def independent_count(message, inventory, approved):
    """A self-contained count must not inherit an unmentioned previous device.

    Require a complete period, an approved scope and one unambiguous current
    source. Referential or incomplete requests keep ordinary dialogue handling.
    This selects intent only; the planner/compiler still validate every filter.
    """
    text=normalized(message)
    if not re.search(r'\b(?:combien|compte\w*|comptage|nombre|denombr\w*)\b',text):return False
    if re.search(r'\b(?:meme\w*|precedent\w*|ce|cet|cette|ces|celui|celle|ceux|celles|son|sa|ses|repren\w*|encore|aussi)\b',text):return False
    return len(_complete_named_sources(message,inventory,approved))==1


def _complete_named_sources(message,inventory,approved):
    """Recognize only explicit current sources with a full date and approved scope."""
    text=normalized(message)
    catalog=[item for item in approved if item.get('active') and
        item.get('schema_hash')==inventory.get('indices',{}).get(item.get('index'),{}).get('schema_hash')]
    try:
        if not french_window(message,datetime.now(timezone.utc)) or not explicit_network_scope(message,catalog):return []
    except ValueError:return []
    selected=[]
    for item in catalog:
        labels=set()
        for name in [item['index'],*inventory['indices'][item['index']].get('aliases',[])]:
            if isinstance(name,str):
                labels.add(normalized(name));labels.update(re.findall(r'[a-z0-9]+',normalized(name)))
        if any(re.search(r'(?<![\w.-])'+re.escape(label)+r'(?![\w-]|\.[\w-])',text) for label in labels):selected.append(item['index'])
    return selected


def independent_equipment(message,inventory,approved):
    """A complete named-equipment search must not inherit an old count/filter."""
    text=normalized(message)
    if re.search(r'\b(?:meme\w*|precedent\w*|ce|cet|cette|ces|celui|celle|ceux|celles|son|sa|ses|encore|aussi|ajout\w*|egalement)\b',text):return False
    selected=_complete_named_sources(message,inventory,approved)
    if not selected:return False
    name=r'[«"\'`]?([a-z0-9][a-z0-9_.:@-]{0,127})'
    explicit=re.findall(r'\b(?:equipement|routeur|hote|machine)\s+(?:(?:nomme|appele)\s+)?'+name,text)
    indirect=re.findall(r'\b(?:activite|logs|journaux|evenements)\s+(?:de|du|pour)\s+'+name,text)
    indirect+=re.findall(r'\b(?:reprenons|reprends)\s+'+name,text)
    labels=set()
    for index in selected:
        for value in [index,*inventory['indices'][index].get('aliases',[])]:
            if isinstance(value,str):labels.add(normalized(value));labels.update(re.findall(r'[a-z0-9]+',normalized(value)))
    values={v.rstrip(':') for v in [*explicit,*(v for v in indirect if v not in labels)]
            if v not in {'le','la','les','l','un','une','de','du','des','ce','cet','cette','meme','reseau','site','equipement','routeur'}}
    return len(values)==1


def source_label_as_identity(question,proposal,catalog,inventory):
    """Detect an ambiguous count using an approved source label as a device."""
    lookup=proposal.get('equipment_lookup')
    value=lookup.get('value') if isinstance(lookup,dict) else None
    if not isinstance(value,str) or not value.strip():return False
    text=normalized(' '.join(question_turns(question)))
    if not re.search(r'\b(?:combien|compte\w*|comptage|nombre|denombr\w*)\b',text):return False
    labels=set()
    for item in catalog:
        for name in [item['index'],*inventory.get('indices',{}).get(item['index'],{}).get('aliases',[])]:
            if isinstance(name,str):
                labels.add(normalized(name));labels.update(re.findall(r'[a-z0-9]+',normalized(name)))
    if normalized(value) not in labels:return False
    # A source and a real device can share a name. An explicitly named device
    # remains an identity request; the usual resolution/ACL checks still apply.
    named=r'\b(?:equipement|routeur|machine|hote|nom|fqdn|identite)\s+(?:(?:nomme|appele)\s+)?[«"`\']?'+re.escape(normalized(value))+r'(?![\w.-])'
    return not bool(re.search(named,text))


def apply_log_exclusions(question,proposal,catalog,inventory):
    """Apply named user log targets and exclusions from the approved catalogue.

    Positive additions require explicit user labels. Exclusions alone never
    expand a bad model subset. Ordinary identity, mapping and ACL checks remain
    mandatory; no field, relationship or authorization is inferred.
    """
    lookup=proposal.get('equipment_lookup')
    if proposal.get('source','opensearch')!='opensearch' or not isinstance(lookup,dict):return proposal,{}
    targets=lookup.get('log_indices')
    participants=lookup.get('indices')
    if (not isinstance(targets,list) or not targets or any(not isinstance(v,str) for v in targets)
            or len(set(targets))!=len(targets)
            or not isinstance(participants,list) or not participants
            or any(not isinstance(v,str) for v in participants)):return proposal,{}
    if not set(targets)<={item['index'] for item in catalog}:return proposal,{}
    labels={};exact=set()
    for item in catalog:
        for name in [item['index'],*inventory['indices'][item['index']].get('aliases',[])]:
            if not isinstance(name,str):continue
            value=normalized(name)
            if not value:continue
            exact.add(value)
            for label in {value,*re.findall(r'[a-z][a-z0-9]+',value)}:
                labels.setdefault(label,set()).add(item['index'])
    # Shared pieces of physical names are not administered family aliases.
    labels={label:names for label,names in labels.items() if len(names)==1 or label in exact}
    labels={label:names for label,names in labels.items() if label in exact or label not in
            {'source','sources','index','indices','log','logs','journaux','event','events','network','reseau'}}
    if not labels:return proposal,{}
    # A terminal full stop is punctuation; a dot followed by a name character
    # belongs to a qualified source name. Never match a partial index or alias.
    pattern=re.compile(r'(?<![\w.-])(?:'+'|'.join(re.escape(v) for v in sorted(labels,key=lambda v:(-len(v),v)))+r')(?![\w-]|\.[\w-])')
    scopes={normalized(v) for item in catalog for v in item.get('concepts',{}).get('network_scope',{}).get('values',[]) if isinstance(v,str)}
    states={};requested=[];additive=False
    for turn in question_turns(question):
        text=normalized(turn);previous=None;negative=False;mentioned=False;positive=[];complete_list=True
        for match in pattern.finditer(text):
            prefix=re.sub(r'[«»“”"\'`]', '', text[:match.start()])
            source_cue=re.search(r'\b(?:sources?|index|familles?|journaux|logs)(?:\s+(?:de|du|des))?\s*$',prefix)
            if ((match[0]==normalized(str(lookup.get('value',''))) or match[0].isdigit()
                    or match[0] in {'utc','gmt','europe/paris'}) and not source_cue):
                continue  # A device may have the same name as a source.
            if match[0] in scopes and re.search(r'\b(?:dans|perimetre|scope)\s*$',prefix):continue
            gap=text[previous:match.start()] if previous is not None else text[:match.start()]
            gap=re.sub(r'[«»“”"\'`]', '', gap)
            if previous is None or not re.fullmatch(r'[\s,]*(?:(?:et|ou|ni)\s*)?',gap):
                negative=bool(re.search(r'\b(?:sans|sauf|hors|excepte\w*|exclu\w*|pas|non)(?:\s+(?:de|du|des|le|la|les|logs|journaux|source|sources|famille|familles|index))*\s*$',gap))
            indices=labels[match[0]]
            if len(indices)!=1:raise ValueError('Le libellé de source est ambigu ; précisez un index ou alias unique.')
            mentioned=True
            if not negative and positive and not re.fullmatch(r'[\s,]*(?:(?:et|ou|ni)\s*)?',gap):complete_list=False
            for index in indices:
                states[index]=negative
                if not negative and index not in positive:positive.append(index)
            previous=match.end()
        if mentioned:
            requested=positive
            additive=not complete_list or bool(re.search(r'\b(?:ajout\w*|aussi|egalement|en plus|complet\w*)\b',text))
        elif re.search(r'\b(?:sources?|familles?|families|family|index(?:es)?|indices)\b',text):
            # A new source selection without locally resolved names belongs to
            # the planner. Never overwrite it with an older named selection.
            states={};requested=[];additive=False
    excluded={index for index,value in states.items() if value}
    if not excluded and not requested:return proposal,{}
    if requested and not any(spec.get('identity_namespace') and
            (spec.get('identity_role')=='id' or spec.get('identity_anchor') is True)
            for item in catalog if item['index'] in participants for spec in item.get('concepts',{}).values()):
        return proposal,{}  # A named source must never invent the missing anchor.
    selected=list(dict.fromkeys([*targets,*requested])) if requested and additive else requested or targets
    remaining=[index for index in selected if index not in excluded]
    if not remaining:raise ValueError('Aucune cible de logs proposée ne reste après vos exclusions ; précisez les sources à lire.')
    added=[index for index in remaining if index not in targets]
    participants=[*participants,*(index for index in added if index not in participants)]
    return ({**proposal,'equipment_lookup':{**lookup,'indices':participants,'log_indices':remaining}},
        {'user_excluded_log_indices':sorted(excluded),'removed_log_indices':[index for index in targets if index not in remaining],
         'user_requested_log_indices':requested,'added_log_indices':added,
         'identity_participants_unchanged':participants==lookup['indices'],'log_targets_added':bool(added)})


def source_update_clarification(question,proposal,catalog,inventory):
    """Recognize a chronological source replacement mistaken for a conflict.

    Reuse the ordinary catalogue constraints. Additions, current contradictions
    and unspecified source selections remain ordinary clarifications.
    """
    text=normalized(str(proposal.get('clarification') or ''))
    turns=question_turns(question)
    if len(turns)<2 or not re.search(r'\b(?:contradic\w*|incompatib\w*)\b',text):return False
    if not re.search(r'\b(?:sources?|familles?|logs|journaux)\b',text):return False
    latest=normalized(turns[-1])
    if re.search(r'\b(?:ajout\w*|aussi|egalement|compar\w*|complet\w*|compte\w*|combien|nombre|group\w*|class\w*)\b',latest):return False
    if re.search(r'\bsans\s+[«"\'`]?([\w.-]+)[»"\'`]?\b.*\b\1\b',latest):return False
    names=[item['index'] for item in catalog]
    probe={'source':'opensearch','equipment_lookup':{'value':'','indices':names,'log_indices':names}}
    try:_,selection=apply_log_exclusions(turns[-1],probe,catalog,inventory)
    except ValueError:return False
    requested=set(selection.get('user_requested_log_indices') or [])
    excluded=set(selection.get('user_excluded_log_indices') or [])
    return bool(requested and not requested&excluded)

from .telemetry import albert_call, record_albert_response

# Keep the portable planner independent of HTTPX, including its minimal CI.
MAX_REQUEST_BYTES = 1_048_576
MAX_RESPONSE_BYTES = 8_388_608


class AlbertPlannerError(ValueError):
    """A closed provider code, without transport URLs or exception messages."""
    def __init__(self, code):
        self.code = code
        super().__init__('Albert ' + code)


def _albert_origin(value):
    try:
        parsed = urlsplit(value.strip())
        port = parsed.port
        if (parsed.scheme not in ('https', 'http') or not parsed.hostname or parsed.username is not None
                or parsed.password is not None or parsed.query or parsed.fragment
                or '?' in value or '#' in value or parsed.path.rstrip('/') not in ('', '/v1')
                or (port is not None and not 1 <= port <= 65535)
                or (parsed.scheme == 'http' and parsed.hostname not in ('127.0.0.1', 'localhost', '::1'))):
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        raise ValueError('URL Albert invalide ; HTTPS requis hors loopback') from None
    return urlunsplit((parsed.scheme, parsed.netloc, '/v1', '', ''))


SYSTEM = """Tu traduis une question métier PDL en intention JSON bornée.
Tu n'écris jamais de DSL OpenSearch. Tu choisis exclusivement les index et concepts présents dans le contexte.
Si un catalogue approuvé est fourni, utilise ses concepts sans changer leur sens. Sinon propose une correspondance
concept -> champ physique qui devra être approuvée par un humain. Opérations autorisées: search, count, aggregate.
Opérateurs autorisés: eq, in, ne, not_in, exists. eq/ne exigent un scalaire, in/not_in une liste non vide.
ne/not_in excluent les valeurs demandées. Préserve exactement leur casse. Période maximale: 31 jours.
time_range exige gte et exactement une borne supérieure lt (exclusive) OU lte (inclusive), jamais les deux.
Utilise les query_defaults et business_aliases du catalogue approuvé. Par défaut le tri est desc;
limit est borné par le serveur. Pour aggregate, group_by est le NOM D'UN SEUL CONCEPT du catalogue
approuvé, sous forme de chaîne JSON, jamais un champ physique, un objet ou plusieurs concepts.
Le périmètre demandé est un filtre et non un regroupement supplémentaire. Réponds uniquement avec un objet JSON:
{"source":"opensearch|zabbix|grafana","index":"...","operation":"search|count|aggregate","time_range":{"gte":"...","lt":"..."},
"filters":[{"concept":"...","operator":"eq","value":"..."}],"group_by":null,
"select":[],"limit":20,"sort_order":"desc","proposed_mapping":{"timestamp":{"field":"@timestamp","type":"date"},...},
"external_call":{"name":"méthode ou outil autorisé","arguments":{}},
"route_reason":"...","clarification":null,"hypotheses":[]} Le proposed_mapping est vide si un catalogue approuvé
est utilisé. Pour un schéma sans catalogue approuvé, hypotheses peut contenir jusqu'à cinq objets de même forme,
ordonnés du plus plausible au moins plausible, avec confidence entre 0 et 1.
Si la question est réellement ambiguë, renseigne clarification et ne suppose pas de source."""

SYSTEM += """
Pour type et subtype de pare-feu, utilise le concept unique dataset avec la valeur finale
type:subtype uniquement si cette valeur figure dans les valeurs du mapping approuvé. Aucun
champ type/subtype ou transformation libre n'est autorisé. Un couple inconnu ou incomplet
nécessite une précision/revue; n'ignore pas un critère de la question. Pour not_action utilise
le concept action et ne (scalaire) ou not_in (liste), jamais un champ physique inventé.
Pour PFAING, une communauté inconnue ou sans route d'index administrée doit demander une
précision. N'élargis jamais la recherche à tous les index; n'invente pas une table de communautés.
Pour les logs d'un équipement identifié par nom/FQDN/IP/référence, utilise equipment_lookup:
{"value":"identité présente dans la question","indices":["index autorisés"],
"log_indices":["sous-ensemble des index participants dont les logs sont demandés"],
"scope":{"concept":"network_scope","value":"périmètre demandé"}} et time_range explicite.
indices contient au moins une source d'ancre approuvée et les cibles de logs. log_indices est obligatoire:
son omission est rejetée avant toute lecture. Le serveur ajoute pour l'identité les autres sources
actuellement approuvées partageant le namespace d'ancre et un périmètre compatible ; il n'élargit
jamais log_indices. Pour une demande portant
uniquement sur une famille ou excluant une famille, conserve ses sources d'identité nécessaires
dans indices, puis déclare dans log_indices exclusivement les cibles demandées, d'après les mappings
et le contexte disponibles. N'invente pas de famille ou de relation; demande une précision si cette
sélection n'est pas établie. Les preuves d'identité restent distinctes des logs publiés.
Les champs d'identité exigent identity_role (name,fqdn,ip,id,reference) et identity_namespace dans
le mapping approuvé. L'ancre est un ID stable ou une option identity_anchor explicitement
approuvée pour un nom/FQDN; n'invente jamais asset.id. Les options identity_match et
identity_extractor sont utilisables seulement si déjà approuvées dans le catalogue. Une
ambiguïté, une boucle bornée incomplète ou une identité non vérifiée interdit les lectures
cibles; demander une précision/revue. Les IP clientes/destination des flux
ne sont pas des IP de gestion. Sans relations approuvées, proposed_mappings peut proposer un objet
index -> mapping de concepts avec les rôles; toutes ces propositions exigent une revue humaine.
Ne limite pas les logs au champ du nom initial: la résolution recherche les références cross-index.
Une cible de logs n'a pas besoin de posséder elle-même le nom de l'équipement : ses champs
d'identité approuvés peuvent ne contenir que des références ou des adresses, résolues depuis
les autres sources d'identité participantes. Utilise alors equipment_lookup avec ces sources.
Ne demande pas à l'utilisateur de choisir un champ physique lorsque les rôles et namespaces
sont déjà définis par les mappings approuvés ; leur résolution appartient au serveur.
La sémantique des champs et les espaces de noms ne peuvent être déduits avec certitude des types.
Demande une précision lorsqu'un rôle, une période, une identité ou le périmètre sont incertains.
Pour un multi-champ keyword absent de _source, déclare source_field avec le champ parent existant.
"""

SYSTEM = """Choisis d'abord la forme d'intention adaptée à la question.
Un nom de famille, d'index ou de source de journaux n'est pas une identité d'équipement.
Une demande de nombre d'événements enregistrés par une source relève de count,
avec les filtres demandés ; ne recherche pas le nom de cette source comme un équipement.
Une recherche des logs, événements ou de l'activité d'une identité nommée, même
sans le mot « équipement », surtout sur plusieurs familles d'index,
exige equipment_lookup et non une recherche simple sur un seul index.
Dans ce cas réponds avec cette forme, en utilisant les index et concepts approuvés :
{"source":"opensearch","equipment_lookup":{"value":"nom présent dans la question",
"indices":["sources d'identité et cibles nécessaires"],"log_indices":["cibles demandées uniquement"],
"scope":{"concept":"concept de périmètre approuvé","value":"périmètre demandé"}},
"time_range":{"gte":"début UTC","lt":"fin UTC"},"limit":20,"proposed_mappings":{},"clarification":null}
Une famille d'index demandée ou exclue se sélectionne dans log_indices. Ce n'est
jamais une valeur d'action d'événement : ne filtre pas action sur un nom de famille.
log_indices est toujours explicite, même pour tous les logs ; son omission est une erreur.
Préserve les sources d'identité nécessaires dans indices, même quand leurs logs
ne sont pas demandés. Ne remplace pas ce parcours par des filtres simples.
Si le catalogue ne permet pas ce choix, demande une précision et ne l'invente pas.
identity_capabilities résume les rôles et espaces de noms déjà approuvés.
Une cible qui ne possède pas de champ de nom reste utilisable par ses références
ou IP de gestion, avec les sources d'identité participantes. Une demande
portant sur plusieurs familles ne doit jamais être réduite à une seule cible
parce qu'une autre ne contient pas le nom initial. Les champs physiques sont
un choix du mapping approuvé, jamais une question à poser à l'utilisateur.
\n""" + SYSTEM

SYSTEM += """
Dialogue de clarification : une question commençant par PDL_DIALOGUE contient un objet JSON
avec request (demande initiale), replies (réponses utilisateur dans l'ordre) et clarification
(dernière question du serveur). Réunis uniquement les messages utilisateur pour l'intention.
La dernière correction explicite d'une identité, d'une période, d'un périmètre ou des sources
remplace l'ancienne valeur. Une nouvelle liste de familles remplace la liste précédente et
ses restrictions de sources ; ce n'est pas une contradiction entre deux tours successifs.
Une addition ou comparaison explicitement demandée étend les sources. Conserve les autres
critères non modifiés ; une contradiction dans le message courant demande une clarification.
clarification indique ce qui manque, jamais une valeur confirmée ni une approbation de mapping.
Pour une lecture de logs sans période fournie par l'utilisateur, demande la période :
n'invente ni dates ni fenêtre par défaut. Une journée civile explicite est suffisante,
sans demander inutilement des heures. Ne demande que les précisions réellement nécessaires
à l'opération et aux concepts du catalogue. Si plusieurs précisions manquent, formule
une question concise couvrant ces éléments. Une réponse partielle nécessite une nouvelle
clarification ciblée; aucune lecture métier n'est autorisée tant que l'intention est ambiguë.
Un changement de critère ne supprime pas les critères non modifiés. Une source ou une
relation inexistante doit être signalée; une clarification ne peut jamais l'autoriser.
"""

IDENTITY_TOOL = 'extract_equipment_request'
IDENTITY_REPAIR = """Extrais uniquement les arguments de lecture écrits dans la question.
Il ne s'agit pas de l'identité de l'utilisateur : relève le nom/FQDN/IP/référence
initial de L'ÉQUIPEMENT. Un seul identifiant, sans ajouter les noms des sources.
Choisis les index dont les logs sont demandés dans available_sources.
La période et le périmètre sont déjà validés par Python : ne les liste pas comme
critères supplémentaires. Le moteur résout les identifiants intermédiaires et
valide les relations approuvées ; tu ne juges jamais les jointures ni les champs.
Ne devine aucun prérequis technique et ne demande pas d'adresse ou de référence
intermédiaire. Utilise seulement la fonction imposée. Les filtres supplémentaires
réellement demandés et non représentables sont copiés mot pour mot dans
unsupported_user_constraints ; liste vide sinon. Une identité ou source réellement
non indiquée reste vide, sans invention. PDL_DIALOGUE contient les messages
utilisateur ; leur dernière correction explicite remplace l'ancienne valeur.
"""


def _json_object(text: str) -> dict:
    """Decode a JSON object, optionally wrapped in a Markdown code block.

    Reject lists/scalars and propagate decoding errors to the service.
    No code or DSL contained in the response is executed here.
    """
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1].rsplit("```", 1)[0]
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError("Albert n'a pas renvoyé un objet JSON.")
    return value


def equipment_participants(proposal: dict) -> dict:
    """Include explicitly declared log targets in the participant list.

    Providers sometimes put only identity sources in indices. This completes
    that redundant list, never log_indices. Missing/malformed selections remain
    invalid; ordinary inventory, mapping, size and ACL checks still apply.
    """
    lookup = proposal.get('equipment_lookup')
    if proposal.get('source', 'opensearch') != 'opensearch' or not isinstance(lookup, dict):
        return proposal
    selections = [lookup.get('indices'), lookup.get('log_indices')]
    if any(not isinstance(items, list) or not items or
           any(not isinstance(item, str) or not item for item in items) or
           len(set(items)) != len(items) for items in selections):
        return proposal
    participants = list(dict.fromkeys([*selections[0], *selections[1]]))
    return {**proposal, 'equipment_lookup': {**lookup, 'indices': participants}}


def identity_metadata_clarification(proposal,catalog):
    """A physical-field question can be checked once against approved relations."""
    if proposal.get('source','opensearch')!='opensearch':return False
    text=proposal.get('clarification')
    if not isinstance(text,str) or not text.strip() or len(text)>1000:return False
    specs=[(name,spec) for item in catalog for name,spec in item.get('concepts',{}).items()
        if spec.get('identity_role') and spec.get('identity_namespace')]
    if not any(spec.get('identity_role')=='id' or spec.get('identity_anchor') is True for _,spec in specs):return False
    declared=any(re.search(r'(?<!\w)'+re.escape(label)+r'(?!\w)',text,re.I)
        for name,spec in specs for label in (name,spec['field']))
    words=normalized(text)
    metadata=bool(re.search(r'\b(?:champ|field|mapping|namespace|ancre|anchor|catalogue?|schema|jointure|relation|index|indices)\w*\b',words))
    identity=bool(re.search(r'\b(?:identit\w*|identifi\w*|reference\w*|equipement\w*|fqdn|namespace)\b',words))
    return declared or metadata and identity


def identity_argument_proposal(arguments,question,inventory,catalog,settings,period,scope):
    """Compile extracted user arguments using one locally validated identity pool."""
    from .equipment import prepare_lookup
    if set(arguments)!={'equipment_value','log_indices','unsupported_user_constraints'}:
        raise ValueError('Arguments de résolution incomplets ou inconnus.')
    value=arguments['equipment_value'];targets=arguments['log_indices'];criteria=arguments['unsupported_user_constraints']
    if not isinstance(value,str) or not isinstance(targets,list) or not isinstance(criteria,list):
        raise ValueError('Types des arguments de résolution invalides.')
    # Like dates/scopes, an explicitly labelled user identifier wins over a
    # model which accidentally appends source names to that identifier.
    for turn in reversed(question_turns(question)):
        matches=re.findall(r"\b(?:équipement|equipement|routeur|hôte|hote|machine|reprenons|reprends)\s+(?:(?:nommé|nomme|appelé|appele)\s+)?[«\"`']?([A-Za-z0-9][A-Za-z0-9_.:@-]{0,127})",turn,re.I)
        matches=[m for m in matches if normalized(m) not in {'sur','dans','de','du','le','la','les','l','un','une','ce','cet','meme','avec'}]
        cleaned=[]
        for v in matches:
            if v.endswith(':'):
                try:ip_address(v)
                except ValueError:v=v[:-1]
            cleaned.append(v)
        matches=cleaned
        if matches:
            if len({normalized(v) for v in matches})!=1:
                return {'source':'opensearch','clarification':'Plusieurs équipements sont nommés ; précisez une identité unique.'}
            value=matches[0];break
    names={item['index'] for item in catalog}
    if len(targets)>settings.max_indices or any(not isinstance(v,str) or v not in names for v in targets) or len(set(targets))!=len(targets):
        raise ValueError('Cible de logs absente du catalogue courant approuvé.')
    user_text='\n'.join(question_turns(question))
    if len(criteria)>8 or any(not isinstance(v,str) or not v or len(v)>200 or v not in user_text for v in criteria):
        raise ValueError('Critère supplémentaire inventé ou invalide.')
    if criteria:return {'source':'opensearch','clarification':'Le critère supplémentaire demandé ne peut pas être appliqué par cette résolution ; précisez une recherche compatible.'}
    if not value or not targets or not period:
        return {'source':'opensearch','clarification':'Précisez l’équipement initial, les sources demandées et une période complète.'}
    proposal={'source':'opensearch','equipment_lookup':{'value':value,'indices':list(targets),'log_indices':list(targets)},'time_range':dict(period),'clarification':None}
    if scope:proposal['equipment_lookup']['scope']={'concept':'network_scope','value':scope}
    def anchors(item):return {s['identity_namespace'] for s in item.get('concepts',{}).values()
        if s.get('identity_namespace') and (s.get('identity_role')=='id' or s.get('identity_anchor') is True)}
    selected=set().union(*(anchors(item) for item in catalog if item['index'] in targets))
    candidates=[[]] if selected else [[item['index']] for item in catalog if anchors(item) and item['index'] not in targets]
    valid={}
    for addition in candidates:
        candidate={**proposal,'equipment_lookup':{**proposal['equipment_lookup'],'indices':[*targets,*addition]}}
        try:lookup,_,missing=prepare_lookup(candidate,inventory,catalog,settings,question)
        except ValueError:continue
        if not missing:
            key=(lookup['source_addition']['anchor_namespace'],frozenset(lookup['indices']))
            valid.setdefault(key,candidate)
    if len(valid)!=1:return {'source':'opensearch','clarification':'Aucun pool d’identité approuvé unique ne correspond aux cibles ; précisez le périmètre ou faites examiner les relations du catalogue.'}
    return next(iter(valid.values()))


class AlbertPlanner:
    """Propose intent, with one shared repair for metadata or source confusion."""

    def __init__(self, settings: Settings):
        """Prepare the Albert session with TLS and a private key without an initial call."""
        self.settings, self.config = settings, settings.albert
        self.url = _albert_origin(self.config.url)
        if self.config.tls.verify is not True:
            raise ValueError('Albert requiert la vérification TLS')
        key = self.config.api_key
        if not key or any(ord(character) < 33 or ord(character) > 126 for character in key):
            raise ValueError('Clé Albert invalide')
        self.session = session_for(self.config.tls, bearer=key)

    def propose(self, question: str, inventory: dict, approved: list[dict]) -> dict:
        """Send the question, fields, and current catalog and return a proposed intent.

        Missing explicit periods/years return a local clarification before any
        generation. Context contains bounded metadata, not complete logs or secrets.
        Exclude approvals with an obsolete hash. Make one POST without redirects
        or transport retries; one metadata/source-identity ambiguity may be repaired.
        Retain configured/returned model names for provenance reporting.
        The proposal still requires validation before any business read.
        """
        missing_period = period_clarification(question)
        if missing_period:
            return {'source': 'opensearch', 'clarification': missing_period}
        reference_time = datetime.now(timezone.utc)
        try:
            bounds = french_window(question, reference_time)
        except ValueError:
            return {'source': 'opensearch', 'clarification':
                    'La période indiquée est invalide ou ambiguë. Précisez deux bornes ISO 8601 avec '
                    'leur décalage UTC, ou des dates et heures en heure de Paris/UTC.'}
        confirmed_period = {'gte': bounds['start'], 'lt': bounds['end']} if bounds else None
        current_catalog = [item for item in approved if item.get("active") and
                           item.get("schema_hash") == inventory.get("indices", {}).get(item.get("index"), {}).get("schema_hash")]
        catalog_by_index = {item['index']: item for item in current_catalog}
        try:confirmed_scope=explicit_network_scope(question,current_catalog)
        except ValueError as exc:return {'source':'opensearch','clarification':str(exc)}
        safe_inventory = {}
        for name, item in inventory.get('indices', {}).items():
            mapping = catalog_by_index.get(name, {}).get('concepts')
            # Approved concepts already define usable fields. Sending unrelated
            # schema again wastes model context; it never authorizes those fields.
            selected = ({spec['field'] for spec in mapping.values()} if mapping else set(item['fields']))
            safe_inventory[name] = {
                'fields': {field: cap for field, cap in item['fields'].items() if field in selected},
                'aliases': item.get('aliases', []),
                'bounded_values': {field: values for field, values in item.get('bounded_values', {}).items() if field in selected},
                'field_scope': 'approved_mapping' if mapping else 'discovered_schema'}
        active_sources = ["opensearch"]
        if self.settings.zabbix.enabled:
            active_sources.append("zabbix")
        if self.settings.grafana.enabled:
            active_sources.append("grafana")
        context = {"question": question, "active_sources": active_sources,
                   "reference_time": reference_time.isoformat(), "confirmed_time_range": confirmed_period,
                   "confirmed_network_scope":confirmed_scope,
                   "approved_catalog": [{key: item[key] for key in ('index', 'concepts', 'query_defaults', 'business_aliases') if key in item}
                                        for item in current_catalog],
                   "inventory": safe_inventory}
        context['identity_capabilities']=[{'index':item['index'],
            'identifiers':[{'concept':name,'role':spec['identity_role'],
                'namespace':spec['identity_namespace'],
                'anchor':spec['identity_role']=='id' or spec.get('identity_anchor') is True}
                for name,spec in item.get('concepts',{}).items()
                if spec.get('identity_role') and spec.get('identity_namespace')]}
            for item in current_catalog]
        payload = {"model": self.config.model, "temperature": 0, "response_format": {"type": "json_object"},
                      "messages": [{"role": "system", "content": SYSTEM},
                                   {"role": "user", "content": json.dumps(context, ensure_ascii=False)}]}
        proposal,raw=self._request_proposal(payload)
        attempts=[{'returned_model':raw.get('model'),'usage':raw.get('usage',{})}]
        repair_reason=('source_label_as_identity' if source_label_as_identity(question,proposal,current_catalog,inventory)
            else 'source_selection_update' if source_update_clarification(question,proposal,current_catalog,inventory)
            else 'approved_identity_metadata' if identity_metadata_clarification(proposal,current_catalog) else None)
        if repair_reason:
            review=('Le plan confond un libellé de source approuvée avec une identité d’équipement '
                    'dans une demande de comptage. Vérifie la question originale : un nombre d’événements '
                    'enregistrés par une source demande count avec les critères approuvés, sans recherche '
                    'de cette source comme équipement. Ne supprime aucun filtre demandé. Si un véritable '
                    'équipement est explicitement demandé, conserve son identité ; sinon ne l’invente pas. '
                    'Une ambiguïté réelle reste une clarification.' if repair_reason=='source_label_as_identity' else
                    'Les mappings actifs définissent déjà les rôles, champs et espaces de noms '
                    'd’identité. Vérifie si la question demande une activité d’équipement pouvant être résolue '
                    'par equipment_lookup, avec les sources d’identité et les cibles de logs demandées. '
                    'Ne demande pas de champ physique ou de référence que le moteur doit retrouver. '
                    'N’invente aucune relation ni valeur. Si une information métier manque réellement, '
                    'conserve une clarification ciblée. Le texte précédent n’est pas une preuve.')
            # Start again from trusted inputs. Repeating a false schema claim
            # can anchor the correction on that claim despite an "untrusted" label.
            repair_context={**context,'repair_reason':repair_reason,'local_review':review}
            system=payload['messages'][0]
            if repair_reason in ('approved_identity_metadata','source_selection_update'):
                # Argument extraction receives no physical schema to adjudicate.
                repair_context={'question':'\n'.join(question_turns(question)),'confirmed_time_range':confirmed_period,
                    'confirmed_network_scope':confirmed_scope,'repair_reason':repair_reason,
                    'available_sources':[{'index':item['index'],
                        'aliases':inventory['indices'][item['index']].get('aliases',[])} for item in current_catalog]}
                if repair_reason=='source_selection_update':
                    repair_context['current_source_request']=question_turns(question)[-1]
                    repair_context['source_precedence']='La dernière sélection de sources remplace les restrictions des tours précédents.'
                schema={'type':'object','additionalProperties':False,'properties':{
                    'equipment_value':{'type':'string','pattern':'^[A-Za-z0-9][A-Za-z0-9_.:@-]{0,127}$|^$',
                        'description':'Un seul identifiant initial de l’équipement écrit dans la question. Exclure les noms des familles et sources. Ce n’est pas l’identité LDAP de l’utilisateur.'},
                    'log_indices':{'type':'array','maxItems':self.settings.max_indices,
                        'items':{'type':'string','enum':[item['index'] for item in current_catalog]},
                        'description':'Sources de logs demandées, sans ajouter de source.'},
                    'unsupported_user_constraints':{'type':'array','maxItems':8,'items':{'type':'string','maxLength':200},
                        'description':'Filtres supplémentaires écrits dans la question et non représentables. Ne jamais lister les dates, heures, périmètres, équipement ou familles déjà traités. Ne jamais inventer un prérequis de jointure. Liste vide sinon.'}},
                    'required':['equipment_value','log_indices','unsupported_user_constraints']}
                payload={k:v for k,v in payload.items() if k!='response_format'}
                payload.update(tools=[{'type':'function','function':{'name':IDENTITY_TOOL,
                    'description':'Relever uniquement l’équipement initial et les sources demandées. Python gère tous les champs, relations, adresses et références intermédiaires.','parameters':schema}}],
                    tool_choice={'type':'function','function':{'name':IDENTITY_TOOL}},parallel_tool_calls=False)
                system={'role':'system','content':IDENTITY_REPAIR}
            payload={**payload,'messages':[system,
                {'role':'user','content':json.dumps(repair_context,ensure_ascii=False)}]}
            proposal,raw=self._request_proposal(payload)
            attempts.append({'returned_model':raw.get('model'),'usage':raw.get('usage',{})})
            if repair_reason=='source_selection_update':
                # Validate model targets with the ordinary guard before choosing
                # an identity pool. Unknown/malformed targets are never erased.
                probe={'source':'opensearch','equipment_lookup':{'value':proposal.get('equipment_value',''),
                    'indices':[item['index'] for item in current_catalog],'log_indices':proposal.get('log_indices')}}
                corrected,_=apply_log_exclusions(question_turns(question)[-1],probe,current_catalog,inventory)
                proposal={**proposal,'log_indices':corrected['equipment_lookup']['log_indices']}
            if repair_reason in ('approved_identity_metadata','source_selection_update'):
                proposal=identity_argument_proposal(proposal,question,inventory,current_catalog,self.settings,confirmed_period,confirmed_scope)
        if source_label_as_identity(question,proposal,current_catalog,inventory):
            proposal={'source':'opensearch','clarification':
                'Le plan confond encore une source de journaux et un équipement. '
                'Précisez la source à compter ou le nom de l’équipement à rechercher ; aucune lecture exécutée.'}
        proposal = equipment_participants(proposal)
        try:proposal,log_exclusions=apply_log_exclusions(question,proposal,current_catalog,inventory)
        except ValueError as exc:
            proposal={'source':'opensearch','clarification':str(exc)};log_exclusions={}
        if proposal.get('source','opensearch')=='opensearch':proposal=apply_scope(proposal,confirmed_scope)
        if proposal.get('source', 'opensearch') == 'opensearch' and confirmed_period:
            # User dates win over both the original and any corrective proposal.
            proposal['time_range'] = dict(confirmed_period)
            hypotheses = proposal.get('hypotheses')
            if isinstance(hypotheses, list):
                proposal['hypotheses'] = [{**candidate, 'time_range': dict(confirmed_period)}
                                          if isinstance(candidate, dict) else candidate for candidate in hypotheses]
        proposal['_planner_metadata']={'configured_model':self.config.model,
            'returned_model':raw.get('model') if isinstance(raw.get('model'),str) else None}
        if log_exclusions:proposal['_planner_metadata']['log_exclusions']=log_exclusions
        if len(attempts)>1:proposal['_planner_metadata'].update(repair=repair_reason,attempts=attempts)
        return proposal

    def _request_proposal(self,payload):
        """One bounded transport call, also used by the single semantic repair."""
        request_bytes = len(json.dumps(payload, ensure_ascii=False).encode('utf-8'))
        if request_bytes > min(MAX_REQUEST_BYTES, self.settings.max_context_bytes):
            raise ValueError(f'Albert request_too_large : {request_bytes} octets dépassent max_context_bytes={self.settings.max_context_bytes} ; réduire le catalogue/périmètre ou calibrer le budget du modèle.')
        with albert_call(self.config.model) as span:
            end = time.monotonic() + 60
            response = None
            try:
                response = self.session.post(self.url + '/chat/completions', json=payload,
                    headers={'Accept-Encoding': 'identity'}, stream=True,
                    timeout=(10, 60), allow_redirects=False)
                record_albert_response(span, {}, status_code=response.status_code)
                if response.status_code != 200:
                    raise RuntimeError(f"Albert API indisponible : HTTP {response.status_code}")
                if response.headers.get('content-encoding', 'identity').strip().lower() not in ('', 'identity'):
                    raise ValueError('Albert unsupported_content_encoding')
                body = bytearray()
                for chunk in response.iter_content(chunk_size=65_536):
                    if time.monotonic() > end:
                        raise ValueError('Albert deadline_exceeded')
                    if len(body) + len(chunk) > MAX_RESPONSE_BYTES:
                        raise ValueError('Albert response_too_large')
                    body.extend(chunk)
                raw = json.loads(body)
                record_albert_response(span, raw, status_code=response.status_code)
                message=raw["choices"][0]["message"]
                if not isinstance(message,dict):raise ValueError('Albert invalid_response')
                if payload.get('tool_choice'):
                    calls=message.get('tool_calls')
                    if (not isinstance(calls,list) or len(calls)!=1 or not isinstance(calls[0],dict)
                            or calls[0].get('type')!='function' or not isinstance(calls[0].get('function'),dict)
                            or calls[0]['function'].get('name')!=IDENTITY_TOOL
                            or not isinstance(calls[0]['function'].get('arguments'),str)):
                        raise ValueError('Albert invalid_identity_tool_response')
                    proposal=_json_object(calls[0]['function']['arguments'])
                else:proposal = _json_object(message["content"])
            except (KeyError, IndexError, TypeError, json.JSONDecodeError, UnicodeError):
                raise ValueError('Albert invalid_response') from None
            except requests.Timeout:
                raise AlbertPlannerError('timeout') from None
            except requests.RequestException:
                raise AlbertPlannerError('unavailable') from None
            finally:
                if response is not None:
                    response.close()
        return proposal,raw


def validate_proposal(proposal: dict, inventory: dict, approved: list[dict]) -> tuple[dict | None, dict]:
    """Check a simple intent and return (active approval, enriched plan).

    Current approval overrides any mapping proposed by Albert. Without approval,
    a candidate still requires review even if it is physically valid. Check the
    index, mapping, aggregatability, and filter concepts, then apply managed aliases
    and defaults. ``compile_plan`` validates operators and the period later.
    Aggregate group_by accepts one concept string or a one-string list, normalized
    to that scalar before capability checks; multiple concepts remain unsupported.
    Do not perform any network reads.
    """
    if proposal.get("clarification"):
        return None, proposal
    index = proposal.get("index")
    entry = inventory.get("indices", {}).get(index)
    if not entry:
        raise ValueError("Albert a sélectionné un index absent de l'inventaire autorisé.")
    active = active_mapping(index, entry, approved)
    mapping = active["concepts"] if active else proposal.get("proposed_mapping")
    if not isinstance(mapping, dict) or "timestamp" not in mapping:
        raise ValueError("La proposition ne contient pas de mapping temporel exploitable.")
    validate_mapping(mapping, entry)
    # validate_mapping already checks type, searchability, and capability conflicts
    # for every field. Only aggregation adds a further requirement here.
    group = proposal.get("group_by")
    if proposal.get("operation") == "aggregate":
        if isinstance(group, list) and len(group) == 1 and isinstance(group[0], str):
            group = group[0]
        if not isinstance(group, str) or group not in mapping:
            raise ValueError("Le regroupement exige un seul concept approuvé, sous forme de chaîne ou de liste à un élément.")
        field = mapping[group]["field"]
        if not entry["fields"][field]["aggregatable"]:
            raise ValueError(f"Champ non agrégeable : {field}.")
    filters = proposal.get("filters", [])
    if not isinstance(filters, list) or len(filters) > 100:
        raise ValueError("Les filtres doivent être une liste de cent critères au plus.")
    aliases = active.get("business_aliases", {}) if active else {}
    checked_filters = []
    for criterion in filters:
        if not isinstance(criterion, dict) or set(criterion) - {"concept", "operator", "value"}:
            raise ValueError("Structure de filtre invalide ; aucun DSL libre n'est accepté.")
        concept = criterion.get("concept")
        target = aliases.get(concept)
        if isinstance(target, str) and target in mapping:
            criterion = {**criterion, "concept": target}
        if criterion.get("concept") not in mapping:
            raise ValueError("Un filtre utilise un concept non validé.")
        checked_filters.append(criterion)
    defaults = active.get("query_defaults", {}) if active else {}
    checked = {**proposal, "mapping": mapping, "filters": checked_filters}
    if proposal.get("operation") == "aggregate":
        checked["group_by"] = group
    checked.setdefault("limit", defaults.get("limit", 20))
    checked.setdefault("sort_order", defaults.get("sort_order", "desc"))
    return active, checked
