"""Compatibility exports for the shared, standard-library date parser."""
from dinum_albert.natural_dates import french_window, relative_window
