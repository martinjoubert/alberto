"""PDL runtime: Albert proposals, deterministic checks, and human review.

Importing this package does not start services. The admin_app and mcp_app
entry points construct their dependencies from the configuration.
"""

__version__ = "0.1.0"
