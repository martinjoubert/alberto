"""Explicit configuration of the OpenWebUI preset and MCP connection.

This script uses an existing administrator account; it neither creates accounts
nor runs Albert generation. Credentials stay in the authentication request
and are excluded from the public result.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import urllib.parse

import requests

from .openwebui_dialogue import FILTER_ID


SERVER_ID = "dinum-pdl-agent"
MODEL_ID = "albert-pdl-rie"
SYSTEM_PROMPT = """Tu es l'assistant PDL du RIE. Pour toute question sur les journaux ou l'état du PDL,
appelle une seule fois investigate_pdl avec la question fournie par le filtre de dialogue.
Si elle commence par PDL_DIALOGUE, elle contient la demande initiale et les précisions utilisateur
dans l'ordre : la dernière correction explicite remplace l'ancienne valeur, les autres critères restent valides.
Cet outil est ta seule source factuelle.
N'invente jamais d'index, de champ, de DSL, de résultat ou d'URL. Si status=success, restitue le résultat,
la route, le niveau de validation, les preuves, le DSL exact et ses limites. Si status=awaiting_human,
n'affiche aucun résultat métier : explique que le mapping doit être validé et fournis review_url.
Si status=needs_clarification, pose uniquement la question de clarification. Si status=error, restitue
l'erreur sans la masquer. Si status=partial, affiche l'état incomplet, les limites et les avertissements ;
ne conclus jamais à une absence de logs ou à un résultat exhaustif. Utilise uniquement les preuves
effectivement retournées. Pour un équipement, route désigne les participants, pas les index lus pour les logs.
Présente séparément evidence.log_indices (logs demandés), evidence.identity_indices (sources d'identité)
et evidence.resources avec leur phase. Un index exclu des logs ne doit pas être annoncé comme consulté pour ses logs.
Un identity_namespace est un espace logique, jamais un champ OpenSearch. Explique les rapprochements avec
les champs physiques du DSL réellement retourné pour chaque index ; ne reconstruis pas une clause commune fictive.
Distingue le total, le nombre de lignes affichées, la limite effective du plan et les plafonds du serveur.
Refuse toute écriture ou administration des sources. N'appelle aucun autre outil.
Pour les droits et index accessibles, appelle le même outil sans demander de période.
Restitue uniquement les autorisations du compte connecté retournées par le serveur ; n’invente aucun droit."""


class OpenWebUI:
    """Short-lived HTTP client for OpenWebUI administration, without Albert generation."""
    def __init__(self, base_url: str, verify: str | bool = True):
        """Prepare URL and session without inheriting environment proxies or credentials."""
        self.base_url, self.verify = base_url.rstrip('/'), verify
        self.session = requests.Session()
        self.session.trust_env = False

    def request(self, path: str, method='GET', token=None, payload=None):
        """Call a route with JSON and an optional Bearer token, without redirects.

        Return JSON or an empty dictionary; HTTP, network, and JSON errors remain
        visible. The token is never included in the script's public result.
        """
        headers = {'Authorization': f'Bearer {token}'} if token else {}
        response = self.session.request(method, self.base_url + path, headers=headers, json=payload,
                                        timeout=30, verify=self.verify, allow_redirects=False)
        if response.status_code >= 400:
            raise RuntimeError(f"OpenWebUI HTTP {response.status_code} sur {path}")
        return response.json() if response.content else {}


def configure(client: OpenWebUI, email: str, password: str, mcp_url: str, model='gpt-oss-120b') -> dict:
    """Verify the sole expected MCP tool, then create or update the PDL preset.

    Authenticate the existing account, retain other connections, and require a
    published model. Update OpenWebUI without generation or mapping approval.
    The sequence is not transactional: failure may follow a partial update.
    """
    token = client.request('/api/v1/auths/signin', 'POST', payload={'email': email, 'password': password})['token']
    connection = {
        'url': mcp_url, 'path': '', 'type': 'mcp', 'auth_type': 'none', 'headers': {}, 'key': '',
        'config': {'enable': True, 'access_grants': [], 'function_name_filter_list': 'investigate_pdl'},
        'info': {'id': SERVER_ID, 'name': 'Agent PDL RIE — lecture seule',
                 'description': 'Traduction contrôlée, preuves, DSL et revue humaine des mappings.'},
    }
    verified = client.request('/api/v1/configs/tool_servers/verify', 'POST', token, connection)
    tools = {item['name'] for item in verified.get('specs', [])}
    if tools != {'investigate_pdl'}:
        raise RuntimeError(f"Inventaire MCP inattendu : {sorted(tools)}")
    current = client.request('/api/v1/configs/tool_servers', token=token)
    connections = [item for item in current.get('TOOL_SERVER_CONNECTIONS') or []
                   if (item.get('info') or {}).get('id') != SERVER_ID]
    connections.append(connection)
    client.request('/api/v1/configs/tool_servers', 'POST', token, {'TOOL_SERVER_CONNECTIONS': connections})
    models = {item.get('id') for item in client.request('/api/models', token=token).get('data', [])}
    if model not in models:
        raise RuntimeError(f"Le modèle {model} n'est pas publié dans OpenWebUI.")
    # Install only this preset's filter; leave all unrelated functions untouched.
    guard = {'id': FILTER_ID, 'name': 'PDL RIE : dialogue de clarification',
             'content': Path(__file__).with_name('openwebui_dialogue.py').read_text(encoding='utf-8'),
             'meta': {'description': 'Reprise bornée des demandes après une clarification vérifiée.'}}
    try:
        existing_filter = client.request(f'/api/v1/functions/id/{FILTER_ID}', token=token)
    except RuntimeError as exc:
        if 'HTTP 404' not in str(exc):
            raise
        existing_filter = {}
    endpoint = f'/api/v1/functions/id/{FILTER_ID}/update' if existing_filter.get('id') == FILTER_ID \
               else '/api/v1/functions/create'
    saved_filter = client.request(endpoint, 'POST', token, guard)
    if saved_filter.get('id') != FILTER_ID:
        raise RuntimeError('Le filtre de dialogue PDL n’a pas été enregistré.')
    if not saved_filter.get('is_active'):
        client.request(f'/api/v1/functions/id/{FILTER_ID}/toggle', 'POST', token, {})
    query = urllib.parse.urlencode({'id': MODEL_ID})
    try:
        previous = client.request(f'/api/v1/models/model?{query}', token=token)
        endpoint = '/api/v1/models/model/update'
    except RuntimeError as exc:
        if 'HTTP 404' not in str(exc):
            raise
        previous, endpoint = {}, '/api/v1/models/create'
    previous_meta = previous.get('meta') or {}
    payload = {
        'id': MODEL_ID, 'base_model_id': model, 'name': 'Albert PDL RIE',
        'params': {**(previous.get('params') or {}), 'system': SYSTEM_PROMPT, 'function_calling': 'native', 'temperature': 0,
                   'tool_choice': 'auto'},
        'meta': {**previous_meta, 'description': 'Agent PDL adaptatif contrôlé par catalogue approuvé.',
                 'toolIds': [f'server:mcp:{SERVER_ID}'],
                 'capabilities': {**(previous_meta.get('capabilities') or {}), 'builtin_tools': False},
                 'filterIds': list(dict.fromkeys([*(previous_meta.get('filterIds') or []), FILTER_ID])),
                 'tags': [{'name': 'DINUM'}, {'name': 'PDL'}, {'name': 'RIE'}]},
        'access_grants': previous.get('access_grants') or [], 'is_active': True,
    }
    saved = client.request(endpoint, 'POST', token, payload)
    if saved.get('id') != MODEL_ID:
        raise RuntimeError("Le preset OpenWebUI n'a pas été enregistré.")
    return {'status': 'success', 'server_id': SERVER_ID, 'model_id': MODEL_ID,
            'filter_id': FILTER_ID, 'tools': sorted(tools)}


def main() -> None:
    """Read the password from a private file and run the requested configuration.

    Require --model or ALBERT_MODEL; print only public preset and server identifiers,
    never the password or session token.
    """
    parser = argparse.ArgumentParser(description='Configure OpenWebUI de façon idempotente.')
    parser.add_argument('--url', required=True)
    parser.add_argument('--email', required=True)
    parser.add_argument('--password-file', type=Path, required=True)
    parser.add_argument('--mcp-url', required=True)
    parser.add_argument('--ca-file')
    parser.add_argument('--model', default=os.getenv('ALBERT_MODEL'),
                        help='Identifiant du modèle publié dans OpenWebUI ; défaut : ALBERT_MODEL.')
    args = parser.parse_args()
    if not args.model:
        parser.error('--model ou ALBERT_MODEL est obligatoire.')
    result = configure(OpenWebUI(args.url, args.ca_file or True), args.email,
                       args.password_file.read_text(encoding='utf-8').strip(), args.mcp_url, model=args.model)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
