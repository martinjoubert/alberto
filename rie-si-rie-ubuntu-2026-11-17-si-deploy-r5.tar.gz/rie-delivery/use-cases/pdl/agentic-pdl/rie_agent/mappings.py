"""Use one mapping contract for proposals and their human review.

The physical type establishes what a field supports. Its role and namespace
express business meaning, which requires separate human approval.
"""
from __future__ import annotations

import re
from .identity_extractors import PARSERS


IDENTITY_ROLES = {"name", "fqdn", "ip", "id", "reference"}


def validate_mapping(mapping: dict, entry: dict) -> dict:
    """Check a concept -> field mapping against the current inventory.

    ``entry`` holds discovered physical capabilities. Return the mapping unchanged
    or raise ``ValueError`` for an incompatible field, type, ``_source`` parent,
    role, namespace, or extractor. Validation grants no approval and never infers
    that a traffic IP address identifies the equipment.
    """
    if not isinstance(mapping, dict) or not mapping or len(mapping) > 100:
        raise ValueError("Mapping vide, invalide ou trop volumineux.")
    if not isinstance(mapping.get("timestamp"), dict) or mapping["timestamp"].get("type") not in {"date", "date_nanos"}:
        raise ValueError("Le concept timestamp doit utiliser un champ temporel.")
    for concept, spec in mapping.items():
        if not isinstance(concept, str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,63}", concept):
            raise ValueError("Nom de concept invalide.")
        if not isinstance(spec, dict) or set(spec) - {"field", "type", "values", "source_field", "identity_role", "identity_namespace",
                                                       "identity_anchor", "identity_match", "identity_extractor"}:
            raise ValueError(f"Mapping invalide pour {concept}.")
        if not isinstance(spec.get('field'), str):
            raise ValueError(f"Champ physique invalide pour {concept}.")
        cap = entry.get("fields", {}).get(spec.get("field"))
        if (not cap or cap["type"] != spec.get("type") or not cap.get("searchable")
                or cap.get("types", [cap["type"]]) != [cap["type"]]):
            raise ValueError(f"Champ proposé incompatible : {concept}/{spec.get('field')}.")
        source_field = spec.get("source_field", spec["field"])
        # A .keyword multi-field can be searchable without existing in _source.
        # Its parent must then be declared explicitly to read the evidence.
        if not isinstance(source_field, str) or source_field not in entry.get("fields", {}) or (
                source_field != spec["field"] and not spec["field"].startswith(source_field + ".")):
            raise ValueError("Le champ _source doit correspondre au champ physique ou au parent de son multi-champ.")
        values = spec.get("values")
        if values is not None and (not isinstance(values, list) or not values or len(values) > 100
                                   or any(not isinstance(value, (str, int, float, bool)) for value in values)):
            raise ValueError(f"Valeurs métier invalides pour {concept}.")
        role, namespace = spec.get("identity_role"), spec.get("identity_namespace")
        extractor = spec.get('identity_extractor')
        # Raw text supports temporary compatibility, never an arbitrary parser.
        # Requiring text avoids extraction truncated by keyword ignore_above.
        if extractor is not None and (not isinstance(extractor, str) or extractor not in PARSERS or role != 'ip'
                                      or spec['type'] != 'text'):
            raise ValueError('Extraction IP textuelle incompatible ou parseur non enregistré.')
        if 'identity_anchor' in spec and (not isinstance(spec['identity_anchor'], bool)
                                          or not isinstance(role, str) or role not in {'name', 'fqdn'}):
            raise ValueError('Une ancre nominative doit être explicitement approuvée sur un nom ou FQDN.')
        if 'identity_match' in spec and (spec['identity_match'] != 'short_name_prefix' or role != 'fqdn'):
            raise ValueError('Le rapprochement par préfixe est réservé aux FQDN approuvés.')
        if role is not None or namespace is not None:
            if not isinstance(role, str) or role not in IDENTITY_ROLES or not isinstance(namespace, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", namespace):
                raise ValueError("Chaque relation d'identité exige un rôle et un espace de noms approuvés.")
            allowed_types = {'text'} if extractor else ({"ip"} if role == "ip" else {"keyword", "constant_keyword"})
            if spec["type"] not in allowed_types:
                raise ValueError(f"Type incompatible avec le rôle d'identité {role}.")
    return mapping


def active_mapping(index: str, entry: dict, approved: list[dict]) -> dict | None:
    """Find the unique active approval matching the current schema hash.

    An obsolete hash makes a mapping unusable. No match returns ``None``;
    two active approvals raise an error requiring review.
    """
    matching = [item for item in approved if item.get("active") and item["index"] == index
                and item["schema_hash"] == entry["schema_hash"]]
    if len(matching) > 1:
        raise ValueError("Plusieurs mappings actifs pour cet index ; revue nécessaire.")
    return matching[0] if matching else None
