"""Resume a bounded PDL request after a verified tool clarification.

OpenWebUI loads this file as a self-contained filter. The history is the only
conversation storage: no global state, provider-written intent, or old evidence
is carried into a new investigation. Helpers also serve the legacy PDL filter.
"""
import inspect
import json
import re
import unicodedata
from copy import deepcopy
from dataclasses import dataclass
from functools import wraps


DIALOGUE_PREFIX = 'PDL_DIALOGUE\n'
MAX_QUESTION = 2000
MAX_REPLIES = 12
FILTER_ID = 'pdl_rie_dialogue'
MODEL_ID = 'albert-pdl-rie'
TOOL_NAME = 'dinum-pdl-agent_investigate_pdl'
CAPTURE_KEY = '_pdl_rie_dialogue'


def normalized(text):
    """Normalize command spelling, without changing query values or their case."""
    return ''.join(c for c in unicodedata.normalize('NFKD', text.casefold())
                   if not unicodedata.combining(c)).strip()


def is_cancel(question):
    """Recognize an explicit cancellation; ordinary query negations are preserved."""
    return bool(re.fullmatch(r'(?:annule(?:\s+(?:la|cette|ma)\s+demande)?|annuler|cancel|stop)[.!?\s]*',
                             normalized(question)))


def is_reset(question):
    """Reset only on an explicit new task, not on corrections such as 'cherche plutôt'."""
    return bool(re.match(r'^(?:nouvelle\s+(?:demande|question|recherche)|'
                         r'(?:oublie|abandonne)\s+(?:la|cette|ma)\s+(?:demande|question)|'
                         r'(?:(?:tu peux|peux[- ]tu|vous pouvez|pouvez[- ]vous)\s+)?'
                         r'recommenc(?:e|er|ons|ez)\s+(?:a|de)\s+zero)\b', normalized(question)))


def is_retry(question):
    """Recognize an explicit replay without absorbing new filters or dates."""
    return bool(re.fullmatch(
        r'(?:(?:tu peux|peux[- ]tu|vous pouvez|pouvez[- ]vous)\s+)?'
        r'(?:reessai(?:e|es|er)|reessay(?:e|es|er)|relanc(?:e|er)|rejou(?:e|er)|'
        r'recommenc(?:e|er|ez)|refai(?:s|re|tes)|reexecut(?:e|er|ez)|'
        r'repren(?:ds|dre|ez|ons)|retent(?:e|er|ez|ons))'
        r'(?:\s+(?:(?:la|cette|ma|la meme|la derniere)\s+(?:demande|question|recherche|requete)|'
        r'a nouveau|encore|maintenant))?'
        r'(?:[,\s]+(?:stp|svp|s[’\']il (?:te|vous) plait))?[\s.!?]*', normalized(question)))


def unwrap_result(value, depth=0):
    """Decode MCP transport envelopes, never traverse evidence or document fields."""
    if depth > 5:
        return None
    if isinstance(value, str):
        try:
            return unwrap_result(json.loads(value), depth + 1)
        except (ValueError, TypeError):
            return None
    if isinstance(value, dict):
        if isinstance(value.get('status'), str) and 'route' in value:
            return value
        for key in ('content', 'text', 'structuredContent'):
            if key in value:
                result = unwrap_result(value[key], depth + 1)
                if result is not None:
                    return result
    if isinstance(value, list):
        for item in value:
            result = unwrap_result(item, depth + 1)
            if result is not None:
                return result
    return None


def current_result(output, tool_name):
    """Accept exactly one completed native call to the expected PDL tool."""
    if not isinstance(output, list):
        return None
    calls = [item.get('call_id') for item in output if isinstance(item, dict)
             and item.get('type') == 'function_call' and item.get('name') == tool_name
             and item.get('status') in ('completed','failed') and isinstance(item.get('call_id'), str)]
    if len(calls) != 1:
        return None
    results = [unwrap_result(item.get('output')) for item in output if isinstance(item, dict)
               and item.get('type') == 'function_call_output' and item.get('call_id') == calls[0]]
    if len(results)!=1:return None
    result=results[0]
    failed=next(item.get('status')=='failed' for item in output if item.get('type')=='function_call' and item.get('call_id')==calls[0])
    if failed and not (isinstance(result,dict) and result.get('assistant_contract')=='server-dialogue-v1'
            and isinstance(result.get('answer'),str) and result.get('status') in ('denied','error','needs_clarification','cancelled','rate_limited')
            and not any(result.get(k) for k in ('evidence','sources','metrics','events','logs','documents','results','indices','dsl'))):return None
    return result


def turn_result(messages, start, end, tool_name):
    """Read one completed tool result in a user turn, never assistant prose."""
    calls, results = {}, []
    for message in messages[start + 1:end]:
        if message.get('role') == 'assistant':
            output = message.get('output')
            if output:
                result = current_result(output, tool_name)
                if result is not None:
                    results.append(result)
            for call in message.get('tool_calls') or []:
                if isinstance(call, dict) and call.get('function', {}).get('name') == tool_name \
                        and isinstance(call.get('id'), str):
                    calls[call['id']] = True
        elif message.get('role') == 'tool' and message.get('tool_call_id') in calls:
            result = unwrap_result(message.get('content'))
            if result is not None:
                results.append(result)
    return results[0] if len(results) == 1 else None


def previous_continuation(messages, tool_name):
    """Resume the last verified turn of this UC, with a barrier at any own failed turn."""
    positions=[i for i,m in enumerate(messages) if m.get('role')=='user']
    for start,end in reversed(list(zip(positions,positions[1:]))):
        selected=any(c.get('name',c.get('function',{}).get('name'))==tool_name
                     for m in messages[start+1:end] if m.get('role')=='assistant'
                     for c in [*(m.get('output') or []),*(m.get('tool_calls') or [])]
                     if c.get('type')=='function_call' or isinstance(c.get('function'),dict))
        if not selected:continue
        result=turn_result(messages,start,end,tool_name)
        if result and result.get('assistant_contract')=='server-dialogue-v1':
            token=result.get('continuation_token')
            if isinstance(token,str) and re.fullmatch(r'[0-9a-f]{32}\.[0-9a-f]{32}',token):return token
        return ''
    return ''


def pending_result(messages, tool_name):
    """Resume only the preceding turn's verified clarification."""
    positions = [i for i, message in enumerate(messages) if message.get('role') == 'user']
    if len(positions) < 2:
        return None
    start, end = positions[-2:]
    result = turn_result(messages, start, end, tool_name)
    if result is None or result.get('status') != 'needs_clarification':
        return None
    if not isinstance(result.get('question'), str) or not result['question'].strip() \
            or len(result['question']) > MAX_QUESTION or not isinstance(result.get('clarification'), str):
        return None
    try:
        if question_turns(result['question'])[-1] != messages[start].get('content'):
            return None
    except ValueError:
        return None
    return result


def retry_question(messages, tool_name):
    """Replay user intent after a verified turn, never its old result or rights.

    Skip bounded consecutive retry turns, including retries that previously
    produced a missing-source clarification. Stop at cancellation, unrelated
    clients or missing tool receipts. The backend checks current access anew.
    """
    positions = [i for i, message in enumerate(messages) if message.get('role') == 'user']
    for offset in range(len(positions)-2, max(-1, len(positions)-MAX_REPLIES-3), -1):
        start, end = positions[offset:offset+2]
        raw = messages[start].get('content')
        if not isinstance(raw, str) or not raw.strip() or is_cancel(raw):
            return None
        result = turn_result(messages, start, end, tool_name)
        if result is None or result.get('status') not in {
                'denied', 'error', 'success', 'limited', 'needs_clarification', 'awaiting_human'}:
            return None
        if is_retry(raw):
            continue
        # Recompose any verified clarification replies, preserving corrections.
        return compose_question(messages[:end], tool_name)
    return None


def compose_question(messages, tool_name):
    """Join the original request and raw replies only after a verified clarification.

    A JSON envelope makes ordering explicit to the planner. Replies amend the
    request; they do not grant mapping approval or replace source authorization.
    Refuse overflow instead of silently dropping the initial query constraints.
    None denotes an explicit cancellation and requires no investigation.
    """
    users = [message for message in messages if message.get('role') == 'user']
    question = users[-1].get('content') if users else None
    if not isinstance(question, str) or not question.strip() or len(question) > MAX_QUESTION:
        raise ValueError('Question PDL absente ou trop longue ; formulez une demande de moins de 2000 caractères.')
    if is_cancel(question):
        return None
    if is_retry(question):
        return retry_question(messages, tool_name) or question
    pending = None if is_reset(question) else pending_result(messages, tool_name)
    if pending is None:
        return question
    previous = pending['question']
    state = {'request': previous, 'replies': []}
    if previous.startswith(DIALOGUE_PREFIX):
        try:
            state = json.loads(previous[len(DIALOGUE_PREFIX):])
        except ValueError as exc:
            raise ValueError('Demande en attente invalide ; commencez par « Nouvelle demande : … ».') from exc
        if not isinstance(state, dict) or not isinstance(state.get('request'), str) \
                or not isinstance(state.get('replies'), list) \
                or any(not isinstance(reply, str) for reply in state['replies']):
            raise ValueError('Demande en attente invalide ; commencez par « Nouvelle demande : … ».')
    replies = state['replies'] + [question]
    result = DIALOGUE_PREFIX + json.dumps({'request': state['request'], 'replies': replies,
                                         'clarification': pending['clarification']}, ensure_ascii=False)
    if len(replies) > MAX_REPLIES or len(result) > MAX_QUESTION:
        raise ValueError('La clarification dépasse les limites du dialogue. Reformulez une demande complète '
                         'en commençant par « Nouvelle demande : … ». Aucun traitement lancé.')
    return result


def question_turns(question):
    """Return bounded user turns for local validators, latest corrections last.

    A server clarification is deliberately excluded: it is a question, never a
    user-supplied equipment, period, family, or authorization.
    """
    if not isinstance(question, str) or not question.strip() or len(question) > MAX_QUESTION:
        raise ValueError('Question PDL invalide.')
    if not question.startswith(DIALOGUE_PREFIX):
        return [question]
    try:
        state = json.loads(question[len(DIALOGUE_PREFIX):])
    except ValueError as exc:
        raise ValueError('Demande en attente invalide.') from exc
    if not isinstance(state, dict) or not isinstance(state.get('request'), str) \
            or not isinstance(state.get('replies'), list) or len(state['replies']) > MAX_REPLIES \
            or any(not isinstance(reply, str) or not reply.strip() for reply in state['replies']):
        raise ValueError('Demande en attente invalide.')
    return [state['request']] + state['replies']


def source_turns(question):
    """Select current source intent while leaving all user turns available for dates.

    The server interpreter supplies a bounded turn index, not source names or
    permissions. Legacy envelopes retain their complete source context.
    """
    turns = question_turns(question)
    start = json.loads(question[len(DIALOGUE_PREFIX):]).get('source_start', 0) if question.startswith(DIALOGUE_PREFIX) else 0
    if type(start) is not int or not 0 <= start < len(turns):
        raise ValueError('Contexte des sources invalide ; aucune lecture exécutée.')
    return turns[start:]


def source_question(question):
    """Keep chronological turns for source-specific validators after a scope change."""
    turns = source_turns(question)
    if turns == question_turns(question):
        return question
    return DIALOGUE_PREFIX+json.dumps({'request': turns[0], 'replies': turns[1:]}, ensure_ascii=False)


def period_clarification(question):
    """Ask for an explicitly missing period/year before calling the provider.

    This is a conservative admission check, not a date parser. A relative
    window can be resolved normally. A named civil date needs its year from
    that turn or a later reply; an earlier date's year never fills a corrected
    day/month silently. Schema-only questions do not require a log period.
    """
    turns = question_turns(question)
    user_text = normalized('\n'.join(turns))
    if re.search(r'\b(?:mapping|schema|inventaire|catalogue|champs)\b', user_text) \
            and not re.search(r'\b(?:logs|journaux|evenements|connexions|acces|compte|nombre|cherche|recherche)\b', user_text):
        return None
    months = r'janvier|fevrier|mars|avril|mai|juin|juillet|aout|septembre|octobre|novembre|decembre'
    dated, missing_year, relative = False, False, False
    for turn in turns:
        text = normalized(turn)
        has_relative = bool(re.search(r'\b(?:hier|avant-hier|aujourd.hui|maintenant|cette\s+(?:annee|semaine|journee)|'
                                      r'(?:dernier\w*|precedent\w*)\s+(?:jour\w*|heure\w*|minute\w*|semaine\w*)|'
                                      r'(?:jour\w*|heure\w*|minute\w*|semaine\w*)\s+(?:dernier\w*|precedent\w*))\b|'
                                      r'\bdepuis\s+(?:\d+|un|une|deux|trois|quatre|cinq|six|sept|huit|neuf|dix|quinze|trente)\s*(?:minutes?|heures?|jours?|semaines?|min|h|j|d|w)\b|'
                                      r'\bnow(?:-\d+[smhdw])?\b', text)) or bool(re.fullmatch(r'(?:sur\s+)?\d+\s*(?:min|h|j|d|w)[.!?]?', text))
        french_dates = list(re.finditer(r'\b(?:[12]?\d|3[01])(?:er)?\s+(?:' + months + r')\b(?:\s+(\d{4}))?', text))
        numeric_dates = list(re.finditer(r'\b\d{4}-\d{2}-\d{2}(?:\b|(?=t))|'
                                        r'\b\d{1,2}[/.-]\d{1,2}[/.-]\d{4}\b', text))
        partial_numeric = bool(re.search(r'\b\d{1,2}/\d{1,2}\b(?!/\d)', text))
        if french_dates or numeric_dates or partial_numeric:
            dated, relative = True, False
            # All dates in this turn share an explicitly supplied year when a
            # range writes it only once, e.g. 'du 28 au 29 septembre 2026'.
            explicit_year = bool(re.search(r'\b(?:19|20)\d{2}\b', text))
            missing_year = not numeric_dates and not explicit_year and not has_relative
        elif has_relative:
            relative, missing_year = True, False
        elif dated and missing_year and re.match(r'^(?:en\s+|annee\s+)?(?:19|20)\d{2}\b', text):
            missing_year = False
    if missing_year:
        return 'Quelle année pour cette période ? Indiquez une date complète pour éviter toute supposition.'
    if not dated and not relative:
        return 'Sur quelle période souhaitez-vous consulter le PDL ? Indiquez une date complète ou une période relative explicite.'
    return None


@dataclass(frozen=True)
class CapturedDialogue:
    """An inlet-created object cannot be forged by JSON request metadata."""
    raw: str
    question: str | None


def protect_question(metadata, tool_name, question, continuation_token=''):
    """Enforce the captured question immediately before the native MCP callable."""
    tools = metadata.get('tools') or {}
    tool = tools.get(tool_name)
    if not isinstance(tool, dict) or tool.get('type') != 'mcp' or tool.get('direct') is not False:
        raise ValueError('Outil MCP PDL natif attendu absent ; aucun traitement lancé.')
    spec = tool.get('spec') or {}
    properties = (spec.get('parameters') or {}).get('properties') or {}
    portable = 'continuation_token' in properties
    expected = {'question', 'continuation_token'} if portable else {'question'}
    if spec.get('name') != tool_name or set(properties) != expected \
            or properties['question'].get('type') != 'string':
        raise ValueError('Signature de l’outil PDL inattendue ; aucun traitement lancé.')
    original = tool.get('callable')
    if not inspect.iscoroutinefunction(original):
        raise ValueError('Callable MCP PDL asynchrone attendu.')
    original = getattr(original, '_pdl_original_callable', original)

    @wraps(original, updated=())
    async def protected(**kwargs):
        if set(kwargs) - expected:
            raise ValueError('Arguments MCP PDL inattendus ; aucun traitement lancé.')
        return await original(question=question, **({'continuation_token': continuation_token} if portable else {}))

    protected._pdl_original_callable = original
    metadata['tools'] = {**tools, tool_name: {**tool, 'spec': deepcopy(spec), 'callable': protected}}


def set_visible_text(message, text):
    """Update both client renderings without changing native tool receipts."""
    message['content'] = text
    if isinstance(message.get('output'), list):
        message['output'] = [item for item in message['output']
                             if isinstance(item, dict) and item.get('type') != 'message'] + [
            {'type': 'message', 'role': 'assistant', 'status': 'completed',
             'content': [{'type': 'output_text', 'text': text}]}]


class Filter:
    """Capture the user request and safely resume a clarification in OpenWebUI."""
    async def inlet(self, body: dict, __model__: dict = None, __metadata__: dict = None, __request__=None) -> dict:
        if (__model__ or {}).get('id', body.get('model')) != MODEL_ID:
            return body
        if not isinstance(__metadata__, dict):
            raise ValueError('Métadonnées natives OpenWebUI requises.')
        if (__metadata__.get('params') or {}).get('function_calling') not in (None, 'native'):
            raise ValueError('Appels MCP natifs requis pour protéger le dialogue PDL.')
        users = [message for message in body.get('messages', []) if message.get('role') == 'user']
        raw = users[-1].get('content') if users else None
        capture = __metadata__.get(CAPTURE_KEY)
        if isinstance(capture, CapturedDialogue):
            if capture.raw != raw:
                raise ValueError('La question PDL capturée a changé pendant ce tour.')
        else:
            __metadata__[CAPTURE_KEY] = CapturedDialogue(raw, raw)
        body['tool_ids'] = ['server:mcp:dinum-pdl-agent']
        body['parallel_tool_calls'] = False
        if __request__ is not None:
            __request__.state.max_tool_call_iterations = 1
        return body

    async def request(self, body: dict, __model__: dict = None, __metadata__: dict = None) -> dict:
        if (__model__ or {}).get('id', body.get('model')) != MODEL_ID:
            return body
        capture = (__metadata__ or {}).get(CAPTURE_KEY)
        if not isinstance(capture, CapturedDialogue):
            raise ValueError('Question PDL non capturée ; aucun traitement lancé.')
        messages = body.get('messages', [])
        tool = ((__metadata__.get('tools') or {}).get(TOOL_NAME) or {})
        properties = ((tool.get('spec') or {}).get('parameters') or {}).get('properties') or {}
        portable = 'continuation_token' in properties
        if not portable:
            capture = CapturedDialogue(capture.raw, compose_question(messages, TOOL_NAME))
            __metadata__[CAPTURE_KEY] = capture
        if capture.question is None:
            # OpenWebUI's request hook precedes provider execution. The outlet
            # supplies the deterministic visible cancellation; no tool is run.
            body['messages'] = [{'role': 'user', 'content': 'Réponds uniquement OK.'}]
            body['tool_choice'], body['max_tokens'] = 'none', 1
            return body
        # Protected arguments apply even when OpenWebUI resumes an approved
        # saved call or has already received a result in this request cycle.
        protect_question(__metadata__, TOOL_NAME, capture.raw if portable else capture.question,
                         previous_continuation(messages, TOOL_NAME) if portable else '')
        last = max((i for i, message in enumerate(messages) if message.get('role') == 'user'), default=-1)
        current_messages = messages[last + 1:]
        result = next((current_result(message.get('output'), TOOL_NAME)
                       for message in current_messages if current_result(message.get('output'), TOOL_NAME)), None)
        if result is None:
            call_ids = {call.get('id') for message in current_messages
                        if message.get('role') == 'assistant' for call in message.get('tool_calls') or []
                        if isinstance(call, dict) and call.get('function', {}).get('name') == TOOL_NAME}
            role_tools = [unwrap_result(message.get('content')) for message in current_messages
                          if message.get('role') == 'tool' and message.get('tool_call_id') in call_ids]
            result = role_tools[0] if len(role_tools) == 1 else None
        if result and (result.get('assistant_contract')=='server-dialogue-v1' and isinstance(result.get('answer'),str)
                       or result.get('status')=='needs_clarification' and result.get('question')==capture.question):
            # The outlet renders the verified clarification. Do not spend a
            # second substantive model answer merely to repeat that question.
            body['messages'] = [{'role': 'user', 'content': 'Réponds uniquement OK.'}]
            body['tool_choice'], body['max_tokens'], body['tools'] = 'none', 1, []
            return body
        if any(message.get('role') == 'tool' or current_result(message.get('output'), TOOL_NAME)
               for message in current_messages):
            body['tool_choice'] = 'none'
            return body
        body['messages'] = [message for message in messages if message.get('role') == 'system'] + \
                           [{'role': 'system', 'content':
                             'À chaque tour, y compris une réponse courte ou PDL_DIALOGUE, appelle exactement une fois '
                             'investigate_pdl. Ne pose jamais toi-même une question et ne réponds jamais directement : '
                             'le serveur valide la demande et fournit la clarification éventuelle. Le filtre protège '
                             'la question utilisateur ; aucune reformulation de ta part ne peut la remplacer.'}] + \
                           [{'role': 'user', 'content': capture.question}]
        body['tool_choice'] = {'type': 'function', 'function': {'name': TOOL_NAME}}
        body['parallel_tool_calls']=False
        if portable:
            # Keep the MCP signature intact. Only the provider-facing copy is
            # empty: the protected callable already owns question and handle.
            body['tools']=deepcopy(body.get('tools',[]))
            for item in body['tools']:
                if item.get('type')=='function' and item.get('function',{}).get('name')==TOOL_NAME:
                    item['function']['description']='Exécuter une lecture déjà préparée par le serveur. Ne choisir ni source ni argument métier.'
                    item['function']['parameters']={'type':'object',
                        'properties':{'question':{'type':'string','enum':['']}},'required':['question'],'additionalProperties':False}
            body['messages']=[{'role':'system','content':
                f'Tu es un relais technique. Appelle exactement une fois la fonction de nom exact {TOOL_NAME}, sans abréger ni modifier ce nom, avec question vide. Ne rédige pas de réponse.'},
                {'role':'user','content':'Lancer l’appel de lecture préparé.'}]
        return body

    async def outlet(self, body: dict, __model__: dict = None, __metadata__: dict = None) -> dict:
        if (__model__ or {}).get('id', body.get('model')) != MODEL_ID:
            return body
        capture = (__metadata__ or {}).get(CAPTURE_KEY)
        if isinstance(capture, CapturedDialogue) and capture.question is None:
            for message in reversed(body.get('messages', [])):
                if message.get('role') == 'assistant':
                    set_visible_text(message, 'Demande annulée. Vous pouvez commencer une nouvelle investigation.')
                    break
        elif isinstance(capture, CapturedDialogue):
            for message in reversed(body.get('messages', [])):
                if message.get('role') != 'assistant':
                    continue
                result = current_result(message.get('output'), TOOL_NAME)
                text = None
                if result and result.get('assistant_contract') == 'server-dialogue-v1':
                    if result.get('status') == 'needs_clarification':
                        question = result.get('clarification') or result.get('answer')
                        text = question if isinstance(question, str) and question.strip() else (
                            'Le serveur n’a pas fourni de question de clarification exploitable. '
                            'Reformulez une demande complète.')
                    elif isinstance(result.get('answer'), str) and result['answer'].strip():
                        text = result['answer']
                elif result and result.get('status') == 'needs_clarification' \
                        and result.get('question') == capture.question \
                        and isinstance(result.get('clarification'), str):
                    # The planner has not executed a business query. Provider
                    # prose must not turn its clarification into invented facts.
                    text = result['clarification']
                elif result is None or result.get('question') != capture.question:
                    text = ('Le serveur n’a pas fourni de résultat PDL vérifiable. '
                            'Aucune preuve métier n’est publiée. Consultez le détail de l’appel '
                            'ou les journaux pour identifier l’erreur.')
                if text is not None:
                    set_visible_text(message, text)
                break
        return body
