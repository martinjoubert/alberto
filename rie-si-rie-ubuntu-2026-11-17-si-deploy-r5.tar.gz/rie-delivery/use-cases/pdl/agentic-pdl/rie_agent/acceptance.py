"""Deterministic PFS/BB/PFAING/TACACS acceptance using the real runtime, without Albert.

The test planner supplies a known intent, while the service keeps its normal
compilation, safety, search, and publication checks. This module neither seeds
documents nor approves mappings: the operator must review them first.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path

from .config import load_settings
from .service import RIEAgentService


FIXTURE_PATH = Path(__file__).with_name("fixtures") / "pdl_portable.json"


class ExplicitPlanner:
    """Planner double returning a known fixture intent without AI calls.

    Only the proposal is injected: the service's search and checks remain real.
    """
    def __init__(self, proposal: dict):
        """Retain the expected intent for the acceptance scenario."""
        self.proposal = proposal

    def propose(self, question, inventory, approved):
        """Return a deep copy of the plan to isolate each acceptance execution."""
        return deepcopy(self.proposal)


def scenarios(fixture: dict) -> list[dict]:
    """Describe six synthetic intents covering operations and selected index families.

    Expectations remain explicit and independent of runtime-compiled DSL.
    """
    period = fixture["proposal"]["time_range"]
    cases = [{"id": "equipment_cross_index", "question": fixture["question"], "proposal": fixture["proposal"]}]
    definitions = [("pfs_count", "rie-pfs-fixture", "count", None,
                    [{"concept": "action", "operator": "eq", "value": "deny"}]),
                   ("bb_aggregate", "rie-bb-fixture", "aggregate", "equipment", []),
                   ("pfaing_search", "rie-pfaing-fixture", "search", None,
                    [{"concept": "source_ip", "operator": "eq", "value": "192.0.2.25"}])]
    for name, index, operation, group, filters in definitions:
        cases.append({"id": name, "question": f"Recette synthétique {name} dans demo-alpha le 12 octobre 2026 de 08:00 à 09:00 UTC",
                      "proposal": {"source": "opensearch", "index": index, "operation": operation,
                                   "time_range": period, "filters": [*filters, {"concept": "network_scope", "operator": "eq", "value": "demo-alpha"}],
                                   "group_by": group, "limit": 20, "proposed_mapping": fixture["indices"][index]["concepts"]}})
    for name, families, selected in (
            ("equipment_tacacs_only", "uniquement TACACS", ["rie-tacacs-fixture"]),
            ("equipment_without_tacacs", "PFS BB PFAING sans TACACS",
             ["rie-pfs-fixture", "rie-bb-fixture", "rie-pfaing-fixture"])):
        proposal = deepcopy(fixture["proposal"])
        proposal["equipment_lookup"]["log_indices"] = selected
        cases.append({"id": name,
                      "question": f"Montre les logs de l'équipement edge-a {families} dans demo-alpha du 12 octobre 2026 de 08:00 à 09:00 UTC.",
                      "proposal": proposal})
    return cases


def run(service: RIEAgentService, fixture: dict) -> dict:
    """Run every intent through the supplied service and retain results and assertions.

    Replace its planner for acceptance; neither seed documents nor approve mappings,
    and never hide or force the business responses obtained.
    """
    results = []
    for case in scenarios(fixture):
        service.planner = ExplicitPlanner(case["proposal"])
        result = service.investigate(case["question"])
        checks = validate_result(case["id"], result)
        results.append({"scenario": case["id"], "result": result, "checks": checks,
                        "passed": all(check["passed"] for check in checks)})
    all_published = all(item["result"]["status"] == "success" for item in results)
    all_checks_passed = all(item["passed"] for item in results)
    return {"dataset": "fabricated_pfs_bb_pfaing_tacacs", "planner": "explicit_fixture_intents_no_albert",
            "human_approval_automatic": False, "results": results,
            "all_published": all_published, "all_checks_passed": all_checks_passed,
            "qualification_passed": all_published and all_checks_passed}


def validate_result(scenario: str, result: dict) -> list[dict]:
    """Compare produced evidence with the fixture's known documents and counts.

    Check family selection, scope, identity, and logs missing the initial identifier;
    assertions never alter the runtime result.
    """
    from .equipment import value_at

    checks = []

    def check(name, actual, expected):
        """Append an actual/expected comparison without stopping subsequent assertions."""
        checks.append({"name": name, "actual": actual, "expected": expected, "passed": actual == expected})

    check("published_success", result.get("status"), "success")
    evidence = result.get("evidence") or {}
    check("complete_for_query", evidence.get("complete_for_query"), True)
    rows = evidence.get("rows") or []
    if scenario in {"equipment_cross_index", "equipment_tacacs_only", "equipment_without_tacacs"}:
        # Fixed expectations: never derive them from rows returned by the code
        # under test, or a selection error could validate its own output.
        expected_ids = [["rie-pfs-fixture", "pfs-a-1"], ["rie-pfs-fixture", "pfs-a-2"],
                        ["rie-bb-fixture", "bb-a-1"], ["rie-pfaing-fixture", "pfaing-reference-only"],
                        ["rie-tacacs-fixture", "tacacs-ipv4-only"], ["rie-tacacs-fixture", "tacacs-ipv6-only"]]
        if scenario == "equipment_tacacs_only":
            expected_ids = expected_ids[-2:]
        elif scenario == "equipment_without_tacacs":
            expected_ids = expected_ids[:-2]
        expected_counts = {}
        for index, _ in expected_ids:
            expected_counts[index] = expected_counts.get(index, 0) + 1
        check("exact_total_documents", evidence.get("total"), len(expected_ids))
        check("exact_documents_from_selected_indices", sorted([[row.get("index"), row.get("document_id")] for row in rows]), sorted(expected_ids))
        check("index_counts", evidence.get("counts"), expected_counts)
        check("selected_log_indices", sorted(evidence.get("log_indices") or []), sorted(expected_counts))
        check("only_selected_indices_read_as_logs", sorted(resource.get("index") for resource in evidence.get("resources", [])
              if resource.get("phase") == "logs"), sorted(expected_counts))
        check("identity_source_indices", sorted(evidence.get("identity_indices") or []), ["rie-bb-fixture", "rie-pfs-fixture"])
        check("beta_scope_excluded", all(value_at(row.get("source", {}), "network.scope") == "demo-alpha" for row in rows), True)
        check("stable_id", (evidence.get("identity") or {}).get("stable_id"), ["asset-id", "asset-001"])
        identifiers = [list(token) for token in (evidence.get("identity") or {}).get("identifiers", [])]
        check("ipv4_and_ipv6_management_identity", all(["management-ip", address] in identifiers
              for address in ("10.20.0.1", "2001:db8::10")), True)
        if scenario != "equipment_tacacs_only":
            reference_only = next((row for row in rows if row.get("index") == "rie-pfaing-fixture"
                                   and row.get("document_id") == "pfaing-reference-only"), None)
            check("pfaing_reference_only_found", reference_only is not None, True)
            source = (reference_only or {}).get("source", {})
            check("pfaing_without_initial_name_or_id", reference_only is not None and all(value_at(source, field) is None
                  for field in ("observer.name", "observer.hostname", "host.name", "asset.id")), True)
            check("pfaing_reference", value_at(source, "gateway.ref"), "gateway-73")
        if scenario != "equipment_without_tacacs":
            tacacs = [row for row in rows if row.get("index") == "rie-tacacs-fixture"]
            check("tacacs_management_destinations", sorted((value_at(row.get("source", {}), "log.tacacs.dest")
                  for row in tacacs), key=str), ["10.20.0.1", "2001:db8::10"])
            check("tacacs_without_initial_name_or_id", len(tacacs) == 2 and all(value_at(row.get("source", {}), field) is None
                  for row in tacacs for field in ("observer.name", "observer.fqdn", "host.name", "asset.id")), True)
    elif scenario == "pfs_count":
        check("count_two_denials", evidence.get("total"), 2)
    elif scenario == "bb_aggregate":
        check("total_two_backbone_events", evidence.get("total"), 2)
        check("two_exact_groups", rows, [{"key": "edge-a", "count": 1}, {"key": "edge-b", "count": 1}])
    elif scenario == "pfaing_search":
        check("total_two_client_events", evidence.get("total"), 2)
        check("two_exact_search_documents", sorted(row.get("id", "") for row in rows), ["pfaing-reference-only", "pfaing-unrelated"])
    else:
        check("known_scenario", False, True)
    return checks


def main() -> None:
    """Load the fixture, run acceptance, and write or print a JSON report.

    Exit code 0 means qualification success; 2 means failure. Execution exceptions
    retain their traceback instead of becoming a fabricated result.
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    fixture = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    service = RIEAgentService(load_settings(args.config), planner=ExplicitPlanner(fixture["proposal"]))
    report = run(service, fixture)
    raw = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(raw + "\n", encoding="utf-8")
        print(str(args.output))
    else:
        print(raw)
    raise SystemExit(0 if report["qualification_passed"] else 2)


if __name__ == "__main__":
    main()
