"""Optional Zabbix and Grafana adapters restricted to approved read operations.

These connections are not part of the standard OpenSearch acceptance recipe.
Disabled sources and tools outside the allowlist are rejected before network calls.
"""

from __future__ import annotations

import asyncio
import json
import re
from typing import Any, Callable
from dinum_access import current_subject, AccessDenied, require_resources

from .config import SourceConfig
from .http import session_for, bounded_json


def _scoped_zabbix_params(method, params):
    """A host rule permits only bounded host metadata, never related objects."""
    if (method != 'host.get' or not isinstance(params, dict)
            or set(params) - {'hostids', 'output'}):
        raise AccessDenied('connector_authorization_unavailable')
    identifiers = params.get('hostids')
    if (not isinstance(identifiers, list) or not 1 <= len(identifiers) <= 50
            or any(not isinstance(value, str) or not re.fullmatch(r'[1-9][0-9]{0,19}', value)
                   for value in identifiers)):
        raise AccessDenied('connector_object_scope_required')
    output = params.get('output', ['hostid', 'host', 'name', 'status'])
    allowed = {'hostid', 'host', 'name', 'status'}
    if (not isinstance(output, list) or not output or len(output) > 4
            or any(not isinstance(field, str) or field not in allowed for field in output)):
        raise AccessDenied('connector_object_scope_required')
    identifiers = list(dict.fromkeys(identifiers))
    require_resources(['pdl.zabbix.host.'+value for value in identifiers])
    return {'hostids': identifiers, 'output': list(dict.fromkeys(['hostid', *output]))}


def _grafana_payload(value):
    """Decode one bounded MCP JSON payload, dropping protocol metadata entirely."""
    if hasattr(value, 'model_dump'):
        value = value.model_dump(mode='json')
    if len(json.dumps(value, ensure_ascii=True).encode()) > 2*1024*1024:
        raise ValueError('Réponse Grafana trop volumineuse.')
    if isinstance(value, dict) and value.get('isError'):
        raise RuntimeError('Grafana a rejeté la lecture.')
    if isinstance(value, dict) and 'structuredContent' in value and value['structuredContent'] is not None:
        value = value['structuredContent']
    elif isinstance(value, dict) and 'content' in value:
        content = value['content']
        if (not isinstance(content, list) or len(content) != 1 or not isinstance(content[0], dict)
                or content[0].get('type') != 'text' or not isinstance(content[0].get('text'), str)):
            raise ValueError('Contrat de réponse Grafana non pris en charge.')
        value = json.loads(content[0]['text'])
    return value


def _metadata(value, fields):
    if not isinstance(value, dict):
        raise ValueError('Métadonnées Grafana invalides.')
    result = {}
    for key in fields:
        item = value.get(key)
        if item is not None:
            if not (isinstance(item, str) and len(item) <= 20000 or type(item) is int and 0 <= item <= 1000000):
                raise ValueError('Métadonnées Grafana invalides.')
            result[key] = item
    return result


def _scoped_grafana_result(name, uid, value):
    """Project approved dashboard content; never return arbitrary datasource JSON."""
    value = _grafana_payload(value)
    if name == 'get_dashboard_summary':
        if not isinstance(value, dict) or value.get('uid') != uid:
            raise ValueError('Identité du tableau Grafana inattendue.')
        result = _metadata(value, ('uid', 'title', 'panelCount'))
        panels = value.get('panels', [])
        if not isinstance(panels, list) or len(panels) > 500:
            raise ValueError('Liste de panneaux Grafana invalide.')
        result['panels'] = [_metadata(panel, ('id', 'title', 'type', 'queryCount')) for panel in panels]
        return result
    # Only text expressions and datasource UID/type are dashboard metadata.
    # Raw targets, variables, URLs and provider-specific credential JSON are omitted.
    if not isinstance(value, list) or len(value) > 500:
        raise ValueError('Requêtes de panneaux Grafana invalides.')
    queries = []
    for panel in value:
        row = _metadata(panel, ('title', 'query', 'refId'))
        if panel.get('target') is not None:
            # Visual query builders need an adapter contract; no incomplete query is claimed.
            raise ValueError('Requête Grafana visuelle non prise en charge sous contrôle d’accès.')
        datasource = panel.get('datasource', {})
        row['datasource'] = _metadata(datasource, ('uid', 'type'))
        queries.append(row)
    return queries


class ZabbixReadOnlyAdapter:
    """Expose only the read-only Zabbix JSON-RPC methods listed in ALLOWED."""
    ALLOWED = {"host.get", "problem.get", "trigger.get", "item.get", "history.get"}

    def __init__(self, config: SourceConfig):
        """Retain settings and prepare the session without contacting the source."""
        self.config, self.session = config, session_for(config)

    def call(self, method: str, params: dict) -> dict:
        """Run an allowed JSON-RPC read with params and return result.

        Reject disabled sources and methods outside the allowlist; HTTP and JSON-RPC
        errors raise RuntimeError. Network and JSON exceptions remain visible.
        """
        if not self.config.enabled:
            raise RuntimeError("Zabbix est désactivé.")
        if method not in self.ALLOWED:
            raise ValueError("Méthode Zabbix interdite.")
        scoped = bool(current_subject())
        if scoped:
            params = _scoped_zabbix_params(method, params)
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        token = self.config.token
        if token:
            payload["auth"] = token
        response = self.session.post(self.config.url, json=payload, timeout=15, allow_redirects=False,
                                     **({"stream": True} if scoped else {}))
        if response.status_code != 200:
            response.close()
            raise RuntimeError(f"Zabbix indisponible : HTTP {response.status_code}")
        body = bounded_json(response, max_bytes=2*1024*1024) if scoped else response.json()
        if "error" in body:
            raise RuntimeError("Zabbix a rejeté la lecture.")
        result = body["result"]
        if scoped:
            if (not isinstance(result, list) or len(result) > len(params['hostids'])
                    or any(not isinstance(row, dict) or row.get('hostid') not in params['hostids'] for row in result)):
                raise ValueError('Périmètre de réponse Zabbix inattendu.')
            return [{field: row[field] for field in params['output'] if field in row} for row in result]
        return result


class GrafanaMCPReadOnlyAdapter:
    """Restrict Grafana MCP tools to an explicit subset of SAFE_TOOLS.

    The caller callback enables offline tests; otherwise call uses HTTP MCP.
    """
    SAFE_TOOLS = {"search_dashboards", "get_dashboard_summary", "get_dashboard_panel_queries",
                  "list_datasources", "check_datasources_health",
                  "generate_deeplink", "user_info"}

    def __init__(self, config: SourceConfig, caller: Callable[[str, dict], Any] | None = None):
        """Validate the configured allowlist and retain the injected client without network I/O."""
        self.config, self._caller = config, caller
        configured = set(config.allowed_tools or self.SAFE_TOOLS)
        if not configured <= self.SAFE_TOOLS:
            raise ValueError("La liste Grafana contient un outil non autorisé.")
        self.allowed = configured

    async def _mcp_call(self, name: str, arguments: dict):
        """Open a short-lived MCP session, call the tool, and close every client.

        Apply TLS, a 15-second timeout, and rejection of proxies and redirects;
        transport and protocol errors propagate to the calling service.
        """
        import httpx2
        from mcp import ClientSession
        from mcp.client.streamable_http import streamable_http_client
        token = self.config.token
        headers = {"Authorization": f"Bearer {token}"} if token else None
        tls = self.config.tls
        verify = tls.ca_file if tls.ca_file else tls.verify
        cert = ((tls.client_cert_file, tls.client_key_file) if tls.client_cert_file and tls.client_key_file
                else tls.client_cert_file)
        async with httpx2.AsyncClient(headers=headers, verify=verify, cert=cert, trust_env=False,
                                      timeout=15, follow_redirects=False) as client:
            async with streamable_http_client(self.config.url, http_client=client) as (read, write, _):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    return await session.call_tool(name, arguments)

    def call(self, name: str, arguments: dict) -> Any:
        """Reject disallowed tools, then return the injected or MCP result.

        The asyncio.run bridge is for the synchronous service, outside an active loop.
        """
        if not self.config.enabled:
            raise RuntimeError("Grafana est désactivé.")
        if name not in self.allowed:
            raise ValueError("Outil Grafana interdit.")
        scoped = bool(current_subject())
        if scoped:
            if name not in {'get_dashboard_summary', 'get_dashboard_panel_queries'}:
                raise AccessDenied('connector_authorization_unavailable')
            if (not isinstance(arguments, dict) or set(arguments) != {'uid'}
                    or not isinstance(arguments['uid'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,40}', arguments['uid'])):
                raise AccessDenied('connector_object_scope_required')
            require_resources(['pdl.grafana.dashboard.'+arguments['uid']])
        result = self._caller(name, arguments) if self._caller else asyncio.run(self._mcp_call(name, arguments))
        return _scoped_grafana_result(name, arguments['uid'], result) if scoped else result
