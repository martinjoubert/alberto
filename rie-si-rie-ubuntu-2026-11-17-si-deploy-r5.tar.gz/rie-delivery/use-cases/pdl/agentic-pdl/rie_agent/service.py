"""Coordinate investigations without delegating execution or approval to the model.

Albert proposes an intent. The service checks the inventory and catalog, performs
only authorized reads, and stores a local report. A candidate mapping creates a
human review; its results cannot become published evidence until that mapping
has been approved.
"""
from __future__ import annotations

import json
from dinum_access import access_information
from typing import Any

from .config import Settings, load_settings
from .adapters import GrafanaMCPReadOnlyAdapter, ZabbixReadOnlyAdapter
from .inventory import OpenSearchInventory, required_source_coverage
from .opensearch import ReadOnlyOpenSearch, compile_plan, summarize
from .planner import AlbertPlanner, validate_proposal
from .store import Store, now_iso
from .equipment import prepare_lookup, resolve_equipment
from .telemetry import operation


def render_result(result):
    """Render validated facts and the full bounded evidence, independently of provider prose."""
    from html import escape
    status=result.get('status')
    if status=='needs_clarification':return result.get('clarification') or 'Précisez la demande ; aucune nouvelle lecture métier.'
    if status=='awaiting_human':return 'Mapping à faire approuver avant publication de résultats.\n\n'+str(result.get('review_url') or '')
    if status not in ('success','partial'):return 'Le traitement n’a pas abouti. Aucun résultat métier vérifié n’est publié ; consultez les détails du contrôle.'
    plan=result.get('plan') or {};evidence=result.get('evidence') or {};lookup=plan.get('equipment_lookup') or {}
    if not isinstance(evidence,dict):evidence={'data':evidence}
    def cell(value):return escape(str(value)).replace('|','\\|').replace('\n',' ')
    def block(value):
        text=json.dumps(value,ensure_ascii=False,indent=2).replace('`','\\u0060').replace('<','\\u003c')
        return '\n```json\n'+text+'\n```\n'
    sources=result.get('route') or []
    if not isinstance(sources,list):sources=[sources]
    period=evidence.get('time_range') or lookup.get('time_range') or plan.get('time_range') or {}
    lines=['**Résultat PDL**','Lecture seule ; les observations ci-dessous correspondent à la requête exécutée.','',
           '**Sources** : '+', '.join(cell(v) for v in sources)]
    if period:lines+=['**Période** : '+cell(period.get('gte'))+' → '+cell(period.get('lt',period.get('lte')))+' ; borne de fin exclue.']
    if lookup.get('value'):lines+=['**Équipement** : '+cell(lookup['value'])]
    scope=lookup.get('scope')
    if scope:lines+=['**Périmètre** : '+cell(scope.get('value'))]
    filters=plan.get('filters',[])
    if filters:
        lines+=['','**Filtres exécutés**','','| Critère | Opérateur | Valeur |','| --- | --- | --- |']
        lines+=['| '+' | '.join(cell(f.get(k,'')) for k in ('concept','operator','value'))+' |' for f in filters]
    if 'total' in evidence:lines+=['','**Documents correspondant aux critères : '+cell(evidence['total'])+'**.']
    if evidence.get('counts'):
        lines+=['','| Source | Documents |','| --- | ---: |']
        lines+=['| '+cell(k)+' | '+cell(v)+' |' for k,v in evidence['counts'].items()]
    rows=evidence.get('rows') or []
    if rows:
        lines+=['','**Documents et preuves détaillées**']
        for row in rows:
            lines+=['Source : '+cell(row.get('index',plan.get('index','')))+' · document : '+cell(row.get('document_id',row.get('id',''))),block(row.get('source',row))]
    details={k:v for k,v in evidence.items() if k not in {'rows','resources','limits','time_range','total','counts'}}
    if details:lines+=['**Complétude et éléments de rapprochement**',block(details)]
    if plan.get('operation')=='count':
        lines+=['Le comptage porte sur les documents correspondant aux filtres ; la limite d’affichage des lignes ne borne pas ce comptage.']
    if status=='partial':lines+=['**Résultat partiel :** les limites signalées empêchent de conclure à une collecte complète.']
    lines+=['','**Limites d’affichage et de collecte**',block(result.get('limits') or evidence.get('limits') or {}),
            '**Requêtes de preuve exécutées**',block(result.get('dsl'))]
    model=(result.get('planner') or {}).get('returned_model')
    if model:lines+=['Planification Albert · modèle retourné : '+cell(model)+'.']
    return '\n'.join(lines)


class RIEAgentService:
    """Business entry point shared by HTTP and the single MCP investigation tool."""

    def __init__(self, settings: Settings | None = None, *, planner=None, inventory=None, search=None,
                 zabbix=None, grafana=None):
        """Assemble dependencies; injecting them supports tests without network access.

        Without injected arguments, load configuration, open private storage, and
        prepare the clients. Constructing the service does not run an investigation.
        """
        self.settings = settings or load_settings()
        self.store = Store(self.settings.data_dir)
        self.inventory_service = inventory or OpenSearchInventory(self.settings, self.store)
        self.search = search or ReadOnlyOpenSearch(self.settings)
        self.planner = planner or AlbertPlanner(self.settings)
        self.zabbix = zabbix or ZabbixReadOnlyAdapter(self.settings.zabbix)
        self.grafana = grafana or GrafanaMCPReadOnlyAdapter(self.settings.grafana)

    def health(self) -> dict:
        """Report that the service responds without calling external systems."""
        return {"status": "ok", "version": "0.1.0", "at": now_iso()}

    def readiness(self) -> tuple[dict, int]:
        """Separate process health, reviewed initialization and fresh source access.

        Read-only resolution runs in the caller's authorization context. A cached
        inventory cannot hide a source outage; no Albert generation is performed.
        """
        inventory = self.store.inventory()
        active = [item for item in self.store.catalog() if item.get('active')]
        initialized = bool(self.settings.allowed_index_patterns and inventory.get('indices') and active)
        body = {"status": "not_ready", "inventory_at": inventory.get("created_at"),
                "indices": len(inventory.get("indices", {})), "active_mappings": len(active)}
        if not initialized:
            return body, 503
        try:
            resolved = set(self.inventory_service.resolve_indices())
            coverage = required_source_coverage(self.settings, inventory, active, resolved)
            body['required_sources'] = coverage
            if not resolved or not all(item['ready'] for item in coverage):
                body['source'] = 'required_approved_index_missing'
                return body, 503
        except Exception:
            # A readiness response never exposes source URLs, policy details,
            # credentials or an exception that may contain a source response.
            return {"status": "sources_unavailable", "source": "unavailable_or_denied"}, 503
        body['status'] = 'ready'
        body['source'] = 'verified_read_only'
        return body, 200

    def _persist_report(self, report: dict, *, planner_metadata: dict | None = None) -> str:
        """Add model provenance, write the report, and return its local path.

        Enrich the supplied dictionary in place. Metadata contains model names,
        never client authentication settings.
        """
        report["planner"] = planner_metadata or {"kind": type(self.planner).__name__,
                                                 "configured_model": self.settings.albert.model,
                                                 "returned_model": None}
        report['answer']=render_result(report)
        name = now_iso().replace(":", "").replace("+00:00", "Z") + ".json"
        path = self.settings.data_dir / "reports" / name
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def investigate(self, question: str) -> dict[str, Any]:
        """Process a question and return its result, limits, evidence, and report.

        Dispatch in this order: clarification, enabled adapter, equipment lookup,
        mapping hypotheses, then a simple query. Model proposals remain untrusted
        until local validation. Errors become an explicit result and audit event;
        no automatic retry adds an Albert call or OpenSearch read.
        """
        question = question.strip()
        if not question or len(question) > 2000:
            return {"status": "error", "question": question, "route": None, "validation_level": "none",
                    "plan": None, "evidence": None, "dsl": None, "limits": {}, "review_url": None,
                    "report": None, "error": {"code": "invalid_question", "message": "Question vide ou trop longue."}}
        access = access_information(question)
        if access is not None:
            return access
        planner_metadata = {"kind": type(self.planner).__name__, "configured_model": self.settings.albert.model,
                            "returned_model": None}
        try:
            # Catalog entries are usable only with the current schema hash.
            inventory = self.inventory_service.ensure_fresh()
            approved = self.store.catalog()
            proposal = self.planner.propose(question, inventory, approved)
            planner_metadata.update(proposal.pop("_planner_metadata", {}))
            # Missing information stops every adapter, not only OpenSearch.
            # The proposed source may help phrase a question; it grants no read.
            if proposal.get("clarification"):
                clarification = proposal["clarification"]
                if not isinstance(clarification, str) or not clarification.strip() or len(clarification) > 1000:
                    raise ValueError("Question de clarification invalide.")
                result = {"status": "needs_clarification", "question": question, "route": None,
                          "clarification": clarification, "validation_level": "none",
                          "plan": None, "evidence": None, "dsl": None, "limits": {}, "review_url": None}
                result["report"] = self._persist_report(result, planner_metadata=planner_metadata)
                return result
            source = proposal.get("source", "opensearch")
            if source in {"zabbix", "grafana"}:
                # Each adapter has its own allowlist of read operations.
                if source == "zabbix" and not self.settings.zabbix.enabled:
                    raise ValueError("Source Zabbix non activée.")
                if source == "grafana" and not self.settings.grafana.enabled:
                    raise ValueError("Source Grafana non activée.")
                call = proposal.get("external_call") or {}
                evidence = (self.zabbix.call(call.get("name", ""), call.get("arguments") or {}) if source == "zabbix"
                            else self.grafana.call(call.get("name", ""), call.get("arguments") or {}))
                result = {"status": "success", "question": question, "route": source,
                          "validation_level": "adapter_allowlist", "plan": proposal, "evidence": evidence,
                          "dsl": None, "limits": {"source_enabled": True}, "review_url": None}
                result["report"] = self._persist_report(result, planner_metadata=planner_metadata)
                return result
            if source != "opensearch":
                raise ValueError("Source proposée inconnue ou non exposée.")
            if proposal.get("equipment_lookup"):
                # Preparation does not read logs: every relation must be approved
                # before resolving name -> anchor -> IP addresses/references.
                lookup, mappings, missing = prepare_lookup(proposal, inventory, approved, self.settings, question)
                if missing:
                    reviews = []
                    for index in missing:
                        review = self.store.create_review({
                            "kind": "equipment_mapping", "question": question, "index": index,
                            "schema_hash": inventory["indices"][index]["schema_hash"],
                            "proposed_mapping": mappings[index], "equipment_lookup": lookup,
                            "dsl_trials": [],
                        })
                        reviews.append(f"{self.settings.public_admin_url}/reviews/{review['id']}")
                    result = {"status": "awaiting_human", "question": question, "route": lookup["indices"],
                              "validation_level": "candidate", "plan": {"equipment_lookup": lookup},
                              "evidence": None, "dsl": None, "limits": {"result_not_published": True,
                              "identity_queries_executed": 0}, "review_url": reviews[0], "review_urls": reviews}
                else:
                    evidence = resolve_equipment(lookup, mappings, self.search, self.settings)
                    status = {"resolved": "success", "partial": "partial", "incomplete": "partial",
                              "not_found": "needs_clarification", "ambiguous": "needs_clarification"}[evidence["status"]]
                    result = {"status": status, "question": question, "route": lookup["indices"],
                              "validation_level": "human_approved", "plan": {"equipment_lookup": lookup},
                              "evidence": evidence, "dsl": evidence["resources"], "limits": evidence["limits"],
                              "review_url": None}
                    if status == "needs_clarification":
                        result["clarification"] = evidence["message"]
                result["report"] = self._persist_report(result, planner_metadata=planner_metadata)
                return result
            hypotheses = proposal.get("hypotheses") or []
            if hypotheses:
                # At most five trials may run, all against the same index.
                # Their summaries support review without publishing candidate results.
                if not isinstance(hypotheses, list) or len(hypotheses) > 5:
                    raise ValueError("Nombre d'hypothèses hors limite.")
                attempts, valid = [], []
                root = {key: value for key, value in proposal.items() if key != "hypotheses"}
                for position, hypothesis in enumerate(hypotheses, 1):
                    candidate = {**root, **hypothesis, "source": "opensearch"}
                    try:
                        with operation("rie.arguments.validate"):
                            active_candidate, checked = validate_proposal(candidate, inventory, approved)
                            if valid and checked["index"] != valid[0][1]["index"]:
                                raise ValueError("Une session de revue ne peut pas mélanger plusieurs index.")
                            dsl = compile_plan(checked, {"concepts": checked["mapping"]}, self.settings)
                        raw = self.search.search(checked["index"], dsl)
                        with operation("rie.results.normalize"):
                            summary = summarize(raw, checked["operation"])
                        attempt = {"position": position, "status": "valid", "confidence": hypothesis.get("confidence"),
                                   "dsl": dsl, "result_summary": summary}
                        attempts.append(attempt)
                        valid.append((active_candidate, checked, dsl, summary))
                    except Exception as exc:
                        attempts.append({"position": position, "status": "rejected", "confidence": hypothesis.get("confidence"),
                                         "error": {"type": type(exc).__name__, "message": str(exc)[:500]}})
                if not valid:
                    raise ValueError("Toutes les hypothèses de mapping ont été rejetées par les contrôles.")
                active, validated, body, evidence = valid[0]
                if not active:
                    candidates = [{"proposed_mapping": checked["mapping"],
                                   "plan": {key: value for key, value in checked.items() if key != "mapping"},
                                   "dsl": dsl, "result_summary": summary}
                                  for _, checked, dsl, summary in valid]
                    review = self.store.create_review({
                        "kind": "discovered_mapping", "question": question, "index": validated["index"],
                        "schema_hash": inventory["indices"][validated["index"]]["schema_hash"],
                        "proposed_mapping": validated["mapping"], "plan": candidates[0]["plan"],
                        "candidates": candidates, "dsl_trials": attempts,
                    })
                    result = {"status": "awaiting_human", "question": question, "route": validated["index"],
                              "validation_level": "candidate", "plan": review["plan"], "evidence": None,
                              "dsl": body, "limits": {"result_not_published": True, "hypotheses_tested": len(attempts)},
                              "review_url": f"{self.settings.public_admin_url}/reviews/{review['id']}"}
                    result["report"] = self._persist_report(result, planner_metadata=planner_metadata)
                    return result
                result = {"status": "partial" if evidence.get("timed_out") or evidence.get("failed_shards") else "success", "question": question, "route": validated["index"],
                          "validation_level": "human_approved", "plan": {key: value for key, value in validated.items() if key != "mapping"},
                          "evidence": evidence, "dsl": body, "limits": {"hypotheses_tested": len(attempts)}, "review_url": None}
                result["report"] = self._persist_report(result, planner_metadata=planner_metadata)
                return result
            with operation("rie.arguments.validate"):
                active, validated = validate_proposal(proposal, inventory, approved)
                # Clarification was already handled before the OpenSearch paths.
                body = compile_plan(validated, {"concepts": validated["mapping"]}, self.settings)
            raw = self.search.search(validated["index"], body)
            with operation("rie.results.normalize"):
                evidence = summarize(raw, validated["operation"])
            if not active:
                review = self.store.create_review({
                    "kind": "discovered_mapping", "question": question, "index": validated["index"],
                    "schema_hash": inventory["indices"][validated["index"]]["schema_hash"],
                    "proposed_mapping": validated["mapping"], "plan": {key: value for key, value in validated.items() if key != "mapping"},
                    "dsl_trials": [{"dsl": body, "result_summary": evidence}],
                })
                result = {"status": "awaiting_human", "question": question, "route": validated["index"],
                          "validation_level": "candidate", "plan": review["plan"], "evidence": None,
                          "dsl": body, "limits": {"result_not_published": True},
                          "review_url": f"{self.settings.public_admin_url}/reviews/{review['id']}"}
            else:
                result = {"status": "partial" if evidence.get("timed_out") or evidence.get("failed_shards") else "success", "question": question, "route": validated["index"],
                          "validation_level": "human_approved", "plan": {key: value for key, value in validated.items() if key != "mapping"},
                          "evidence": evidence, "dsl": body, "limits": {"max_rows": self.settings.max_rows,
                          "max_buckets": self.settings.max_buckets}, "review_url": None}
            result["report"] = self._persist_report(result, planner_metadata=planner_metadata)
            return result
        except Exception as exc:
            self.store.audit("investigation.error", {"code": "validation_failed" if isinstance(exc, ValueError) else "investigation_failed"})
            result = {"status": "error", "question": question, "route": None, "error": {
                "code": type(exc).__name__, "message": str(exc)[:500]}, "validation_level": "none",
                "plan": None, "evidence": None, "dsl": None, "limits": {}, "review_url": None}
            try:
                result["report"] = self._persist_report(result, planner_metadata=planner_metadata)
            except OSError:
                result["report"] = None
            return result
