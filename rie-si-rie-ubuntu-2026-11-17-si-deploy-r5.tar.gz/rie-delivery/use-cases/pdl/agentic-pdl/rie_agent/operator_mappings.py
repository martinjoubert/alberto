"""Load operator mappings as pending human reviews, never active approvals.

Profiles select physical indices in the current authorized inventory. Relations
assign a shared namespace to explicitly named identity concepts; field types
cannot establish their business meaning. No Albert or OpenSearch call is made.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import fnmatch
import hashlib
import json
import math
from pathlib import Path
import re
import sys

import yaml

from .equipment import is_anchor
from .mappings import validate_mapping
from .store import Store


MAX_BYTES = 1024 * 1024
LABEL = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")
INDEX = re.compile(r"[a-z0-9][a-z0-9._*-]{0,254}\Z")


class _Loader(yaml.SafeLoader):
    """Reject duplicate keys, aliases, excessive nesting, and oversized trees."""

    def __init__(self, stream):
        """Initialize bounded YAML composition without enabling unsafe constructors."""
        super().__init__(stream)
        self.depth = self.nodes = 0

    def compose_node(self, parent, index):
        """Count nodes before construction and reject every alias reference."""
        self.depth += 1
        self.nodes += 1
        if self.depth > 12 or self.nodes > 10000 or self.check_event(yaml.AliasEvent):
            raise ValueError("YAML aliases or excessive structure are not supported.")
        try:
            return super().compose_node(parent, index)
        finally:
            self.depth -= 1

    def construct_mapping(self, node, deep=False):
        """Require unique string keys, including keys inside concept definitions."""
        result = {}
        for key_node, value_node in node.value:
            key = self.construct_object(key_node, deep=True)
            if not isinstance(key, str) or key in result:
                raise ValueError("YAML mapping keys must be unique strings.")
            result[key] = self.construct_object(value_node, deep=True)
        return result


def _check_data(value):
    """Accept only finite JSON scalars and bounded strings in the YAML tree."""
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ValueError("Operator mapping keys must be strings.")
            _check_data(key)
            _check_data(item)
    elif isinstance(value, list):
        for item in value:
            _check_data(item)
    elif isinstance(value, str):
        if len(value) > 1024 or any(ord(char) < 32 for char in value):
            raise ValueError("Operator strings must be bounded single-line values.")
    elif value is not None and (type(value) not in {int, float, bool}
                               or isinstance(value, float) and not math.isfinite(value)):
        raise ValueError("Operator values must use JSON-compatible scalar types.")


def load_bytes(raw: bytes) -> tuple[dict, str]:
    """Parse at most one MiB of strict UTF-8 YAML and fingerprint its exact bytes.

    Parsing errors deliberately omit YAML excerpts, which could contain an
    operator's accidentally pasted credential. The document has no secret fields.
    """
    if not isinstance(raw, bytes) or not 1 <= len(raw) <= MAX_BYTES:
        raise ValueError("Operator file must contain between one byte and one MiB.")
    try:
        document = yaml.load(raw.decode("utf-8"), Loader=_Loader)
    except (UnicodeError, yaml.YAMLError, RecursionError) as error:
        raise ValueError("Operator file is not valid strict UTF-8 YAML.") from error
    _check_data(document)
    if not isinstance(document, dict):
        raise ValueError("Operator document must be a mapping.")
    return document, hashlib.sha256(raw).hexdigest()


def load_file(path: Path) -> tuple[dict, str]:
    """Read a bounded regular file; reject symlinks before parsing its bytes."""
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError("Operator file must be a regular file, not a symlink.")
    with path.open("rb") as handle:
        return load_bytes(handle.read(MAX_BYTES + 1))


def validate_document(document: dict, inventory: dict) -> list[dict]:
    """Expand explicit profiles and validate all mappings without writing state.

    Match only physical names from the saved authorized inventory, never aliases
    or undiscovered indices. Each identity concept belongs to exactly one
    relation; its namespace is injected here. One consistent anchor namespace
    is required when identity relations are declared. Return review proposals.
    """
    _check_data(document)
    if (not isinstance(document, dict) or set(document) != {"version", "indices", "relations"}
            or type(document["version"]) is not int or document["version"] != 1):
        raise ValueError("Operator document requires version: 1, indices and relations.")
    profiles, relations = document["indices"], document["relations"]
    if not isinstance(profiles, dict) or not 1 <= len(profiles) <= 20:
        raise ValueError("Declare between one and twenty index profiles.")
    if not isinstance(relations, dict) or len(relations) > 20:
        raise ValueError("Declare at most twenty identity relations.")
    if not isinstance(inventory, dict):
        raise ValueError("A current authorized inventory is required.")
    entries, patterns = inventory.get("indices", {}), inventory.get("allowed_patterns", [])
    if (not isinstance(entries, dict) or not 1 <= len(entries) <= 20
            or not isinstance(patterns, (list, tuple)) or not patterns
            or any(not isinstance(pattern, str) or not INDEX.fullmatch(pattern) or ".." in pattern
                   for pattern in patterns)):
        raise ValueError("A bounded authorized inventory is required before loading mappings.")
    mappings = {}
    for profile, definition in profiles.items():
        if (not LABEL.fullmatch(profile) or not isinstance(definition, dict)
                or set(definition) != {"match", "concepts"}):
            raise ValueError("Each index profile requires only match and concepts.")
        pattern, concepts = definition["match"], definition["concepts"]
        if (not isinstance(pattern, str) or not INDEX.fullmatch(pattern) or ".." in pattern
                or not isinstance(concepts, dict) or not 1 <= len(concepts) <= 100):
            raise ValueError("Index selector or concepts are invalid.")
        for spec in concepts.values():
            if not isinstance(spec, dict) or "identity_namespace" in spec:
                raise ValueError("Identity namespaces must be declared only in relations.")
        mappings[profile] = deepcopy(concepts)
    assigned = set()
    for namespace, members in relations.items():
        if not LABEL.fullmatch(namespace) or not isinstance(members, dict) or not members:
            raise ValueError("Each relation requires a valid namespace and profile members.")
        roles = set()
        for profile, concepts in members.items():
            if (profile not in mappings or not isinstance(concepts, list) or not concepts
                    or len(concepts) > 100 or any(not isinstance(name, str) for name in concepts)):
                raise ValueError("Relation references an unknown profile or invalid concept list.")
            for concept in concepts:
                key = (profile, concept)
                spec = mappings[profile].get(concept)
                if not spec or not isinstance(spec.get("identity_role"), str) or key in assigned:
                    raise ValueError("Relation references an unknown, non-identity or repeated concept.")
                assigned.add(key)
                spec["identity_namespace"] = namespace
                roles.add(spec["identity_role"])
        if len(roles) != 1:
            raise ValueError("One identity namespace must use one consistent normalization role.")
    anchors = set()
    proposals, selected = [], set()
    for profile, mapping in mappings.items():
        for spec in mapping.values():
            if spec.get("identity_role") and "identity_namespace" not in spec:
                raise ValueError("Every identity concept must be declared in a relation.")
            if is_anchor(spec):
                anchors.add(spec.get("identity_namespace"))
        names = sorted(name for name in entries
                       if fnmatch.fnmatchcase(name, profiles[profile]["match"])
                       and any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns))
        if not names:
            raise ValueError(f"No authorized physical index matches profile {profile}.")
        for index in names:
            entry = entries[index]
            if index in selected:
                raise ValueError("Index profiles overlap; each physical index requires one mapping.")
            if (not isinstance(entry, dict) or not isinstance(entry.get("schema_hash"), str)
                    or not re.fullmatch(r"[0-9a-f]{64}", entry["schema_hash"])):
                raise ValueError("Current inventory requires valid schema fingerprints.")
            validate_mapping(mapping, entry)
            selected.add(index)
            proposals.append({"index": index, "profile": profile,
                              "schema_hash": entry["schema_hash"], "proposed_mapping": deepcopy(mapping)})
    if relations and (len(anchors) != 1 or None in anchors):
        raise ValueError("Identity relations require exactly one shared anchor namespace.")
    return proposals


def stage_reviews(store: Store, document: dict, *, file_hash: str, author: str, reason: str,
                  skip_unchanged: bool = False) -> list[dict]:
    """Validate the entire file, then stage or reuse identical pending reviews.

    A lock serializes staging with catalog updates. Validation precedes every
    review write; I/O failures are not a multi-file transaction. Existing active
    approvals remain unchanged. Changed files or schema hashes require new reviews.
    """
    if (not isinstance(file_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", file_hash)
            or not isinstance(author, str) or not 1 <= len(author.strip()) <= 100
            or not isinstance(reason, str) or not 1 <= len(reason.strip()) <= 1000):
        raise ValueError("File fingerprint, explicit author and reason are required.")
    with store._lock():
        proposals = validate_document(document, store.inventory())
        pending = store.reviews()
        active = store.catalog() if skip_unchanged else []
        results = []
        for proposal in proposals:
            if any(row.get('active') and row.get('index') == proposal['index']
                   and row.get('schema_hash') == proposal['schema_hash']
                   and row.get('concepts') == proposal['proposed_mapping'] for row in active):
                continue
            provenance = {"sha256": file_hash, "profile": proposal["profile"],
                          "author": author.strip(), "reason": reason.strip()}
            value = {"kind": "operator_mapping", **proposal, "operator_file": provenance, "dsl_trials": []}
            previous = next((review for review in pending if review.get("status") == "pending"
                             and (all(review.get(key) == item for key, item in value.items())
                                  or (skip_unchanged and review.get('kind') == 'operator_mapping'
                                      and all(review.get(key) == proposal[key]
                                              for key in ('index', 'schema_hash', 'proposed_mapping'))))), None)
            review = previous or store.create_review(value)
            results.append({**review, "reused": previous is not None})
        return results


def main(argv=None):
    """Validate YAML from stdin or stage it as pending reviews using local config."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("validate", "load"))
    parser.add_argument("--author", default="")
    parser.add_argument("--reason", default="")
    args = parser.parse_args(argv)
    try:
        from .config import load_settings
        settings = load_settings()
        document, file_hash = load_bytes(sys.stdin.buffer.read(MAX_BYTES + 1))
        # Reading directly avoids creating data directories during validation.
        path = settings.data_dir / "inventory/latest.json"
        inventory = json.loads(path.read_text(encoding="utf-8"))
        inventory["allowed_patterns"] = list(settings.allowed_index_patterns)
        proposals = validate_document(document, inventory)
        # Keep CLI output bounded after wildcard expansion; full mappings stay in reviews.
        result = {"valid": True, "file_hash": file_hash, "approval_required": True,
                  "indices": [{key: item[key] for key in ("index", "profile", "schema_hash")} for item in proposals]}
        if args.operation == "load":
            store = Store(settings.data_dir)
            # Validate against both saved and currently configured authorization.
            if store.inventory().get("allowed_patterns") != inventory["allowed_patterns"]:
                raise ValueError("Refresh inventory after changing the authorized index scope.")
            reviews = stage_reviews(store, document, file_hash=file_hash, author=args.author, reason=args.reason)
            result["reviews"] = [{key: review[key] for key in ("id", "index", "status", "reused")} for review in reviews]
        print(json.dumps(result, ensure_ascii=False))
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(f"Operator mappings rejected: {type(error).__name__}.", file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
