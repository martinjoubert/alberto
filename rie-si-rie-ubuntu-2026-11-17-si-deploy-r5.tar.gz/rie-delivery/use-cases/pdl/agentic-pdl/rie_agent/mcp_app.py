"""Runtime MCP entry point: one business question and one controlled tool.

Configuration and service instances are constructed by the app factory. The service
decides whether to return evidence, a clarification, or a human review.
This transport accepts no free-form DSL and approves no mapping.
"""

from __future__ import annotations

from typing import Annotated, Any
from contextlib import asynccontextmanager
import time

from mcp.server.mcpserver import MCPServer
from pydantic import Field, ValidationError
from mcp.server.mcpserver.exceptions import ToolError
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
import uvicorn
from dinum_access import protect, guard_result, current_subject, access_information, AccessDenied
from dinum_albert.dialogue import Dialogue, Interpreter, StateStore
import ssl

from .config import load_settings, require_safe_bind
from .service import RIEAgentService
from .planner import independent_count, independent_equipment
from .telemetry import (agent_execution, record_result, configure_from_env, mcp_execution_middleware,
    observe_mcp_server, secure_mcp_diagnostics, process_diagnostics, diagnostic_scope, emit_diagnostic)


INSTRUCTIONS = """Serveur MCP de lecture du PDL. Un seul outil reçoit une question métier.
Il retourne le plan validé, les preuves, le DSL exact et le lien de revue. Un résultat awaiting_human
ne contient jamais de réponse métier publiable. Aucun index, champ ou DSL libre n'est accepté en entrée.
Un statut denied est un refus d'accès : afficher son message sans contourner la politique."""
INSTRUCTIONS += """ Transmettre le message courant complet et le dernier continuation_token retourné
dans cette conversation, vide pour une nouvelle demande. Le serveur interprète le dialogue,
conserve la demande et revérifie les droits ; le client ne recompose pas la question."""

def _create_dialogue(settings, service):
    """Build the ordinary dialogue, keeping configuration and disk I/O out of import."""
    tls = settings.albert.tls
    verification = ssl.create_default_context(cafile=tls.ca_file) if tls.ca_file else tls.verify
    if tls.client_cert_file:
        if verification is True:
            verification = ssl.create_default_context()
        verification.load_cert_chain(tls.client_cert_file, tls.client_key_file)
    interpreter=Interpreter(settings.albert.url,settings.albert.api_key,settings.albert.model,verify=verification,domain='pdl')
    def interpret(message,state):
        decision,usage=interpreter(message,state)
        if (state and state.get('kind','investigation')=='investigation'
                and decision.get('action') in ('follow_up','retry') and decision.get('confidence',0)>=.8):
            inventory,catalog=service.store.inventory(),service.store.catalog()
            reason=('independent_complete_count' if independent_count(message,inventory,catalog) else
                    'independent_complete_equipment' if independent_equipment(message,inventory,catalog) else None)
            if reason:
                decision={**decision,'action':'new','source_change':'unchanged'}
                usage={**usage,'context_resolution':{'action':'new','reason':reason}}
        return decision,usage
    return Dialogue(
        lambda question: guard_result(service.investigate(question)),
        interpret,
        StateStore(settings.data_dir / '.dialogue', 'pdl-rie-v1', current_subject),
        access=access_information,
    )


def create_app(settings=None, *, service=None, dialogue=None, allow_unauthenticated_fixture=False,
               diagnostic_logger=None):
    """Assemble the real MCP transport with injectable local business dependencies.

    Each app owns its server and closures. Tests can supply settings, an ordinary
    service with fake HTTP sessions, and a temporary dialogue without loading the
    workstation configuration. Authentication remains in ``protect``.
    """
    settings = settings or (service.settings if service is not None else load_settings())
    # The opt-out is an explicit trusted fixture-construction choice. It is not
    # read from an HTTP request, a model response or the observability metadata.
    if type(allow_unauthenticated_fixture) is not bool:
        raise ValueError('Le mode fixture doit être un booléen explicite.')
    if not allow_unauthenticated_fixture:
        require_safe_bind(settings.mcp_host)
    secure_mcp_diagnostics()
    if diagnostic_logger is None:
        diagnostic_logger = process_diagnostics()
    service = service if service is not None else RIEAgentService(settings)
    dialogue = dialogue if dialogue is not None else _create_dialogue(settings, service)
    execution_middleware = mcp_execution_middleware()
    class DiagnosticMCPServer(observe_mcp_server(MCPServer)):
        async def call_tool(self, name, arguments, context=None):
            with diagnostic_scope(diagnostic_logger):
                try:
                    return await super().call_tool(name, arguments, context)
                except ToolError as exc:
                    if isinstance(exc.__cause__, ValidationError):
                        emit_diagnostic(diagnostic_logger, 'rie.tool.validation_failed', code='tool_schema',
                                        error_type='ValidationError')
                    elif isinstance(exc.__cause__, AccessDenied):
                        emit_diagnostic(diagnostic_logger, 'rie.authorization.denied', code='access_denied',
                                        error_type='AccessDenied')
                    raise
    server = DiagnosticMCPServer(
        name="dinum-pdl-agent", title="Agent PDL RIE", description="Traduction contrôlée des questions PDL.",
        instructions=INSTRUCTIONS, version="0.1.0", log_level="INFO",
        middleware=[execution_middleware] if execution_middleware is not None else None,
    )

    @server.tool(name="investigate_pdl", title="Investiguer le PDL", structured_output=True,
                 description="Traduit une question métier, exécute uniquement des lectures approuvées et renvoie preuves et DSL.")
    def investigate_pdl(question: Annotated[str, Field(min_length=1, max_length=2000)],
                        continuation_token: Annotated[str, Field(max_length=65, description=
                            'Last server continuation_token in this conversation; empty for a new request.')] = '') -> dict[str, Any]:
        """Run one Python-owned agent cycle below the SDK's native MCP server span."""
        with diagnostic_scope(diagnostic_logger), agent_execution(agent_id="albert-pdl-rie", owner="python") as span:
            began = time.monotonic()
            outcome = 'failure'
            emit_diagnostic(diagnostic_logger, 'rie.execution.started', code='started')
            try:
                result = dialogue.run(question, continuation_token)
                record_result(span, result)
                status = result.get('status') if isinstance(result, dict) else None
                outcome = {'success': 'success', 'needs_clarification': 'success', 'awaiting_human': 'success',
                           'partial': 'partial', 'error': 'failure', 'denied': 'failure',
                           'cancelled': 'cancelled'}.get(status, 'unknown')
                if status == 'denied':
                    emit_diagnostic(diagnostic_logger, 'rie.authorization.denied', code='access_denied')
                return result
            finally:
                emit_diagnostic(diagnostic_logger, 'rie.execution.completed', code=outcome,
                                technical_status=outcome, duration_ms=(time.monotonic()-began)*1000)

    async def healthz(_: Request) -> JSONResponse:
        return JSONResponse(service.health())

    async def readyz(_: Request) -> JSONResponse:
        body, status = service.readiness()
        return JSONResponse(body, status_code=status)

    app = server.streamable_http_app(streamable_http_path="/mcp", json_response=True, stateless_http=True,
                                     max_request_body_size=16_384, max_sessions=50,
                                     session_idle_timeout=120, host=settings.mcp_host)
    app.routes.extend([Route("/healthz", healthz), Route("/readyz", readyz)])
    original_lifespan = app.router.lifespan_context
    @asynccontextmanager
    async def lifespan(application):
        async with original_lifespan(application):
            emit_diagnostic(diagnostic_logger, 'rie.application.started', code='startup')
            try:
                yield
            finally:
                emit_diagnostic(diagnostic_logger, 'rie.application.stopped', code='shutdown')
    app.router.lifespan_context = lifespan
    from dinum_access.oauth import install
    return install(protect(app, diagnostic_logger=diagnostic_logger), 'pdl')


def main() -> None:
    """Audit failed initial discovery, then start the Uvicorn transport.

    The service retains its availability checks for every investigation.
    """
    configure_from_env(service_name="rie-agent-mcp", component_type="mcp-server", service_version="0.1.0")
    settings = load_settings()
    require_safe_bind(settings.mcp_host)
    service = RIEAgentService(settings)
    try:
        service.inventory_service.refresh()
    except Exception:
        service.store.audit("startup.inventory_failed", {"code": "source_unavailable"})
    uvicorn.run(create_app(settings, service=service), host=settings.mcp_host, port=settings.mcp_port, log_level="info")


if __name__ == "__main__":
    main()
