"""NiceGUI interface for discovery, mapping corrections, and human approval.

The browser presents Store data; writes use its methods to retain versions and
audit events. Deployment restricts access to the local administration network;
this module does not implement application authentication.
"""

from __future__ import annotations

import json

from nicegui import app, ui

from .config import load_settings, require_safe_bind
from .inventory import OpenSearchInventory
from .opensearch import ReadOnlyOpenSearch, compile_plan, summarize
from .store import Store
from .mappings import validate_mapping


settings = load_settings()
store = Store(settings.data_dir)
inventory_service = OpenSearchInventory(settings, store)
search = ReadOnlyOpenSearch(settings)


def shell(title: str):
    """Build the shared header, links, and title for an administration page."""
    ui.colors(primary='#000091', secondary='#6a6af4', accent='#e1000f')
    with ui.header().classes('items-center'):
        ui.label('Agent PDL — administration RIE').classes('text-h6')
        ui.space()
        for label, path in [('Inventaire', '/'), ('Revues', '/reviews'), ('Catalogue', '/catalog'), ('Rapports', '/reports'), ('Audit', '/audit')]:
            ui.link(label, path).classes('text-white')
    ui.label(title).classes('text-h4 text-primary mt-6')
    ui.label("Interface réservée au réseau d'administration du RIE. Aucun secret n'est affiché.").classes('text-caption')


@app.get('/healthz')
def healthz():
    """Report that the admin process is alive, without guaranteeing source availability."""
    return {'status': 'ok', 'service': 'pdl-agent-admin'}


@ui.page('/')
def inventory_page():
    """Display physical fields, capabilities, bounded profiles, and inactive proposals."""
    shell('Inventaire OpenSearch')
    ui.label('Processus : périmètre autorisé → mapping / alias / field_caps → comparaison → correction humaine → revalidation → catalogue versionné → rejeu et preuves.').classes('text-body1')
    status = ui.label()

    def refresh():
        """Run audited discovery and reload the page; display any errors."""
        try:
            value = inventory_service.refresh()
            status.set_text(f"Inventaire rafraîchi : {len(value['indices'])} index autorisé(s).")
            ui.navigate.reload()
        except Exception as exc:
            ui.notify(str(exc), type='negative')

    ui.button('Rafraîchir maintenant', on_click=refresh, icon='refresh')
    inventory = store.inventory()
    ui.label(f"Dernier inventaire : {inventory.get('created_at', 'jamais')}")
    for index, entry in inventory.get('indices', {}).items():
        with ui.expansion(index, icon='storage').classes('w-full'):
            ui.label(f"Empreinte : {entry['schema_hash']}").classes('font-mono text-xs')
            ui.label(f"{len(entry['fields'])} champs — alias : {', '.join(entry.get('aliases', [])) or 'aucun'}")
            with ui.expansion('Mapping physique et capacités de tous les champs').classes('w-full'):
                rows = [{'champ': name, 'type': cap['type'], 'types': ', '.join(cap.get('types', [])),
                         'recherche': cap['searchable'], 'agrégation': cap['aggregatable']}
                        for name, cap in sorted(entry['fields'].items())]
                ui.table(columns=[{'name': key, 'label': key.title(), 'field': key}
                                  for key in ('champ', 'type', 'types', 'recherche', 'agrégation')], rows=rows).classes('w-full')
                ui.code(json.dumps(entry.get('physical_mapping', entry.get('mapping', {})), ensure_ascii=False, indent=2), language='json').classes('w-full')
            with ui.expansion('Valeurs profilées (échantillon borné, sens métier à confirmer)').classes('w-full'):
                ui.code(json.dumps(entry.get('bounded_values', {}), ensure_ascii=False, indent=2), language='json').classes('w-full')
            # Capture values as defaults so later clicks do not use the last index
            # visited by the loop that constructs the page.
            def create_manual(selected_index=index):
                """Open a manual review for the index captured by the rendering loop."""
                review = inventory_service.review_for_index(selected_index)
                ui.navigate.to(f"/reviews/{review['id']}")
            ui.button('Créer un mapping manuel', on_click=create_manual)
            for comparison in entry.get('template_comparisons', []):
                color = 'positive' if comparison['compatible'] else 'warning'
                with ui.card().classes('w-full'):
                    ui.label(f"Modèle initial : {comparison['title']}").classes(f'text-{color} font-bold')
                    rows = [{'concept': name, 'état': item['status'], 'champ': item.get('selected') or '—'}
                            for name, item in comparison['concepts'].items()]
                    ui.table(columns=[{'name': key, 'label': key.title(), 'field': key} for key in ('concept', 'état', 'champ')], rows=rows)
                    with ui.expansion('Candidats et contrôles de compatibilité').classes('w-full'):
                        ui.code(json.dumps(comparison, ensure_ascii=False, indent=2), language='json').classes('w-full')
                    def create_review(template_id=comparison['template_id'], selected_index=index):
                        """Create a review of the captured template and index without activating its mapping."""
                        review = inventory_service.review_for_template(template_id, selected_index)
                        ui.navigate.to(f"/reviews/{review['id']}")
                    ui.button('Créer une revue à compléter' if not comparison['compatible'] else 'Créer une revue (sans activer)', on_click=create_review)


@ui.page('/reviews')
def reviews_page():
    """List persisted reviews and provide navigation to their details."""
    shell('Sessions de revue')
    rows = [{'id': item['id'], 'type': item['kind'], 'index': item['index'], 'statut': item['status'],
             'créée': item['created_at']} for item in store.reviews()]
    table = ui.table(columns=[{'name': key, 'label': key.title(), 'field': key} for key in ('id', 'type', 'index', 'statut', 'créée')], rows=rows)
    table.on('rowClick', lambda event: ui.navigate.to(f"/reviews/{event.args[1]['id']}"))


@ui.page('/reviews/{review_id}')
def review_page(review_id: str):
    """Present a review and its correction, approval, or rejection controls.

    Decision buttons appear only for pending reviews; Store checks that state
    again at the time of writing.
    """
    shell(f'Revue {review_id}')
    try:
        review = store.review(review_id)
    except (KeyError, ValueError):
        ui.label('Revue introuvable.').classes('text-negative')
        return
    ui.label(f"Index : {review['index']} — état : {review['status']}")
    ui.label(f"Empreinte : {review['schema_hash']}").classes('font-mono text-xs')
    if review.get('question'):
        ui.label(review['question'])
    entry = store.inventory().get('indices', {}).get(review['index'], {})
    with ui.expansion('Champs disponibles et contrôles physiques').classes('w-full'):
        ui.code(json.dumps(entry.get('fields', {}), ensure_ascii=False, indent=2), language='json').classes('w-full')
    ui.label("Identité : identity_role=name|fqdn|ip|id|reference et identity_namespace explicite. Approuver uniquement les IP de gestion et les relations confirmées ; les types seuls ne prouvent pas le sens métier.").classes('text-body2')
    ui.label("Mapping proposé").classes('text-h6')
    if review.get('query_defaults') or review.get('business_aliases'):
        ui.label('Paramètres et alias métier proposés — à confirmer avec le mapping').classes('text-h6')
        ui.code(json.dumps({key: review[key] for key in ('query_defaults', 'business_aliases') if key in review},
                           ensure_ascii=False, indent=2), language='json').classes('w-full')
    mapping_editor = ui.textarea(value=json.dumps(review['proposed_mapping'], ensure_ascii=False, indent=2)).props('outlined autogrow').classes('w-full font-mono')
    if review.get('dsl_trials'):
        ui.label('Essais DSL en lecture seule').classes('text-h6')
        ui.code(json.dumps(review['dsl_trials'], ensure_ascii=False, indent=2), language='json').classes('w-full')
    if review['status'] == 'pending':
        reason = ui.input('Motif du rejet').classes('w-full')
        author = ui.input('Auteur de la validation', value='local-admin').classes('w-full')
        correction_reason = ui.input('Motif de la correction / approbation').classes('w-full')

        def validated_mapping():
            """Parse the edited JSON and validate it against current inventory fields.

            JSON and mapping errors propagate to the callback displaying a notification.
            """
            mapping = json.loads(mapping_editor.value)
            entry = store.inventory()['indices'][review['index']]
            return validate_mapping(mapping, entry)

        if len(review.get('candidates', [])) > 1:
            ui.label('Choisir une autre hypothèse testée').classes('text-h6')
            with ui.row():
                for position, candidate in enumerate(review['candidates'], 1):
                    def select_candidate(selected=candidate):
                        """Copy a tested hypothesis into the editor and persist its proposal and plan."""
                        mapping_editor.set_value(json.dumps(selected['proposed_mapping'], ensure_ascii=False, indent=2))
                        store.update_review(review_id, {'proposed_mapping': selected['proposed_mapping'],
                                                        'plan': selected['plan']})
                        ui.notify('Hypothèse sélectionnée ; vérifier puis approuver.', type='positive')
                    ui.button(f'Hypothèse {position}', on_click=select_candidate)

        def save_mapping():
            """Save a validated correction and its human metadata without approving it."""
            try:
                store.update_review(review_id, {'proposed_mapping': validated_mapping(),
                                               'corrected_by': author.value,
                                               'correction_reason': correction_reason.value})
                ui.notify('Mapping corrigé et enregistré.', type='positive')
            except Exception as exc:
                ui.notify(str(exc), type='negative')

        def approve():
            """Refresh the schema and revalidate any DSL before audited approval.

            Compilation and reads remain controlled; Store.approve rejects a fingerprint
            different from the reviewed one. Errors prevent approval.
            """
            try:
                mapping = validated_mapping()
                current = inventory_service.refresh()['indices'][review['index']]['schema_hash']
                updates = {'proposed_mapping': mapping}
                if review.get('plan'):
                    dsl = compile_plan(review['plan'], {'concepts': mapping}, settings)
                    result = summarize(search.search(review['index'], dsl), review['plan']['operation'])
                    updates['dsl_trials'] = [*review.get('dsl_trials', []), {'dsl': dsl, 'result_summary': result,
                                                                             'expert_revalidation': True}]
                store.update_review(review_id, updates)
                store.approve(review_id, current, author=author.value, reason=correction_reason.value)
                ui.notify('Mapping approuvé. Le rejeu peut maintenant publier un résultat.', type='positive')
                ui.navigate.reload()
            except Exception as exc:
                ui.notify(str(exc), type='negative')

        def reject():
            """Persist a human rejection and its reason, then reload the review."""
            store.reject(review_id, reason.value or 'Rejet expert')
            ui.navigate.reload()

        with ui.row():
            ui.button('Enregistrer la correction', on_click=save_mapping)
            ui.button('Approuver après revalidation', on_click=approve, color='positive')
            ui.button('Rejeter', on_click=reject, color='negative')


@ui.page('/catalog')
def catalog_page():
    """Display every mapping version, its status, and approval provenance."""
    shell('Catalogue approuvé')
    catalog = store.catalog()
    if not catalog:
        ui.label('Le catalogue actif est vide. C’est l’état initial attendu avant validation experte.')
    for entry in catalog:
        with ui.card().classes('w-full'):
            ui.label(f"{entry['id']} — {entry['index']}").classes('text-h6')
            ui.badge('actif' if entry.get('active') else 'invalidé', color='positive' if entry.get('active') else 'negative')
            ui.label(entry['schema_hash']).classes('font-mono text-xs')
            ui.label(f"Validation : {entry.get('approved_by', 'historique')} — {entry['approved_at']} — revue {entry['approved_from_review']}")
            ui.code(json.dumps(entry['concepts'], ensure_ascii=False, indent=2), language='json')


@ui.page('/reports')
def reports_page():
    """Present up to 100 recent reports with plans, DSL, evidence, and limits."""
    shell('Processus et preuves des investigations')
    ui.label('Chaque rapport conserve le plan, les DSL de chaque phase, les preuves, les limites et les liens de revue. Un mapping candidat ne publie pas de résultat métier.')
    paths = sorted((settings.data_dir / 'reports').glob('*.json'), reverse=True)[:100]
    if not paths:
        ui.label('Aucune investigation exécutée.')
    for path in paths:
        report = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(report, dict):
            report = {'content': report}
        if report.get('dataset') and isinstance(report.get('results'), list):
            dataset = {'fabricated_pfs_bb_pfaing': 'PFS / BB / PFAING',
                       'fabricated_pfs_bb_pfaing_tacacs': 'PFS / BB / PFAING / TACACS'}.get(report['dataset'], str(report['dataset']))
            qualification = ('qualification réussie' if report.get('qualification_passed') is True else
                             'qualification échouée' if report.get('qualification_passed') is False else
                             'qualification non renseignée')
            count = len(report['results'])
            title = f"Recette {dataset} — {qualification} — {count} scénario{'s' if count != 1 else ''}"
        else:
            title = f"{report.get('status') or 'Statut non renseigné'} — {report.get('question') or report.get('title') or 'Rapport d’investigation'}"
        with ui.expansion(f"{title} — {path.stem}").classes('w-full'):
            ui.code(json.dumps(report, ensure_ascii=False, indent=2), language='json').classes('w-full')


@ui.page('/audit')
def audit_page():
    """Display the latest 200 journal events without changing the journal."""
    shell('Journal d’audit')
    path = settings.data_dir / 'audit' / 'events.jsonl'
    records = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()] if path.exists() else []
    ui.code(json.dumps(records[-200:][::-1], ensure_ascii=False, indent=2), language='json').classes('w-full')


def main() -> None:
    """Refresh the inventory, then start the administration server.

    Audit startup discovery failure without preventing the interface from opening:
    the operator can inspect and correct source connectivity.
    """
    require_safe_bind(settings.admin_host, administration=True)
    try:
        inventory_service.refresh()
    except Exception:
        store.audit('startup.inventory_failed', {'code': 'source_unavailable'})
    ui.run(host=settings.admin_host, port=settings.admin_port, title='Agent PDL — administration', reload=False, show=False)


if __name__ in {'__main__', '__mp_main__'}:
    main()
