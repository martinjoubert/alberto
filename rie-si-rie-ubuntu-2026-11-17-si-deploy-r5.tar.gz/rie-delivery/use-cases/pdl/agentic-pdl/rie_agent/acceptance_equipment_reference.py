"""Optional comparison with the previous tools, without Albert calls.

This synthetic recipe checks explicitly approved transitional compatibility
with event.original. Structured fields remain the target; this module
neither seeds documents nor approves mappings.
"""

from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime
import json
import os
from pathlib import Path

from .acceptance import ExplicitPlanner
from .config import load_settings
from .equipment import value_at
from .service import RIEAgentService


FIXTURE_PATH = Path(__file__).with_name('fixtures') / 'equipment_reference.json'
BB = 'rie-bb-legacy-fixture'
TACACS = 'rie-tacacs-legacy-fixture'


def scenarios(fixture):
    """Describe two explicit intents: same-index BB, then TACACS in a separate index."""
    same = deepcopy(fixture['proposal'])
    same['equipment_lookup']['indices'] = [BB]
    same['equipment_lookup']['log_indices'] = [BB]
    same['proposed_mappings'] = {BB: deepcopy(fixture['indices'][BB]['concepts'])}
    return [
        {'id': 'legacy_same_index', 'question': 'Comparaison temporaire : logs BB et TACACS de edge-a dans demo-alpha du 12 octobre 2026 de 08:00 à 09:00 UTC.', 'proposal': same},
        {'id': 'legacy_cross_index_tacacs_only', 'question': fixture['question'], 'proposal': deepcopy(fixture['proposal'])},
    ]


def clauses(value, operation):
    """Traverse nested DSL and yield clauses for the requested operation.

    This evidence reader neither compiles nor changes the executed query.
    """
    if isinstance(value, dict):
        if operation in value and isinstance(value[operation], dict):
            yield value[operation]
        for child in value.values():
            yield from clauses(child, operation)
    elif isinstance(value, list):
        for child in value:
            yield from clauses(child, operation)


def validate_result(scenario, result):
    """Compare results and DSL against fixed transitional-compatibility expectations.

    Check the reviewed anchor, normalized IPs, nameless logs, and bounds of every read;
    these assertions never alter runtime evidence.
    """
    checks = []

    def check(name, actual, expected):
        """Record an independent assertion in the report to explain any failure."""
        checks.append({'name': name, 'actual': actual, 'expected': expected, 'passed': actual == expected})

    index = BB if scenario == 'legacy_same_index' else TACACS
    ids = ['legacy-tacacs-v4', 'legacy-tacacs-v6']
    if index == BB:
        ids.append('legacy-bb-origin')
    check('published_success', result.get('status'), 'success')
    evidence = result.get('evidence') or {}
    rows = evidence.get('rows') or []
    check('complete_for_query', evidence.get('complete_for_query'), True)
    check('exact_total', evidence.get('total'), len(ids))
    check('exact_ids_and_index', sorted([[row.get('index'), row.get('document_id')] for row in rows]),
          sorted([[index, name] for name in ids]))
    check('exact_counts', evidence.get('counts'), {index: len(ids)})
    check('selected_log_index', evidence.get('log_indices'), [index])
    check('identity_source_only_bb', evidence.get('identity_indices'), [BB])
    identity = evidence.get('identity') or {}
    check('reviewed_fqdn_anchor', identity.get('stable_id'), ['equipment-fqdn', 'edge-a.demo.invalid'])
    check('anchor_kind', identity.get('anchor_kind'), 'reviewed_name_or_fqdn')
    tokens = [list(token) for token in identity.get('identifiers', [])]
    check('normalized_origin_ipv4_ipv6', all(['tacacs-origin', address] in tokens
                                           for address in ('192.0.2.10', '2001:db8::10')), True)
    check('no_invented_asset_id', all(namespace != 'asset-id' for namespace, _ in tokens), True)
    check('bounded_scope', all(value_at(row.get('source', {}), 'network.scope') == 'demo-alpha' for row in rows), True)
    nameless = [row for row in rows if row.get('document_id') in ('legacy-tacacs-v4', 'legacy-tacacs-v6')]
    check('tacacs_without_name_id_or_raw_text', len(nameless) == 2 and all(
        value_at(row.get('source', {}), field) is None for row in nameless
        for field in ('observer.name', 'observer.fqdn', 'asset.id', 'event.original')), True)
    resources = evidence.get('resources') or []
    logs = [resource for resource in resources if resource.get('phase') == 'logs']
    check('logs_read_only_selected_index', [resource.get('index') for resource in logs], [index])
    seeds = [resource for resource in resources if resource.get('phase') == 'seed' and resource.get('index') == BB]
    seed_query = (seeds[0].get('dsl') or {}).get('query', {}) if seeds else {}
    check('case_insensitive_name_clause', any(term.get('observer.name.keyword') == {'value': 'edge-a', 'case_insensitive': True}
                                               for term in clauses(seed_query, 'term')), True)
    check('reviewed_short_fqdn_clause', any(term.get('observer.fqdn.keyword') == {'value': 'edge-a.*', 'case_insensitive': True}
                                           for term in clauses(seed_query, 'wildcard')), True)
    check('seed_requires_an_identity_match', any(body.get('minimum_should_match') == 1 for body in clauses(seed_query, 'bool')), True)
    log_query = (logs[0].get('dsl') or {}).get('query', {}) if logs else {}
    check('logs_query_uses_normalized_destinations', all(any(term.get('log.tacacs.dest') == address
          for term in clauses(log_query, 'term')) for address in ('192.0.2.10', '2001:db8::10')), True)
    check('no_term_query_on_raw_text', not any('event.original' in term for resource in resources
          for operation in ('term', 'terms', 'wildcard') for term in clauses(resource.get('dsl', {}), operation)), True)
    bounded = []
    for resource in resources:
        dsl = resource.get('dsl') or {}
        ranges = [item['@timestamp'] for item in clauses(dsl.get('query', {}), 'range') if '@timestamp' in item]
        scopes = [item.get('network.scope') for item in clauses(dsl.get('query', {}), 'term')]
        period_ok = bool(ranges) and all(set(period) == {'gte', 'lt'} and
            datetime.fromisoformat(period['gte'].replace('Z', '+00:00')) == datetime.fromisoformat('2026-10-12T08:00:00+00:00') and
            datetime.fromisoformat(period['lt'].replace('Z', '+00:00')) == datetime.fromisoformat('2026-10-12T09:00:00+00:00') for period in ranges)
        maximum = 20 if resource.get('phase') == 'logs' else 1000
        bounded.append(period_ok and 'demo-alpha' in scopes and 0 < dsl.get('size', 0) <= maximum
                       and dsl.get('sort') == [{'@timestamp': 'desc'}])
    check('all_proof_reads_time_scope_size_sort_bounded', bool(resources) and all(bounded), True)
    proofs = evidence.get('identity_proofs') or []
    check('origin_extraction_provenance', any(proof.get('index') == BB
          and proof.get('document_id') == 'legacy-bb-origin' and 'quoted_from_ip_v1' in proof.get('extractors', [])
          for proof in proofs), True)
    return checks


def run(service, fixture):
    """Replay both intents without Albert and report every assertion.

    The report explicitly distinguishes compatibility from the target architecture;
    the operator must have approved mappings beforehand.
    """
    results = []
    for case in scenarios(fixture):
        service.planner = ExplicitPlanner(case['proposal'])
        result = service.investigate(case['question'])
        checks = validate_result(case['id'], result)
        results.append({'scenario': case['id'], 'result': result, 'checks': checks,
                        'passed': all(item['passed'] for item in checks)})
    passed = all(item['passed'] for item in results)
    return {'dataset': 'fabricated_equipment_reference', 'mode': 'temporary_legacy_compatibility_opt_in',
            'target_architecture': False, 'target': 'structured_fields_without_event_original',
            'planner': 'explicit_fixture_intents_no_albert', 'human_approval_automatic': False,
            'results': results, 'qualification_passed': passed}


def main():
    """Restrict comparison to the dedicated synthetic demonstration source.

    Write or print the report; exit with 0 if qualified and 2 otherwise. Add no Albert
    call, document seeding, or automatic approval.
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    fixture = json.loads(FIXTURE_PATH.read_text())
    settings = load_settings(args.config)
    if os.environ.get('PDL_MODE') != 'demo' or settings.opensearch.url != 'http://opensearch:9200':
        raise RuntimeError('The legacy comparison is restricted to the dedicated synthetic demo source.')
    service = RIEAgentService(settings, planner=ExplicitPlanner(fixture['proposal']))
    report = run(service, fixture)
    raw = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(raw + '\n')
        print(str(args.output))
    else:
        print(raw)
    raise SystemExit(0 if report['qualification_passed'] else 2)


if __name__ == '__main__':
    main()
