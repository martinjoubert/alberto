"""Bounded OpenSearch schema discovery and preparation of human reviews.

YAML templates propose mappings between business concepts and physical fields.
Technical compatibility never constitutes business approval of a catalog entry.
"""

from __future__ import annotations

from datetime import datetime, timezone
import fnmatch
from pathlib import Path
import re
from typing import Any

import yaml
from dinum_access import authorize_path

from .config import Settings
from .http import session_for, bounded_json
from .store import Store, canonical_hash, now_iso


INDEX_RE = re.compile(r"[a-z0-9][a-z0-9._-]{0,254}")


def required_source_coverage(settings: Settings, inventory: dict, catalog: list[dict], resolved) -> list[dict]:
    """Check each required pattern against resolved, currently approved indices."""
    approved = {item['index'] for item in catalog if item.get('active') and item.get('schema_hash') and
                item['schema_hash'] == inventory.get('indices', {}).get(item.get('index'), {}).get('schema_hash')}
    available = set(resolved).intersection(approved)
    required = settings.required_index_patterns or settings.allowed_index_patterns
    return [{'pattern': pattern, 'ready': any(fnmatch.fnmatchcase(index, pattern) for index in available)}
            for pattern in required]


def flatten_mapping(properties: dict, prefix: str = "") -> dict[str, str]:
    """Flatten properties and multi-fields into dotted paths associated with their types.

    Retain object/nested paths: this describes the schema, without transforming
    documents or guaranteeing that scalar queries support a nested field.
    """
    fields: dict[str, str] = {}
    for name, spec in properties.items():
        path = prefix + name
        if "type" in spec:
            fields[path] = spec["type"]
        fields.update(flatten_mapping(spec.get("properties", {}), path + "."))
        for sub_name, sub_spec in spec.get("fields", {}).items():
            if "type" in sub_spec:
                fields[f"{path}.{sub_name}"] = sub_spec["type"]
    return fields


def load_templates(path: Path | None = None) -> list[dict]:
    """Load a supplied file or the bundled initial and reference profiles.

    Return inactive proposals; read no secret and contact no OpenSearch source.
    """
    paths = [path] if path else [Path(__file__).with_name("templates.yaml"), Path(__file__).with_name("reference_profiles.yaml")]
    return [template for source in paths
            for template in (yaml.safe_load(source.read_text(encoding="utf-8")) or {}).get("templates", [])]


def compare_template(template: dict, fields: dict[str, dict], index: str) -> dict:
    """Compare template candidates with observed field types and capabilities.

    An explicit preference or a single compatible candidate can be selected;
    ambiguity, absence, and incompatible types remain visible. active stays False.
    """
    concepts, compatible = {}, True
    for concept, spec in template["concepts"].items():
        matches = []
        for candidate in spec["candidates"]:
            cap = fields.get(candidate)
            if cap:
                matches.append({"field": candidate, "type": cap["type"], "searchable": cap["searchable"],
                                "aggregatable": cap["aggregatable"],
                                "compatible": cap["type"] in spec["types"] and cap.get("types", [cap["type"]]) == [cap["type"]]
                                and cap["searchable"] and cap["aggregatable"]})
        valid = [item for item in matches if item["compatible"]]
        preferred = spec.get("preferred")
        if preferred and any(item["field"] == preferred for item in valid):
            status, selected = "compatible", preferred
        elif len(valid) == 1:
            status, selected = "compatible", valid[0]["field"]
        elif len(valid) > 1:
            status, selected = "ambiguous", None
        elif matches:
            status, selected = "type_mismatch", None
        else:
            status, selected = "missing", None
        compatible &= status == "compatible"
        concepts[concept] = {"status": status, "selected": selected, "matches": matches,
                             "expected_types": spec["types"], **({"values": spec["values"]} if "values" in spec else {}),
                             **({"source_field": spec["source_field"]} if "source_field" in spec else {})}
    return {"template_id": template["id"], "title": template["title"], "index": index,
            "compatible": compatible, "concepts": concepts, "active": False,
            **({key: template[key] for key in ("query_defaults", "business_aliases") if key in template})}


class OpenSearchInventory:
    """Discover the allowed schema and prepare reviews without automatic approval."""
    def __init__(self, settings: Settings, store: Store):
        """Prepare clients and templates from shared settings without network discovery."""
        self.settings, self.store = settings, store
        self.source = settings.opensearch
        self.session = session_for(self.source)
        self.base_url = self.source.url.rstrip("/")
        self.templates = load_templates()

    def _request(self, method: str, path: str, **kwargs) -> Any:
        """Allow only resolution, mappings, capabilities, aliases, and _search profiling.

        A read request times out after 15 seconds; redirects, non-200 responses,
        and responses exceeding 2 MB are rejected before using the JSON.
        """
        allowed_get = method == "GET" and (path.startswith("/_resolve/index/") or re.fullmatch(
            r"/[a-z0-9][a-z0-9._-]{0,254}/_(mapping|field_caps|alias)", path))
        allowed_profile = method == "POST" and re.fullmatch(r"/[a-z0-9][a-z0-9._-]{0,254}/_search", path)
        if not (allowed_get or allowed_profile):
            raise ValueError("Endpoint de découverte interdit.")
        path = authorize_path(path, self.base_url, self.session, 15)
        response = self.session.request(method, self.base_url + path, timeout=15, allow_redirects=False, stream=True, **kwargs)
        if response.status_code != 200:
            response.close()
            raise RuntimeError(f"Découverte OpenSearch impossible : HTTP {response.status_code}")
        return bounded_json(response)

    def _profile(self, index: str, fields: dict[str, dict]) -> dict[str, list[dict]]:
        """Sample at most 20 values from each of the first 20 eligible fields.

        Keyword/IP aggregations aid review but prove neither business semantics
        nor completeness. A timeout or failed shard invalidates discovery.
        """
        selected = [name for name, cap in sorted(fields.items())
                    if cap["type"] in {"keyword", "ip"} and cap["aggregatable"]][:20]
        if not selected:
            return {}
        body = {"size": 0, "timeout": "5s", "aggs": {
            f"f{position}": {"terms": {"field": name, "size": 20, "shard_size": 40}}
            for position, name in enumerate(selected)}}
        raw = self._request("POST", f"/{index}/_search", json=body)
        if raw.get("timed_out") or raw.get("_shards", {}).get("failed"):
            raise ValueError("Profilage incomplet ; réessayer la découverte.")
        return {name: [{"value": bucket["key"], "count": bucket["doc_count"]}
                       for bucket in raw.get("aggregations", {}).get(f"f{position}", {}).get("buckets", [])]
                for position, name in enumerate(selected)}

    def _allowed(self, index: str) -> bool:
        """Check the physical name and its membership in the allowed index patterns."""
        return bool(INDEX_RE.fullmatch(index)) and any(fnmatch.fnmatchcase(index, pattern) for pattern in self.settings.allowed_index_patterns)

    def resolve_indices(self) -> list[str]:
        """Resolve patterns within the configured number of open physical indices.

        Aliases grant no additional access; an oversized scope raises ValueError
        so the operator must narrow it.
        """
        indices = set()
        for pattern in self.settings.allowed_index_patterns:
            result = self._request("GET", f"/_resolve/index/{pattern}", params={"expand_wildcards": "open"})
            indices.update(item["name"] for item in result.get("indices", []) if self._allowed(item["name"]))
        if len(indices) > self.settings.max_indices:
            raise ValueError(f"Découverte de {len(indices)} index : limite max_indices={self.settings.max_indices} dépassée ; réduire le périmètre ou ajuster la configuration.")
        return sorted(indices)

    @staticmethod
    def _caps(raw: dict, mapping: dict[str, str]) -> dict[str, dict]:
        """Combine physical mappings and field_caps without hiding type conflicts.

        A field is searchable/aggregatable only when all variants support the capability.
        """
        fields = {}
        for name, by_type in raw.get("fields", {}).items():
            kinds = sorted(by_type)
            fields[name] = {
                "type": mapping.get(name, kinds[0] if len(kinds) == 1 else "conflict"),
                "types": kinds,
                "searchable": all(bool(item.get("searchable")) for item in by_type.values()),
                "aggregatable": all(bool(item.get("aggregatable")) for item in by_type.values()),
            }
        return fields

    def refresh(self) -> dict:
        """Reload schemas, bounded profiles, and aliases, then persist the inventory.

        The fingerprint covers physical mappings and capabilities; changes or
        disappearance invalidate active catalog versions and create an audit event.
        Errors during collection stop the refresh before saving.
        """
        inventory = {"created_at": now_iso(), "allowed_patterns": list(self.settings.allowed_index_patterns), "indices": {}}
        for index in self.resolve_indices():
            mapping_raw = self._request("GET", f"/{index}/_mapping")
            entry = mapping_raw.get(index) or next(iter(mapping_raw.values()))
            mapping = flatten_mapping(entry.get("mappings", {}).get("properties", {}))
            caps_raw = self._request("GET", f"/{index}/_field_caps", params={"fields": "*"})
            aliases_raw = self._request("GET", f"/{index}/_alias")
            fields = self._caps(caps_raw, mapping)
            if len(fields) > self.settings.max_fields_per_index:
                raise ValueError(f"Index {index} : {len(fields)} champs dépassent max_fields_per_index={self.settings.max_fields_per_index} ; adapter la configuration.")
            # Physical mappings include settings that flattening does not retain
            # (e.g. ignore_above). They must also invalidate previous approval.
            fingerprint_payload = {"mapping": entry.get("mappings", {}), "field_caps": fields}
            comparisons = []
            for template in self.templates:
                if fnmatch.fnmatchcase(index, template["index_pattern_hint"]):
                    comparisons.append(compare_template(template, fields, index))
            inventory["indices"][index] = {
                "schema_hash": canonical_hash(fingerprint_payload), "mapping": mapping,
                "physical_mapping": entry.get("mappings", {}), "fields": fields,
                "aliases": sorted((aliases_raw.get(index) or {}).get("aliases", {})),
                "bounded_values": self._profile(index, fields), "template_comparisons": comparisons,
            }
        # Publish the snapshot, then add the record of invalidated versions.
        # These writes and the catalog update do not form a global transaction.
        self.store.save_inventory(inventory)
        hashes = {name: item["schema_hash"] for name, item in inventory["indices"].items()}
        inventory["invalidated_catalog_ids"] = self.store.invalidate(hashes)
        self.store.save_inventory(inventory)
        self.store.audit("inventory.refreshed", {"indices": sorted(inventory["indices"]), "invalidated": inventory["invalidated_catalog_ids"]})
        return inventory

    def stale(self) -> bool:
        """Report whether inventory is missing or older than refresh_seconds."""
        inventory = self.store.inventory()
        if not inventory.get("created_at"):
            return True
        created = datetime.fromisoformat(inventory["created_at"])
        return (datetime.now(timezone.utc) - created).total_seconds() >= self.settings.refresh_seconds

    def ensure_fresh(self) -> dict:
        """Return the current inventory, refreshing it only when stale.

        This can perform network reads and propagate discovery errors.
        """
        return self.refresh() if self.stale() else self.store.inventory()

    def review_for_template(self, template_id: str, index: str) -> dict:
        """Create a pending review from a template compared with an allowed index.

        Only selected fields are proposed; creation is persisted and audited,
        but no catalog version becomes active.
        """
        inventory = self.ensure_fresh()
        entry = inventory.get("indices", {}).get(index)
        if not entry:
            raise ValueError("Index absent de l'inventaire autorisé.")
        comparison = next((item for item in entry["template_comparisons"] if item["template_id"] == template_id), None)
        if not comparison:
            raise ValueError("Ce modèle initial ne correspond pas au motif de l'index.")
        proposed = {name: {"field": spec["selected"], "type": entry["fields"][spec["selected"]]["type"],
                           **({"values": spec["values"]} if "values" in spec else {}),
                           **({"source_field": spec["source_field"]} if "source_field" in spec else {})}
                    for name, spec in comparison["concepts"].items() if spec.get("selected")}
        return self.store.create_review({
            "kind": "initial_template", "template_id": template_id, "index": index,
            "schema_hash": entry["schema_hash"], "proposed_mapping": proposed,
            "comparison": comparison, "dsl_trials": [],
            **({key: comparison[key] for key in ("query_defaults", "business_aliases") if key in comparison}),
        })

    def review_for_index(self, index: str) -> dict:
        """Create a pending manual review for an index present in the inventory.

        Prefill timestamp only when exactly one searchable date field exists;
        the operator must decide the meaning of the remaining fields.
        """
        entry = self.ensure_fresh().get("indices", {}).get(index)
        if not entry:
            raise ValueError("Index absent de l'inventaire autorisé.")
        temporal = [name for name, cap in entry["fields"].items()
                    if cap["type"] in {"date", "date_nanos"} and cap["searchable"]]
        mapping = {"timestamp": {"field": temporal[0], "type": entry["fields"][temporal[0]]["type"]}} if len(temporal) == 1 else {}
        return self.store.create_review({"kind": "manual_mapping", "index": index,
                                        "schema_hash": entry["schema_hash"], "proposed_mapping": mapping,
                                        "dsl_trials": []})
