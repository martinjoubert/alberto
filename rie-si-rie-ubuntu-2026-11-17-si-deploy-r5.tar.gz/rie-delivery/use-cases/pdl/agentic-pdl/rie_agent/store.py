"""JSON persistence for inventory, reviews, the catalog, and audit events.

Document writes atomically replace a file; a lock protects concurrent catalog
updates. This is not a transactional database: audit events and documents
remain separate files.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import secrets
import tempfile
import os
import time
import re
from typing import Any
from contextlib import contextmanager

from .documents import canonical_hash


def now_iso() -> str:
    """Return an explicit UTC timestamp for documents and audit events."""
    return datetime.now(timezone.utc).isoformat()


def approval_state_hash(review: dict, catalog: list[dict]) -> str:
    """Bind a human decision to its review and the version shown for that index."""
    return canonical_hash({'review': review, 'active_catalog': [
        entry for entry in catalog if entry.get('active') and entry.get('index') == review.get('index')]})


class Store:
    """Manage business documents, mapping versions, and their audit journal.

    Deployment protects root and its permissions. Review identifiers are
    validated here before they become file paths.
    """
    def __init__(self, root: Path):
        """Create business subdirectories in the supplied volume without loading secrets."""
        self.root = root
        for name in ("inventory", "reviews", "reports", "catalog", "audit"):
            (root / name).mkdir(parents=True, exist_ok=True)

    def _write(self, path: Path, value: Any) -> None:
        """Write JSON to a neighboring temporary file, then atomically replace the target.

        Renaming prevents partially read JSON; it provides neither a multi-file
        transaction nor an fsync guarantee against abrupt power loss.
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            temp = Path(handle.name)
        temp.replace(path)

    def _read(self, path: Path, default: Any) -> Any:
        """Read JSON or return default if absent; malformed JSON remains an error."""
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default

    @contextmanager
    def _lock(self):
        """Serialize catalog updates using a shared lock directory.

        Wait up to 10 seconds, recover a lock older than 60 seconds, and release
        it on exit. This simple mechanism targets the deployment's local volume.
        """
        lock = self.root / ".write-lock"
        deadline = time.monotonic() + 10
        while True:
            try:
                os.mkdir(lock)
                break
            except FileExistsError:
                try:
                    if time.time() - lock.stat().st_mtime > 60:
                        os.rmdir(lock)
                        continue
                except (FileNotFoundError, OSError):
                    pass
                if time.monotonic() >= deadline:
                    raise RuntimeError("Le stockage partagé est verrouillé.")
                time.sleep(0.05)
        try:
            yield
        finally:
            os.rmdir(lock)

    def audit(self, event: str, details: dict[str, Any]) -> None:
        """Append a projected UTC event to the local, unsigned security journal.

        Free-form messages/reasons and business index names stay in their business
        documents, never the journal. No log collector is implied by this append.
        """
        allowed_events = {"review.created", "review.updated", "mapping.approved", "mapping.rejected",
                          "mapping.invalidated", "inventory.refreshed", "investigation.error", "startup.inventory_failed"}
        safe_event = event if isinstance(event, str) and event in allowed_events else "diagnostic.unknown"
        details = details if isinstance(details, dict) else {}
        clean = {}
        review_id = details.get("review_id")
        if isinstance(review_id, str) and re.fullmatch(r"[0-9]{8}T[0-9]{6}Z-[0-9a-f]{8}", review_id):
            clean["review_id"] = review_id
        schema_hash = details.get("schema_hash")
        if isinstance(schema_hash, str) and re.fullmatch(r"[0-9a-f]{64}", schema_hash):
            clean["schema_hash"] = schema_hash
        allowed_errors = {"RuntimeError", "ValueError", "TypeError", "KeyError", "OSError", "TimeoutError",
                          "ReadTimeout", "ConnectTimeout", "HTTPError", "HTTPStatusError", "AlbertError"}
        if "type" in details:
            error = details["type"]
            clean["type"] = error if isinstance(error, str) and error in allowed_errors else "unknown_error"
        allowed_codes = {"timeout", "unavailable", "invalid_key", "forbidden", "rate_limited", "http_error",
                         "invalid_response", "inventory_error", "investigation_error", "access_denied",
                         "validation_failed", "investigation_failed", "source_unavailable"}
        code = details.get("code")
        if isinstance(code, str) and code in allowed_codes:
            clean["code"] = code
        for source, target in (("indices", "index_count"), ("invalidated", "invalidated_count"),
                               ("catalog_ids", "catalog_count")):
            value = details.get(source)
            if isinstance(value, list):
                clean[target] = min(len(value), 1_000_000)
        fields = details.get("fields")
        if isinstance(fields, list):
            allowed_fields = {"proposed_mapping", "plan", "dsl_trials", "candidates", "correction_reason", "corrected_by"}
            clean["fields"] = sorted({value for value in fields if isinstance(value, str) and value in allowed_fields})
        record = {"at": now_iso(), "event": safe_event, "details": clean,
                  "schema_version": "1.0.0", "channel": "security_audit" if safe_event.startswith(("review.", "mapping.")) else "diagnostic"}
        with (self.root / "audit" / "events.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    def save_inventory(self, value: dict) -> None:
        """Atomically replace the latest inventory snapshot."""
        self._write(self.root / "inventory" / "latest.json", value)

    def inventory(self) -> dict:
        """Return the latest inventory, or an empty dictionary before discovery."""
        return self._read(self.root / "inventory" / "latest.json", {})

    def create_review(self, value: dict) -> dict:
        """Assign a unique identifier, persist a pending review, and audit its creation.

        Force its initial state and timestamp; the proposal gains no publication rights.
        """
        review_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(4)
        value = {**value, "id": review_id, "status": "pending", "created_at": now_iso()}
        self._write(self.root / "reviews" / f"{review_id}.json", value)
        self.audit("review.created", {"review_id": review_id, "schema_hash": value.get("schema_hash")})
        return value

    def reviews(self) -> list[dict]:
        """List reviews from newest to oldest without changing their states."""
        return sorted((self._read(path, {}) for path in (self.root / "reviews").glob("*.json")),
                      key=lambda item: item.get("created_at", ""), reverse=True)

    def review(self, review_id: str) -> dict:
        """Load an identified review; reject unsafe or missing identifiers.

        An invalid identifier raises ValueError; a missing review raises KeyError.
        """
        if not review_id.replace("-", "").isalnum():
            raise ValueError("Identifiant de revue invalide.")
        value = self._read(self.root / "reviews" / f"{review_id}.json", None)
        if value is None:
            raise KeyError(review_id)
        return value

    def update_review(self, review_id: str, updates: dict) -> dict:
        """Correct only allowed fields in a review that is still pending.

        Persist the correction and audit changed field names; decision, identity,
        and fingerprint metadata cannot be changed through this entry point.
        """
        if set(updates) - {"proposed_mapping", "plan", "dsl_trials", "candidates", "correction_reason", "corrected_by"}:
            raise ValueError("Modification de métadonnées de revue interdite.")
        review = self.review(review_id)
        if review["status"] != "pending":
            raise ValueError("Cette revue a déjà été traitée.")
        review.update(updates)
        review["updated_at"] = now_iso()
        self._write(self.root / "reviews" / f"{review_id}.json", review)
        self.audit("review.updated", {"review_id": review_id, "fields": sorted(updates)})
        return review

    def catalog(self) -> list[dict]:
        """Return all approved versions, active and historical, or an empty list."""
        return self._read(self.root / "catalog" / "approved.json", [])

    def approve(self, review_id: str, current_hash: str, *, author: str = "local-admin", reason: str = "",
                expected_state_hash: str | None = None) -> dict:
        """Approve a pending review after checking its fingerprint and current mapping.

        Under the lock, create an active version and deactivate previous versions
        for that index. Retain the author and review; inconsistencies raise ValueError.
        Append the approval audit event after writing the documents.
        """
        with self._lock():
            review = self.review(review_id)
            if review["status"] != "pending":
                raise ValueError("Cette revue a déjà été traitée.")
            catalog = self.catalog()
            if expected_state_hash is not None and expected_state_hash != approval_state_hash(review, catalog):
                raise ValueError("La revue ou la version active a changé : relire avant d’approuver.")
            if review["schema_hash"] != current_hash:
                raise ValueError("Le schéma a changé : rafraîchir et recommencer la revue.")
            if not isinstance(author, str) or not author.strip() or len(author) > 100:
                raise ValueError("Auteur de la validation requis (100 caractères maximum).")
            from .mappings import validate_mapping
            inventory_entry = self.inventory().get("indices", {}).get(review["index"])
            if not inventory_entry or inventory_entry["schema_hash"] != current_hash:
                raise ValueError("Approbation impossible sans inventaire courant compatible.")
            validate_mapping(review["proposed_mapping"], inventory_entry)
            # The physical index is the stable key; a correction creates a new
            # version and retains the previous one to explain historical evidence.
            catalog_key = review["index"]
            version = 1 + max((int(item.get("version", 0)) for item in catalog
                               if item.get("catalog_key", item.get("id")) == catalog_key), default=0)
            for previous in catalog:
                if previous.get("index") == review["index"] and previous.get("active"):
                    previous["active"] = False
                    previous["superseded_at"] = now_iso()
            entry = {
                "id": f"{catalog_key}:v{version}", "catalog_key": catalog_key, "version": version,
                "index": review["index"], "schema_hash": current_hash,
                "concepts": review["proposed_mapping"], "approved_at": now_iso(),
                "approved_from_review": review_id, "approved_by": author.strip(),
                "approval_reason": reason[:1000], "active": True,
                **({key: review[key] for key in ("query_defaults", "business_aliases") if key in review}),
            }
            catalog.append(entry)
            self._write(self.root / "catalog" / "approved.json", catalog)
            review["status"], review["decided_at"] = "approved", now_iso()
            self._write(self.root / "reviews" / f"{review_id}.json", review)
        self.audit("mapping.approved", {"review_id": review_id, "catalog_id": entry["id"], "schema_hash": current_hash})
        return entry

    def reject(self, review_id: str, reason: str) -> None:
        """Persist a pending review's rejection and bounded reason, then audit it.

        Reject previously decided reviews; do not change catalog versions.
        """
        review = self.review(review_id)
        if review["status"] != "pending":
            raise ValueError("Cette revue a déjà été traitée.")
        review.update(status="rejected", decided_at=now_iso(), decision_reason=reason[:1000])
        self._write(self.root / "reviews" / f"{review_id}.json", review)
        self.audit("mapping.rejected", {"review_id": review_id, "reason": reason[:1000]})

    def invalidate(self, hashes: dict[str, str]) -> list[str]:
        """Deactivate versions under the lock when their schema changes or disappears.

        Return their identifiers and audit invalidation; retain historical versions
        and require a new review before reactivation.
        """
        with self._lock():
            catalog, invalidated = self.catalog(), []
            for entry in catalog:
                if entry.get("active") and hashes.get(entry["index"]) != entry["schema_hash"]:
                    entry["active"] = False
                    entry["invalidated_at"] = now_iso()
                    entry["invalidated_reason"] = "schema_changed"
                    invalidated.append(entry["id"])
            if invalidated:
                self._write(self.root / "catalog" / "approved.json", catalog)
        if invalidated:
            self.audit("mapping.invalidated", {"catalog_ids": invalidated})
        return invalidated
