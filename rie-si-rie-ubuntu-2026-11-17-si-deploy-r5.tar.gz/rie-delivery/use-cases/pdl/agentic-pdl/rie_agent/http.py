"""HTTP sessions for sources, using configured TLS and credentials.

Clients ignore proxy and credential settings inherited from the environment.
Each caller must also disable redirects on its requests.
"""

from __future__ import annotations

import requests
import json

from .config import SourceConfig, TLSConfig


def bounded_json(response, *, max_bytes: int = 2_000_000):
    """Decode a streamed JSON response within a decompressed byte bound.

    Callers must request ``stream=True``. A single requests chunk is at most
    64 KiB; oversized bodies are rejected before being accumulated or decoded.
    The response is closed on success, overflow, malformed JSON and read errors.
    """
    payload = bytearray()
    try:
        for chunk in response.iter_content(chunk_size=65_536):
            if not isinstance(chunk, bytes):
                raise ValueError("Réponse HTTP JSON invalide.")
            if len(payload) + len(chunk) > max_bytes:
                raise ValueError("Réponse HTTP JSON supérieure à la limite.")
            payload.extend(chunk)
        return json.loads(payload)
    finally:
        response.close()


def session_for(config: SourceConfig | TLSConfig, *, bearer: str | None = None) -> requests.Session:
    """Create a TLS session without environment inheritance or network calls.

    An enabled source adds Basic, Bearer, and/or X-Api-Key from its files; bearer
    overrides the Bearer header. The caller closes the session and sets timeouts
    and allow_redirects=False on every request.
    """
    session = requests.Session()
    session.trust_env = False
    source = config if isinstance(config, SourceConfig) else None
    tls = source.tls if source else config
    session.verify = tls.ca_file if tls.ca_file else tls.verify
    if tls.client_cert_file:
        session.cert = (tls.client_cert_file, tls.client_key_file) if tls.client_key_file else tls.client_cert_file
    if source and source.enabled:
        if source.api_key_file and (not source.url.startswith("https://") or source.tls.verify is not True):
            raise ValueError("Une clé API de source requiert HTTPS avec vérification TLS activée.")
        if source.username:
            session.auth = (source.username, source.password or "")
        token = source.token
        if token:
            session.headers["Authorization"] = f"Bearer {token}"
        api_key = source.api_key
        if api_key:
            session.headers["X-Api-Key"] = api_key
    if bearer:
        session.headers["Authorization"] = f"Bearer {bearer}"
    session.headers["User-Agent"] = "dinum-pdl-agent/0.1.0"
    return session
