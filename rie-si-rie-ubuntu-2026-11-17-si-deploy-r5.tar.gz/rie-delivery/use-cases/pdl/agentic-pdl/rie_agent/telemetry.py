"""Optional observability hooks, with no dependency on a configured exporter.

The Linux image includes ``dinum_observability``. Existing source installations
without that optional package keep their original business behaviour.
"""
from __future__ import annotations

try:
    from dinum_observability import (
        operation,
        agent_execution,
        albert_call,
        record_albert_response,
        record_result,
        configure_from_env,
        mcp_execution_middleware,
    )
except ModuleNotFoundError as exc:
    if exc.name != "dinum_observability":
        raise
    from contextlib import nullcontext

    class _NullSpan:
        def set_attribute(self, *_args, **_kwargs):
            pass

        def set_attributes(self, *_args, **_kwargs):
            pass

    def operation(*_args, **_kwargs):
        return nullcontext(_NullSpan())

    agent_execution = albert_call = operation

    def record_albert_response(*_args, **_kwargs):
        pass

    def record_result(*_args, **_kwargs):
        pass

    def configure_from_env(*_args, **_kwargs):
        pass

    def mcp_execution_middleware():
        return None


try:
    from dinum_observability import record_pdl_response
except ImportError:
    # Older optional installations keep their business behaviour unchanged.
    def record_pdl_response(*_args, **_kwargs):
        pass


try:
    from dinum_observability import observe_mcp_server
except ImportError:
    def observe_mcp_server(server_class):
        return server_class


def secure_mcp_diagnostics():
    """Choose the server's native-log policy independently of tracing activation.

    Called explicitly while constructing a server, never by importing this
    module. Older optional installations retain their existing behaviour and
    are not qualified for G0 logging until the common package is available.
    """
    try:
        from dinum_observability.logging import install_mcp_log_filter
    except ModuleNotFoundError as exc:
        if exc.name not in {'dinum_observability', 'dinum_observability.logging'}:
            raise
        return False
    install_mcp_log_filter()
    return True


def process_diagnostics():
    """Use only a logger explicitly owned by the application's SDK bootstrap."""
    try:
        from dinum_observability.logging import get_process_logger
    except ImportError:
        return None
    return get_process_logger()


def diagnostic_scope(logger):
    from contextlib import nullcontext
    if logger is None:
        return nullcontext()
    try:
        from dinum_observability.logging import diagnostic_scope as scope
    except ImportError:
        return nullcontext()
    return scope(logger)


def emit_diagnostic(logger, event, *, code, **fields):
    """Diagnostic loss must never replace the application's actual result."""
    if logger is None:
        return False
    try:
        return logger.emit(event, code=code, **fields)
    except Exception:
        return False
