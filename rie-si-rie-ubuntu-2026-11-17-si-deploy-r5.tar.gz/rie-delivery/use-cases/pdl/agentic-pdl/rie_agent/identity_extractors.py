"""Support temporary text compatibility enabled by a human-approved mapping.

The target design uses structured fields normalized during ingestion. This module
applies only when the catalog explicitly declares a registered parser;
it is never an automatic fallback to event.original.
"""
from ipaddress import ip_address
import re

PARSERS = {'quoted_from_ip_v1'}
MAX_TEXT_BYTES = 16 * 1024
MAX_MATCHES = 32
QUOTED_FROM = re.compile('\\bfrom\\s+(?P<quote>[\'"])(?P<ip>[0-9a-f:.]+)(?P=quote)', re.IGNORECASE)


def extract_ips(parser: str, value) -> list[str]:
    """Extract canonical IP addresses from bounded text fragments.

    The only accepted parser matches an IP between paired quotes after ``from``.
    Return valid, unique, sorted IPv4/IPv6 addresses and ignore invalid candidates.
    Exceeding 16 KiB or 32 fragments/candidates raises an error so that partial
    extraction cannot be presented as complete.
    """
    if parser not in PARSERS:
        raise ValueError('Parseur d’identité non enregistré.')
    texts = value if isinstance(value, list) else [value]
    if len(texts) > MAX_MATCHES:
        raise ValueError('Trop de fragments pour l’extraction d’identité.')
    values = set()
    matches = 0
    total_bytes = 0
    for text in texts:
        if text is None:
            continue
        if not isinstance(text, str):
            raise ValueError('Texte d’identité invalide.')
        total_bytes += len(text.encode('utf-8'))
        if total_bytes > MAX_TEXT_BYTES:
            raise ValueError('Texte d’identité invalide ou supérieur à 16 KiB.')
        for match in QUOTED_FROM.finditer(text):
            matches += 1
            if matches > MAX_MATCHES:
                raise ValueError('Plus de 32 candidats IP ; identité incomplète.')
            try:
                values.add(str(ip_address(match.group('ip'))))
            except ValueError:
                continue
    return sorted(values)
