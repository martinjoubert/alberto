"""Resolve identity across indices using only human-approved relations.

A management IP or external reference is never inferred from client traffic.
Each identifier has an approved namespace. The anchor is a physical ID or an
explicitly approved name/FQDN; a name never becomes a physical ID.
Identity evidence and requested logs have separate scopes.
"""
from __future__ import annotations

from datetime import datetime, timezone
from ipaddress import ip_address
import re
import requests

from .mappings import active_mapping, validate_mapping
from .opensearch import _time_value, summarize, validate_time_range
from .openwebui_dialogue import question_turns
from .identity_extractors import extract_ips
from .documents import value_at


def _values(value) -> list[str]:
    """Normalize a text identity scalar/list without converting other types.

    Discard None and empty strings. Raise ValueError for non-text values so that
    an invalid identity cannot silently participate in a match.
    """
    values = value if isinstance(value, list) else [value]
    if any(item is not None and not isinstance(item, str) for item in values):
        raise ValueError("Une identité structurée doit être une chaîne ou une liste de chaînes.")
    return [item for item in values if item]


def _token(spec: dict, value: str) -> tuple[str, str]:
    """Return (namespace, canonical value) according to the field's approved role.

    Normalize IPv4/IPv6 addresses and name casing/trailing dots. Preserve IDs and
    references; identical values in different namespaces remain distinct.
    """
    if spec["identity_role"] == "ip":
        value = str(ip_address(value))
    elif spec["identity_role"] in {"name", "fqdn"}:
        value = value.casefold().rstrip(".")
    return spec["identity_namespace"], value


def is_anchor(spec: dict) -> bool:
    """Recognize a stable ID or an already approved name/FQDN anchor option."""
    return spec.get('identity_role') == 'id' or spec.get('identity_anchor') is True


def identifiers(hit: dict, mapping: dict, *, anchors_only=False) -> set[tuple[str, str]]:
    """Extract approved tokens from evidence, or only its anchors.

    Read the explicitly declared source field. Structured fields use _values;
    raw text requires the mapping's temporary identity_extractor option.
    No undeclared field contributes to identity resolution.
    """
    tokens = set()
    for spec in mapping.values():
        if not spec.get("identity_role") or (anchors_only and not is_anchor(spec)):
            continue
        value = value_at(hit.get("_source", {}), spec.get("source_field", spec["field"]))
        values = extract_ips(spec["identity_extractor"], value) if spec.get("identity_extractor") else _values(value)
        tokens.update(_token(spec, item) for item in values)
    return tokens


def _compact_proofs(records: list[dict]) -> list[dict]:
    """Retain one evidence document for each fully examined identifier set.

    This runs only after reading and validating every matching document. It
    compacts reports, never the reads or the ambiguity checks.
    """
    groups = {}
    for record in records:
        key = (record['index'], record['phase'], tuple(record['identifiers']), tuple(record.get('extractors', [])))
        if key not in groups:
            groups[key] = {**record, 'equivalent_documents': 0}
        groups[key]['equivalent_documents'] += 1
    return list(groups.values())


def prepare_lookup(proposal: dict, inventory: dict, approved: list[dict], settings, question: str):
    """Validate an equipment lookup without reading OpenSearch.

    Return (bounded lookup, mappings by index, indices still requiring approval).
    The identity must appear in the question, and log_indices must select only
    the requested log targets. Check period, role, namespace, scope, and current
    hash. Add only already approved identity sources in the same namespace/scope;
    never expand log targets. Any incompatibility raises ValueError before reading.
    """
    lookup = proposal.get("equipment_lookup")
    if not isinstance(lookup, dict) or set(lookup) - {"value", "indices", "log_indices", "scope"}:
        raise ValueError("Structure de recherche équipement invalide.")
    value = lookup.get("value")
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:@-]{0,127}", value):
        raise ValueError("Nom, IP ou référence d'équipement invalide.")
    user_text = '\n'.join(question_turns(question))
    if not re.search(r"(?<![\w.-])" + re.escape(value) + r"(?![\w.-])", user_text, re.IGNORECASE):
        raise ValueError("L'identité proposée doit figurer explicitement dans la question.")
    indices = lookup.get("indices")
    if (not isinstance(indices, list) or not 1 <= len(indices) <= settings.max_indices
            or any(not isinstance(index, str) or not index for index in indices)
            or len(set(indices)) != len(indices)):
        raise ValueError(f"Déclarer entre un et {settings.max_indices} index distincts pour l'équipement (max_indices).")
    log_indices = lookup.get("log_indices")
    if (not isinstance(log_indices, list) or not 1 <= len(log_indices) <= settings.max_indices
            or any(not isinstance(index, str) or index not in indices for index in log_indices)
            or len(set(log_indices)) != len(log_indices)):
        raise ValueError("log_indices est obligatoire : déclarer un sous-ensemble non vide et distinct des index participants.")
    scope = lookup.get("scope")
    if scope is not None and (not isinstance(scope, dict) or set(scope) != {"concept", "value"}
                              or not isinstance(scope["value"], str)):
        raise ValueError("Périmètre invalide : concept et valeur textuelle requis.")
    period = proposal.get("time_range")
    if not isinstance(period, dict):
        raise ValueError("La résolution équipement exige une période explicite.")
    validate_time_range(period, settings)
    now = datetime.now(timezone.utc)
    period = {key: _time_value(value, now).isoformat() for key, value in period.items()}
    log_limit = proposal.get('limit', min(20, settings.max_rows))
    if isinstance(log_limit, bool) or not isinstance(log_limit, int) or not 1 <= log_limit <= settings.max_rows:
        raise ValueError('Limite des logs invalide.')

    def scope_compatible(mapping):
        """Check that the mapping supports the requested textual scope."""
        if not scope:
            return True
        spec = mapping.get(scope["concept"])
        return bool(spec and spec["type"] in {"keyword", "constant_keyword"}
                    and (not spec.get("values") or scope["value"] in spec["values"]))

    def anchor_namespaces(mapping):
        """List declared anchor namespaces to compare identity sources."""
        return {spec["identity_namespace"] for spec in mapping.values() if is_anchor(spec)}

    mappings, missing = {}, []
    for index in indices:
        entry = inventory.get("indices", {}).get(index)
        if not entry:
            raise ValueError("Index équipement absent de l'inventaire autorisé.")
        active = active_mapping(index, entry, approved)
        mapping = active["concepts"] if active else (proposal.get("proposed_mappings") or {}).get(index)
        if not mapping:
            raise ValueError(f"Mapping d'identité absent pour {index}; créer une revue dans l'inventaire.")
        validate_mapping(mapping, entry)
        if not any(spec.get("identity_role") for spec in mapping.values()):
            raise ValueError(f"Aucune relation d'identité approuvable dans {index}.")
        if not scope_compatible(mapping):
            raise ValueError(f"Périmètre absent ou incompatible dans {index}.")
        mappings[index] = mapping
        if not active:
            missing.append(index)
    namespaces = set().union(*(anchor_namespaces(mapping) for mapping in mappings.values()))
    if len(namespaces) != 1:
        raise ValueError("Déclarer un seul espace de noms d'ancre approuvée pour la résolution.")
    namespace = next(iter(namespaces))
    added = []
    # A TACACS request may omit a BB source needed for IPv6. The current catalog
    # completes identity coverage without adding BB logs to the result.
    for index, entry in sorted(inventory.get("indices", {}).items()):
        if index in mappings:
            continue
        active = active_mapping(index, entry, approved)
        if not active:
            continue
        candidate = active["concepts"]
        candidate_namespaces = anchor_namespaces(candidate)
        if namespace not in candidate_namespaces or not scope_compatible(candidate):
            continue
        validate_mapping(candidate, entry)
        if candidate_namespaces != {namespace}:
            raise ValueError(f"Plusieurs espaces de noms d'ancre approuvée dans {index}; revue nécessaire.")
        if len(mappings) >= settings.max_indices:
            raise ValueError(f"Le pool d'identité approuvé dépasse max_indices={settings.max_indices} ; préciser le catalogue ou le périmètre.")
        mappings[index] = candidate
        added.append(index)
    source_addition = {"policy": "current_approved_anchor_namespace_and_scope",
                       "anchor_namespace": namespace, "added_identity_indices": added,
                       "log_indices_expanded": False,
                       "coverage": "current_approved_catalogue_in_requested_scope"}
    return {"value": value, "indices": list(mappings), "requested_indices": list(indices),
            "log_indices": list(log_indices), "added_identity_indices": added,
            "source_addition": source_addition,
            "scope": scope, "time_range": period, 'log_limit': log_limit,
            'identity_limit': settings.max_identity_documents}, mappings, missing


def resolve_equipment(lookup: dict, mappings: dict, search, settings) -> dict:
    """Prove a unique anchor, expand its identifiers, then read the log targets.

    ``lookup`` and ``mappings`` come from prepare_lookup. Each read is bounded and
    retained with its DSL/summary; evidence includes the index and document ID.
    Reverse reads reject shared identifiers before accessing target logs. At most
    four rounds expand identity across indices. Return a result with resolved,
    partial, not_found, ambiguous, or incomplete status. Uncertain resolution
    prevents an exhaustive conclusion; a read error clears published rows.
    This function never calls the model.
    """
    resources, proofs = [], []
    result = {"status": "resolved", "equipment": lookup["value"], "identity": None,
              "identity_proofs": proofs, "resources": resources, "rows": [], "counts": {},
              "time_range": lookup["time_range"], "complete_for_query": False,
              "limits": {"max_identity_documents_per_read": lookup.get('identity_limit', settings.max_identity_documents),
                         'max_logs_displayed': lookup.get('log_limit', min(20, settings.max_rows)),
                         'sort_order': 'desc', 'raw_identity_scan_is_bounded': True,
                         'identity_proofs': 'one_representative_per_examined_identifier_set',
                         "max_indices": settings.max_indices, "max_expansion_rounds": 4,
                         "identity_period_equals_log_period": True}}
    anchor_sources = {index: mapping for index, mapping in mappings.items()
                      if any(is_anchor(spec) for spec in mapping.values())}
    result["identity_indices"] = list(anchor_sources)
    result["log_indices"] = lookup["log_indices"]
    result["added_identity_indices"] = lookup.get("added_identity_indices", [])
    result["source_addition"] = lookup.get("source_addition", {})
    namespaces = {spec["identity_namespace"] for mapping in anchor_sources.values()
                  for spec in mapping.values() if is_anchor(spec)}
    if len(namespaces) != 1:
        raise ValueError("Déclarer un seul espace de noms d'ancre approuvée pour la résolution.")

    def read(index, mapping, conditions, phase, *, raw_scan=False):
        """Perform a bounded read and append its evidence to the enclosing result.

        Identity reads must be complete; displayed logs may be truncated if their
        total remains exact. raw_scan is reserved for the approved temporary
        parser: scanning documents without anchors also rejects shared IP addresses
        whose identity cannot be proved.
        """
        if not conditions and not raw_scan:
            return []
        filters = [{"range": {mapping["timestamp"]["field"]: lookup["time_range"]}}]
        if raw_scan:
            filters.append({'bool': {'should': [{'exists': {'field': spec['field']}} for spec in mapping.values()
                                                if spec.get('identity_extractor')], 'minimum_should_match': 1}})
        else:
            filters.append({"bool": {"should": conditions, "minimum_should_match": 1}})
            if phase == 'identity_reverse' and any(spec.get('identity_anchor') for spec in mapping.values()):
                filters.append({'bool': {'should': [{'exists': {'field': spec['field']}} for spec in mapping.values()
                                                   if is_anchor(spec)], 'minimum_should_match': 1}})
        if lookup["scope"]:
            scope = lookup["scope"]
            filters.append({"term": {mapping[scope["concept"]]["field"]: scope["value"]}})
        limit = result['limits']['max_logs_displayed'] if phase == 'logs' else result['limits']['max_identity_documents_per_read']
        body = {"size": limit, "track_total_hits": True, "timeout": "5s",
                "query": {"bool": {"filter": filters}},
                "_source": sorted({spec.get("source_field", spec["field"]) for spec in mapping.values()}),
                "sort": [{mapping["timestamp"]["field"]: "desc"}]}
        resource = {"index": index, "phase": phase, "dsl": body}
        resources.append(resource)
        try:
            reader = search.search if phase == 'logs' else getattr(search, 'search_identity', search.search)
            raw = reader(index, body)
        except (RuntimeError, ValueError, requests.RequestException) as exc:
            resource["error"] = {"type": type(exc).__name__, "message": str(exc)[:500]}
            raise ValueError(f"Lecture interrompue dans {index}; aucune conclusion exhaustive.") from exc
        summary = summarize(raw, "search")
        resource["result_summary"] = summary
        if phase != 'logs' and summary['total_relation'] == 'eq' and summary['total'] > limit:
            raise ValueError(f"Lecture d'identité : {summary['total']} documents dépassent max_identity_documents={limit} ; préciser la période/le périmètre ou ajuster le budget. Cibles non interrogées.")
        if not summary["complete_for_query"] and (phase != 'logs' or summary['timed_out'] or
                summary['failed_shards'] or summary['total_relation'] != 'eq'):
            raise ValueError("Lecture d'identité ou de logs incomplète ; aucune conclusion exhaustive.")
        hits = raw.get("hits", {}).get("hits", [])
        if any(not hit.get("_id") for hit in hits):
            raise ValueError("Document sans identifiant de preuve.")
        return hits

    def conditions_for(mapping, tokens):
        """Compile equality clauses for tokens and fields in the same namespace.

        Raw text is handled by the temporary scan rather than a term query.
        Names/FQDNs use explicitly allowed case-insensitive comparison;
        IP addresses, IDs, and references retain exact equality.
        """
        conditions = []
        for spec in mapping.values():
            if not spec.get("identity_role") or spec.get('identity_extractor'):
                continue
            values = sorted(value for namespace, value in tokens if namespace == spec["identity_namespace"])
            for value in values:
                if spec["identity_role"] in {"name", "fqdn"}:
                    conditions.append({"term": {spec["field"]: {"value": value, "case_insensitive": True}}})
                else:
                    conditions.append({"term": {spec["field"]: value}})
        return conditions

    try:
        # 1. Find initial evidence and one stable ID or reviewed name/FQDN anchor.
        seed_hits = []
        for index, mapping in anchor_sources.items():
            seed_tokens = set()
            for spec in mapping.values():
                if spec.get("identity_role") and not spec.get('identity_extractor'):
                    try:
                        seed_tokens.add(_token(spec, lookup["value"]))
                    except ValueError:
                        pass  # A hostname is never artificially converted into an IP.
            conditions = conditions_for(mapping, seed_tokens)
            if re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,127}', lookup['value']):
                conditions += [{'wildcard': {spec['field']: {'value': lookup['value'] + '.*', 'case_insensitive': True}}}
                               for spec in mapping.values() if spec.get('identity_match') == 'short_name_prefix']
            seed_hits.extend((index, hit) for hit in read(index, mapping, conditions, "seed"))
        anchors = set().union(*(identifiers(hit, mappings[index], anchors_only=True) for index, hit in seed_hits))
        proofs.extend(_compact_proofs([{"index": index, "document_id": hit["_id"], "phase": "seed",
                                      "identifiers": sorted(identifiers(hit, mappings[index]))} for index, hit in seed_hits]))
        if not seed_hits or not anchors:
            result.update(status="not_found", message="Identité stable introuvable dans la période et le périmètre ; cibles non interrogées.")
            return result
        if len(anchors) != 1 or any(not identifiers(hit, mappings[index], anchors_only=True) for index, hit in seed_hits):
            result.update(status="ambiguous", message="Plusieurs équipements ou ID stable absent ; préciser le périmètre ou le nom.")
            return result
        tokens = set().union(*(identifiers(hit, mappings[index]) for index, hit in seed_hits))
        seen = {}
        # 2. Expand identifiers through reverse reads. Any other anchor signals a
        # shared relation; target logs must then remain unread.
        for round_number in range(4):
            previous = set(tokens)
            for index, mapping in anchor_sources.items():
                raw_scan = any(spec.get('identity_extractor') for spec in mapping.values())
                for hit in read(index, mapping, conditions_for(mapping, tokens),
                                'identity_reverse_text' if raw_scan else 'identity_reverse', raw_scan=raw_scan):
                    hit_tokens = identifiers(hit, mapping) if raw_scan else None
                    if raw_scan and not hit_tokens.intersection(tokens):
                        continue
                    found = identifiers(hit, mapping, anchors_only=True)
                    if found != anchors:
                        result.update(status="ambiguous", message="IP, nom ou référence partagé entre identités ; cibles non interrogées.")
                        return result
                    if hit_tokens is None:
                        hit_tokens = identifiers(hit, mapping)
                    tokens.update(hit_tokens)
                    seen[(index, hit["_id"])] = {"index": index, "document_id": hit["_id"],
                                                  "identifiers": sorted(hit_tokens),
                                                  'extractors': sorted({spec['identity_extractor'] for spec in mapping.values()
                                                                        if spec.get('identity_extractor')})}
            if tokens == previous:
                break
        else:
            raise ValueError("Chaîne d'identité supérieure à quatre tours ; revue nécessaire.")
        proofs.extend(_compact_proofs([{**proof, "phase": "identity_reverse"} for proof in seen.values()]))
        result["identity"] = {"stable_id": list(next(iter(anchors))), "identifiers": sorted(tokens),
                              'anchor_kind': 'physical_id' if any(spec.get('identity_role') == 'id'
                               for mapping in anchor_sources.values() for spec in mapping.values()) else 'reviewed_name_or_fqdn'}
        rows = []
        # 3. Read only log_indices using established references. This finds logs
        # that no longer contain the original equipment name/ID.
        for index in result["log_indices"]:
            mapping = mappings[index]
            conditions = conditions_for(mapping, tokens)
            if not conditions:
                raise ValueError(f"Aucune relation d'identité compatible avec l'index {index}.")
            hits = read(index, mapping, conditions, "logs")
            result["counts"][index] = resources[-1]['result_summary']['total']
            rows.extend({"index": index, "document_id": hit["_id"], "source": hit.get("_source", {})} for hit in hits)
        def timestamp(row):
            """Read an evidence timestamp for global ordering across indices.

            Reject missing/non-text timestamps rather than inventing their order.
            """
            spec = mappings[row['index']]['timestamp']
            value = value_at(row['source'], spec.get('source_field', spec['field']))
            if not isinstance(value, str):
                raise ValueError('Horodatage de preuve absent ou non textuel ; affichage incomplet.')
            return _time_value(value, datetime.now(timezone.utc))
        rows.sort(key=lambda row: (timestamp(row), row['index'], row['document_id']), reverse=True)
        # An exact total does not mean all matching rows are displayed.
        # Without PIT, this result covers these reads and their period, not an
        # immutable snapshot of all indices or proof of causality.
        result["total"] = sum(result['counts'].values())
        result["rows"] = rows[:result['limits']['max_logs_displayed']]
        result["returned"] = len(result["rows"])
        result["complete_for_query"] = result['total'] == result['returned']
        if not result["complete_for_query"]:
            result.update(status="partial", message="Identité vérifiée ; seuls les logs les plus récents sont affichés. Le total exact est distinct des logs présentés.")
    except ValueError as exc:
        result.update(status="incomplete", message=str(exc), rows=[], counts={})
    return result
