"""Typed runtime configuration and deferred reads of secret files.

The YAML stores private paths, never secret values. Validation rejects an empty
index scope or a source API key sent without verified TLS.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import os
import ipaddress
from pathlib import Path
import re
from typing import Any

import yaml


def require_safe_bind(host: str, *, administration: bool = False) -> None:
    """Keep unauthenticated administration local; require access for public MCP.

    A configured proxy is not inferred from an arbitrary bind address. The
    NiceGUI administration callbacks have no application authentication today.
    """
    try:
        loopback = ipaddress.ip_address(host).is_loopback
    except ValueError:
        loopback = host == 'localhost'
    if loopback:
        return
    if administration:
        raise ValueError("L'administration sans authentification doit rester liée au loopback.")
    from dinum_access import AccessGate
    if AccessGate.configured() is None:
        raise ValueError("Un serveur MCP exposé requiert DINUM_ACCESS_CONFIG valide.")


def _secret(path: str | None) -> str | None:
    """Read the indicated secret file; return None when no path is configured.

    Missing or unreadable files preserve their I/O error; empty content raises
    ValueError. The value is neither cached nor displayed.
    """
    if not path:
        return None
    value = Path(path).read_text(encoding="utf-8").strip()
    if not value:
        raise ValueError(f"Secret vide : {path}")
    return value


@dataclass(frozen=True)
class TLSConfig:
    """TLS settings: trust anchor, client certificate, and verification policy."""
    ca_file: str | None = None
    client_cert_file: str | None = None
    client_key_file: str | None = None
    verify: bool = True


@dataclass(frozen=True)
class SourceConfig:
    """Describe an external source and paths to its authentication credentials.

    Properties read secrets on demand. Clients must check enabled before using
    them, especially for optional sources.
    """
    enabled: bool
    url: str
    username: str | None = None
    password_file: str | None = None
    token_file: str | None = None
    tls: TLSConfig = field(default_factory=TLSConfig)
    allowed_tools: tuple[str, ...] = ()
    api_key_file: str | None = None

    @property
    def password(self) -> str | None:
        """Read the private password on demand, or return None when no path is set."""
        return _secret(self.password_file)

    @property
    def token(self) -> str | None:
        """Read the private token on demand, or return None when no path is set."""
        return _secret(self.token_file)

    @property
    def api_key(self) -> str | None:
        """Read the key and reject whitespace, controls, and non-printable ASCII.

        This validation prevents ambiguous values in the HTTP X-Api-Key header.
        """
        value = _secret(self.api_key_file)
        if value is not None and any(ord(char) < 33 or ord(char) > 126 for char in value):
            raise ValueError("Clé API de source invalide : caractères non autorisés.")
        return value


@dataclass(frozen=True)
class AlbertConfig:
    """Endpoint, model, and key-file path for the remote Albert planner."""
    url: str
    model: str
    api_key_file: str
    tls: TLSConfig = field(default_factory=TLSConfig)

    @property
    def api_key(self) -> str:
        """Read the private Albert key; _secret rejects an empty file."""
        return _secret(self.api_key_file) or ""


@dataclass(frozen=True)
class Settings:
    """Immutable settings shared by discovery, the service, and transports.

    Limits bound discovery and results; separate hosts and ports serve
    the administration interface and MCP server.
    """
    data_dir: Path
    allowed_index_patterns: tuple[str, ...]
    refresh_seconds: int
    public_admin_url: str
    mcp_host: str
    mcp_port: int
    admin_host: str
    admin_port: int
    albert: AlbertConfig
    opensearch: SourceConfig
    zabbix: SourceConfig
    grafana: SourceConfig
    max_rows: int = 100
    max_buckets: int = 100
    max_time_range_days: int = 31
    max_indices: int = 20
    max_fields_per_index: int = 500
    max_identity_documents: int = 1000
    max_context_bytes: int = 1_048_576
    required_index_patterns: tuple[str, ...] = ()

    def validate(self) -> None:
        """Reject invalid index patterns, URLs, and limits before startup.

        A source API key requires HTTPS with verified TLS. Validation contacts
        no source and reads no secret file.
        """
        if any(not isinstance(patterns, (list, tuple)) or any(not isinstance(value, str) for value in patterns)
               for patterns in (self.allowed_index_patterns, self.required_index_patterns)):
            raise ValueError("allowed_index_patterns et required_index_patterns exigent des listes de motifs textuels.")
        if not self.allowed_index_patterns:
            raise ValueError("Au moins un motif d'index OpenSearch autorisé est obligatoire.")
        for pattern in (*self.allowed_index_patterns, *self.required_index_patterns):
            if not re.fullmatch(r"[a-z0-9][a-z0-9._*-]{0,254}", pattern) or '..' in pattern:
                raise ValueError(f"Motif d'index interdit : {pattern!r}")
        if not self.opensearch.enabled:
            raise ValueError("OpenSearch doit être activé pour la recette RIE initiale.")
        for source in (self.opensearch, self.zabbix, self.grafana):
            if source.enabled and not source.url.startswith(("http://", "https://")):
                raise ValueError("Chaque source activée doit utiliser une URL HTTP(S).")
            if source.enabled and source.api_key_file and (not source.url.startswith("https://") or source.tls.verify is not True):
                raise ValueError("Une clé API de source requiert HTTPS avec vérification TLS activée.")
        if self.refresh_seconds < 60 or self.max_rows not in range(1, 1001):
            raise ValueError("Limites de découverte ou de résultats invalides.")
        for name, maximum in (("max_indices", 200), ("max_fields_per_index", 10000),
                              ("max_identity_documents", 10000), ("max_context_bytes", 1_048_576)):
            value = getattr(self, name)
            if type(value) is not int or not 1 <= value <= maximum:
                raise ValueError(f"Limite {name} invalide : entier entre 1 et {maximum} requis.")


def _tls(value: dict[str, Any] | None) -> TLSConfig:
    """Convert the YAML TLS block to settings, using safe defaults."""
    return TLSConfig(**(value or {}))


def _source(value: dict[str, Any] | None) -> SourceConfig:
    """Convert a YAML source block without mutating the caller's dictionary.

    Allowed tools become a tuple and the TLS block becomes a TLSConfig object.
    """
    value = dict(value or {})
    value["tls"] = _tls(value.get("tls"))
    value["allowed_tools"] = tuple(value.get("allowed_tools") or ())
    return SourceConfig(**value)


def _patterns(value, name: str) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)) or any(not isinstance(item, str) for item in value):
        raise ValueError(f"{name} exige une liste de motifs textuels.")
    return tuple(value)


def load_settings(path: str | Path | None = None) -> Settings:
    """Load and validate YAML from path, PDL_CONFIG, or the standard location.

    Expand environment variables; PDL_DATA_DIR can override the business-data
    volume. File, YAML, and validation errors propagate to the caller.
    """
    path = Path(path or os.getenv("PDL_CONFIG", "/etc/pdl-agent/config.yaml"))
    raw = yaml.safe_load(os.path.expandvars(path.read_text(encoding="utf-8"))) or {}
    server = raw.get("server", {})
    limits = raw.get("limits", {})
    discovery = raw.get("discovery", {})
    sources = raw.get("sources", {})
    albert_raw = dict(raw.get("albert") or {})
    albert_raw["tls"] = _tls(albert_raw.get("tls"))
    settings = Settings(
        data_dir=Path(os.getenv("PDL_DATA_DIR", raw.get("storage", {}).get("data_dir", "/var/lib/pdl-agent"))),
        allowed_index_patterns=_patterns(discovery.get("allowed_index_patterns", ()), "allowed_index_patterns"),
        refresh_seconds=int(discovery.get("refresh_seconds", 3600)),
        public_admin_url=str(server.get("public_admin_url", "http://127.0.0.1:8090")).rstrip("/"),
        mcp_host=str(server.get("mcp_host", "127.0.0.1")), mcp_port=int(server.get("mcp_port", 9910)),
        admin_host=str(server.get("admin_host", "127.0.0.1")), admin_port=int(server.get("admin_port", 8090)),
        albert=AlbertConfig(**albert_raw),
        opensearch=_source(sources.get("opensearch")),
        zabbix=_source(sources.get("zabbix")),
        grafana=_source(sources.get("grafana")),
        max_rows=int(limits.get("max_rows", 100)), max_buckets=int(limits.get("max_buckets", 100)),
        max_time_range_days=int(limits.get("max_time_range_days", 31)),
        max_indices=discovery.get("max_indices", 20),
        max_fields_per_index=discovery.get("max_fields_per_index", 500),
        max_identity_documents=limits.get("max_identity_documents", 1000),
        max_context_bytes=limits.get("max_context_bytes", 1_048_576),
        required_index_patterns=_patterns(discovery.get("required_index_patterns", ()), "required_index_patterns"),
    )
    settings.validate()
    return settings
