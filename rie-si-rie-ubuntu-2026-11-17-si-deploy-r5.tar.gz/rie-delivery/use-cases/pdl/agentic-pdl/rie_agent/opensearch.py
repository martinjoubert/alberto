"""Compile business intents and restrict all OpenSearch reads.

The compiler is deterministic: Albert never supplies DSL. The client rechecks
the index, forbidden keys, and row limit immediately before the HTTP call.
Summaries distinguish an exact total, truncated display, and incomplete search.
"""
from __future__ import annotations

from dinum_access import require_indices

from datetime import datetime, timezone
import fnmatch
import re
from typing import Any

from .config import Settings
from .http import session_for, bounded_json
from .telemetry import operation, record_pdl_response


FORBIDDEN_DSL_KEYS = {"script", "script_fields", "runtime_mappings", "update", "delete", "delete_by_query",
                      "percolate", "more_like_this", "indexed_shape"}


def _time_value(value: str, now: datetime) -> datetime:
    """Resolve a timezone-aware date or ``now[-Ns|m|h|d]`` to a UTC datetime.

    The caller supplies ``now`` as a shared reference for relative bounds.
    An absolute date without a timezone or an unknown syntax raises ``ValueError``.
    """
    relative = re.fullmatch(r"now(?:-(\d+)([smhd]))?", value)
    if relative:
        amount = int(relative.group(1) or 0)
        seconds = amount * {"s": 1, "m": 60, "h": 3600, "d": 86400}.get(relative.group(2), 0)
        from datetime import timedelta
        return now - timedelta(seconds=seconds)
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Une borne temporelle absolue doit inclure son fuseau.")
    return parsed.astimezone(timezone.utc)


def validate_time_range(period: dict, settings: Settings) -> None:
    """Require gte and exactly one lt/lte end within the configured maximum duration.

    Raise ``ValueError`` before any read if the period is empty, reversed, or too
    long. Preserve the requested inclusive/exclusive bounds.
    """
    if not isinstance(period, dict) or set(period) - {"gte", "lt", "lte"} or "gte" not in period or ("lt" in period) == ("lte" in period):
        raise ValueError("La période exige gte et exactement une borne supérieure lt ou lte.")
    now = datetime.now(timezone.utc)
    end_key = "lt" if "lt" in period else "lte"
    start, end = _time_value(str(period["gte"]), now), _time_value(str(period[end_key]), now)
    seconds = (end - start).total_seconds()
    if seconds <= 0 or seconds > settings.max_time_range_days * 86400:
        raise ValueError("Période vide, inversée ou supérieure à la limite.")


def _walk(value: Any, depth: int = 0):
    """Recursively yield DSL keys, including keys inside lists."""
    if depth > 32:
        raise ValueError("Profondeur DSL supérieure à la limite.")
    if isinstance(value, dict):
        if ({"index", "_index"}.intersection(value) and
                {"id", "_id", "path", "query", "document", "routing"}.intersection(value)):
            raise ValueError("Référence DSL vers un autre document ou index interdite.")
        for key, nested in value.items():
            yield key
            yield from _walk(nested, depth + 1)
    elif isinstance(value, list):
        for nested in value:
            yield from _walk(nested, depth + 1)


class ReadOnlyOpenSearch:
    """HTTP client restricted to ``POST /<concrete index>/_search``."""

    def __init__(self, settings: Settings):
        """Prepare the TLS/authentication session and URL without initial network access."""
        self.settings = settings
        self.source = settings.opensearch
        self.session = session_for(self.source)
        self.base_url = self.source.url.rstrip("/")

    def index_allowed(self, index: str) -> bool:
        """Check a concrete index name against the configured allowed patterns.

        Wildcards are accepted only in configuration, never in the name supplied
        when executing a search.
        """
        return bool(re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,254}", index)) and any(
            fnmatch.fnmatchcase(index, pattern) for pattern in self.settings.allowed_index_patterns)

    def validate_dsl(self, index: str, body: dict, *, identity: bool = False) -> None:
        """Reject unauthorized indices, scripts, write operations, or row counts.

        This final check protects the transport; business validation and compilation
        happen earlier. It does not authorize arbitrary DSL from the model.
        """
        if not self.index_allowed(index):
            raise ValueError("Index hors de la liste autorisée.")
        forbidden = FORBIDDEN_DSL_KEYS.intersection(_walk(body))
        if forbidden:
            raise ValueError(f"DSL interdit : {sorted(forbidden)}")
        if set(body) - {"size", "track_total_hits", "timeout", "query", "aggs", "_source", "sort"}:
            raise ValueError("Clé DSL non autorisée.")
        maximum = self.settings.max_identity_documents if identity else self.settings.max_rows
        if type(body.get("size", 0)) is not int or not 0 <= body.get("size", 0) <= maximum:
            raise ValueError("Nombre de lignes supérieur à la limite.")

    def search(self, index: str, body: dict) -> dict:
        """Validate then read OpenSearch without redirects, with bounded time and size.

        Return the raw JSON response; raise an HTTP/transport error or ``ValueError``
        if the response exceeds 2 MB. Do not retry automatically.
        """
        return self._search(index, body, identity=False)

    def search_identity(self, index: str, body: dict) -> dict:
        """Read bounded identity evidence independently of displayed log counts.

        The caller must reject a truncated response. ACL, response-size and
        timeout protections are identical to ordinary searches.
        """
        return self._search(index, body, identity=True)

    def _search(self, index: str, body: dict, *, identity: bool) -> dict:
        with operation("rie.arguments.validate"):
            self.validate_dsl(index, body, identity=identity)
        def resolve(expression):
            response = self.session.get(self.base_url+'/_resolve/index/'+expression, timeout=10, allow_redirects=False, stream=True)
            if response.status_code != 200:
                response.close()
                raise RuntimeError("Résolution OpenSearch indisponible.")
            return bounded_json(response)
        with operation("db.query opensearch", kind="CLIENT", attributes={
            "db.system.name": "opensearch", "db.operation.name": "search",
        }) as span:
            index = require_indices(index, resolve)
            response = self.session.post(f"{self.base_url}/{index}/_search", json=body, timeout=15, allow_redirects=False, stream=True)
            span.set_attribute("http.response.status_code", response.status_code)
            if response.status_code != 200:
                response.close()
                raise RuntimeError(f"Recherche OpenSearch impossible : HTTP {response.status_code}")
            data = bounded_json(response)
            record_pdl_response(span, data)
            return data


def compile_plan(plan: dict, catalog: dict, settings: Settings) -> dict:
    """Convert a validated intent to bounded search/count/aggregate DSL.

    ``catalog['concepts']`` maps concepts to checked physical fields. Validate
    the period, operators, business values, projection, and sort order; preserve
    value casing exactly. Return a JSON body without network effects.
    Aggregate group_by must already be a scalar approved concept; incompatible
    intents raise ``ValueError`` without reading OpenSearch.
    """
    concepts = catalog["concepts"]
    timestamp = concepts.get("timestamp", {}).get("field")
    if not timestamp:
        raise ValueError("Le mapping approuvé ne déclare pas le temps.")
    period = plan.get("time_range") or {"gte": "now-2h", "lt": "now"}
    validate_time_range(period, settings)
    filters = [{"range": {timestamp: dict(period)}}]
    exclusions = []
    # Positive criteria are conjunctive; exclusions have their own must_not.
    # The model cannot add arbitrary DSL expressions or operators.
    for criterion in plan.get("filters", []):
        concept = criterion.get("concept")
        if concept not in concepts or concept == "timestamp":
            raise ValueError(f"Concept non approuvé : {concept}")
        field, value = concepts[concept]["field"], criterion.get("value")
        declared_values = concepts[concept].get("values")
        if criterion.get("operator", "eq") != "exists" and (value is None or isinstance(value, dict)):
            raise ValueError("Une égalité exige une valeur simple, jamais une expression DSL.")
        op = criterion.get("operator", "eq")
        if op in {"eq", "ne"} and (isinstance(value, list) or not isinstance(value, (str, int, float, bool))):
            raise ValueError("eq et ne exigent une valeur scalaire ; utiliser in ou not_in pour une liste.")
        if op in {"in", "not_in"} and (not isinstance(value, list) or not value or len(value) > 100
                                      or any(not isinstance(item, (str, int, float, bool)) for item in value)):
            raise ValueError("in et not_in exigent une liste non vide de cent valeurs simples au plus.")
        checked_values = value if isinstance(value, list) else [value]
        if criterion.get("operator", "eq") != "exists" and declared_values and any(item not in declared_values for item in checked_values):
            raise ValueError(f"Valeur non approuvée pour le concept {concept}.")
        if op == "eq":
            filters.append({"term": {field: value}})
        elif op == "in" and isinstance(value, list) and value:
            filters.append({"terms": {field: value}})
        elif op == "exists":
            filters.append({"exists": {"field": field}})
        elif op == "ne":
            exclusions.append({"term": {field: value}})
        elif op == "not_in":
            exclusions.append({"terms": {field: value}})
        else:
            raise ValueError("Opérateur non autorisé.")
    operation = plan.get("operation", "search")
    raw_limit = plan.get("limit", 20)
    limit = int(raw_limit)
    # Counts always use size=0; zero requests no rows, never an unlimited search.
    if limit < 1 and not (operation == "count" and type(raw_limit) is int and raw_limit == 0):
        raise ValueError("La limite doit être positive.")
    body: dict[str, Any] = {"size": 0, "track_total_hits": True, "timeout": "5s", "query": {"bool": {"filter": filters}}}
    if exclusions:
        body["query"]["bool"]["must_not"] = exclusions
    if operation == "search":
        body["size"] = min(limit, settings.max_rows)
        selected = plan.get("select") or list(concepts)
        if any(name not in concepts for name in selected):
            raise ValueError("Projection non approuvée.")
        body["_source"] = sorted({concepts[name].get("source_field", concepts[name]["field"]) for name in selected})
        sort_order = plan.get("sort_order", "desc")
        if sort_order not in {"asc", "desc"}:
            raise ValueError("Le tri temporel doit être asc ou desc.")
        body["sort"] = [{timestamp: sort_order}]
    elif operation == "count":
        pass
    elif operation == "aggregate":
        # missing_group tracks documents without a value. Error counters and
        # omitted buckets determine whether the summary is complete.
        group = plan.get("group_by")
        if not isinstance(group, str) or group not in concepts:
            raise ValueError("Regroupement non approuvé.")
        group_field = concepts[group]["field"]
        body["aggs"] = {"groups": {"terms": {"field": group_field,
                                                  "size": min(limit, settings.max_buckets),
                                                  "order": [{"_count": "desc"}, {"_key": "asc"}],
                                                  "show_term_doc_count_error": True}},
                        "missing_group": {"missing": {"field": group_field}}}
    else:
        raise ValueError("Opération non autorisée.")
    return body


def summarize(raw: dict, operation: str) -> dict:
    """Reduce a raw response to evidence and completeness indicators.

    ``complete_for_query`` covers only the query that ran. A search requires all
    rows; an aggregation requires buckets without errors or omissions and a sum
    consistent with the total, including documents missing the grouped field.
    Truncation, timeouts, and failed shards remain visible.
    """
    total = raw.get("hits", {}).get("total", {})
    total_value = total.get("value", 0) if isinstance(total, dict) else int(total or 0)
    result = {"total": total_value, "total_relation": total.get("relation", "eq") if isinstance(total, dict) else "eq",
              "timed_out": bool(raw.get("timed_out")), "failed_shards": raw.get("_shards", {}).get("failed", 0)}
    if operation == "search":
        result["rows"] = [{"id": hit.get("_id"), "source": hit.get("_source", {})} for hit in raw.get("hits", {}).get("hits", [])]
        result["complete_for_query"] = (result["total_relation"] == "eq" and not result["timed_out"]
                                        and not result["failed_shards"] and len(result["rows"]) == result["total"])
    elif operation == "count":
        result["complete_for_query"] = result["total_relation"] == "eq" and not result["timed_out"] and not result["failed_shards"]
    elif operation == "aggregate":
        groups = raw.get("aggregations", {}).get("groups", {})
        result["rows"] = [{"key": bucket["key"], "count": bucket["doc_count"]}
                          for bucket in groups.get("buckets", [])]
        result["visible_sum"] = sum(item["count"] for item in result["rows"])
        result["missing_group_count"] = raw.get("aggregations", {}).get("missing_group", {}).get("doc_count", 0)
        result["sum_other_doc_count"] = groups.get("sum_other_doc_count", 0)
        result["doc_count_error_upper_bound"] = groups.get("doc_count_error_upper_bound", 0)
        result["complete_for_query"] = (result["total_relation"] == "eq" and not result["timed_out"] and
                                         not result["failed_shards"] and not result["sum_other_doc_count"] and
                                         not result["doc_count_error_upper_bound"] and
                                         result["visible_sum"] + result["missing_group_count"] == result["total"])
    return result
