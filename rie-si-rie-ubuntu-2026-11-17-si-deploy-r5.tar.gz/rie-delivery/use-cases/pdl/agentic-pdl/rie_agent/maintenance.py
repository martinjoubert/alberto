"""Backup and restore of the PDL runtime business-data volume only.

These local operations handle Store files, not OpenSearch/OpenWebUI volumes
or secrets. The operator must stop writers to obtain a consistent backup.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path
import zipfile


def backup(data: Path, destination: Path) -> Path:
    """Archive business files under data and return the UTC timestamped ZIP path.

    Do not lock writer processes; stop services before calling and protect
    destination, which can contain evidence and sensitive business data.
    """
    destination.mkdir(parents=True, exist_ok=True)
    name = "pdl-agent-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + ".zip"
    target = destination / name
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(data.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(data))
    return target


def restore(data: Path, source: Path) -> None:
    """Restore a ZIP into an existing empty volume after validating all member paths.

    Reject a nonempty destination or a member escaping the volume. File and archive
    errors propagate; existing data is never merged.
    """
    if any(data.iterdir()):
        raise RuntimeError("Le volume doit être vide avant restauration.")
    with zipfile.ZipFile(source) as archive:
        for member in archive.infolist():
            destination = (data / member.filename).resolve()
            if data.resolve() not in destination.parents and destination != data.resolve():
                raise ValueError("Archive de sauvegarde invalide.")
        archive.extractall(data)


def main() -> None:
    """Run the requested local operation; restore requires an explicit --source path."""
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("backup", "restore"))
    parser.add_argument("--data", type=Path, default=Path("/data"))
    parser.add_argument("--destination", type=Path, default=Path("/backup"))
    parser.add_argument("--source", type=Path)
    args = parser.parse_args()
    if args.operation == "backup":
        print(backup(args.data, args.destination))
    else:
        if not args.source:
            parser.error("--source est obligatoire pour restore")
        restore(args.data, args.source)


if __name__ == "__main__":
    main()
