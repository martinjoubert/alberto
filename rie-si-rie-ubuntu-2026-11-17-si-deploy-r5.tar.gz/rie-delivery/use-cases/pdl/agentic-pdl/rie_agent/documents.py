"""Pure document primitives shared by both PDL engines.

No source client, configuration, storage or optional integration is imported.
These helpers interpret neither business mappings nor authorization rules.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any


def value_at(document: dict, field: str):
    """Read a flat or dotted _source field without traversing arrays.

    An exact dotted key takes precedence over a nested representation, including
    when its value is None. Missing or non-object parents return None.
    """
    if field in document:
        return document[field]
    value = document
    for part in field.split('.'):
        if not isinstance(value, dict):
            return None
        value = value.get(part)
    return value


def canonical_hash(value: Any, *, compact: bool = True) -> str:
    """Hash sorted UTF-8 JSON while preserving the existing persisted formats.

    Schema/catalog hashes use compact separators. Historical relation profiles
    use JSON's spaced separators; compact=False preserves their fingerprints.
    A fingerprint detects changes and does not grant approval or access.
    """
    separators = (',', ':') if compact else None
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=separators).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()
