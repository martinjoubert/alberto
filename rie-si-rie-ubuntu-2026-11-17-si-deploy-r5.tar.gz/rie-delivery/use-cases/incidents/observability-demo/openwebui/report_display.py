"""
title: Incident native relay and report display (optional)
description: Require one native tool call and display its report; no business interpretation.
version: 1.1.0
"""
import json
import inspect
import re
from copy import deepcopy
from functools import wraps


def report_result(output,tool_name=None):
    """Read only a native MCP result linked to this assistant's tool invocation."""
    calls=[item for item in output if item.get('type')=='function_call'
           and (item.get('name')==tool_name if tool_name else item.get('name','').endswith('_diagnose_observability'))]
    if len(calls)!=1 or calls[0].get('status') not in ('completed','failed') or not calls[0].get('call_id'):return None
    linked=[item for item in output if item.get('type')=='function_call_output' and item.get('call_id')==calls[0]['call_id']]
    if len(linked)!=1:return None
    for part in linked[0].get('output',[]):
        try:
            value=json.loads(part.get('text',''))
            if isinstance(value,dict) and value.get('application')=='observability' and isinstance(value.get('answer'),str):
                if calls[0]['status']=='failed' and not (
                    value.get('assistant_contract')=='incident-dialogue-v1' and value.get('request_id')
                    and value.get('status') in ('denied','error','clarification','cancelled','rate_limited')
                    and not any(value.get(k) for k in ('evidence','sources','metrics','events','logs','documents','results','indices','dsl'))):return None
                return value
        except (ValueError,TypeError):pass
    return None


def previous_continuation(messages,name):
    """Select the last own UC turn, never an earlier handle after its cancellation/failure."""
    positions=[i for i,m in enumerate(messages) if m.get('role')=='user']
    for start,end in reversed(list(zip(positions,positions[1:]))):
        results=[];calls=set();selected=False
        for message in messages[start+1:end]:
            if message.get('role')=='assistant':
                own=[c for c in [*(message.get('output') or []),*(message.get('tool_calls') or [])]
                     if c.get('name',c.get('function',{}).get('name'))==name and (c.get('type')=='function_call' or isinstance(c.get('function'),dict))]
                selected=selected or bool(own)
                result=report_result(message.get('output',[]),name)
                if result:results.append(result)
                calls.update(c['id'] for c in message.get('tool_calls',[]) if c.get('function',{}).get('name')==name and c.get('id'))
            elif message.get('role')=='tool' and message.get('tool_call_id') in calls:
                try:result=json.loads(message.get('content',''))
                except (ValueError,TypeError):continue
                if isinstance(result,dict):results.append(result)
        if not selected:continue
        if len(results)!=1:return ''
        result=results[0];token=result.get('continuation_token','');contract=result.get('assistant_contract')
        resumable=contract=='incident-dialogue-v1' or contract is None and result.get('status')=='rate_limited'
        if result.get('application')=='observability' and resumable and isinstance(token,str) and re.fullmatch(r'[0-9a-f]{16}\.[0-9a-f]{32}',token):return token
        return ''
    return ''


def protect_arguments(metadata,name,question,continuation):
    tools=metadata.get('tools') or {};tool=tools.get(name) or {}
    spec=tool.get('spec') or {};fields=(spec.get('parameters') or {}).get('properties',{})
    original=tool.get('callable')
    if (tool.get('type')!='mcp' or tool.get('direct') is not False or spec.get('name')!=name
            or set(fields)!={'question','continuation_token'} or not inspect.iscoroutinefunction(original)):
        raise ValueError('Signature native MCP Incidents inattendue ; aucun appel transmis.')
    original=getattr(original,'_incident_original',original)
    @wraps(original,updated=())
    async def protected(**kwargs):
        if set(kwargs)-{'question','continuation_token'}:raise ValueError('Arguments MCP Incidents inattendus.')
        return await original(question=question,continuation_token=continuation)
    protected._incident_original=original
    metadata['tools']={**tools,name:{**tool,'callable':protected}}


class Filter:
    async def request(self,body:dict,__metadata__:dict=None)->dict:
        """Enforce transport only: one selected native call, then no further call."""
        messages=body.get('messages',[])
        last=max((i for i,m in enumerate(messages) if m.get('role')=='user'),default=-1)
        if last<0:return body
        if any(m.get('role')=='tool' for m in messages[last+1:]):
            # The outlet supplies the authoritative result; no second synthesis
            # by the conversational model is needed, including for a refusal.
            body.update(messages=[{'role':'user','content':'Réponds uniquement OK.'}],
                        tools=[],tool_choice='none',max_tokens=1)
            return body
        tools=body.get('tools') or []
        names=[t.get('function',{}).get('name','') for t in tools if t.get('type')=='function']
        if len(tools)!=1 or len(names)!=1 or not names[0].endswith('_diagnose_observability'):
            raise ValueError('Un unique outil MCP Incidents est requis pour ce modèle.')
        question=messages[last].get('content')
        if not isinstance(question,str) or not question.strip():raise ValueError('Un message textuel complet est requis.')
        continuation=previous_continuation(messages,names[0])
        if __metadata__ is None:raise ValueError('Métadonnées de l’outil natif absentes.')
        protect_arguments(__metadata__,names[0],question,continuation)
        # Arguments are already bound by the protected callable. The provider
        # only selects an empty call; it never serializes private state handles.
        body['tools']=deepcopy(tools)
        body['tools'][0]['function']['description']='Exécuter une lecture déjà préparée par le serveur. Ne choisir ni source ni argument métier.'
        body['tools'][0]['function']['parameters']={'type':'object',
            'properties':{'question':{'type':'string','enum':['']}},'required':['question'],'additionalProperties':False}
        body['messages']=[{'role':'system','content':
            f'Tu es un relais technique. Appelle exactement une fois la fonction de nom exact {names[0]}, sans abréger ni modifier ce nom, avec question vide. Ne rédige pas de réponse.'},
            {'role':'user','content':'Lancer l’appel de lecture préparé.'}]
        body['tool_choice']={'type':'function','function':{'name':names[0]}}
        body['parallel_tool_calls']=False
        return body

    async def outlet(self,body:dict)->dict:
        """Preserve backend wording in OpenWebUI; the MCP is usable without this filter."""
        messages=body.get('messages',[])
        if not messages or messages[-1].get('role')!='assistant':return body
        message=messages[-1];result=report_result(message.get('output',[]))
        text=result['answer'] if result else (
            'Le serveur n’a pas fourni de diagnostic vérifiable. Aucune preuve métier n’est publiée. '
            'Consultez le détail de l’appel pour identifier l’erreur.')
        message['content']=text
        message['output']=[item for item in message.get('output',[]) if item.get('type')!='message']+[
            {'type':'message','role':'assistant','status':'completed',
             'content':[{'type':'output_text','text':text}]}]
        return body
