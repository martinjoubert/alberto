"""Normalize equipment and time windows, then calculate facts without model calls."""
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import math
import re
import unicodedata
from urllib.parse import urlencode

def normalized(value):
    return ''.join(c for c in unicodedata.normalize('NFKD',value.casefold()) if not unicodedata.combining(c)).strip()

class QueryError(ValueError):
    """Only missing/ambiguous user fields are resumable clarification errors."""
    def __init__(self,message,fields=()):
        super().__init__(message);self.fields=tuple(fields)

def reference_period(question,start,end,reference_start='',reference_end=''):
    # The duration of an explicit previous hour is arithmetic, not a model
    # estimate. Other reference periods remain explicit validated ISO bounds.
    text=normalized(question)
    # Comparing symptoms with prior tickets is an analogy, not permission to
    # query another measurement window. Remove only that comparison clause;
    # an additional temporal comparison must still request validated bounds.
    current=r'(?:pistes?|hypotheses?|diagnostics?|symptomes?|observations?|signaux|mesures?|solutions?|situations?|cas)'
    history=r"(?:precedents(?:\s+itsm)?|(?:tickets|incidents)\s+(?:historiques|anterieurs|passes|resolus)|retours\s+d['’ ]experience)"
    article=r'(?:(?:le|la|les|des|ce|ces|cette)\s+)?'
    relation=r'(?:aux\s+|avec\s+'+article+r'|par\s+rapport\s+aux\s+)'
    for subject,target in ((r'(?:'+article+current+r'\s+)?',history),(article+history+r'\s+',current)):
        text=re.sub(r'\bcompar\w*\s+'+subject+relation+target+r'\b','',text)
    requested=bool(re.search(r'\b(?:compar\w*|vs|versus|ecart\w*)\b|\bpar rapport\b|\b(?:periode|fenetre) de reference\b|\breference\s*:?\s*du\b',text))
    declined=bool(re.search(r'\bsans (?:comparaison|reference)\b|\bne compar\w* pas\b',text))
    if not requested or declined:
        # Optional planner arguments may contain a previous turn's reference.
        # Only the current original question can authorize this extra period.
        return '', ''
    if re.search(r'\bcompar\w*\s+(?:les\s+|des\s+)?(?:deux\s+)?(?:routeurs|equipements|sites|perimetres)\b',text) and not re.search(r'\bavec\b|\bpar rapport\b|\breference\b|\bprecedent\w*\b',text):
        # Comparing authorized hosts inside one scope does not authorize
        # additional temporal reads or require another time window.
        return '', ''
    if re.search(r'\bcompar\w*\b',text) and re.search(r"\bl['’ ]heure precedente\b",text):
        a,_=window(start,end)
        return (a-timedelta(hours=1)).isoformat(),a.isoformat()
    if not reference_start or not reference_end:
        raise QueryError('Avec quelle période souhaitez-vous comparer le diagnostic ?',('reference_start','reference_end'))
    return reference_start,reference_end

def context(manifest, equipment='', scope='', start='', end='', reference_start='', reference_end=''):
    allowed = [h for h in manifest['hosts'] if h.get('allowed')]
    if not equipment and not scope: raise QueryError('Quel routeur ou périmètre souhaitez-vous consulter ?',('equipment','scope'))
    selected = allowed
    if equipment:
        # A canonical name followed by its alias still denotes one identity.
        # Every component must resolve to the SAME authorized host; this never
        # broadens an ambiguous pair such as R1/R2 into a multi-host query.
        identities=[normalized(v) for v in equipment.split('/')]
        matches=[{h['equipment'] for h in allowed if value in {normalized(a) for a in [h['equipment'],*h.get('aliases',[])]}} for value in identities]
        if 1<=len(matches)<=2 and all(matches) and len(set.union(*matches))>1:
            raise QueryError('Plusieurs routeurs possibles : lequel souhaitez-vous consulter ?',('equipment','scope'))
        selected = [h for h in selected if 1<=len(identities)<=2 and all(
            v in {normalized(a) for a in [h['equipment'],*h.get('aliases',[])]} for v in identities)]
        if len(selected)>1:raise QueryError('Alias ambigu : précisez le nom canonique de l’équipement.',('equipment','scope'))
    if scope:
        # Operator-defined scope aliases select one existing group, never a union.
        scope=next((target for alias,target in manifest.get('scope_aliases',{}).items()
                    if normalized(alias)==normalized(scope)),scope)
        groups=[h for h in allowed if normalized(h['scope'])==normalized(scope)]
        aliases=[h for h in allowed if normalized(scope) in {normalized(a) for a in [h['equipment'],*h.get('aliases',[])]}]
        if aliases:
            # A user may call R1 a "périmètre". Accept a unique authorized
            # identity whichever selector the planner used, never a union or
            # a guess. Conflicting equipment/scope still yields no selection.
            if len(aliases)!=1 or groups:raise QueryError('Alias ambigu : précisez le nom canonique de l’équipement.',('equipment','scope'))
            selected=[h for h in selected if h['equipment']==aliases[0]['equipment']]
            equipment=aliases[0]['equipment'];scope=''
        else:
            selected=[h for h in selected if h in groups]
    if not selected: raise QueryError('Équipement ou périmètre inconnu ou non autorisé. Précisez un périmètre autorisé.')
    if len(selected)>10: raise QueryError('Dix équipements maximum par diagnostic.')
    if not start or not end: raise QueryError('Sur quelle période ? Précisez la date complète et les heures de début et de fin (heure de Paris par défaut).',('start','end'))
    a,b = window(start,end)
    result={'equipment':equipment,'scope':scope,'equipment_ids':[h['equipment'] for h in selected],
            'start':a.isoformat(),'end':b.isoformat(),'timezone':'Europe/Paris'}
    if reference_start or reference_end:
        try:x,y=window(reference_start,reference_end)
        except QueryError as exc:raise QueryError('Quelle période de comparaison souhaitez-vous utiliser ? '+str(exc),('reference_start','reference_end')) from None
        result.update(reference_start=x.isoformat(),reference_end=y.isoformat())
    return result,selected

def window(start,end):
    try:
        a,b = [datetime.fromisoformat(v.replace('Z','+00:00')) for v in (start,end)]
        if a.utcoffset() is None or b.utcoffset() is None: raise ValueError()
        a,b=a.astimezone(timezone.utc),b.astimezone(timezone.utc)
        if not timedelta(0)<b-a<=timedelta(days=7): raise ValueError()
        if b>datetime.now(timezone.utc)+timedelta(minutes=1): raise ValueError()
        return a,b
    except (ValueError,TypeError): raise QueryError('Période invalide : précisez une date complète et un créneau valide, sept jours maximum, sans date future (heure de Paris par défaut).',('start','end')) from None


def pending_request(manifest,question,parameters,error):
    """Retain validated intent and slots, never observations or hidden selectors."""
    confirmed={key:'' for key in parameters};missing=list(error.fields)
    try:
        context(manifest,parameters['equipment'],parameters['scope'])
    except QueryError as exc:
        if exc.fields==('start','end'):
            confirmed.update({key:parameters[key] for key in ('equipment','scope')})
    try:
        a,b=window(parameters['start'],parameters['end'])
        confirmed.update(start=a.isoformat(),end=b.isoformat())
    except QueryError:
        missing.extend(key for key in ('start','end') if key not in missing)
    if confirmed['start'] and parameters['reference_start'] and parameters['reference_end']:
        try:
            a,b=window(parameters['reference_start'],parameters['reference_end'])
            confirmed.update(reference_start=a.isoformat(),reference_end=b.isoformat())
        except QueryError:pass
    selectors=sorted({h['equipment'] for h in manifest['hosts'] if h.get('allowed')} |
                     {h['scope'] for h in manifest['hosts'] if h.get('allowed')})[:20]
    return {'version':1,'question':question,'parameters':confirmed,'missing_fields':missing,
            'allowed_selectors':selectors}

def aggregate(rows,start,end,interval=60):
    from .contracts import interval as validate_interval
    interval=validate_interval(interval)
    a,b=window(start,end)
    values={}
    for row in rows:
        t=int(row['clock']); ns=int(row.get('ns',0)); value=float(row['value'])
        if a.timestamp()<=t+ns/1e9<b.timestamp() and math.isfinite(value): values[(t,ns)]=value
    ordered=sorted(values.items()); expected=math.ceil((b-a).total_seconds()/interval)
    slots={int((key[0]-a.timestamp())//interval) for key,_ in ordered}
    numbers=[v for _,v in ordered]
    return {'count':len(numbers),'expected':expected,'coverage_percent':round(min(len(slots),expected)*100/expected,2),
            'mean':round(sum(numbers)/len(numbers),3) if numbers else None,'max':max(numbers) if numbers else None,
            'last':numbers[-1] if numbers else None,
            'first_at':datetime.fromtimestamp(ordered[0][0][0],timezone.utc).isoformat() if ordered else None,
            'last_at':datetime.fromtimestamp(ordered[-1][0][0],timezone.utc).isoformat() if ordered else None}

def overlap(event,start,end):
    a,b=window(start,end); begin=int(event['clock']); finish=int(event.get('recovery_clock') or 0)
    return begin<b.timestamp() and (not finish or finish>a.timestamp())

def event_duration(event,start,end):
    a,b=window(start,end)
    return max(0,min(int(event.get('recovery_clock') or b.timestamp()),b.timestamp())-max(int(event['clock']),a.timestamp()))

def links(settings,host,start,end,metric=None,event=None):
    """Link only configured readers for the selected evidence provider.

    VictoriaMetrics and the ITSM simulator do not require Zabbix identifiers.
    An absent reader has no browser URL; source citations can remain plain IDs.
    """
    a,b=window(start,end)
    gf_base=getattr(settings,'grafana','').rstrip('/')
    gf=(gf_base+'/d/obs-network/diagnostic-reseau?'+urlencode({'var-router':host['equipment'],
        'var-interface':host.get('interface','uplink0'),'from':int(a.timestamp()*1000),
        'to':int(b.timestamp()*1000)-1,'timezone':'Europe/Paris'})) if gf_base else ''
    zb_base=getattr(settings,'zabbix_public','').rstrip('/')
    provider=getattr(settings,'metrics_provider','zabbix') if metric and not event else getattr(settings,'events_provider','zabbix')
    if provider!='zabbix' or not zb_base:
        zb=''
    elif event:
        zb=zb_base+'/tr_events.php?'+urlencode({'triggerid':event['objectid'],'eventid':event['eventid']})
    elif metric:
        zb=zb_base+'/history.php?'+urlencode({'action':'showgraph','itemids[]':host['items'][metric],
            'from':a.astimezone(ZoneInfo('Europe/Paris')).strftime('%Y-%m-%d %H:%M:%S'),
            'to':(b-timedelta(seconds=1)).astimezone(ZoneInfo('Europe/Paris')).strftime('%Y-%m-%d %H:%M:%S')})
    else:
        zb=zb_base+'/zabbix.php?'+urlencode({'action':'problem.view','filter_set':1,'show':2,'filter_custom_time':1,
            'hostids[]':host['hostid'],'from':a.astimezone(ZoneInfo('Europe/Paris')).strftime('%Y-%m-%d %H:%M:%S'),
            'to':(b-timedelta(seconds=1)).astimezone(ZoneInfo('Europe/Paris')).strftime('%Y-%m-%d %H:%M:%S')})
    return {'grafana':gf,'zabbix':zb}
