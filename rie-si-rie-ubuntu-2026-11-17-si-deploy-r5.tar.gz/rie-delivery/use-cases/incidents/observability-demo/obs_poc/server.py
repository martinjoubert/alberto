"""Serve bounded incident MCP and HTTP operations under the shared access controls."""
from contextlib import asynccontextmanager,AsyncExitStack
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextvars import copy_context
from datetime import datetime,timezone
from dataclasses import replace
from pathlib import Path
import hmac
import json
import os
import time
from typing import Any
from mcp.server.mcpserver import MCPServer
from mcp.types import ToolAnnotations
from starlette.applications import Starlette
from starlette.routing import Mount,Route
from starlette.responses import JSONResponse,HTMLResponse
from html import escape
import uvicorn
from dinum_access import protect, guard_result, access_information, require_indices, require_resources, AccessDenied
from .config import Settings,MODELS,ADAPTIVE_MODELS,CODE_REVISION,ROOT
from .service import Service
from .clients import Sources,SourceError
from .domain import context,QueryError
from .opensearch_links import logs_query,document_query,search_url
from .contracts import query_fields
from .assistant import assistant_server, Admission
from .agent_observability import (request_scope, technical_outcome, process_diagnostics,
    emit_diagnostic, diagnostic_event, diagnostic_cycle)
from dinum_albert.dialogue import Interpreter


def source_failure(exc):
    """Keep authorization refusals distinct from source/network availability."""
    denied = isinstance(exc, SourceError) and exc.source == 'authorization'
    return JSONResponse({'error': 'access_denied' if denied else 'source_unavailable'},
                        status_code=403 if denied else 503)


def create_app(settings=None, *, service_factory=None, observability=False, diagnostic_logger=None):
    s=settings or Settings()
    if not s.mcp_token:raise ValueError('MCP_TOKEN requis')
    # Native tool errors may include untrusted names. Choose the diagnostic log
    # policy at server construction even when distributed tracing is disabled.
    try:
        from dinum_observability.logging import install_mcp_log_filter
    except ModuleNotFoundError as exc:
        if exc.name not in {'dinum_observability', 'dinum_observability.logging'}:raise
    else:install_mcp_log_filter()
    if diagnostic_logger is None:diagnostic_logger=process_diagnostics()
    apps=[];routes=[]
    admission=Admission(float(os.getenv('OBS_MIN_TURN_INTERVAL_SECONDS','60')))
    def engine_for(settings):
        engine=service_factory(settings) if service_factory else Service(settings)
        engine.admission=admission
        return engine
    async def diagnose_http(request):
        """Run the existing incident analysis behind the existing access boundary."""
        with request_scope(request.headers, enabled=observability, diagnostic_logger=diagnostic_logger) as run:
            def invalid(code='invalid_request', status_code=400):
                technical_outcome(run, {'status': 'error'})
                diagnostic_event('rie.tool.validation_failed', code='business_validation')
                headers={}
                if run is not None and run.metadata.get('rie.execution.id') and run.trace_id:
                    headers={'X-RIE-Execution-Id':run.metadata['rie.execution.id'],'X-RIE-Trace-Id':run.trace_id}
                return JSONResponse({'error':code},status_code=status_code,headers=headers)
            body=bytearray()
            try:
                async for chunk in request.stream():
                    body.extend(chunk)
                    if len(body)>16384:return invalid('request_too_large',413)
                payload=json.loads(body)
            except (ValueError,UnicodeDecodeError):
                return invalid()
            allowed={'question','variant','equipment','scope','start','end','reference_start','reference_end','synthesize'}
            if not isinstance(payload,dict) or set(payload)-allowed:return invalid()
            question=payload.get('question')
            if not isinstance(question,str) or not 1<=len(question)<=2000:return invalid()
            variant=payload.get('variant','gptoss')
            if not isinstance(variant,str) or variant not in MODELS:return invalid()
            parameters={name:payload.get(name,'') for name in ('equipment','scope','start','end','reference_start','reference_end')}
            if any(not isinstance(value,str) or len(value)>100 for value in parameters.values()):return invalid()
            synthesize=payload.get('synthesize',True)
            if type(synthesize) is not bool:return invalid()
            access=access_information(question)
            if access is not None:
                result={**access,'application':'observability','status':'ok'}
            else:
                def execute():
                    engine=engine_for(s)
                    try:
                        with admission.turn():
                            return guard_result(engine.diagnose(variant,question,**parameters,synthesize=synthesize))
                    finally:engine.sources.close()
                # A synchronous source read cannot be cancelled safely midway.
                # Keep the execution open until its bounded worker has drained,
                # then report cancellation without publishing a false terminal.
                worker=asyncio.create_task(asyncio.to_thread(execute))
                stop_watching=asyncio.Event()
                async def disconnected():
                    while not stop_watching.is_set():
                        if await request.is_disconnected():return True
                        await asyncio.sleep(.02)
                    return False
                watcher=asyncio.create_task(disconnected())
                try:
                    finished,_=await asyncio.wait((worker,watcher),return_when=asyncio.FIRST_COMPLETED)
                    if watcher in finished and not worker.done():
                        technical_outcome(run, {'status': 'cancelled'})
                        await asyncio.shield(worker)
                        return JSONResponse({'error':'client_disconnected'},status_code=499)
                    result=await worker
                except asyncio.CancelledError:
                    technical_outcome(run, {'status': 'cancelled'})
                    await asyncio.shield(worker)
                    raise
                finally:
                    # Starlette's disconnect probe has its own cancellation
                    # scope; use an explicit stop instead of cancelling inside
                    # that scope and accidentally swallowing task cancellation.
                    stop_watching.set()
                    await watcher
            technical_outcome(run,result)
            headers={}
            if run is not None and run.metadata.get('rie.execution.id') and run.trace_id:
                headers={'X-RIE-Execution-Id':run.metadata['rie.execution.id'],'X-RIE-Trace-Id':run.trace_id}
            return JSONResponse(result,headers=headers)
    def runtime_settings(variant):
        if variant not in ADAPTIVE_MODELS:return s
        token=Path(os.getenv('BALANCER_TOKEN_FILE',str(ROOT.parents[2]/'simulation-rie/infrastructure-demo/secrets/balancer_token'))).read_text().strip()
        return replace(s,albert='http://127.0.0.1:9960/v1',albert_key=token,generation_timeout=100,diagnostic_timeout=240)
    for variant in MODELS | ADAPTIVE_MODELS:
        server=MCPServer(name='obs-'+variant,instructions='Diagnostic réseau en lecture seule, chiffres calculés par le serveur, citations vérifiées.')
        def make_tool(v):
            def diagnose(question:str,equipment:str='',scope:str='',start:str='',end:str='',reference_start:str='',reference_end:str='')->dict[str,Any]:
                """Diagnose network issues using fresh, read-only evidence.

                equipment is one router: OBS-RTR-01/02/03, with aliases R1/R2/R3.
                scope is Site de Rennes (legacy alias Alpha) or Beta. Keep missing selectors and timezone-aware
                ISO start/end empty; the server returns a clarification question
                and a bounded pending request. Never invent a selector or date.
                Pass unknown selectors for server authorization. Reference bounds
                are optional and require an explicit comparison request. Call once
                per user turn; earlier reports are never current evidence.
                """
                with diagnostic_cycle(diagnostic_logger):
                    access = access_information(question)
                    if access is not None:
                        result = {**access, 'application': 'observability', 'status': 'ok'}
                    else:
                        settings = runtime_settings(v)
                        engine=engine_for(settings)
                        try:
                            with admission.turn():
                                result=guard_result(engine.diagnose(v,question,equipment,scope,start,end,reference_start,reference_end))
                        finally:engine.sources.close()
                    technical_outcome(None, result)
                    return result
            return diagnose
        server.tool(name='diagnose_observability',structured_output=True,annotations=ToolAnnotations(readOnlyHint=True,destructiveHint=False,idempotentHint=True,openWorldHint=False))(make_tool(variant))
        sub=server.streamable_http_app(streamable_http_path='/mcp',json_response=True,stateless_http=True,host='0.0.0.0',max_request_body_size=16384)
        apps.append(sub);routes.append(Mount('/'+variant,app=sub))
        def execute(question,_variant=variant,**parameters):
            engine=engine_for(runtime_settings(_variant))
            try:return guard_result(engine.diagnose(_variant,question,**parameters))
            finally:engine.sources.close()
        def interpreter(message,state,_variant=variant):
            dialogue_settings=runtime_settings(_variant)
            return Interpreter(dialogue_settings.albert,dialogue_settings.albert_key,
                os.getenv('OBS_DIALOGUE_MODEL') or dialogue_settings.model(_variant),verify=dialogue_settings.ca_file or True,domain='incidents')(message,state)
        portable=assistant_server(s,variant,execute,admission,interpreter=interpreter)
        portable_app=portable.streamable_http_app(streamable_http_path='/mcp',json_response=True,
            stateless_http=True,host='0.0.0.0',max_request_body_size=16384)
        apps.append(portable_app)
        routes.insert(0,Mount('/'+variant+'/assistant',app=portable_app))
    async def health(request):return JSONResponse({'status':'ok','application':'observability',
        'models':{variant:s.model(variant) for variant in MODELS},'code_revision':CODE_REVISION})
    def authorize_incidents():
        require_indices(s.logs_index+','+s.docs_index)
        require_resources(('incidents.metrics','incidents.tickets'))
    def status(request):
        try:authorize_incidents()
        except AccessDenied:return JSONResponse({'error':'access_denied'},status_code=403)
        try:
            m=s.manifest()
            result={k:m[k] for k in ('status','anchor_date','start','end')}
            if any(not isinstance(value,str) or not value.strip() for value in result.values()):raise ValueError()
            hosts=m['hosts']
            if not isinstance(hosts,list) or not hosts or any(not isinstance(h,dict) or type(h['allowed']) is not bool for h in hosts):raise ValueError()
            # The portable deterministic seed has no preparation timestamp.
            # Preserve historical timestamps without making business data optional.
            result['prepared_at']=m.get('prepared_at')
            if result['prepared_at'] is not None and (not isinstance(result['prepared_at'],str) or not result['prepared_at'].strip()):raise ValueError()
            result['hosts']=[h for h in hosts if h['allowed']]
            result['data_flow']=m.get('data_flow',{})
            if not isinstance(result['data_flow'],dict):raise ValueError()
            return JSONResponse(result)
        except (OSError,ValueError,KeyError,TypeError):return JSONResponse({'status':'not_prepared'},status_code=503)
    def document(request):
        try:require_indices(s.docs_index)
        except AccessDenied:return JSONResponse({'error':'access_denied'},status_code=403)
        sources=Sources(s)
        try:
            hosts=[h['equipment'] for h in s.manifest()['hosts'] if h['allowed']]
            doc=sources.document(request.path_params['identifier'],hosts)
            if doc:
                fields=s.manifest().get('source_fields',{}).get('documents')
                query=document_query(doc['record_id'],hosts,fields)
                doc['opensearch']={'index':s.docs_index,'query':query,'url':search_url(s.opensearch_public,s.docs_index,query)}
                doc['corpus_synthetic']=bool(s.manifest().get('synthetic'))
            return JSONResponse(doc or {'error':'not_found'},status_code=200 if doc else 404)
        except (SourceError,OSError,ValueError) as exc:return source_failure(exc)
        finally:sources.close()
    def readiness(request):
        try:authorize_incidents()
        except AccessDenied:return JSONResponse({'error':'access_denied'},status_code=403)
        def check(name):
            sources=Sources(s)
            try:
                hosts=[h for h in s.manifest()['hosts'] if h['allowed']]
                if name=='victoriametrics':
                    if not sources.measurements(hosts[0],'cpu',s.manifest()['start'],s.manifest()['end']):
                        return {'service':name,'status':'partial','detail':'Aucune mesure disponible sur la fenêtre de contrôle.'}
                elif name=='itsm-ng-simulator':
                    from .telemetry import tickets
                    tickets(s,hosts)
                elif name=='itsm-ng-history':
                    sources.deadline=min(sources.deadline,time.monotonic()+8)
                    sources.historical_tickets({'start':s.manifest()['start'],'end':s.manifest()['end'],
                        'equipment_ids':[host['equipment'] for host in hosts]},['couverture','chronologie'])
                elif name=='zabbix':
                    visible=sources.rpc('host.get',{'hostids':[h['hostid'] for h in hosts],'output':['hostid']})
                    if {h['hostid'] for h in visible}!={h['hostid'] for h in hosts}:
                        return {'service':name,'status':'partial','detail':'Périmètre incomplet ou non autorisé.'}
                elif name=='opensearch':
                    for index,kind in ((s.logs_index,'logs'),(s.docs_index,'documents')):
                        fields=query_fields(kind,s.manifest().get('source_fields',{}).get(kind))
                        sources.os(index,{'size':0,'query':{'terms':{fields['equipment']:[h['equipment'] for h in hosts]}}})
                else:sources.request('grafana','GET',s.grafana.rstrip('/')+'/api/health')
                return {'service':name,'status':'ok','detail':'Lecture vérifiée.'}
            except SourceError as exc:return {'service':name,'status':'unavailable','detail':exc.code}
            except (OSError,ValueError,KeyError,IndexError):return {'service':name,'status':'unavailable','detail':'Configuration ou corpus invalide.'}
            finally:sources.close()
        names=tuple(dict.fromkeys((s.metrics_provider,s.events_provider,'opensearch')+
            (('itsm-ng-history',) if s.itsm_history_config is not None else ())+(('grafana',) if s.grafana else ())))
        with ThreadPoolExecutor(max_workers=4) as pool:
            # A new thread does not inherit the authenticated ContextVar by itself.
            states=[future.result() for future in [pool.submit(copy_context().run,check,name) for name in names]]
        ready=all(row['status']=='ok' for row in states)
        states.append({'service':'albert','status':'not_probed','detail':'Vérifié lors du diagnostic ; aucun appel de génération pour ce contrôle.'})
        return JSONResponse({'ready':ready,'read_at':datetime.now(timezone.utc).isoformat(),'services':states},status_code=200 if ready else 503)
    def log_view(request):
        try:require_indices(s.logs_index)
        except AccessDenied:return JSONResponse({'error':'access_denied'},status_code=403)
        sources=Sources(s)
        try:
            args={k:request.query_params.get(k,'') for k in ('equipment','scope','start','end')}
            ctx,_=context(s.manifest(),**args)
            result=sources.logs(ctx['equipment_ids'],ctx['start'],ctx['end'])
            fields=s.manifest().get('source_fields',{}).get('logs')
            query=logs_query(ctx['equipment_ids'],ctx['start'],ctx['end'],fields)
            result.update(context=ctx,opensearch={'index':s.logs_index,'query':query,'url':search_url(s.opensearch_public,s.logs_index,query)})
            return JSONResponse(result)
        except QueryError:return JSONResponse({'error':'invalid_scope_or_period'},status_code=400)
        except (SourceError,OSError,ValueError) as exc:return source_failure(exc)
        finally:sources.close()
    def itsm_ticket(request):
        try:require_resources('incidents.tickets')
        except AccessDenied:return JSONResponse({'error':'access_denied'},status_code=403)
        # Shared fictional corpus only; no excluded equipment or arbitrary file path.
        from .telemetry import tickets
        try:
            if s.events_provider!='itsm-ng-simulator':return JSONResponse({'error':'simulator_disabled'},status_code=404)
            rows=tickets(s,[h for h in s.manifest()['hosts'] if h['allowed']])
            row=next((r['ticket'] for r in rows if r['eventid']==request.path_params['identifier']),None)
            if row is None:return JSONResponse({'error':'not_found'},status_code=404)
            text=escape(json.dumps(row,ensure_ascii=False,indent=2))
            return HTMLResponse('<!doctype html><html lang="fr"><meta charset="utf-8"><title>Ticket fictif '+escape(row['id'])+'</title><h1>ITSM-NG — simulateur de démonstration</h1><p>Données fictives, lecture seule. Ce lecteur ne représente pas une instance ITSM-NG réelle.</p><p>La résolution technique de l’alerte est distincte de la clôture administrative du ticket.</p><pre>'+text+'</pre></html>')
        except (SourceError,OSError,ValueError) as exc:return source_failure(exc)
    @asynccontextmanager
    async def lifespan(app):
        async with AsyncExitStack() as stack:
            for sub in apps:await stack.enter_async_context(sub.router.lifespan_context(sub))
            emit_diagnostic(diagnostic_logger, 'rie.application.started', code='startup')
            try:yield
            finally:emit_diagnostic(diagnostic_logger, 'rie.application.stopped', code='shutdown')
    application=Starlette(routes=[Route('/healthz',health),Route('/status',status),Route('/readiness',readiness),Route('/diagnose',diagnose_http,methods=['POST']),Route('/demo-itsm/tickets/{identifier}',itsm_ticket),Route('/documents/{identifier}',document),Route('/logs',log_view),*routes],lifespan=lifespan)
    class Auth:
        async def __call__(self,scope,receive,send):
            if scope['type']=='http' and scope['path'] not in ('/healthz','/status') and not scope['path'].startswith('/demo-itsm/tickets/') and not hmac.compare_digest(dict(scope['headers']).get(b'authorization',b''),('Bearer '+s.mcp_token).encode()):
                emit_diagnostic(diagnostic_logger, 'rie.authentication.failed', code='invalid_credentials')
                await JSONResponse({'error':'unauthorized'},status_code=401)(scope,receive,send);return
            await application(scope,receive,send)
    from dinum_access.oauth import install
    return install(protect(Auth(), service_token=s.mcp_token, diagnostic_logger=diagnostic_logger), 'incidents')

if __name__=='__main__':uvicorn.run(create_app(),host=os.getenv('BIND_ADDRESS','127.0.0.1'),port=int(os.getenv('MCP_PORT','9950')),log_level='warning')
