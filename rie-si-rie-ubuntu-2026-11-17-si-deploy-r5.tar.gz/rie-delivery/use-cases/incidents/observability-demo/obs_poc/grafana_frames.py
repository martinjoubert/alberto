"""Identify actual Grafana metric frames for qualification of both providers."""
import json
import re
from .config import Settings


def metric_key(field,queries=()):
    if field.get('type')!='number':return None
    labels=field.get('labels',{})
    if labels.get('item_key','').startswith('obs.'):return labels['item_key']
    mapping=json.loads(Settings().metric_mapping.read_text(encoding='utf-8'))['metrics']
    matches={key for key,spec in mapping.items() if labels.get('__name__')==spec['name']}
    # Rollup functions can remove __name__. The actual panel request still
    # identifies the metric; accept exactly one mapped name, never guess.
    if not matches:
        matches={key for key,spec in mapping.items() for query in queries
                 if re.search(r'(?<![a-zA-Z0-9_:])'+re.escape(spec['name'])+r'\s*\{',query.get('expr',''))}
    return 'obs.'+next(iter(matches)) if len(matches)==1 else None


def metric_equipment(field):
    labels=field.get('labels',{})
    return labels.get('equipment') or labels.get('host')
