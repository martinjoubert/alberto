"""Deterministic transports around the real Incidents engine, laboratory only.

No client, network, telemetry configuration or native conversation is created.
The simulated model deliberately consumes the actual RAG evidence produced by
Service; its result is a transport test, not evidence of LLM quality.
"""
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import tempfile

from dinum_albert.recommendation_release import dumps_release
from .config import Settings
from .service import Service, SYSTEM, REVIEW
from .recommendation_context import recommendation_descriptor
from .clients import SourceError

START = '2026-09-28T10:00:00+02:00'
END = '2026-09-28T12:00:00+02:00'
QUESTION = 'Examiner la latence et la congestion possibles, sans exécuter d’action.'


def manifest():
    return {'synthetic': True, 'hosts': [
        {'equipment': 'OBS-RTR-01', 'aliases': ['R1'], 'number': 1,
         'scope': 'Alpha', 'hostid': '1', 'allowed': True,
         'items': {key: '1:' + key for key in ('cpu', 'latency', 'loss', 'in', 'out')}},
        {'equipment': 'OBS-RTR-04', 'aliases': ['R4'], 'number': 4,
         'scope': 'Beta', 'hostid': '4', 'allowed': False, 'items': {}},
    ]}


class DemoSources:
    def __init__(self):
        self.model_inputs = []

    def history(self, item, start, end):
        number, key = item.split(':')
        if number != '1':
            raise SourceError('authorization', 'fixture_scope_forbidden')
        values = {'cpu': 25, 'latency': 80, 'loss': 2, 'in': 92, 'out': 85}
        begin = datetime.fromisoformat(start)
        return [{'clock': int((begin + timedelta(minutes=i)).timestamp()), 'ns': 0,
                 'value': values[key]} for i in range(120)]

    def events(self, *_args):
        return []

    def logs(self, equipment, *_args):
        if equipment != ['OBS-RTR-01']:
            raise SourceError('authorization', 'fixture_scope_forbidden')
        return {'total': 3, 'counts': {'congestion': 3},
                'by_equipment': {'OBS-RTR-01': {'congestion': 3}},
                'rows': [], 'truncated': False}

    def documents(self, equipment, _terms):
        if equipment != ['OBS-RTR-01']:
            raise SourceError('authorization', 'fixture_scope_forbidden')
        return [{'record_id': 'DOC-001', 'kind': 'document',
                 'title': 'Vérifications de congestion — fiche fictive',
                 'text': 'Consulter les courbes en lecture seule. Une concordance ne démontre pas la cause.',
                 'equipment': ['OBS-RTR-01'], 'date': '2026-09-28',
                 'keywords': ['congestion', 'latence'], 'truncated': False}]

    def request(self, source, method, _url, **kwargs):
        if source != 'albert' or method != 'POST':
            raise SourceError('fixture', 'unexpected_transport')
        messages = kwargs['json']['messages']
        evidence = json.JSONDecoder().raw_decode(messages[1]['content'])[0]
        if 'Contrôle factuel' in messages[0]['content']:
            result = {'valid': True, 'reason': 'Transport de revue simulé pour la recette documentaire.'}
        else:
            self.model_inputs.append(evidence)
            approved = next((doc for doc in evidence['documents']
                             if doc.get('origin') == 'approved_feedback'), None)
            verification = {'text': approved['text'] if approved else 'Consulter les courbes en lecture seule.',
                            'sources': [approved['source_id'] if approved else 'S1']}
            result = {'situation': 'Une congestion est possible sans cause démontrée.',
                      'hypotheses': [{'text': 'La saturation pourrait expliquer les ralentissements.', 'sources': ['S1']}],
                      'verifications': [verification]}
        return {'model': 'fixture-incidents-no-provider',
                'choices': [{'message': {'content': json.dumps(result, ensure_ascii=False)}}],
                'usage': {'total_tokens': None}}

    def close(self):
        pass


def run_demo(release=None):
    with tempfile.TemporaryDirectory(prefix='rie-incidents-recommendation-demo-') as directory:
        root = Path(directory)
        release_path = None
        release_sha = ''
        if release is not None:
            release_path = root / 'approved-release.json'
            content = dumps_release(release)
            release_path.write_text(content, encoding='utf-8')
            release_sha = hashlib.sha256(content.encode('utf-8')).hexdigest()
        settings = Settings(reports=root / 'reports', recommendation_release=release_path,
            recommendation_release_sha256=release_sha,
            albert='http://fixture.invalid/v1', albert_key='fixture-no-credential',
            zabbix_token='', os_password='', os_user='', mcp_token='fixture-no-credential',
            victoria_token='', ca_file='', metrics_provider='zabbix', events_provider='zabbix')
        settings.manifest = manifest
        sources = DemoSources()
        report = Service(settings, sources).diagnose('gemma', QUESTION,
            equipment='R1', start=START, end=END, synthesize=True)
        report.update(fixture=True, model_simulated=True)
        report['recommendation_context'] = recommendation_descriptor(report, SYSTEM, REVIEW)
        return report, {
            **report.get('recommendation_release', {}),
            'selected_document_ids': [doc['record_id'] for doc in report['documents']
                                      if doc.get('origin') == 'approved_feedback'],
            'rag_document_ids': [doc['record_id'] for evidence in sources.model_inputs
                                  for doc in evidence['documents']],
            'model_simulated': True, 'si_accessed': False,
        }
