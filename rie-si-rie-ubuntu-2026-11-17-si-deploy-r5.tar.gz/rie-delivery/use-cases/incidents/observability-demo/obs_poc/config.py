"""Define incident settings, source providers and deferred private configuration reads."""
from dataclasses import dataclass, field
import hashlib
import json
import os
import re
from pathlib import Path
from .contracts import validate_manifest

ROOT = Path(__file__).resolve().parents[1]
CODE_REVISION = hashlib.sha256(b''.join((ROOT/'obs_poc'/name).read_bytes()
    for name in ('config.py','contracts.py','domain.py','clients.py','service.py','server.py','assistant.py','opensearch_links.py','focused_answer.py','telemetry.py','recommendation_context.py','itsm_history.py','precedents.py'))).hexdigest()
MODELS = {'gemma': 'gemma-4-31b-it', 'gptoss': 'gpt-oss-120b', 'deepseek': 'deepseek-v4-flash-0731'}
ADAPTIVE_MODELS = {'auto': 'albert-auto', 'auto-qualification': 'albert-auto-qualification'}
LABELS = {'gemma': 'Gemma 4 31B', 'gptoss': 'GPT-OSS 120B', 'deepseek': 'DeepSeek V4 Flash'}
GROUP = 'DINUM Observabilite synthetique'
METRICS = {'cpu': ('CPU', '%'), 'latency': ('Latence', 'ms'), 'loss': ('Pertes', '%'),
           'in': ('Utilisation entrante', '%'), 'out': ('Utilisation sortante', '%')}

def env_file(path):
    if not path.exists(): return {}
    return {k.strip(): v.strip().strip('"').strip("'") for line in path.read_text(encoding='utf-8-sig').splitlines()
            if '=' in line and not line.lstrip().startswith('#') for k,v in [line.split('=',1)]}

def secret(name):
    path = Path(os.getenv(name+'_FILE', str(ROOT/'deploy/secrets'/name.lower())))
    return os.getenv(name) or (path.read_text(encoding='utf-8').strip() if path.exists() else '')

@dataclass
class Settings:
    review_model: str = field(default_factory=lambda: os.getenv('OBS_REVIEW_MODEL', ''))
    generation_timeout: float = field(default_factory=lambda: float(os.getenv('OBS_GENERATION_TIMEOUT', '60')))
    diagnostic_timeout: float = field(default_factory=lambda: float(os.getenv('OBS_DIAGNOSTIC_TIMEOUT', '150')))
    opensearch: str = field(default_factory=lambda: os.getenv('OPENSEARCH_URL','http://127.0.0.1:9200'))
    opensearch_public: str = field(default_factory=lambda: os.getenv('OPENSEARCH_PUBLIC_URL','http://127.0.0.1:9200'))
    zabbix: str = field(default_factory=lambda: os.getenv('ZABBIX_API_URL','http://127.0.0.1:8081/api_jsonrpc.php'))
    zabbix_public: str = field(default_factory=lambda: os.getenv('ZABBIX_PUBLIC_URL','http://127.0.0.1:8081'))
    grafana: str = field(default_factory=lambda: os.getenv('GRAFANA_PUBLIC_URL','http://127.0.0.1:3000'))
    portal: str = field(default_factory=lambda: os.getenv('PORTAL_PUBLIC_URL','http://127.0.0.1:8090'))
    albert: str = field(default_factory=lambda: os.getenv('ALBERT_API_BASE_URL','https://albert.api.etalab.gouv.fr/v1'))
    albert_key: str = field(default_factory=lambda: secret('ALBERT_KEY'))
    zabbix_token: str = field(default_factory=lambda: secret('ZABBIX_TOKEN'))
    os_user: str = field(default_factory=lambda: os.getenv('OPENSEARCH_USER',''))
    os_password: str = field(default_factory=lambda: secret('OPENSEARCH_PASSWORD'))
    mcp_token: str = field(default_factory=lambda: secret('MCP_TOKEN'))
    ca_file: str = field(default_factory=lambda: os.getenv('CA_BUNDLE',''))
    metrics_provider: str = field(default_factory=lambda: os.getenv('OBS_METRICS_PROVIDER','zabbix'))
    events_provider: str = field(default_factory=lambda: os.getenv('OBS_EVENTS_PROVIDER','zabbix'))
    victoria: str = field(default_factory=lambda: os.getenv('VICTORIAMETRICS_URL','http://127.0.0.1:8428'))
    victoria_token: str = field(default_factory=lambda: secret('VICTORIAMETRICS_TOKEN'))
    metric_mapping: Path = field(default_factory=lambda: Path(os.getenv('OBS_METRIC_MAPPING',str(ROOT/'fixtures/metric-mapping.json'))))
    itsm_snapshot: Path = field(default_factory=lambda: Path(os.getenv('ITSM_DEMO_SNAPSHOT',str(ROOT/'fixtures/itsm-tickets.json'))))
    itsm_public: str = field(default_factory=lambda: os.getenv('ITSM_DEMO_PUBLIC_URL','http://127.0.0.1:9950/demo-itsm/tickets'))
    itsm_history_config: Path | None = field(default_factory=lambda:
        Path(os.environ['OBS_ITSM_HISTORY_CONFIG']) if os.getenv('OBS_ITSM_HISTORY_CONFIG') else None)
    logs_index: str = field(default_factory=lambda: os.getenv('OBS_LOGS_INDEX','obs-network-logs'))
    docs_index: str = field(default_factory=lambda: os.getenv('OBS_DOCS_INDEX','obs-network-docs'))
    manifest_path: Path = field(default_factory=lambda: Path(os.getenv('OBS_MANIFEST',str(ROOT/'reports/corpus.json'))))
    reports: Path = field(default_factory=lambda: Path(os.getenv('OBS_REPORTS',str(ROOT/'.runtime/investigations'))))
    recommendation_release: Path | None = field(default_factory=lambda:
        Path(os.environ['OBS_RECOMMENDATION_RELEASE_FILE']) if os.getenv('OBS_RECOMMENDATION_RELEASE_FILE') else None)
    recommendation_release_sha256: str = field(default_factory=lambda: os.getenv('OBS_RECOMMENDATION_RELEASE_SHA256', ''))

    def manifest(self):
        return validate_manifest(json.loads(self.manifest_path.read_text(encoding='utf-8')))

    def model(self, variant):
        defaults = MODELS | ADAPTIVE_MODELS
        if variant not in defaults:
            raise ValueError('Unknown model preset.')
        configured = os.getenv('OBS_MODEL_' + variant.upper().replace('-', '_'))
        if configured is None and variant == 'gptoss':
            configured = os.getenv('ALBERT_MODEL')
        value = configured if configured is not None else defaults[variant]
        if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,127}', value):
            raise ValueError('A model identifier must contain at most 128 plain identifier characters.')
        return value


    def review_model_for(self, draft_model):
        value=self.review_model or draft_model
        if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,127}',value):
            raise ValueError('A review model identifier must contain at most 128 plain identifier characters.')
        return value
