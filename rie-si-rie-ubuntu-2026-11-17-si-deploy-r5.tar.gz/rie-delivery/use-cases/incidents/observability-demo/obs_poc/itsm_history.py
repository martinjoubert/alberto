"""Bounded, per-user, read-only ITSM-NG 1.6.17 history adapter.

Contract: upstream tag v1.6.17, commit 58a7a9fd7a5b2ef230c9c46ea2d846381c8e3f93.
Collections enumerate IDs only. Each ticket/child is fetched individually so
native canViewItem checks (especially private followups) remain authoritative.
"""
import asyncio
from datetime import datetime, timedelta, timezone
import json
import os
from pathlib import Path
import re
import stat
import ssl
import time
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

import httpx
from dinum_access import AccessDenied, require_resources
from dinum_access.security import CURRENT

from .clients import SourceError

VERSION = '1.6.17'
MAX_BYTES = 2_000_000


def authorized():
    try:
        require_resources('incidents.tickets')
    except AccessDenied:
        raise SourceError('authorization', 'resource_forbidden') from None


def private_json(path):
    path = Path(path)
    if not path.is_absolute() or any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('Invalid private path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077:
            raise ValueError('Private files require mode 0600')
        raw = stream.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError('Private file limit')
    return json.loads(raw)


def configuration(path):
    data = private_json(path)
    if data.get('version') != 1 or data.get('target_version') != VERSION:
        raise ValueError('ITSM-NG 1.6.17 configuration required')
    if data.get('provider') not in {'itsm-ng', 'fixture'}:
        raise ValueError('Unknown ITSM history provider')
    ZoneInfo(data.get('timezone', 'Europe/Paris'))
    if type(data.get('synthetic', False)) is not bool:
        raise ValueError('Explicit boolean history provenance required')
    if data['provider'] == 'fixture':
        if os.getenv('PDL_MODE') != 'demo':
            raise ValueError('Synthetic history requires demo mode')
    else:
        url = urlsplit(data.get('api_url', ''))
        loopback = os.getenv('PDL_MODE') == 'demo' and url.hostname in {'127.0.0.1', 'localhost'}
        if (url.scheme != 'https' and not (loopback and url.scheme == 'http')
                or not url.hostname or url.username or url.password or url.query or url.fragment
                or not url.path.endswith('/apirest.php')):
            raise ValueError('Configure an explicit HTTPS apirest.php endpoint')
        public = urlsplit(data.get('public_url', ''))
        if public.scheme != 'https' or not public.hostname or public.username or public.password or public.query or public.fragment:
            raise ValueError('Configure an explicit HTTPS public ITSM URL')
        if not isinstance(data.get('credentials_file'), str):
            raise ValueError('Individual ITSM credentials required')
    return data


def identifier(value):
    if isinstance(value, bool) or not re.fullmatch(r'[1-9][0-9]{0,14}', str(value)):
        raise ValueError('Invalid ITSM identifier')
    return str(value)


def timestamp(value, zone):
    date = datetime.fromisoformat(value)
    if date.tzinfo is None:
        # A repeated or missing local clock cannot be guessed during DST changes.
        local = date.replace(tzinfo=ZoneInfo(zone))
        if local.utcoffset() != local.replace(fold=1).utcoffset():
            raise ValueError('Ambiguous ITSM local time')
        if local.astimezone(timezone.utc).astimezone(ZoneInfo(zone)).replace(tzinfo=None) != date:
            raise ValueError('Nonexistent ITSM local time')
        date = local
    return date.astimezone(timezone.utc)


class History:
    def __init__(self, sources, config):
        self.sources, self.config = sources, config
        self.session = ''
        self.headers = {'Content-Type': 'application/json'}
        self.deadline = min(sources.deadline, time.monotonic() + 25)

    def get(self, endpoint, params=None):
        authorized()
        if not re.fullmatch(r'(?:initSession|killSession|getFullSession|listSearchOptions/Ticket|search/Ticket|Ticket/[1-9][0-9]*(?:/(?:ITILSolution|ITILFollowup|Item_Ticket))?|(?:ITILSolution|ITILFollowup|NetworkEquipment)/[1-9][0-9]*)', endpoint):
            raise SourceError('itsm-ng', 'endpoint_not_allowed')
        remaining = min(self.deadline - time.monotonic(), self.sources.remaining_budget('itsm-ng', 10))
        if remaining <= 0:
            raise SourceError('itsm-ng', 'deadline_exceeded')
        async def read():
            # Total cancellation includes connect, headers and a dribbling body.
            async with asyncio.timeout(remaining):
                async with httpx.AsyncClient(verify=ssl.create_default_context(cafile=self.sources.s.ca_file)
                        if self.sources.s.ca_file else True, trust_env=False,
                        transport=getattr(self.sources, 'history_transport', None)) as client:
                    async with client.stream('GET', self.config['api_url'].rstrip('/') + '/' + endpoint,
                            headers=self.headers, params=params, timeout=remaining, follow_redirects=False) as response:
                        if response.status_code in {401, 403}:
                            raise SourceError('itsm-ng', 'native_access_denied')
                        if response.status_code not in {200, 206}:
                            raise SourceError('itsm-ng', 'http_' + str(response.status_code))
                        raw = bytearray()
                        async for block in response.aiter_bytes():
                            raw.extend(block)
                            if len(raw) > MAX_BYTES:
                                raise SourceError('itsm-ng', 'response_limit')
                        authorized()
                        return json.loads(raw), response.headers
        try:
            return asyncio.run(read())
        except TimeoutError:
            raise SourceError('itsm-ng', 'deadline_exceeded') from None
        except httpx.TimeoutException:
            raise SourceError('itsm-ng', 'timeout') from None
        except (httpx.HTTPError, ValueError):
            raise SourceError('itsm-ng', 'invalid_or_unavailable_response') from None

    def collection(self, endpoint):
        result, expected = [], None
        for offset in range(0, 200, 50):
            rows, headers = self.get(endpoint, {'range': f'{offset}-{offset+49}', 'only_id': 'true', 'get_hateoas': 'false'})
            if not isinstance(rows, list):
                raise SourceError('itsm-ng', 'invalid_collection')
            match = re.fullmatch(r'(\d+)-(\d+)/(\d+)', headers.get('content-range', ''))
            if not rows and offset == 0:
                return []
            if not match or int(match[1]) != offset or int(match[2]) != offset + len(rows) - 1:
                raise SourceError('itsm-ng', 'incomplete_collection')
            total = int(match[3])
            if expected not in (None, total):
                raise SourceError('itsm-ng', 'collection_changed')
            expected = total
            result.extend(identifier(row['id']) for row in rows)
            if len(set(result)) != len(result):
                raise SourceError('itsm-ng', 'duplicate_item')
            if len(result) == total:
                return result
        raise SourceError('itsm-ng', 'collection_limit')

    def children(self, ticket_id, kind):
        result = []
        for child_id in self.collection('Ticket/' + ticket_id + '/' + kind):
            try:
                child, _ = self.get(kind + '/' + child_id)
            except SourceError as exc:
                if exc.code == 'native_access_denied':
                    continue  # This private child must never enter evidence or scoring.
                raise
            if child.get('itemtype') != 'Ticket' or str(child.get('items_id')) != ticket_id:
                raise SourceError('itsm-ng', 'child_parent_mismatch')
            result.append(child)
        return result

    def search(self, terms, before):
        authorized()
        active = CURRENT.get()
        if active is None:
            raise SourceError('itsm-ng', 'individual_identity_required')
        credentials = private_json(self.config['credentials_file'])
        record = credentials['users'].get(active[1].subject)
        if not isinstance(record, dict):
            raise SourceError('itsm-ng', 'individual_credential_missing')
        user_id = identifier(record['itsm_user_id'])
        token = record['user_token']
        if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{20,256}', token):
            raise ValueError('Invalid individual credential')
        app = credentials.get('app_token', '')
        if app:
            if not re.fullmatch(r'[A-Za-z0-9_-]{20,256}', app):
                raise ValueError('Invalid application credential')
            self.headers['App-Token'] = app
        self.headers['Authorization'] = 'user_token ' + token
        response, _ = self.get('initSession', {'session_write': 'false'})
        self.session = response.get('session_token', '')
        self.headers.pop('Authorization', None)
        if not isinstance(self.session, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,256}', self.session):
            raise ValueError('Invalid ITSM session')
        self.headers['Session-Token'] = self.session
        try:
            session, _ = self.get('getFullSession')
            if str(session.get('session', {}).get('glpiID')) != user_id:
                raise SourceError('itsm-ng', 'individual_identity_mismatch')
            options, _ = self.get('listSearchOptions/Ticket')
            for number, field in [('1', 'name'), ('2', 'id'), ('12', 'status'), ('17', 'solvedate'), ('21', 'content')]:
                if options.get(number, {}).get('table') != 'glpi_tickets' or options[number].get('field') != field:
                    raise SourceError('itsm-ng', 'unsupported_search_contract')
            zone = self.config.get('timezone', 'Europe/Paris')
            params = {'criteria[0][criteria][0][field]': 12, 'criteria[0][criteria][0][searchtype]': 'equals',
                      'criteria[0][criteria][0][value]': 5, 'criteria[0][criteria][1][link]': 'OR',
                      'criteria[0][criteria][1][field]': 12, 'criteria[0][criteria][1][searchtype]': 'equals',
                      'criteria[0][criteria][1][value]': 6,
                      'criteria[1][link]': 'AND', 'criteria[1][field]': 17, 'criteria[1][searchtype]': 'lessthan',
                      'criteria[1][value]': before.astimezone(ZoneInfo(zone)).strftime('%Y-%m-%d %H:%M:%S'),
                      'sort': 17, 'order': 'DESC', 'forcedisplay[0]': 2, 'is_deleted': 0}
            # Search is generated from observed signals, never from LLM-supplied DSL.
            for index, (field, term) in enumerate((field, term) for term in terms[:8] for field in (1, 21)):
                base = f'criteria[2][criteria][{index}]'
                params.update({base+'[link]': 'OR' if index else 'AND', base+'[field]': field,
                               base+'[searchtype]': 'contains', base+'[value]': term})
            params['criteria[2][link]'] = 'AND'
            result, seen, total = [], set(), None
            for offset in (0, 10):
                page, _ = self.get('search/Ticket', {**params, 'range': f'{offset}-{offset+9}'})
                if not isinstance(page, dict) or type(page.get('totalcount')) is not int or page['totalcount'] < 0:
                    raise SourceError('itsm-ng', 'incomplete_search')
                # Native 1.6.17 omits `data` entirely when totalcount is zero.
                # Only an explicit zero can establish a complete empty result.
                rows=page.get('data')
                if page['totalcount']==0 and rows in (None,[]):rows=[]
                if not isinstance(rows,list):raise SourceError('itsm-ng','incomplete_search')
                if total not in (None, page['totalcount']):
                    raise SourceError('itsm-ng', 'search_changed')
                total = page['totalcount']
                if len(rows) != min(10, max(0, total-offset)):
                    raise SourceError('itsm-ng', 'incomplete_search')
                for hit in rows:
                    tid = identifier(hit['2'])
                    if tid in seen:
                        raise SourceError('itsm-ng', 'duplicate_item')
                    seen.add(tid)
                    ticket, _ = self.get('Ticket/' + tid, {'get_hateoas': 'false'})
                    if str(ticket.get('id')) != tid:
                        raise SourceError('itsm-ng', 'ticket_identity_mismatch')
                    if str(ticket.get('status')) not in {'5', '6'} or str(ticket.get('is_deleted', 0)) != '0':
                        continue
                    solved = timestamp(ticket['solvedate'], zone)
                    if solved >= before or solved < before-timedelta(days=730):
                        continue
                    ticket['solutions'] = self.children(tid, 'ITILSolution')
                    ticket['followups'] = self.children(tid, 'ITILFollowup')
                    ticket['url'] = self.config['public_url'].rstrip('/') + '/front/ticket.form.php?id=' + tid
                    result.append(ticket)
                if offset + len(rows) >= total:
                    break
            return {'tickets': result, 'truncated': total > 20, 'candidates_read': len(seen),
                    'provider': 'itsm-ng', 'target_version': VERSION, 'timezone': zone,
                    'synthetic': self.config.get('synthetic', False)}
        finally:
            try:
                self.get('killSession')
            except SourceError:
                pass  # No session is cached or reused, even after a failed cleanup.
            self.headers.clear()
            self.session = ''


def read_history(sources, context, terms):
    authorized()  # Includes local config and fixture reads.
    path = getattr(sources.s, 'itsm_history_config', None)
    if path is None:
        return {'provider': 'disabled', 'tickets': [], 'truncated': False}
    try:
        config = configuration(path)
        before = datetime.fromisoformat(context['start']).astimezone(timezone.utc)
        if config['provider'] == 'fixture':
            from .config import ROOT
            # Public fixture selected by code, never an arbitrary private input.
            data = json.loads((ROOT/'fixtures/itsm-history.json').read_text())
            if data.get('synthetic') is not True:
                raise ValueError('Synthetic history marker missing')
            active = CURRENT.get()
            category = active[1].category if active else 'internal'
            rows = [row for row in data['tickets'] if row['visibility'] == 'authenticated' or category == 'internal' and row['visibility'] == 'internal']
            return {'provider': 'fixture', 'synthetic': True, 'target_version': VERSION,
                    'timezone': 'Europe/Paris',
                    'tickets': rows, 'truncated': False, 'candidates_read': len(rows)}
        return History(sources, config).search(terms, before)
    except SourceError:
        raise
    except (OSError, ValueError, KeyError, TypeError):
        raise SourceError('itsm-ng', 'invalid_history_configuration_or_response') from None
