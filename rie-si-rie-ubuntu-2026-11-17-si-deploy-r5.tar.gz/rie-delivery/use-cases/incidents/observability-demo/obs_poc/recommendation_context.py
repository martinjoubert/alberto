"""Private documentary releases; no telemetry, source write or provider call."""
import hashlib
import hmac
import json
from pathlib import Path
import re

from dinum_albert.recommendation_release import (
    MAX_RELEASE_BYTES, build_descriptor, dumps_release, select_documents, validate_release)


def supplemental_documents(settings, context, query, existing):
    path = getattr(settings, 'recommendation_release', None)
    if path is None:
        return [], None
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_RELEASE_BYTES:
        raise ValueError('invalid_recommendation_release_file')
    with path.open('rb') as source:
        raw = source.read(MAX_RELEASE_BYTES + 1)
    if len(raw) > MAX_RELEASE_BYTES:
        raise ValueError('recommendation_release_limit')
    expected = getattr(settings, 'recommendation_release_sha256', '')
    actual = hashlib.sha256(raw).hexdigest()
    if not isinstance(expected, str) or not re.fullmatch('[0-9a-f]{64}', expected) or not hmac.compare_digest(actual, expected):
        raise ValueError('recommendation_release_checksum_mismatch')
    release = validate_release(json.loads(raw))
    return select_documents(release, context, query, existing), {
        'corpus_version': release.get('corpus_version'),
        'release_sha256': hashlib.sha256(dumps_release(release).encode('utf-8')).hexdigest(),
        'file_sha256': actual,
    }


def recommendation_descriptor(report, system, review):
    return build_descriptor(report, hashlib.sha256((system + '\n' + review).encode()).hexdigest())
