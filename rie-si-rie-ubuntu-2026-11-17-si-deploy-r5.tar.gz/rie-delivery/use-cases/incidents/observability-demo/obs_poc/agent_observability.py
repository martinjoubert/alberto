"""Optional application adapter; the SDK owns no incident-domain behavior.

Only the trusted server factory enables the adapter. User requests select no
profile, producer identity, exporter or collection policy.
"""
from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
import asyncio
import time

_diagnostics = ContextVar('incident_diagnostics', default=None)


def process_diagnostics():
    try:
        from dinum_observability.logging import get_process_logger
    except ImportError:
        return None
    return get_process_logger()


def emit_diagnostic(logger, event, *, code, **fields):
    if logger is None:
        return False
    try:
        return logger.emit(event, code=code, **fields)
    except Exception:
        return False


def diagnostic_event(event, *, code, **fields):
    state = _diagnostics.get()
    return emit_diagnostic(state['logger'] if state else None, event, code=code, **fields)


@contextmanager
def diagnostic_cycle(logger):
    if logger is None:
        yield
        return
    try:
        from dinum_observability.logging import diagnostic_scope
    except ImportError:
        scope = nullcontext()
    else:
        scope = diagnostic_scope(logger)
    state = {'logger': logger, 'outcome': 'unknown'}
    token = _diagnostics.set(state)
    began = time.monotonic()
    with scope:
        emit_diagnostic(logger, 'rie.execution.started', code='started')
        try:
            yield
        except asyncio.CancelledError:
            state['outcome'] = 'cancelled'
            raise
        except Exception:
            state['outcome'] = 'failure'
            raise
        finally:
            emit_diagnostic(logger, 'rie.execution.completed', code=state['outcome'],
                            technical_status=state['outcome'], duration_ms=(time.monotonic()-began)*1000)
            _diagnostics.reset(token)


@contextmanager
def _trace_scope(headers, *, enabled=False):
    if not enabled:
        yield None
        return
    try:
        from opentelemetry import trace
        from dinum_observability import execution
    except ImportError:
        yield None
        return
    if not getattr(trace.get_tracer_provider(), 'rie_privacy_projection', False):
        yield None
        return
    # Ignore arbitrary execution/profile headers. The SDK validates W3C types.
    carrier = {name: headers[name] for name in ('traceparent', 'tracestate') if name in headers}
    with execution('rie-incidents', entrypoint='api', carrier=carrier,
                   component_type='agent-runtime', schema='2.1') as run:
        yield run


@contextmanager
def request_scope(headers, *, enabled=False, diagnostic_logger=None):
    logger = diagnostic_logger if diagnostic_logger is not None else process_diagnostics()
    with _trace_scope(headers, enabled=enabled) as run, diagnostic_cycle(logger):
        yield run


def collect(name):
    try:
        from dinum_observability import tool
        from dinum_observability.api import current_execution
    except ImportError:
        return nullcontext()
    if current_execution().get('rie.profile.id') != 'rie-incidents':
        return nullcontext()
    return tool(name)


def technical_outcome(run, result):
    status = result.get('status') if isinstance(result, dict) else None
    outcome = {'ok': 'success', 'clarification': 'success', 'denied': 'failure',
                 'partial': 'partial', 'error': 'failure', 'cancelled': 'cancelled',
                 'rate_limited': 'failure'}.get(status, 'unknown')
    state = _diagnostics.get()
    if state is not None:
        state['outcome'] = outcome
        if status == 'denied':
            diagnostic_event('rie.authorization.denied', code='access_denied')
    if run is not None:
        run.outcome(outcome)
