"""Read authorized source data and call Albert through the shared client.

Source failures stay explicit; the diagnostic does not administer source systems."""
import asyncio
import json
import math
import os
import re
import ssl
import time
import httpx
from dinum_access import require_indices, require_resources, AccessDenied
from dinum_access.security import CURRENT
from dinum_albert import AlbertClient, AlbertError
from .domain import window,overlap
from .opensearch_links import logs_query,document_query,documents_query
from .contracts import IDENTIFIER,normalize_record

READ_METHODS={'apiinfo.version','host.get','hostgroup.get','item.get','history.get','trigger.get','problem.get','event.get'}
MAX_SOURCE_RESPONSE_BYTES=2_000_000

class SourceError(RuntimeError):
    def __init__(self,source,code):self.source=source;self.code=code;super().__init__(source+': '+code)

class Sources:
    def __init__(self,settings):
        self.s=settings
        # Use httpx's maintained CA bundle; an explicit intranet bundle remains configurable.
        self.http=httpx.Client(timeout=20,verify=ssl.create_default_context(cafile=settings.ca_file) if settings.ca_file else True,trust_env=False)
        self.deadline=time.monotonic()+settings.diagnostic_timeout
        self.checked_items=set()

    def close(self): self.http.close()

    def remaining_budget(self, source, maximum=20):
        remaining=self.deadline-time.monotonic()
        if remaining<=0:raise SourceError(source,'deadline_exceeded')
        return min(maximum,remaining)

    def metric_client(self):
        """A per-read async client lets cancellation bound headers and body alike."""
        return httpx.AsyncClient(timeout=20,
            verify=ssl.create_default_context(cafile=self.s.ca_file) if self.s.ca_file else True,
            trust_env=False,transport=getattr(self,'metric_transport',None))

    def source_client(self):
        """A per-read client can cancel a stalled or dribbling source response."""
        return httpx.AsyncClient(
            verify=ssl.create_default_context(cafile=self.s.ca_file) if self.s.ca_file else True,
            trust_env=False,transport=getattr(self,'source_transport',None))

    def measurements(self,host,key,start,end):
        try:require_resources('incidents.metrics')
        except AccessDenied:raise SourceError('authorization','resource_forbidden') from None
        if self.s.metrics_provider == 'zabbix':
            return self.history(host['items'][key],start,end)
        if self.s.metrics_provider == 'victoriametrics':
            from .telemetry import raw_samples
            return raw_samples(self,host,key,start,end)
        raise SourceError('connector','unknown_metrics_provider')

    def request(self,source,method,url,**kwargs):
        timeout=self.remaining_budget(source,60 if source=='albert' else 20)
        if source == 'albert':
            if method != 'POST' or url != self.s.albert.rstrip('/') + '/chat/completions':
                raise SourceError(source, 'endpoint_not_allowed')
            payload = dict(kwargs.get('json') or {})
            try:
                client = AlbertClient(self.s.albert, self.s.albert_key, http=self.http,
                                      timeout=self.s.generation_timeout, deadline=self.deadline)
                return client.chat(payload.pop('model'), payload.pop('messages'), **payload)
            except AlbertError as exc:
                raise SourceError(source, 'http_'+str(exc.status) if exc.status else exc.code) from None
            except (KeyError, ValueError):
                raise SourceError(source, 'invalid_albert_configuration') from None
        async def read():
            async with asyncio.timeout(self.remaining_budget(source,timeout)):
                async with self.source_client() as client:
                    headers=httpx.Headers(kwargs.get('headers') or {});headers['Accept-Encoding']='identity'
                    options={**kwargs,'headers':headers,
                             'timeout':self.remaining_budget(source,timeout),'follow_redirects':False}
                    async with client.stream(method,url,**options) as response:
                        response.raise_for_status()
                        if response.headers.get('content-encoding','identity').strip().lower() not in ('','identity'):
                            raise SourceError(source,'unsupported_content_encoding')
                        length=response.headers.get('content-length')
                        if length is not None and int(length)>MAX_SOURCE_RESPONSE_BYTES:
                            raise SourceError(source,'response_limit')
                        body=bytearray()
                        async for block in response.aiter_bytes():
                            self.remaining_budget(source)
                            if len(body)+len(block)>MAX_SOURCE_RESPONSE_BYTES:
                                raise SourceError(source,'response_limit')
                            body.extend(block)
                        self.remaining_budget(source)
                        result=json.loads(body)
                        self.remaining_budget(source)
                        return result
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            pass
        else:
            raise SourceError('connector','sync_reader_requires_worker_thread')
        try:
            return asyncio.run(read())
        except TimeoutError: raise SourceError(source,'deadline_exceeded') from None
        except httpx.HTTPStatusError as e: raise SourceError(source,'http_'+str(e.response.status_code)) from None
        except httpx.TimeoutException: raise SourceError(source,'timeout') from None
        except httpx.ConnectError: raise SourceError(source,'connection_failed') from None
        except (httpx.HTTPError,ValueError,RecursionError): raise SourceError(source,'unavailable_or_invalid_response') from None

    def rpc(self,method,params):
        if method not in READ_METHODS: raise SourceError('zabbix','method_not_allowed')
        data=self.request('zabbix','POST',self.s.zabbix,headers={'Authorization':'Bearer '+self.s.zabbix_token},
                          json={'jsonrpc':'2.0','method':method,'params':params,'id':1})
        if 'error' in data:
            detail=str(data['error'].get('message',''))+' '+str(data['error'].get('data',''))
            code='authentication_or_permission_denied' if any(w in detail.lower() for w in ('authoriz','permission','session','token')) else 'api_error_'+str(data['error'].get('code'))
            raise SourceError('zabbix',code)
        return data['result']

    def os(self,index,body):
        if index not in (self.s.logs_index,self.s.docs_index): raise SourceError('opensearch','index_not_allowed')
        try:
            def resolve(expression):
                return self.request('opensearch','GET',self.s.opensearch+'/_resolve/index/'+expression,
                    **({'auth':(self.s.os_user,self.s.os_password)} if self.s.os_user else {}))
            if CURRENT.get() or os.getenv('DINUM_ACCESS_CONFIG'):
                # A concrete forbidden index is rejected before any source read.
                if not any(character in index for character in '*?,'):
                    require_indices(index)
                # Resolve outside the authorization callback: a source outage
                # must remain unavailable, not turn into a false policy denial.
                resolved = resolve(index)
                index = require_indices(index, lambda expression: resolved)
            else:
                index = require_indices(index, resolve)
        except AccessDenied:
            raise SourceError('authorization','index_forbidden') from None
        data=self.request('opensearch','POST',self.s.opensearch+'/'+index+'/_search',json=body,
            **({'auth':(self.s.os_user,self.s.os_password)} if self.s.os_user else {}))
        if data.get('timed_out') or data.get('_shards',{}).get('failed',0): raise SourceError('opensearch','incomplete_search')
        return data

    def history(self,item,start,end):
        if str(item) not in self.checked_items:
            visible=self.rpc('item.get',{'itemids':[str(item)],'output':['itemid','value_type']})
            if not visible:raise SourceError('zabbix','item_deleted_or_not_readable')
            if any(str(r['value_type'])!='0' for r in visible):raise SourceError('zabbix','unsupported_history_value_type')
            self.checked_items.add(str(item))
        a,b=window(start,end); lo=math.ceil(a.timestamp());hi=math.ceil(b.timestamp())-1
        def read(x,y):
            params={'history':0,'itemids':[str(item)],'time_from':x,'time_till':y}
            count=int(self.rpc('history.get',{**params,'countOutput':True}))
            if count>50000: raise SourceError('zabbix','observation_limit')
            if count>1000:
                if x==y: raise SourceError('zabbix','same_second_limit')
                middle=(x+y)//2
                return read(x,middle)+read(middle+1,y)
            rows=self.rpc('history.get',{**params,'output':['clock','ns','value'],'sortfield':['clock','ns'],'sortorder':'ASC','limit':1001})
            if len(rows)!=count: raise SourceError('zabbix','history_changed_or_incomplete')
            return rows
        return read(lo,hi)

    def events(self,hosts,start,end):
        if self.s.events_provider == 'itsm-ng-simulator':
            from .telemetry import tickets
            return tickets(self.s,hosts,start,end)
        try:require_resources('incidents.tickets')
        except AccessDenied:raise SourceError('authorization','resource_forbidden') from None
        if self.s.events_provider != 'zabbix':
            raise SourceError('connector','unknown_events_provider')
        a,b=window(start,end)
        params={'source':0,'object':0,'value':1,'hostids':[h['hostid'] for h in hosts],
                'problem_time_from':math.ceil(a.timestamp()),'problem_time_till':math.ceil(b.timestamp())-1}
        total=int(self.rpc('event.get',{**params,'countOutput':True}))
        if total>1000: raise SourceError('zabbix','event_limit')
        rows=self.rpc('event.get',{**params,'output':['eventid','objectid','clock','r_eventid','name','severity'],
            'selectHosts':['hostid','host'],'sortfield':'eventid','sortorder':'ASC','limit':1001})
        if len(rows)!=total: raise SourceError('zabbix','events_incomplete')
        ids=list({r['r_eventid'] for r in rows if r.get('r_eventid') not in (None,'0',0)})
        recoveries={r['eventid']:r['clock'] for r in self.rpc('event.get',{'eventids':ids,'output':['eventid','clock']})} if ids else {}
        for row in rows:
            if row.get('r_eventid') not in (None,'0',0) and row['r_eventid'] not in recoveries: raise SourceError('zabbix','recovery_not_readable')
            row['recovery_clock']=int(recoveries.get(row.get('r_eventid'),0))
        return [r for r in rows if overlap(r,start,end)]

    def logs(self,equipment,start,end):
        fields=self.source_fields('logs',self.s.logs_index)
        body=logs_query(equipment,start,end,fields)
        data=self.os(self.s.logs_index,body)
        if data['hits']['total']['relation']!='eq': raise SourceError('opensearch','inexact_total')
        if data.get('aggregations',{}).get('codes',{}).get('sum_other_doc_count',0): raise SourceError('opensearch','aggregation_limit')
        equipment_counts={r['key']:{c['key']:c['doc_count'] for c in r['codes']['buckets']} for r in data.get('aggregations',{}).get('equipment',{}).get('buckets',[])}
        try:rows=[normalize_record('logs',hit['_source'],fields) for hit in data['hits']['hits']]
        except (ValueError,KeyError,TypeError):raise SourceError('opensearch','invalid_log_record') from None
        return {'total':data['hits']['total']['value'],'rows':rows,
                'counts':{r['key']:r['doc_count'] for r in data['aggregations']['codes']['buckets']},
                'by_equipment':equipment_counts,
                'truncated':data['hits']['total']['value']>100}

    def documents(self,equipment,terms):
        fields=self.source_fields('documents',self.s.docs_index)
        body=documents_query(equipment,terms,fields)
        try:docs=[normalize_record('documents',hit['_source'],fields) for hit in self.os(self.s.docs_index,body)['hits']['hits']]
        except (ValueError,KeyError,TypeError):raise SourceError('opensearch','invalid_document_record') from None
        for doc in docs:
            doc['truncated']=len(doc.get('text',''))>1200
            doc['text']=doc.get('text','')[:1200]
        return docs

    def document(self,identifier,equipment):
        fields=self.source_fields('documents',self.s.docs_index)
        if not isinstance(identifier,str) or not IDENTIFIER.fullmatch(identifier):raise SourceError('opensearch','invalid_document_identifier')
        rows=self.os(self.s.docs_index,document_query(identifier,equipment,fields))['hits']['hits']
        try:return normalize_record('documents',rows[0]['_source'],fields) if rows else None
        except (ValueError,KeyError,TypeError):raise SourceError('opensearch','invalid_document_record') from None

    def historical_tickets(self, context, terms):
        from .itsm_history import read_history
        return read_history(self, context, terms)

    def source_fields(self,kind,index):
        try:require_indices(index)
        except AccessDenied:raise SourceError('authorization','index_forbidden') from None
        try:return self.s.manifest().get('source_fields',{}).get(kind)
        except (OSError,ValueError,KeyError,TypeError):raise SourceError('configuration','invalid_source_contract') from None
