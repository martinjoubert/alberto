"""Bounded readers: raw VictoriaMetrics samples and an explicit ITSM-NG simulator.

The simulator schema is ours. It does not claim compatibility with ITSM-NG's API.
Metric names and label bindings are administrator configuration, never LLM DSL.
"""
import asyncio
import json
import math
import os
import re
from datetime import timedelta
from urllib.parse import urlencode
from .domain import window, overlap
from .contracts import metric_spec
from dinum_access import require_resources, AccessDenied


def selector(settings, host, key):
    mapping = json.loads(settings.metric_mapping.read_text(encoding='utf-8'))
    name, labels, scale = metric_spec(mapping, host, key)
    expr = name+'{'+','.join(field+'='+json.dumps(str(value)) for field,value in sorted(labels.items()))+'}'
    return expr, scale


def raw_samples(source, host, key, start, end):
    from .clients import SourceError
    try:
        # Check before configuration/client construction and before ANY network.
        remaining=source.remaining_budget('victoriametrics',source.s.diagnostic_timeout)
        mapping=json.loads(source.s.metric_mapping.read_text(encoding='utf-8'))
        name,required,scale=metric_spec(mapping,host,key)
        required={**required,'__name__':name}
        expr=name+'{'+','.join(field+'='+json.dumps(value) for field,value in sorted(required.items()) if field!='__name__')+'}'
        a,b = window(start,end)
        rows = {}
        labels_seen = None
        headers = {'Authorization':'Bearer '+source.s.victoria_token} if source.s.victoria_token else {}

        def record(line):
            nonlocal labels_seen
            if not line:return
            source.remaining_budget('victoriametrics')
            data=json.loads(line)
            labels=data['metric']
            if any(labels.get(label)!=value for label,value in required.items()):
                raise SourceError('victoriametrics','labels_mismatch')
            identity=json.dumps(labels,sort_keys=True)
            if labels_seen is not None and identity!=labels_seen:
                raise SourceError('victoriametrics','ambiguous_metric_series')
            labels_seen=identity
            values,timestamps=data['values'],data['timestamps']
            if len(values)!=len(timestamps):raise SourceError('victoriametrics','incomplete_samples')
            for timestamp,value in zip(timestamps,values):
                source.remaining_budget('victoriametrics')
                stamp=float(timestamp)/1000;number=float(value)*scale
                if not math.isfinite(stamp) or not math.isfinite(number):
                    raise SourceError('victoriametrics','invalid_sample')
                if a.timestamp()<=stamp<b.timestamp():
                    if stamp in rows and rows[stamp]['value']!=number:raise SourceError('victoriametrics','conflicting_sample')
                    clock=math.floor(stamp)
                    rows[stamp]={'clock':clock,'ns':round((stamp-clock)*1e9),'value':number}
                if len(rows)>50000:raise SourceError('victoriametrics','observation_limit')

        async def read():
            # A real total budget cancels connection, headers AND slow/dribbling
            # bodies. A synchronous idle-read timeout alone cannot bound a stream.
            async with asyncio.timeout(source.remaining_budget('victoriametrics',remaining)):
                async with source.metric_client() as client:
                    async with client.stream('GET',source.s.victoria.rstrip('/')+'/api/v1/export',
                        params={'match[]':expr,'start':a.isoformat(),'end':(b-timedelta(milliseconds=1)).isoformat(),'max_rows_per_line':1000},
                        headers=headers,timeout=source.remaining_budget('victoriametrics',20)) as response:
                        response.raise_for_status()
                        size=0;pending=b''
                        # Bound bytes BEFORE line splitting, including an endless line.
                        async for block in response.aiter_bytes():
                            source.remaining_budget('victoriametrics')
                            size+=len(block)
                            if size>8_000_000:raise SourceError('victoriametrics','response_limit')
                            lines=(pending+block).split(b'\n');pending=lines.pop()
                            for line in lines:record(line)
                        record(pending)
            return list(rows.values())
        try:asyncio.get_running_loop()
        except RuntimeError:pass
        else:raise SourceError('connector','sync_reader_requires_worker_thread')
        return asyncio.run(read())
    except SourceError: raise
    except Exception as exc:
        import httpx
        if isinstance(exc,TimeoutError):code='deadline_exceeded'
        elif isinstance(exc,httpx.HTTPStatusError): code='http_'+str(exc.response.status_code)
        elif isinstance(exc,httpx.TimeoutException): code='timeout'
        elif isinstance(exc,httpx.HTTPError): code='unavailable'
        else: code='invalid_mapping_or_response'
        raise SourceError('victoriametrics',code) from None


def metric_url(settings, host, key, start, end):
    expr,_ = selector(settings,host,key)
    a,b = window(start,end)
    # VictoriaMetrics includes the end timestamp; our evidence uses [start,end).
    # A deployment can explicitly expose a direct VictoriaMetrics reader, or
    # suppress links entirely. An unset override retains the existing Grafana
    # reader boundary rather than exposing an internal Docker source address.
    public=os.getenv('VICTORIAMETRICS_PUBLIC_URL')
    if public is not None:
        if not public:return ''
        endpoint=public.rstrip('/')+'/api/v1/export'
    else:
        if not settings.grafana:return ''
        endpoint=settings.grafana.rstrip('/')+'/api/datasources/proxy/uid/obs-victoria/api/v1/export'
    return endpoint+'?'+urlencode(
        {'match[]':expr,'start':a.isoformat(),'end':(b-timedelta(milliseconds=1)).isoformat()})


def tickets(settings, hosts, start=None, end=None):
    from .clients import SourceError
    try:require_resources('incidents.tickets')
    except AccessDenied:raise SourceError('authorization','resource_forbidden') from None
    try:
        data = json.loads(settings.itsm_snapshot.read_text(encoding='utf-8'))
        if data.get('simulator') != 'ITSM-NG' or data.get('complete') is not True:
            raise ValueError('Not a complete simulator snapshot')
        hostmap = {h['equipment']:h for h in hosts if h.get('allowed')}
        seen = set()
        result = []
        for ticket in data['tickets']:
            if ticket['equipment'] not in hostmap: continue
            if not re.fullmatch(r'ITSM-[0-9]{3}',ticket['id']) or ticket['id'] in seen:
                raise ValueError('Invalid or duplicate ticket')
            seen.add(ticket['id'])
            host = hostmap[ticket['equipment']]
            from datetime import datetime
            begin = int(datetime.fromisoformat(ticket['alert_started_at']).timestamp())
            recovery = int(datetime.fromisoformat(ticket['alert_resolved_at']).timestamp()) if ticket.get('alert_resolved_at') else 0
            if recovery and recovery < begin: raise ValueError('Invalid recovery')
            event = {'eventid':ticket['id'],'objectid':host.get('triggerid',''), 'name':ticket['title'],
                     'clock':begin,'recovery_clock':recovery,'hosts':[{'hostid':host['hostid']}],
                     'ticket':ticket,'origin':'itsm-ng-simulator',
                     'url':settings.itsm_public.rstrip('/')+'/'+ticket['id'] if settings.itsm_public else ''}
            if start is None or overlap(event,start,end): result.append(event)
        return result
    except (OSError,ValueError,KeyError,TypeError):
        raise SourceError('itsm-ng-simulator','invalid_or_incomplete_snapshot') from None
