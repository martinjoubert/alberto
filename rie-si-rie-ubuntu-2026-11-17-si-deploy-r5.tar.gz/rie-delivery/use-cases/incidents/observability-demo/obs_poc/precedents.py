"""Explainable PoC ranking and a sourced candidate solution, never an action.

No generated probability: the confidence is an ordinal evidence assessment,
separate from diagnostic confidence. Conflicting approved solutions abstain.
"""
from datetime import datetime
from html import unescape
from html.parser import HTMLParser
import re

from .domain import normalized
from .itsm_history import timestamp


class Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts, self.hidden = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in {'script', 'style'}:
            self.hidden += 1
        elif tag in {'p', 'br', 'li', 'div'}:
            self.parts.append(' ')

    def handle_endtag(self, tag):
        if tag in {'script', 'style'}:
            self.hidden = max(0, self.hidden-1)

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def text(value, limit=1200):
    if not isinstance(value, str) or len(value) > 100_000:
        raise ValueError('Invalid historical text')
    parser = Text()
    parser.feed(unescape(value))
    clean = re.sub(r'[\x00-\x1f\x7f]', ' ', ' '.join(parser.parts))
    return re.sub(r'\s+', ' ', clean).strip()[:limit]


def words(value):
    return set(re.findall(r'[a-z][a-z0-9_]{3,}', normalized(value)))


def select(history, report, terms):
    before = datetime.fromisoformat(report['context']['start'])
    zone = history.get('timezone', 'Europe/Paris')
    signals = words(' '.join(terms))
    equipment = set(report['context']['equipment_ids'])
    matches = []
    for ticket in history['tickets']:
        if str(ticket.get('status')) not in {'5', '6'} or not ticket.get('solvedate'):
            continue
        solved = timestamp(ticket['solvedate'], zone)
        if solved >= before or (before-solved).days > 730:
            continue
        title, description = text(ticket['name'], 200), text(ticket.get('content', ''))
        # Use original identifiers as standalone labels, never substring matches.
        same_equipment = any(re.search(r'(?<![\w-])'+re.escape(item)+r'(?![\w-])',
                                      title+' '+description, flags=re.I) for item in equipment)
        common = sorted(signals & words(title+' '+description))
        if not common:
            continue
        solutions = [{'text': text(row.get('content', '')), 'accepted': str(row.get('status')) == '3',
                      'status': str(row.get('status')),
                      'date': timestamp(row['date_creation'], zone).isoformat() if row.get('date_creation') else None}
                     for row in ticket.get('solutions', [])]
        for solution in solutions:
            if not solution['date'] or datetime.fromisoformat(solution['date']) >= before:
                solution['accepted'] = False
        approved = [row for row in solutions if row['accepted'] and row['text']]
        # Distinct accepted texts within a ticket are not silently collapsed.
        approved_texts = {normalized(row['text']) for row in approved}
        candidate = approved[0]['text'] if len(approved_texts) == 1 else ''
        matches.append({'ticket_id': str(ticket['id']), 'title': title, 'description': description,
                        'solved_at': solved.isoformat(), 'url': ticket.get('url', ''),
                        'similarities': common, 'same_equipment': same_equipment,
                        'differences': ([] if same_equipment else ['Équipement identique non établi.']) +
                            ['La configuration et les conditions d’application restent à comparer.'],
                        'solutions': solutions, 'candidate_solution': candidate,
                        'conflicting_solutions': len(approved_texts) > 1,
                        'rank_score': len(common) + (2 if same_equipment else 0),
                        'solution_evidence': 'accepted' if candidate else 'not_established'})
    matches.sort(key=lambda row: (-row['rank_score'], -datetime.fromisoformat(row['solved_at']).timestamp(), row['ticket_id']))
    return matches[:3]


def propose(precedents, report, *, truncated=False):
    result = {'state': 'insufficient_evidence', 'confidence': 'faible', 'solution': '', 'source_ids': [],
              'reason': 'Aucune solution acceptée et suffisamment comparable n’a été retrouvée.',
              'conditions': ['Faire valider la pertinence et la procédure par un opérateur habilité.'],
              'limitations': ['Ce niveau qualitatif ne constitue pas une probabilité de réussite.']}
    candidates = [row for row in precedents if row['candidate_solution']]
    if not candidates:
        return result
    best = candidates[0]
    if len(best['similarities']) < 2 and not best['same_equipment']:
        result['reason']='La ressemblance retrouvée est trop limitée pour privilégier une solution.'
        return result
    comparable = [row for row in candidates if row['rank_score'] >= best['rank_score']-1]
    solutions = {normalized(row['candidate_solution']) for row in comparable}
    if len(solutions) > 1 or any(row.get('conflicting_solutions') and row['rank_score'] >= best['rank_score']-1 for row in precedents):
        result.update(state='conflicting_precedents', source_ids=[row['source_id'] for row in comparable],
                      reason='Des précédents comparables présentent des solutions différentes : aucune priorité suffisamment étayée.')
        return result
    supporters = [row for row in candidates if normalized(row['candidate_solution']) == normalized(best['candidate_solution'])]
    current_complete = report.get('confidence', {}).get('level') == 'élevée' and not report.get('errors')
    high = len(supporters) >= 2 and best['same_equipment'] and len(best['similarities']) >= 2 and current_complete and not truncated
    result.update(state='proposed', solution=best['candidate_solution'],
                  confidence='élevée' if high else 'modérée' if current_complete and not truncated else 'faible',
                  source_ids=[row['source_id'] for row in supporters],
                  reason=('Plusieurs précédents concordants, une solution acceptée et des signaux actuels comparables.' if high else
                          'Solution acceptée dans un précédent comparable ; sa pertinence actuelle reste à confirmer.'))
    result['conditions'].insert(0, 'Comparer équipement, configuration, symptômes et contraintes avec les tickets cités avant toute application.')
    if truncated:
        result['limitations'].append('Recherche bornée aux vingt premiers candidats : d’autres précédents peuvent exister.')
    if not current_complete:
        result['limitations'].append('Les observations actuelles sont incomplètes ou insuffisamment concordantes.')
    result['limitations'].append('Une solution acceptée dans ITSM-NG ne démontre pas la cause du nouvel incident.')
    return result
