"""Use the same bounded queries for API reads and browser source links."""
import json
from urllib.parse import quote, urlencode, urlsplit
from .contracts import field_mapping, query_fields


def logs_query(equipment, start, end, fields=None):
    mapping=field_mapping('logs',fields);query=query_fields('logs',fields)
    return {'size':100,'track_total_hits':True,'sort':[{query['@timestamp']:'asc'},{query['record_id']:'asc'}],
            '_source':[entry['source'] for entry in mapping.values()],
            'query':{'bool':{'filter':[{'terms':{query['equipment']:equipment}},
                                      {'range':{query['@timestamp']:{'gte':start,'lt':end}}}]}},
            'aggs':{'codes':{'terms':{'field':query['event_code'],'size':50}},
                    'equipment':{'terms':{'field':query['equipment'],'size':10},
                                 'aggs':{'codes':{'terms':{'field':query['event_code'],'size':50}}}}}}


def document_query(identifier, equipment, fields=None):
    query=query_fields('documents',fields)
    return {'size':1,'query':{'bool':{'filter':[
        {'term':{query['record_id']:identifier}},{'terms':{query['equipment']:equipment}},{'term':{query['allowed']:True}}]}}}


def documents_query(equipment, terms, fields=None):
    mapping=field_mapping('documents',fields);query=query_fields('documents',fields)
    return {'size':8,'query':{'bool':{'filter':[{'terms':{query['equipment']:equipment}},
        {'term':{query['allowed']:True}}],
        'must':[{'multi_match':{'query':terms[:500],
            'fields':[query['title']+'^2',query['text'],query['keywords']+'^3'],'operator':'or'}}]}},
        '_source':[entry['source'] for key,entry in mapping.items() if key!='allowed']}


def search_url(base, index, body):
    if not base:
        return None
    parsed=urlsplit(base)
    if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('URL publique OpenSearch invalide ; aucun identifiant autorisé dans le lien.')
    return base.rstrip('/')+'/'+quote(index,safe='')+'/_search?'+urlencode({
        'source':json.dumps(body,ensure_ascii=False,separators=(',',':')),
        'source_content_type':'application/json'})
