"""Read-only network investigation with server-calculated evidence."""
