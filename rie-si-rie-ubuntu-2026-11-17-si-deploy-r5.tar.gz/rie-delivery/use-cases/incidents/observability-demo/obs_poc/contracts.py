"""Administrator-owned source contracts, without runtime/network dependencies."""
from datetime import date, datetime, timedelta, timezone
import math
import re
from zoneinfo import ZoneInfo

METRIC_KEYS = ('cpu', 'latency', 'loss', 'in', 'out')
FIELDS = {
    'logs': ('record_id', '@timestamp', 'equipment', 'scope', 'interface', 'event_code', 'message'),
    'documents': ('record_id', 'kind', 'title', 'text', 'equipment', 'date', 'keywords', 'allowed'),
}
FIELD_PATH = re.compile(r'[A-Za-z_@][A-Za-z0-9_@-]*(?:\.[A-Za-z_@][A-Za-z0-9_@-]*)*')
IDENTIFIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}')


def interval(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not .001 <= value <= 86400:
        raise ValueError('A collection interval must be finite and between 0.001 and 86400 seconds.')
    return value


def metric_interval(manifest, host, key):
    return interval(host.get('metric_intervals_seconds', {}).get(key,
        manifest.get('metric_intervals_seconds', {}).get(key, manifest.get('interval_seconds', 60))))


def field_mapping(kind, overrides=None):
    """Allow paths and keyword multifields, never scripts or an operator query."""
    if kind not in FIELDS or overrides is not None and not isinstance(overrides, dict):
        raise ValueError('Invalid source field contract.')
    overrides = overrides or {}
    if set(overrides) - set(FIELDS[kind]):
        raise ValueError('Unknown canonical source field.')
    result = {}
    for key in FIELDS[kind]:
        entry = overrides.get(key, key)
        if isinstance(entry, str):
            entry = {'source': entry, 'query': entry}
        if not isinstance(entry, dict) or set(entry) != {'source', 'query'}:
            raise ValueError('A source field requires source and query paths.')
        if any(not isinstance(value, str) or len(value) > 128 or not FIELD_PATH.fullmatch(value)
               for value in entry.values()):
            raise ValueError('Source fields must be bounded plain field paths.')
        result[key] = dict(entry)
    return result


def query_fields(kind, overrides=None):
    return {key: entry['query'] for key, entry in field_mapping(kind, overrides).items()}


def normalize_record(kind, row, overrides=None):
    if not isinstance(row, dict):
        raise ValueError('A source record must be an object.')
    result = {}
    for key, entry in field_mapping(kind, overrides).items():
        path = entry['source']
        value = row
        # OpenSearch can return either dotted keys or nested source objects.
        if path in row:
            value = row[path]
        else:
            for part in path.split('.'):
                if not isinstance(value, dict) or part not in value:
                    value = None
                    break
                value = value[part]
        if value is not None:
            result[key] = value
    if not isinstance(result.get('record_id'), str) or not IDENTIFIER.fullmatch(result['record_id']):
        raise ValueError('Invalid source record identifier.')
    required=('equipment','@timestamp','event_code','message') if kind=='logs' else ('kind','title','text')
    if any(not isinstance(result.get(key),str) for key in required):
        raise ValueError('Source records must provide their canonical string fields.')
    equipment=result.get('equipment')
    if kind=='documents' and not (isinstance(equipment,str) or isinstance(equipment,list) and all(isinstance(item,str) for item in equipment)):
        raise ValueError('Document equipment must be a string or a list of strings.')
    return result


def _interval_overrides(value):
    if not isinstance(value, dict) or set(value) - set(METRIC_KEYS):
        raise ValueError('Collection intervals require known metric names.')
    for cadence in value.values():
        interval(cadence)


def validate_manifest(value):
    """Validate the local inventory/control window, not availability of real SI data."""
    if not isinstance(value, dict) or value.get('status') != 'ready':
        raise ValueError('The Incidents corpus must be explicitly ready.')
    if type(value.get('synthetic')) is not bool:
        raise ValueError('The Incidents corpus must explicitly identify synthetic data.')
    if any(not isinstance(value.get(key),str) or not value[key] for key in ('timezone','anchor_date','start','end')):
        raise ValueError('The corpus requires string timezone, anchor_date, start and end fields.')
    try:
        ZoneInfo(value['timezone'])
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value['anchor_date']):raise ValueError()
        date.fromisoformat(value['anchor_date'])
        bounds = [datetime.fromisoformat(value[key].replace('Z', '+00:00')) for key in ('start', 'end')]
        if any(bound.utcoffset() is None for bound in bounds) or not timedelta(0) < bounds[1] - bounds[0] <= timedelta(days=7):
            raise ValueError()
        if bounds[1]>datetime.now(timezone.utc)+timedelta(minutes=1):raise ValueError()
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError('The corpus requires a timezone, anchor_date and an ISO control window of at most seven days.') from exc
    interval(value.get('interval_seconds'))
    _interval_overrides(value.get('metric_intervals_seconds', {}))
    hosts = value.get('hosts')
    if not isinstance(hosts, list) or not hosts or not any(isinstance(host, dict) and host.get('allowed') is True for host in hosts):
        raise ValueError('The Incidents corpus requires an explicitly allowed equipment inventory.')
    seen = set()
    for host in hosts:
        if not isinstance(host, dict) or type(host.get('allowed')) is not bool:
            raise ValueError('Every equipment requires an explicit allowed flag.')
        for field in ('equipment', 'scope', 'hostid'):
            if not isinstance(host.get(field), str) or not 1 <= len(host[field]) <= 128:
                raise ValueError('Every equipment requires a bounded equipment, scope and stable hostid.')
        if host['equipment'] in seen:
            raise ValueError('Equipment names must be unique.')
        seen.add(host['equipment'])
        aliases = host.get('aliases', [])
        if not isinstance(aliases, list) or any(not isinstance(alias, str) or not 1 <= len(alias) <= 128 for alias in aliases):
            raise ValueError('Equipment aliases must be bounded strings.')
        _interval_overrides(host.get('metric_intervals_seconds', {}))
    fields = value.get('source_fields', {})
    if not isinstance(fields, dict) or set(fields) - set(FIELDS):
        raise ValueError('Only logs and documents source field contracts are supported.')
    for kind, overrides in fields.items():
        field_mapping(kind, overrides)
    if not isinstance(value.get('scope_aliases', {}), dict) or not isinstance(value.get('data_flow', {}), dict):
        raise ValueError('Scope aliases and data_flow must be objects.')
    if any(not isinstance(item,str) or not 1<=len(item)<=128
           for pair in value.get('scope_aliases',{}).items() for item in pair):
        raise ValueError('Scope aliases must map bounded strings to bounded scope names.')
    return value


def metric_spec(mapping, host, key):
    """Resolve one exact gauge series, with per-metric labels overriding defaults."""
    if key not in METRIC_KEYS or not isinstance(mapping, dict) or not isinstance(host,dict):
        raise ValueError('Unknown metric contract.')
    metrics=mapping.get('metrics')
    if not isinstance(metrics,dict) or key not in metrics:
        raise ValueError('Missing metric contract.')
    spec = metrics[key]
    if not isinstance(spec, dict) or set(spec) - {'name', 'scale', 'bindings', 'fixed_labels'}:
        raise ValueError('Metrics support only name, scale, bindings and fixed_labels; derived gauges belong upstream.')
    name = spec.get('name')
    if not isinstance(name, str) or not re.fullmatch(r'[a-zA-Z_:][a-zA-Z0-9_:]{0,127}', name):
        raise ValueError('Invalid metric name.')
    if not isinstance(mapping.get('fixed_labels', {}), dict) or not isinstance(spec.get('fixed_labels', {}), dict):
        raise ValueError('Fixed metric labels must be objects.')
    labels = {**mapping.get('fixed_labels', {}), **spec.get('fixed_labels', {})}
    bindings = spec.get('bindings', mapping.get('bindings', {}))
    if not isinstance(bindings, dict) or len(labels) + len(bindings) > 32:
        raise ValueError('Invalid metric label contract.')
    for field, binding in bindings.items():
        if binding not in ('equipment', 'interface', 'hostid', 'scope') or not isinstance(host.get(binding), str) or not host[binding]:
            raise ValueError('Unsupported or missing inventory label binding.')
        if field in labels:
            raise ValueError('A metric label cannot be both fixed and bound.')
        labels[field] = host[binding]
    if any(not isinstance(field, str) or not re.fullmatch(r'[a-zA-Z_][a-zA-Z0-9_]{0,127}', field)
           or not isinstance(item, str) or len(item) > 512 for field, item in labels.items()):
        raise ValueError('Invalid metric label name or value.')
    if '__name__' in labels:
        raise ValueError('The metric name cannot be overridden by a label.')
    scale = spec.get('scale', 1)
    if isinstance(scale, bool) or not isinstance(scale, (int, float)) or not math.isfinite(scale) or scale <= 0:
        raise ValueError('Invalid unit conversion.')
    return name, labels, float(scale)


def validate_metric_mapping(mapping, hosts):
    if not isinstance(mapping, dict) or not isinstance(mapping.get('metrics'), dict) or set(mapping['metrics']) != set(METRIC_KEYS):
        raise ValueError('Exactly the five diagnostic metrics must be configured.')
    if not isinstance(hosts,list) or any(not isinstance(host,dict) or type(host.get('allowed')) is not bool for host in hosts):
        raise ValueError('Metric validation requires an explicit equipment inventory.')
    for host in hosts:
        if host['allowed']:
            for key in METRIC_KEYS:
                metric_spec(mapping, host, key)
    return mapping
