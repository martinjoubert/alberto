"""Answer temporal questions from the retrieved event facts, before diagnostics."""
from datetime import datetime,time
from zoneinfo import ZoneInfo
import re
from .domain import normalized

PARIS=ZoneInfo('Europe/Paris')
TEMPORAL=r'\b(?:resolu\w*|resolution|termine\w*|fini\w*|clotur\w*|chevauchement|recouvrement)\b|combien de temps|\bduree\b'


def temporal_text(question):
    latest=normalized(question.rsplit('\nPrécision utilisateur : ',1)[-1])
    # A date/equipment clarification alone does not replace the original intent.
    return latest if re.search(TEMPORAL,latest) else normalized(question)


def temporal_question(question):
    text=temporal_text(question)
    if re.search(r'\b(?:secret\w*|password|token|acquitt\w*|redemarr\w*|supprim\w*|desactiv\w*|modifi\w*|corrig\w*|deploi\w*)\b|mot de passe|cle api|\b(?:fiche|inc-\d+|incident passe|incident similaire|ancien incident|incident ancien)\b',text):
        return False
    return bool(re.search(TEMPORAL,text))


def temporal_reference(question,start,end):
    """Resolve a status time on an already confirmed day, never a new window.

    Return None for multiple points, multiple days or an ambiguous civil hour.
    The caller must still validate explicit calendar/window corrections.
    """
    if not start or not end or not temporal_question(question):return None
    text=temporal_text(question)
    zone=ZoneInfo('UTC') if re.search(r'\butc\b',text) else PARIS
    a,b=(datetime.fromisoformat(value).astimezone(zone) for value in (start,end))
    # Discard range endpoints, which are not times at which status is queried.
    clock=r'\d{1,2}\s*(?:h(?:eures?)?|:)\s*(?:\d{2})?(?!\d)'
    points=re.sub(r'\b(?:de|entre)\s+'+clock+r'\s+(?:a|et)\s+'+clock,'',text)
    matches=list(re.finditer(r'\b(a|avant)\s+(?:(midi)\b|(\d{1,2})\s*(?:h(?:eures?)?|:)\s*(\d{2})?(?!\d))',points))
    if len(matches)==1 and a.date()==b.date():
        match=matches[0];hour=12 if match[2] else int(match[3]);minute=int(match[4] or 0)
        if hour>=24 or minute>=60:return None
        candidate=datetime.combine(a.date(),time(hour,minute),zone)
        valid={c.astimezone(ZoneInfo('UTC')) for c in (candidate.replace(fold=0),candidate.replace(fold=1))
               if c.astimezone(ZoneInfo('UTC')).astimezone(zone).replace(tzinfo=None)==candidate.replace(tzinfo=None)}
        if len(valid)!=1:return None
        before=match[1]=='avant'
        label=('avant' if before else 'à')+(' midi' if match[2] else f' {hour}h{minute:02}')
        return candidate,label+(' UTC' if zone.key=='UTC' else ''),before
    if not matches and re.search(r'\bfin (?:de la )?(?:periode|fenetre)\b',points):
        before=bool(re.search(r'\bavant\s+(?:la\s+)?fin\b',points))
        return b,('avant' if before else 'à')+' la fin de la fenêtre',before
    return None


def local(value):
    return datetime.fromisoformat(value).astimezone(PARIS)


def status_only_question(question,ctx):
    """Only closed status questions at a validated time bypass synthesis.

    Unknown words or an additional request keep the normal generated diagnosis.
    No equipment, date or authorization is inferred here.
    """
    latest=question.rsplit('\nPrécision utilisateur : ',1)[-1]
    if not temporal_reference(latest,ctx['start'],ctx['end']):return False
    text=normalized(latest)
    text=re.sub(r'\b\d{1,2}\s*(?:h(?:eures?)?|:)\s*(?:\d{2})?(?!\d)','',text)
    allowed=set(('a avant midi heure heures de du en paris europe utc l le la les un une ce cette cet '
        'est etait etaient sont il elle ils elles t et deja encore toujours '
        'alerte alertes evenement evenements incident incidents probleme problemes '
        'resolu resolue resolus resolues termine terminee termines terminees fini finie finis finies '
        'ticket tickets dossier dossiers cloture cloturee clotures cloturees clos close closes '
        'ferme fermee fermes fermees technique administratif administrative').split())
    words=set(re.findall(r'\w+',text))
    return bool(words) and words<=allowed


def stamp(value):
    return local(value).strftime('%d/%m/%Y à %Hh%M')


def duration(seconds):
    seconds=float(seconds)
    raw=f'{seconds:g}'
    if seconds%60==0:
        minutes=int(seconds/60);hours,rest=divmod(minutes,60)
        civil=f'{hours}h{rest:02}' if hours else f'{minutes} min'
        return f'{civil} ({minutes} minutes ; {raw} secondes)'
    return raw+' secondes'


def temporal_answer(out,plain,cite):
    if not temporal_question(out.get('question','')):
        return []
    text=temporal_text(out['question']);ctx=out['context'];events=out['events']
    lines=['**Réponse à votre question**','']
    if not events:
        lines.append('**Impossible de confirmer la résolution : aucune alerte exploitable n’a été récupérée.** Une absence d’alerte ou une source indisponible ne prouve pas que l’incident était terminé.')
        return lines
    a,b=local(ctx['start']),local(ctx['end']);target=None;target_label=''
    reference=temporal_reference(out['question'],ctx['start'],ctx['end'])
    strict_before=False
    if reference:target,target_label,strict_before=reference
    elif re.search(r'\bmidi\b',text) and a.date()!=b.date():
        lines.append('La fenêtre couvre plusieurs jours : précisez de quel midi il s’agit. Les horaires observés sont indiqués ci-dessous.')
    if len(events)>1:
        lines.append('Plusieurs événements d’alerte ont été retrouvés : leurs états sont détaillés séparément, sans supposer qu’ils constituent un incident unique.')
    for event in events:
        source=cite([event['source_id']]);finish=local(event['end']) if event.get('end') else None
        name=plain(event['equipment']+' — '+event['title'])
        if target and (local(event['begin'])>=target if strict_before else local(event['begin'])>target):
            lines.append(f'**L’événement {name} n’avait pas encore commencé {target_label}.** {source}')
        elif target and finish:
            yes=finish<target if strict_before else finish<=target
            lines.append(f'**{"Oui" if yes else "Non"} : l’événement {name} {"était déjà résolu" if yes else "n’était pas encore résolu"} {target_label}.** {source}')
        elif finish:
            lines.append(f'**Résolution observée pour {name} : {stamp(event["end"])} (Europe/Paris).** {source}')
        else:
            lines.append(f'**Résolution non observée pour {name} : les données consultées ne permettent pas de confirmer qu’il était terminé.** {source}')
        lines.append(f'- Début : **{stamp(event["begin"])}**. {source}')
        lines.append(f'- Résolution : **{stamp(event["end"]) if finish else "non observée"}**. {source}')
        start_overlap=max(local(event['begin']),a);end_overlap=min(finish or b,b)
        seconds=max(0,(end_overlap-start_overlap).total_seconds())
        span=f', de {start_overlap:%Hh%M} à {end_overlap:%Hh%M}' if seconds else ''
        lines.append(f'- Chevauchement avec la fenêtre **{a:%Hh%M}–{b:%Hh%M}** : **{duration(seconds)}**{span}. {source}')
        if not finish:lines.append('Le chevauchement utilise la fin de la fenêtre comme borne ; ce n’est pas une heure de résolution.')
        ticket=event.get('ticket')
        if ticket:
            close=ticket.get('closed_at')
            lines.append('- Ticket '+plain(ticket['id'])+' : **'+('clôturé le '+stamp(close) if close else 'clôture non enregistrée')+'**. La résolution technique et la clôture du dossier sont distinctes. '+source)
            if target and close:
                closed=local(close)<target if strict_before else local(close)<=target
                lines.append('**'+('Oui' if closed else 'Non')+' : le ticket '+plain(ticket['id'])+
                    (' était déjà clôturé ' if closed else ' n’était pas encore clôturé ')+target_label+'.** '+source)
    lines.append('Horaires en Europe/Paris. La résolution de cet événement ne démontre pas, à elle seule, que tout le service était rétabli.')
    return lines
