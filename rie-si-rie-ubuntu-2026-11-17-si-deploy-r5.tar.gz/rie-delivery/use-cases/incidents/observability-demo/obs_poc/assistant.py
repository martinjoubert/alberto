"""Client-independent incident dialogue, signed continuation and MCP contract.

Only server-issued context can resume a conversation. Every complete turn reads
fresh sources; no historical observations are accepted as current evidence.
"""
import hashlib
import hmac
import secrets
import threading
import time
import uuid
import os
import math
import logging
from contextlib import contextmanager
from contextvars import ContextVar
from dinum_access import (current_subject, access_information, require_indices,
                         require_resources, AccessDenied, guard_result)
from pathlib import Path
from typing import Annotated, Any, Literal
from pydantic import BaseModel, ConfigDict, Field
from .domain import context, normalized, QueryError, reference_period, window
from .focused_answer import temporal_reference,status_only_question
from dinum_albert.dialogue import (Interpreter, validate_decision, DialogueError,
    dialogue_max_states, dialogue_state_lock, expired_dialogue_file)
from dinum_albert import AlbertError

import re
import json
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from dinum_albert.natural_dates import french_window, relative_window

PARAMETERS=('equipment','scope','start','end','reference_start','reference_end')
KEY_LOCK=threading.Lock()


def referenced_period_state(question,state):
    """A new subject can explicitly reuse signed dates, without old selectors."""
    if not state or state['pending']:return None
    text=normalized(question)
    reference=r'(?:(?:ce|cette|la|le)\s+)?meme\s+(?:creneau|periode|fenetre|intervalle)\b'
    if (not re.search(reference,text)
            or re.match(r'^(?:nouvelle (?:demande|question)|autre demande|recommencons)\s*:',text)
            or re.search(r'\b(?:pas|hors|sauf)\s+(?:(?:sur|dans|pendant|pour)\s+)?'+reference,text)):
        return None
    previous=state['parameters']
    try:window(previous['start'],previous['end'])
    except QueryError:return None
    parameters={key:'' for key in PARAMETERS}
    parameters.update(start=previous['start'],end=previous['end'])
    return {'question':question,'replies':[],'parameters':parameters,
            'pending':False,'reference_pending':False}


def signing_key(settings):
    """Keep the signing secret server-only; the client knows its MCP bearer token."""
    path=settings.reports/'.continuation.key'
    with KEY_LOCK:
        path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        try:
            descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        except FileExistsError:pass
        else:
            with os.fdopen(descriptor,'w') as stream:
                stream.write(secrets.token_hex(32));stream.flush();os.fsync(stream.fileno())
        descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(descriptor) as stream:
            metadata=os.fstat(stream.fileno());key=stream.read(65)
        if metadata.st_uid!=os.geteuid() or metadata.st_mode&0o077 or not re.fullmatch(r'[0-9a-f]{64}',key):
            raise ValueError('Invalid server continuation key.')
        return key


class IncidentResult(BaseModel):
    """Stable public fields; diagnostic evidence remains available as extra fields."""
    model_config=ConfigDict(extra='allow')
    application: Literal['observability']='observability'
    status: Literal['ok','partial','clarification','error','cancelled','rate_limited','denied']
    request_id: str
    answer: str
    continuation_token: str | None=None
    sources: list[dict[str,Any]]=Field(default_factory=list)


class Continuations:
    """Authenticate compact intent state, bound to one backend/preset and expiry."""
    def __init__(self,key,namespace,ttl=3600,clock=time.time,directory=None,*,max_states=None):
        if not key:raise ValueError('A configured MCP credential is required for continuation signing.')
        self.key=hmac.digest(key.encode(),b'incident-dialogue-v1','sha256')
        self.namespace=namespace;self.ttl=ttl;self.clock=clock
        self.max_states=dialogue_max_states(max_states)
        self.directory=Path(directory) if directory else None;self.states={};self.lock=threading.Lock()
        if self.directory:self.directory.mkdir(parents=True,exist_ok=True,mode=0o700)
    def issue(self,state):
        # Short opaque handles avoid requiring a model to copy an encoded request.
        nonce=secrets.token_hex(8)
        payload={'version':1,'namespace':self.namespace,'expires':int(self.clock()+self.ttl),
                 'owner':current_subject(),'state':state}
        with dialogue_state_lock(self.directory,self.lock) if self.directory else self.lock:
            if self.directory:
                for path in self.directory.glob('*.json'):
                    try:
                        if expired_dialogue_file(path,self.ttl,self.clock()):path.unlink(missing_ok=True)
                    except FileNotFoundError:continue
                if len(list(self.directory.glob('*.json')))>=self.max_states:raise ValueError('Continuation capacity reached.')
                descriptor=os.open(self.directory/(nonce+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
                with os.fdopen(descriptor,'w') as stream:json.dump(payload,stream,ensure_ascii=False)
            else:
                self.states={k:v for k,v in self.states.items() if v['expires']>self.clock()}
                if len(self.states)>=self.max_states:raise ValueError('Continuation capacity reached.')
                self.states[nonce]=payload
        signature=hmac.new(self.key,(self.namespace+':'+nonce).encode(),hashlib.sha256).hexdigest()[:32]
        return nonce+'.'+signature
    def read(self,token):
        try:
            if not isinstance(token,str) or not re.fullmatch(r'[0-9a-f]{16}\.[0-9a-f]{32}',token):raise ValueError()
            nonce,signature=token.split('.')
            expected=hmac.new(self.key,(self.namespace+':'+nonce).encode(),hashlib.sha256).hexdigest()[:32]
            if not hmac.compare_digest(signature,expected):raise ValueError()
            if self.directory:
                descriptor=os.open(self.directory/(nonce+'.json'),os.O_RDONLY|os.O_NOFOLLOW)
                with os.fdopen(descriptor) as stream:data=json.load(stream)
            else:data=self.states[nonce]
            if data['version']!=1 or data['namespace']!=self.namespace or data['expires']<=self.clock():raise ValueError()
            if data.get('owner','')!=current_subject():raise ValueError()
            state=data['state']
            if set(state)!={'question','replies','parameters','pending','reference_pending'}:raise ValueError()
            if not isinstance(state['question'],str) or len(state['question'])>2000:raise ValueError()
            if not isinstance(state['replies'],list) or len(state['replies'])>12 or any(not isinstance(v,str) for v in state['replies']):raise ValueError()
            if set(state['parameters'])!=set(PARAMETERS) or any(not isinstance(v,str) or len(v)>100 for v in state['parameters'].values()):raise ValueError()
            return state
        except (ValueError,TypeError,KeyError,UnicodeError,OSError):
            raise QueryError('Reprise invalide ou expirée : reformulez une nouvelle demande complète.') from None


class Admission:
    """Share one admission per turn across interpretation, diagnosis and review.

    The interval belongs to this server process. A turn can make several model
    calls; provider token/request quotas still need their own target-SI check.
    """
    def __init__(self,interval=0,clock=time.monotonic):
        if isinstance(interval,bool) or not math.isfinite(interval) or not 0<=interval<=86400:
            raise ValueError('Provider admission interval must be between 0 and 86400 seconds.')
        self.interval=interval;self.clock=clock;self.next=0;self.lock=threading.Lock()
        self._turn=ContextVar('incident_admission_turn',default=None)
    @contextmanager
    def turn(self):
        if self._turn.get() is not None:
            yield
            return
        token=self._turn.set([False])
        try:yield
        finally:self._turn.reset(token)
    def reserve(self):
        with self.lock:
            turn=self._turn.get()
            if turn is not None and turn[0]:return 0
            now=self.clock();remaining=max(0,self.next-now)
            if not remaining:
                self.next=now+self.interval
                if turn is not None:turn[0]=True
            return int(remaining)+1 if remaining else 0


class IncidentAssistant:
    """Own user intent and validation; the MCP client only relays text and a token."""
    def __init__(self,settings,execute,namespace,admission=None,continuations=None,interpreter=None):
        self.s=settings;self.execute=execute
        principal=hashlib.sha256(settings.mcp_token.encode()).hexdigest()
        self.tokens=continuations or Continuations(signing_key(settings),namespace+':'+principal,directory=settings.reports/'.continuations')
        self.admission=admission or Admission()
        self.interpreter=interpreter
    def failure(self,message,status='error',**extra):
        return {'application':'observability','request_id':uuid.uuid4().hex,'status':status,
                'answer':message,'sources':[],'errors':[],'usage':[],'continuation_token':None,
                'assistant_contract':'incident-dialogue-v1',**extra}
    def _capture(self,question,state):
        raw=normalized(question)
        if re.match(r'^(?:annule(?:r)?|abandonne|stop)\b',raw):return None
        if re.search(r'\b(?:poeme|meteo|vacances|recette de cuisine)\b',raw):
            raise QueryError('Ce service traite les incidents réseau du périmètre configuré. Précisez une demande de diagnostic.')
        reset=bool(re.match(r'^(?:nouvelle (?:demande|question)|autre demande|recommencons)\s*:',raw))
        state=None if reset else state
        if state and len(state['replies'])>=12:raise QueryError('Douze précisions maximum : reformulez une nouvelle demande complète.')
        parameters=dict(state['parameters']) if state else {key:'' for key in PARAMETERS}
        if state and not state['pending'] and not re.search(r'\bmeme\s+(?:comparaison|reference)\b',raw):
            parameters.update(reference_start='',reference_end='')
        replies=[*state['replies'],question] if state else []
        original=state['question'] if state else question
        corpus=self.s.manifest();hosts=corpus['hosts']
        # Resolve only user-written names. Include denied hosts so R4 is refused,
        # never confused with a missing selector or the previous authorized host.
        identity_text=re.sub(r'\b(?:pas|non)\s+(?:OBS-RTR-\d{2}|R\d+)\b','',question,flags=re.I)
        identity_text=re.sub(r'\bau lieu de\s+(?:OBS-RTR-\d{2}|R\d+)\b','',identity_text,flags=re.I)
        selectors=[]
        for host in hosts:
            if any(re.search(r'(?<![\w.-])'+re.escape(normalized(v))+r'(?![\w-]|\.\w)',normalized(identity_text)) for v in [host['equipment'],*host.get('aliases',[])]):
                selectors.append(host['equipment'])
        scopes={h['scope'] for h in hosts}|set(corpus.get('scope_aliases',{}))
        matched=[v for v in scopes if re.search(r'(?<![\w.-])'+re.escape(normalized(v))+r'(?![\w-]|\.\w)',raw)]
        # A long label such as "Site de Rennes" subsumes its short alias Rennes.
        matched=[v for v in matched if not any(normalized(v)!=normalized(other) and normalized(v) in normalized(other) for other in matched)]
        if selectors:parameters.update(equipment='/'.join(dict.fromkeys(selectors)),scope='')
        if matched:parameters.update(scope='/'.join(sorted(matched)),equipment=parameters['equipment'] if selectors else '')
        if not selectors and re.search(r'(?<![\w.-])(?:OBS-RTR-\d+|R\d+)(?:[\w-]|\.(?=\w))*(?![\w-]|\.\w)',identity_text,re.I):
            parameters.update(equipment=re.search(r'(?<![\w.-])(?:OBS-RTR-\d+|R\d+)(?:[\w-]|\.(?=\w))*(?![\w-]|\.\w)',identity_text,re.I)[0],scope='')
        if not selectors and not matched and not re.search(r'\b(?:meme|ce|cet|cette|precedent)\s+(?:site|perimetre|routeur|equipement)\b',raw):
            # A lowercase unknown name must also invalidate older scope.
            unknown=re.search(r'\b(?:site(?: de)?|perimetre|routeur|equipement)\s+([\w-]+)',raw)
            if not unknown:unknown=re.search(r'\bsur\s+([\w-]+)',raw)
            if unknown and unknown[1] not in {'le','la','les','de','du','ce','cet','cette','un','une','ou'} and not unknown[1].isdigit():
                parameters.update(scope=unknown[1],equipment='')
        def parse_window(text,now=None):
            # Invalid civil dates remain a clarification, without source reads.
            try:return french_window(text,now)
            except ValueError:return None
        bounds=parse_window(question,datetime.now(timezone.utc))
        if not bounds and state and state['pending']:
            bounds=parse_window('PDL_DIALOGUE\n'+json.dumps({'request':original,'replies':replies},ensure_ascii=False))
        if not bounds and parameters['start'] and re.match(r'^\s*(?:plutot\s+)?(?:de|entre)\s+',raw):
            day=datetime.fromisoformat(parameters['start']).astimezone(ZoneInfo('Europe/Paris'))
            months='janvier fevrier mars avril mai juin juillet aout septembre octobre novembre decembre'.split()
            bounds=parse_window(f'le {day.day} {months[day.month-1]} {day.year} '+question)
        if bounds:
            prefix='reference_' if state and state['reference_pending'] and not re.search(r'\bsans comparaison\b',raw) else ''
            parameters.update({prefix+key:value for key,value in bounds.items()})
        elif (re.search(r'\b(?:le|du)\s+\d|\b\d{4}-\d{2}-\d{2}',raw)
              or (re.search(r'\b(?:de|entre|a|avant)\s+\d{1,2}\s*(?:h|:)',raw)
                  and (re.search(r'\b(?:de|entre)\s+\d{1,2}\s*(?:h|:)',raw)
                       or not temporal_reference(question,parameters['start'],parameters['end'])))):
            parameters.update(start='',end='')
        reference=re.search(r'\b(?:reference|periode de comparaison|fenetre de reference)\s*:\s*(.*)',raw,re.S)
        if reference:
            ref=parse_window(reference[1]) or {'start':'','end':''}
            parameters.update({'reference_'+key:value for key,value in ref.items()})
        effective=original+''.join('\nPrécision utilisateur : '+v for v in replies) if state and state['pending'] else question
        if len(effective)>2000:raise QueryError('Demande complétée trop longue : reformulez une nouvelle demande complète.')
        return {'question':effective,'replies':[],'parameters':parameters,'pending':False,'reference_pending':False}
    def run(self,question,continuation_token='',synthesize=True):
        with self.admission.turn():
            return self._run(question,continuation_token,synthesize)
    def _run(self,question,continuation_token='',synthesize=True):
        phase='request_validation'
        try:
            if not isinstance(question,str) or not question.strip() or len(question)>2000:raise QueryError('Question vide ou trop longue.')
            access=access_information(question.strip())
            if access is not None:
                return {**access,'application':'observability','status':'ok','continuation_token':None,
                        'assistant_contract':'incident-dialogue-v1','usage':[],'errors':[]}
            state=self.tokens.read(continuation_token) if continuation_token else None
            phase='authorization'
            try:
                require_indices(self.s.logs_index+','+self.s.docs_index)
                require_resources(('incidents.metrics','incidents.tickets'))
            except AccessDenied:return guard_result(self.failure('Accès refusé.','denied'))
            semantic=None
            direct_status=bool(state and not state['pending'] and status_only_question(question,state['parameters']))
            if self.interpreter or direct_status:
                if direct_status:
                    decision={'action':'follow_up','confidence':1.,'clarification':''}
                    usage={'albert_calls':0,'interpretation':'source_facts'}
                else:
                    retry=self.admission.reserve()
                    if retry:
                        return self.failure(f'Budget IA : réessayez dans {retry} secondes. Aucune nouvelle source consultée.',
                            'rate_limited',retry_after_seconds=retry,
                            continuation_token=continuation_token or None)
                    intent_state=None if state is None else {'request':state['question'],'replies':state['replies'],
                        'status':'clarification' if state['pending'] else 'ok','clarification':'','pending_message':'','parameters':state['parameters']}
                    phase='dialogue_interpretation'
                    decision,usage=self.interpreter(question.strip(),intent_state)
                action=validate_decision(decision,state is not None)
                semantic={'action':action,**usage}
                if action=='out_of_scope':
                    return self.failure('Cette demande est hors du périmètre du profil Incidents. Sélectionnez le profil PDL pour rechercher ou compter des journaux. Aucune source métier consultée.','clarification',dialogue=semantic,continuation_token=self.tokens.issue(state) if state else None)
                if action=='clarify':
                    answer=decision['clarification'] or 'Souhaitez-vous reprendre la demande précédente ou commencer un autre diagnostic ?'
                    return self.failure(answer,'clarification',dialogue=semantic,
                        continuation_token=self.tokens.issue(state) if state else None)
                if action=='cancel':return self.failure('Demande annulée. Aucune source consultée.','cancelled',dialogue=semantic)
                if action=='new':
                    state=referenced_period_state(question,state)
                    if state:semantic['context_resolution']={'fields':['start','end'],'origin':'signed_previous_period'}
                if action=='access':
                    access=access_information('Quels sont mes droits ?')
                    return {**access,'application':'observability','status':'ok','dialogue':semantic,
                            'continuation_token':self.tokens.issue(state) if state else None}
                phase='intent_capture'
                captured=self._capture(question.strip(),{**state,'pending':True} if action=='retry' else state)
                if captured:
                    captured={**captured,'parameters':dict(captured['parameters']),'replies':list(captured['replies'])}
            else:
                phase='intent_capture'
                captured=self._capture(question.strip(),state)
            if captured is None:return self.failure('Demande annulée. Aucune source de diagnostic consultée.','cancelled')
            parameters=captured['parameters']
            phase='domain_validation'
            try:
                context(self.s.manifest(),**parameters)
                reference_period(captured['question'],parameters['start'],parameters['end'],parameters['reference_start'],parameters['reference_end'])
            except QueryError as exc:
                if not exc.fields:
                    if not semantic:return self.failure(str(exc))
                    out=self.failure(str(exc))
                else:
                    # The domain service builds its usual clarification with zero reads.
                    phase='source_execution'
                    out=self.execute(captured['question'],**parameters,synthesize=synthesize)
            else:
                retry=self.admission.reserve() if synthesize and not direct_status else 0
                if retry:
                    out=self.failure(f'Budget Albert : réessayez dans {retry} secondes. Aucune nouvelle source consultée.',
                        'rate_limited',retry_after_seconds=retry)
                else:
                    phase='source_execution'
                    out=self.execute(captured['question'],**parameters,synthesize=synthesize)
            phase='continuation_write'
            if out['status'] in ('clarification','ok','partial','rate_limited','denied') or (semantic and out['status']=='error'):
                pending=out.get('pending_request')
                captured['pending']=out['status']=='clarification'
                captured['reference_pending']=bool(pending and set(pending['missing_fields'])=={'reference_start','reference_end'})
                # Preserve explicit incomplete date fragments through split replies.
                if captured['pending'] and (not semantic or semantic['action']!='retry'):
                    captured['question']=state['question'] if state and state['pending'] else question.strip()
                    captured['replies']=[*state['replies'],question.strip()] if state and state['pending'] else []
                if out.get('context'):
                    captured['parameters'].update({key:out['context'].get(key,'') for key in PARAMETERS})
                out['continuation_token']=self.tokens.issue(captured)
            else:out['continuation_token']=None
            out['assistant_contract']='incident-dialogue-v1'
            if semantic:out['dialogue']=semantic
            return out
        except (QueryError,ValueError,TypeError,OSError,KeyError,AlbertError) as exc:
            code=(str(exc) if isinstance(exc,DialogueError) and str(exc) in
                  {'dialogue_invalid_json','dialogue_invalid_response','dialogue_invalid_decision'} else
                  'provider_unavailable' if isinstance(exc,AlbertError) else 'invalid_request' if isinstance(exc,QueryError) else 'turn_failed')
            answer=(str(exc) if isinstance(exc,QueryError) else
                    'Albert n’a pas fourni une interprétation valide ; aucun diagnostic publié. Reformulez une demande complète.'
                    if phase=='dialogue_interpretation' else
                    'Le traitement a échoué ; aucun diagnostic publié. Consultez les journaux avec l’identifiant de demande.')
            out=self.failure(answer,errors=[{'source':'dialogue' if phase=='dialogue_interpretation' else 'assistant',
                                           'code':code,'phase':phase}])
            if isinstance(exc,(DialogueError,AlbertError)) and hasattr(exc,'diagnostics'):out['dialogue']=exc.diagnostics
            if isinstance(exc,AlbertError):out['errors'][0]['provider_code']=exc.code
            logging.getLogger(__name__).warning('incident_turn_failed request_id=%s phase=%s code=%s',out['request_id'],phase,code)
            return out


def assistant_server(settings,variant,execute,admission=None,interpreter=None):
    """Expose a portable two-argument tool with a typed MCP output schema."""
    from mcp.server.mcpserver import MCPServer
    from mcp.types import ToolAnnotations
    engine=IncidentAssistant(settings,execute,variant,admission,interpreter=interpreter)
    server=MCPServer(name='incident-assistant-'+variant,instructions=
        'Copy the entire current user message verbatim to diagnose_observability, including every sentence and paragraph. '
        'Never summarize it or drop trailing equipment, scope, date or time information. '
        'For a follow-up in this conversation, pass only its latest server-issued continuation_token. '
        'Display a clarification or refusal as such; never turn it into a diagnosis. '
        'The server owns scope, dates, fresh evidence and the validated report.')
    @server.tool(name='diagnose_observability',structured_output=True,annotations=ToolAnnotations(
        readOnlyHint=True,destructiveHint=False,idempotentHint=False,openWorldHint=False))
    def diagnose(question:Annotated[str,Field(description=
            'Exact, complete current user message, copied verbatim. Include ALL sentences and paragraphs, '
            'especially equipment, scope, date and time stated after the initial question. '
            'Do not summarize, shorten, translate or infer parameters.')],
            continuation_token:Annotated[str,Field(description=
            'Latest server-issued continuation_token from this conversation, copied exactly; empty for a new conversation.')]='')->IncidentResult:
        """Investigate a network incident or resume it with the last server token.

        Send the ENTIRE current user message, including trailing clarification sentences.
        Never send only its first sentence. Do not infer dates, router IDs or scope.
        Keep continuation_token empty for a new conversation. For clarification,
        relay answer to the user and call again with their reply and the returned
        token. Tokens are short backend-issued handles, expire after one hour and contain no
        source observations. The request state stays on the server. Return answer with its evidence and limitations.
        """
        return IncidentResult.model_validate(engine.run(question,continuation_token))
    return server
