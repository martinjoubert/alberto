"""Prepare the visible OpenWebUI editor before a browser recipe sends a turn."""
import re

from playwright.sync_api import expect


def before_typing(page):
    """Dismiss welcome/release notes without accepting terms or other dialogs."""
    editor = page.locator('#chat-input')
    expect(editor).to_be_visible(timeout=180000)
    for attempt in range(3):
        dialogs = [dialog for dialog in page.get_by_role('dialog').all() if dialog.is_visible()]
        if not dialogs:
            break
        for dialog in dialogs:
            text = dialog.inner_text().casefold()
            if not any(label in text for label in (
                "what's new", 'what’s new', 'quoi de neuf', 'nouveautés', 'changelog',
                'welcome to open webui', 'bienvenue dans open webui',
            )):
                raise RuntimeError('Unexpected dialog blocks the chat editor; no agreement accepted.')
            close = dialog.get_by_role('button', name=re.compile(r'^(close|fermer|dismiss|ignorer|×)$', re.I))
            if close.count():
                close.first.click()
            else:
                page.keyboard.press('Escape')
            expect(dialog).not_to_be_visible(timeout=5000)
    if any(dialog.is_visible() for dialog in page.get_by_role('dialog').all()):
        raise RuntimeError('A dialog still blocks the chat editor.')
    expect(editor).to_be_visible(timeout=30000)
    return editor


def enter_question(page, question, *, expected_model_label=None):
    """Return the send button only after DOM and ProseMirror hold the full text."""
    editor = before_typing(page)
    if expected_model_label:
        expect(page.locator('#model-selector-model-button')).to_have_text(expected_model_label, timeout=30000)
    editor.fill(question)
    if '\n' in question:
        # ProseMirror separates paragraphs with two newlines. Use hard breaks
        # within paragraphs so the serialized request preserves the test input.
        editor.evaluate(r'''(element, text) => {
          const content = text.split('\n\n').map(paragraph => ({type: 'paragraph',
            content: paragraph.split('\n').flatMap((line, i) => [
              ...(i ? [{type: 'hardBreak'}] : []), ...(line ? [{type: 'text', text: line}] : [])])}));
          element.editor.commands.setContent({type: 'doc', content});
        }''', question)
    exact = '''question => {
      const editor = document.querySelector('#chat-input');
      return (editor?.editor?.getText?.() ?? editor?.innerText) === question;
    }'''
    page.wait_for_function(exact, arg=question, timeout=10000)
    send = page.locator('#send-message-button')
    expect(send).to_be_visible(timeout=30000)
    expect(send).to_be_enabled(timeout=30000)
    return send
