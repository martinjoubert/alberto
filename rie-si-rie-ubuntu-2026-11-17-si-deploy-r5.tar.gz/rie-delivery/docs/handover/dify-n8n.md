# Dify ou n8n pour les UC du SI-RIE

Évaluation documentaire du **6 novembre 2026**. Aucune de ces plateformes n’est
installée ni qualifiée par cette étude.

## Décision proposée

La priorité reste la livraison autonome du code actuel : UC PDL, UC Incidents
et ACL, avec Open WebUI sur les postes utilisateurs. Ajouter maintenant une
plateforme imposerait une installation et une recette supplémentaires.

Pour un essai ultérieur centré sur la création et la transmission d’applications
IA entre développeurs, **Dify est le premier candidat proposé**. Son atelier
regroupe modèles, workflows, conversations et recherche documentaire. **n8n
serait préférable si le besoin principal devenait l’automatisation du SI** :
enchaîner des API, déclencher un traitement sur un événement, préparer un ticket
ou programmer une tâche. Cette recommandation découle des fonctions documentées ;
elle ne constitue pas encore un résultat de test dans le SI-RIE.

## Ce que chaque édition communautaire apporte

| Critère | Dify Community | n8n Community |
|---|---|---|
| Orientation | Applications IA, workflows/chatflows, modèles et RAG | Automatisation entre services, avec étapes IA |
| Réutilisation des UC | Outils MCP HTTP, OpenAPI et appels HTTP | Client MCP, appels HTTP et connecteurs |
| Travail à plusieurs | Membres et rôles intégrés dans un workspace | Partage des workflows et credentials exclu de Community |
| Transfert | Export/import de packages d’application | Export/import de workflows JSON |
| Limites structurantes | Plusieurs workspaces, rôles personnalisés, droits fins et SSO : Enterprise | Projets, SSO, Git/environnements et partage : offres payantes |

Dify possède bien des rôles communautaires Owner, Admin, Editor et Normal.
Les droits granulaires par application ou base documentaire et les rôles
personnalisés relèvent d’Enterprise. Le workspace communautaire unique peut
convenir à un premier atelier d’équipe ; il ne prouve pas un cloisonnement entre
équipes du SI. Voir les documentations officielles sur les
[membres](https://docs.dify.ai/en/self-host/use-dify/workspace/team-members-management)
et les [workspaces](https://docs.dify.ai/en/self-host/use-dify/workspace/readme).

La limitation de collaboration de n8n Community compte particulièrement pour
ce besoin de transmission : seuls le propriétaire de l’instance et le créateur
accèdent aux workflows et credentials concernés. L’export/import reste possible,
mais ne remplace pas un espace partagé avec Git intégré. Voir la
[comparaison officielle des éditions](https://docs.n8n.io/deploy/host-n8n/community-edition-features.md).

## Porter les UC sans réécrire leurs contrôles

Les deux UC possèdent déjà un moteur Python : interprétation et clarification,
validation, lectures bornées, calcul des faits, preuves et relecture. Le chemin
le plus accessible serait de **conserver ces moteurs et de les appeler depuis
la plateforme**. Dify documente les outils
[MCP HTTP et OpenAPI](https://docs.dify.ai/en/self-host/use-dify/workspace/tools) ;
n8n propose un [client MCP](https://docs.n8n.io/integrations/builtin/cluster-nodes/sub-nodes/n8n-nodes-langchain.toolmcp/)
avec plusieurs modes d’authentification.

Recréer toute la logique dans des blocs visuels serait une migration avec risque
de régression, et non un simple import. Les ACL doivent rester imposées côté
serveur, avant les lectures. Un rôle d’éditeur ou un credential partagé de
workflow ne représente pas l’identité de chaque utilisateur. Il faudra vérifier
la transmission de cette identité, l’isolement des reprises de dialogue, les
refus d’accès et la restitution des preuves. La compatibilité MCP annoncée ne
suffit pas à qualifier ces comportements.

Les futurs UC pourront suivre le même principe s’ils exposent un contrat stable
MCP ou HTTP. Leur logique métier, leurs sources et leurs autorisations resteront
à configurer et à tester ; il n’existe pas de portage automatique universel.

## Transfert et exploitation dans le SI-RIE

La [documentation Dify actuelle](https://docs.dify.ai/en/self-host/use-dify/workspace/export-import-apps)
décrit un export `.ifpkg`, comprenant notamment un DSL `app.yaml`. Il n’emporte
pas tout : bases documentaires, outils MCP/OpenAPI, intégrations et credentials
nécessitent une préparation distincte. Un transfert reproductible doit donc
accompagner le package d’un inventaire des dépendances et des versions.
n8n permet l’[export/import JSON](https://docs.n8n.io/build/manage-workflows/export-and-import.md),
avec références et credentials à reconfigurer. Les exports doivent être relus
avant partage, notamment pour retirer les valeurs sensibles éventuellement
inscrites dans des paramètres HTTP.

Auto-héberger ne garantit pas le fonctionnement sans Internet. Il faudra
préparer images, plugins, modèles, certificats et accès aux services internes,
puis vérifier les flux. n8n documente comment
[désactiver ses connexions de diagnostic, versions et templates](https://docs.n8n.io/deploy/host-n8n/configure-n8n/basic-configuration/configuration-examples/isolate-n8n.md).
Dify ajoute une infrastructure à exploiter, avec notamment une base de données
et un stockage vectoriel dans son
[installation Compose](https://docs.dify.ai/en/self-host/quick-start/docker-compose).
L’accès à Albert, ou à un moteur interne, reste une dépendance distincte.

Les licences comportent aussi des conditions : n8n utilise la
[Sustainable Use License](https://docs.n8n.io/n8n-community-license/), qui prévoit
l’usage interne ; Dify utilise une
[licence Apache 2 modifiée](https://github.com/langgenius/dify/blob/main/LICENSE),
avec restrictions sur les environnements multi-tenant et les marques du
frontend. Aucune ne doit être présentée comme une licence Apache 2 standard.

## Premier essai après la livraison

Tester un parcours Incidents dans Dify, avec le backend actuel, puis comparer
réponses et preuves avec le client existant. La recette couvrira au minimum une
clarification avec reprise, une lecture autorisée, un refus ACL et le transfert
vers une seconde installation. Son résultat permettra de décider si le gain
pour les développeurs justifie une plateforme supplémentaire. Cette expérience
est différée, comme les essais d’observabilité ; elle ne conditionne pas la
livraison des deux UC et des ACL.
