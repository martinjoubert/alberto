"""Prove that changed synthetic source data is read again without reusing reports.

Only a dedicated demo (never the endurance instance) can be modified. A new
metric label isolates revised values; original samples are not overwritten.
Ticket/mapping bytes are restored in a finally block. No synthesis or real IA.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime,timezone
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import uuid


def atomic(path,data):
    temporary=path.with_name(path.name+'.qualification.tmp')
    with temporary.open('xb') as out:out.write(data)
    temporary.chmod(0o600);temporary.replace(path)


def embedded_code(source):
    filename='/delivery/qualification_freshness.py'
    return 'exec(compile('+repr(source)+','+repr(filename)+",'exec'), {'__name__':'__main__','__file__':"+repr(filename)+'})'


def remove_test_series(client,marker,metric_names):
    """Remove only our exact, disposable namespace after verifying its members."""
    if not re.fullmatch(r'qualification-fresh-[a-f0-9]{32}',marker):
        raise ValueError('Invalid disposable qualification series namespace')
    selector='{job="dinum-observability",qualification_revision='+json.dumps(marker)+'}'
    response=client.get('http://victoriametrics:8428/api/v1/series',params={'match[]':selector,
        'start':'2026-09-28T09:00:00+02:00','end':'2026-09-28T13:00:00+02:00'})
    response.raise_for_status();members=response.json().get('data',[])
    if len(members)>20 or any(row.get('qualification_revision')!=marker or row.get('job')!='dinum-observability'
        or row.get('__name__') not in metric_names for row in members):
        raise ValueError('Refusing to clean an unexpected metric series')
    if members:
        client.post('http://victoriametrics:8428/api/v1/admin/tsdb/delete_series',params={'match[]':selector}).raise_for_status()
    return len(members)


def compare(before,changed,restored,marker):
    def maximum(result):return next((row.get('max') for row in result.get('metrics',[]) if row.get('metric')=='latency'),None)
    def marker_present(result):return marker in json.dumps(result.get('events',[]),ensure_ascii=False)
    return {'baseline_complete':before.get('status')=='ok' and not before.get('errors') and len(before.get('metrics',[]))==5,
            'metric_source_change_visible':maximum(before)==80.0 and maximum(changed)==85.0,
            'ticket_source_change_visible':not marker_present(before) and marker_present(changed),
            'fresh_request_ids':len({row['request_id'] for row in (before,changed,restored)})==3,
            'baseline_restored':maximum(restored)==80.0 and not marker_present(restored),
            'no_generation':all(not row.get('usage') and row.get('analysis') is None for row in (before,changed,restored)),
            'logs_preserved':all(row.get('logs',{}).get('total')==120 for row in (before,changed,restored))}


def inside():
    import httpx
    from dinum_access import AccessGate
    from dinum_access.user_tokens import UserTokens
    if os.getenv('PDL_MODE')!='demo' or os.getenv('RIE_LOAD_QUALIFICATION')=='true':raise ValueError('Use a non-load synthetic instance only')
    if os.getenv('OPENSEARCH_URL')!='http://opensearch:9200' or os.getenv('VICTORIAMETRICS_URL')!='http://victoriametrics:8428':
        raise ValueError('Private demo sources required')
    mapping_file=Path('/data/config/metric-mapping.json');ticket_file=Path('/data/config/itsm-tickets.json')
    mapping_bytes=mapping_file.read_bytes();ticket_bytes=ticket_file.read_bytes()
    mapping=json.loads(mapping_bytes);snapshot=json.loads(ticket_bytes)
    marker='qualification-fresh-'+uuid.uuid4().hex
    original_names={spec['name'] for spec in mapping['metrics'].values()}
    revised_names={key:'qualification_'+spec['name']+'_'+marker.rsplit('-',1)[1] for key,spec in mapping['metrics'].items()}
    created=False;report=None
    gate=AccessGate.configured();store=UserTokens(gate.config['user_tokens_directory'])
    body={'question':'Examiner R1 pendant la période de qualification.','variant':'gptoss','equipment':'OBS-RTR-01',
          'start':'2026-09-28T10:00:00+02:00','end':'2026-09-28T12:00:00+02:00','synthesize':False}
    with tempfile.TemporaryDirectory(prefix='rie-freshness-') as private:
        output=Path(private)/'user.token';record=store.issue(gate.directory,'alice.martin',output,days=1)
        headers={'Authorization':'Bearer '+output.read_text().strip()}
        try:
            with httpx.Client(timeout=180,trust_env=False,follow_redirects=False) as client:
                def diagnose():
                    response=client.post('http://incidents:9950/diagnose',headers=headers,json=body)
                    response.raise_for_status();return response.json()
                # Clean only interrupted runs of this exact disposable harness.
                previous=client.get('http://victoriametrics:8428/api/v1/export',params={'match[]':'{job="dinum-observability"}',
                    'start':'2026-09-28T09:00:00+02:00','end':'2026-09-28T13:00:00+02:00'})
                previous.raise_for_status()
                leftovers=[json.loads(line)['metric'] for line in previous.text.splitlines() if line.strip()]
                for old_marker in sorted({row.get('qualification_revision','') for row in leftovers if row.get('qualification_revision','').startswith('qualification-fresh-')}):
                    old_names={row['__name__'] for row in leftovers if row.get('qualification_revision')==old_marker}
                    if not all(name in original_names or name.startswith('qualification_') for name in old_names):
                        raise ValueError('Unexpected metrics in interrupted qualification namespace')
                    remove_test_series(client,old_marker,old_names)
                before=diagnose()
                immutable=json.dumps(before,sort_keys=True)
                response=client.get('http://victoriametrics:8428/api/v1/export',params={
                    'match[]':'{job="dinum-observability",qualification_revision=""}','start':'2026-09-28T09:00:00+02:00','end':'2026-09-28T12:59:59+02:00'})
                response.raise_for_status()
                series=[]
                for line in response.text.splitlines():
                    if not line:continue
                    row=json.loads(line)
                    row['metric']['qualification_revision']=marker
                    if row['metric'].get('equipment')=='OBS-RTR-01' and row['metric'].get('__name__')==mapping['metrics']['latency']['name']:
                        row['values']=[value+5 for value in row['values']]
                    key=next(key for key,spec in mapping['metrics'].items() if spec['name']==row['metric']['__name__'])
                    row['metric']['__name__']=revised_names[key]
                    series.append(row)
                if len(series)!=20:raise ValueError('A complete twenty-series source snapshot is required')
                response=client.post('http://victoriametrics:8428/api/v1/import',content=''.join(json.dumps(row)+'\n' for row in series),headers={'Content-Type':'application/json'})
                response.raise_for_status();created=True
                client.get('http://victoriametrics:8428/internal/force_flush').raise_for_status()
                changed_mapping=deepcopy(mapping);changed_mapping.setdefault('fixed_labels',{})['qualification_revision']=marker
                for key,name in revised_names.items():changed_mapping['metrics'][key]['name']=name
                changed_tickets=deepcopy(snapshot)
                ticket=next(row for row in changed_tickets['tickets'] if row['equipment']=='OBS-RTR-01')
                ticket['title']+=' — '+marker
                ticket['handling'].append({'at':ticket['closed_at'],'actor':'Qualification fictive','text':marker})
                atomic(mapping_file,(json.dumps(changed_mapping)+'\n').encode())
                atomic(ticket_file,(json.dumps(changed_tickets)+'\n').encode())
                changed=diagnose()
                atomic(mapping_file,mapping_bytes);atomic(ticket_file,ticket_bytes)
                restored=diagnose()
                checks=compare(before,changed,restored,marker)
                checks['captured_report_not_mutated']=json.dumps(before,sort_keys=True)==immutable
                report={'at_utc':datetime.now(timezone.utc).isoformat(),'synthetic':True,'passed':all(checks.values()),
                        'checks':checks,'original_samples_replaced':False,'isolated_series_added':len(series),
                        'source_configuration_restored':mapping_file.read_bytes()==mapping_bytes and ticket_file.read_bytes()==ticket_bytes,
                        'reports':{'before':before,'changed':changed,'restored':restored}}
                return report
        finally:
            try:
                atomic(mapping_file,mapping_bytes);atomic(ticket_file,ticket_bytes)
                if created:
                    with httpx.Client(timeout=30,trust_env=False) as cleanup:
                        removed=remove_test_series(cleanup,marker,set(revised_names.values()))
                    if report is not None:report['disposable_series_removed']=removed
            finally:
                store.revoke(record['id'])


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('instance',nargs='?',type=Path);parser.add_argument('--output',type=Path)
    parser.add_argument('--inside',action='store_true');args=parser.parse_args();os.umask(0o077)
    if args.inside:
        report=inside();print(json.dumps(report,ensure_ascii=False));return 0 if report['passed'] else 2
    if not args.instance or not args.output:parser.error('instance and --output required')
    source=Path(__file__).resolve()
    spec=importlib.util.spec_from_file_location('freshness_manage',source.with_name('manage.py'))
    manager=importlib.util.module_from_spec(spec);spec.loader.exec_module(manager)
    instance=args.instance.expanduser().resolve();values=manager.load(instance);manager.guard(instance,values)
    if values['RIE_MODE']!='demo' or values.get('RIE_LOAD_QUALIFICATION')=='true':raise ValueError('A non-load demo is required')
    destination=args.output.expanduser().resolve()
    if destination.exists() or destination.is_relative_to(manager.ROOT):raise ValueError('Choose a new private output outside checkout')
    destination.mkdir(parents=True,mode=0o700)
    # The public harness is supplied as code, never credentials, allowing it to
    # exercise a previously built image without rewriting that image's filesystem.
    code=embedded_code(source.read_text())
    try:
        result=manager.tool(instance,values,'python','-c',code,'--inside',capture=True)
        raw=result.stdout
    except subprocess.CalledProcessError as error:
        raw=error.stdout or ''
        if not raw:
            report={'passed':False,'error':'freshness_harness_failed_before_report'}
            (destination/'report.json').write_text(json.dumps(report)+'\n')
            return 2
    report=json.loads(raw)
    (destination/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'checks':report['checks'],'output':str(destination)}))
    return 0 if report['passed'] else 2


if __name__=='__main__':raise SystemExit(main())
