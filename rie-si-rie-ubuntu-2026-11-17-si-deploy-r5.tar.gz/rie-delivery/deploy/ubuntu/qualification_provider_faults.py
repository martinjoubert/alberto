"""Native provider-failure qualification using temporary loopback-only sidecars.

No provider credential is accepted in arguments. The sidecars have no volumes,
Docker socket, host ports or inherited application environment. Original .env
bytes are restored before the final ordinary acceptance recipe.
"""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import uuid

PORT=8124
PROVIDER_URL='http://127.0.0.1:'+str(PORT)+'/v1'
EVIDENCE=('evidence','results','sources','metrics','events','logs','documents','opensearch_resources')
CASES=(('classification_http500','http500','classification',35),
       ('classification_http429','http429','classification',35),
       ('classification_invalid_json','invalid_json','classification',35),
       ('planner_http500','http500','planner',35),
       ('planner_invalid_json','invalid_json','planner',35),
       ('classification_timeout_60s','timeout','classification',65),
       ('planner_timeout_60s','timeout','planner',65))


def now():return datetime.now(timezone.utc).isoformat()


def structured(body):
    if body.get('error'):return {'status':'protocol_error','error':body['error']}
    result=body.get('result',{})
    if result.get('isError'):return {'status':'protocol_error'}
    if isinstance(result.get('structuredContent'),dict):return result['structuredContent']
    for row in result.get('content',[]):
        if row.get('type')=='text':
            try:return json.loads(row['text'])
            except ValueError:pass
    return result


def safe_observation(status,result,elapsed):
    evidence=result.get('evidence') if isinstance(result.get('evidence'),dict) else {}
    error=result.get('error')
    code=error.get('code') if isinstance(error,dict) else error
    dialogue=result.get('dialogue') if isinstance(result.get('dialogue'),dict) else {}
    def safe_code(value):
        return value if isinstance(value,str) and re.fullmatch(r'[a-z][a-z0-9_]{0,79}',value) else None
    report=result.get('report')
    return {'http_status':status,'status':result.get('status'),'elapsed_seconds':round(elapsed,3),
            'evidence_present':any(result.get(key) for key in EVIDENCE),'evidence_total':evidence.get('total'),
            'request_id':result.get('request_id'),'continuation_token':result.get('continuation_token'),
            'report_reference_sha256':hashlib.sha256(report.encode()).hexdigest() if isinstance(report,str) and report else None,
            'error_code':safe_code(code),'dialogue_error':safe_code(dialogue.get('error_code')),
            'dialogue_calls':dialogue.get('albert_calls',0),
            'analysis_present':result.get('analysis') is not None,'usage_entries':len(result.get('usage',[])),
            'retry_after_seconds':result.get('retry_after_seconds')}


def worker(payload):
    import httpx
    from dinum_access import AccessGate
    from dinum_access.user_tokens import UserTokens
    from rie_agent.acceptance import FIXTURE_PATH,scenarios
    if os.getenv('PDL_MODE')!='demo' or os.getenv('RIE_LOAD_QUALIFICATION')=='true':
        raise ValueError('Provider failure probes require the separate synthetic instance')
    operation=payload.get('operation','pdl')
    if operation not in {'pdl','incidents','anonymous','forged'}:raise ValueError('Unknown provider probe operation')
    gate=AccessGate.configured();store=UserTokens(gate.config['user_tokens_directory']);record=None
    with tempfile.TemporaryDirectory(prefix='rie-provider-probe-') as private,httpx.Client(timeout=100,trust_env=False) as client:
        headers={'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25'}
        if operation not in {'anonymous','forged'}:
            path=Path(private)/'person.token';record=store.issue(gate.directory,'alice.martin',path,days=1)
            headers['Authorization']='Bearer '+path.read_text().strip()
        if operation=='forged':headers['X-OpenWebUI-User-JWT']='client-asserted-admin'
        try:
            if operation=='incidents':
                question='Examine R1 le 28 septembre 2026 de 10 h à 12 h, en Europe/Paris.'
                url='http://incidents:9950/gptoss/assistant/mcp';name='diagnose_observability'
            else:
                fixture=json.loads(FIXTURE_PATH.read_text())
                question=next(case['question'] for case in scenarios(fixture) if case['id']=='pfs_count')
                url='http://pdl:9910/mcp';name='investigate_pdl'
            if payload.get('retry'):question='tu peux recommencer ?'
            request={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':name,'arguments':{
                'question':question,'continuation_token':payload.get('continuation_token') or ''}}}
            began=time.monotonic();response=client.post(url,headers=headers,json=request)
            body=response.json();value=structured(body) if response.status_code==200 else body
            return safe_observation(response.status_code,value,time.monotonic()-began)
        finally:
            if record:store.revoke(record['id'])


def evaluate_failure(observed,stats,stage,*,timeout=False,baseline_request=None,baseline_report=None):
    counts=stats['counts']
    expected={'classification':1,'planner':1 if stage=='planner' else 0,'draft':0,'review':0}
    checks={'explicit_failure':observed['http_status']==200 and observed['status']=='error',
            'old_evidence_not_reused':not observed['evidence_present'],
            # Domain results identify their report by path, dialogue failures by
            # request_id. Neither may reuse the successful report or its facts.
            'old_result_identifier_not_reused':observed['status']=='error' and (
                observed['request_id'] is None or observed['request_id']!=baseline_request) and (
                observed.get('report_reference_sha256') is None or observed['report_reference_sha256']!=baseline_report),
            'one_attempt_per_stage_no_retry':counts==expected}
    if timeout:
        lower,upper=58,76
        checks['deadline_is_bounded']=lower<=observed['elapsed_seconds']<=upper
    else:checks['deadline_is_bounded']=observed['elapsed_seconds']<15
    return checks


def successful(observed):
    return observed['http_status']==200 and observed['status']=='success' and observed['evidence_present'] and observed['evidence_total']==2


def redact(observed):return {key:value for key,value in observed.items() if key!='continuation_token'}


def load_manager():
    spec=importlib.util.spec_from_file_location('provider_fault_manage',Path(__file__).with_name('manage.py'))
    manager=importlib.util.module_from_spec(spec);spec.loader.exec_module(manager);return manager


def invoke_probe(manager,instance,values,payload):
    result=manager.compose(instance,values,'run','--rm','--no-deps','--pull','never','-T','--interactive=true','operator',
        'python','-c',Path(__file__).read_text(),'worker',capture=True,stdin=None,input=json.dumps(payload))
    return json.loads(result.stdout)


def control(manager,backend,path,payload=None):
    if path not in {'healthz','stats','control'}:raise ValueError('Unknown fixture control endpoint')
    code=('import json,urllib.request; p='+repr(payload)+'; data=json.dumps(p).encode() if p is not None else None; '
          'r=urllib.request.Request('+repr('http://127.0.0.1:'+str(PORT)+'/'+path)+',data=data,headers={"Content-Type":"application/json"}); '
          'o=urllib.request.build_opener(urllib.request.ProxyHandler({})); '
          'print(o.open(r,timeout=5).read().decode())')
    return json.loads(manager.docker('exec',backend,'python','-c',code,capture=True).stdout)


def owner_labels(manager,name):
    return json.loads(manager.docker('inspect',name,'--format','{{json .Config.Labels}}',capture=True).stdout) or {}


def remove_sidecar(manager,name,instance_id):
    try:labels=owner_labels(manager,name)
    except subprocess.CalledProcessError:return
    if labels.get('rie.qualification.owner')!=instance_id or labels.get('rie.qualification.purpose')!='provider-fault':
        raise ValueError('Refusing to stop an unrelated provider container')
    manager.docker('stop','--time','5',name,capture=True)
    manager.docker('rm',name,capture=True)


def start_sidecar(manager,values,backend,name,fixture_source):
    manager.docker('run','-d','--name',name,'--pull','never','--restart','no','--network','container:'+backend,
        '--label','rie.qualification.owner='+values['RIE_INSTANCE_ID'],'--label','rie.qualification.purpose=provider-fault',
        '--read-only','--cap-drop','ALL','--security-opt','no-new-privileges:true','--pids-limit','64','--memory','128m',
        '--user','10001:10001','--tmpfs','/tmp:rw,noexec,nosuid,size=16m,mode=1777',values['RIE_IMAGE'],
        'python','-c',fixture_source,'serve','--port',str(PORT),capture=True)
    deadline=time.monotonic()+20
    while time.monotonic()<deadline:
        try:
            if control(manager,backend,'healthz').get('rie_simulation'):return
        except (subprocess.CalledProcessError,ValueError):time.sleep(.25)
    raise ValueError('Qualification provider did not become healthy')


def run(instance,output,*,manager=None):
    manager=manager or load_manager();instance=Path(instance).expanduser().resolve();output=Path(output).expanduser().resolve()
    values=manager.load(instance);manager.guard(instance,values)
    if values['RIE_MODE']!='demo' or values.get('RIE_LOAD_QUALIFICATION')=='true':
        raise ValueError('Never inject provider faults into external sources or the endurance instance')
    if output.exists() or output.is_relative_to(manager.ROOT):raise ValueError('Choose a new private result directory outside sources')
    fixture_source=Path(__file__).with_name('provider_fault_fixture.py').read_text()
    before=(instance/'.env').read_bytes()
    output.mkdir(parents=True,mode=0o700);(output/'environment-before.sha256').write_text(hashlib.sha256(before).hexdigest()+'\n')
    lock=instance/'.provider-faults.lock';descriptor=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(descriptor)
    report={'started_at':now(),'kind':'controlled_loopback_provider_faults','simulated_provider':True,'actual_albert_calls':0,
            'cases':[],'checks':{},'passed':False,'native_deadlines_seconds':{'classification':60,'planner':60}}
    nonce=uuid.uuid4().hex[:12];sidecars={};backends={};restore_needed=False
    def save():
        (output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
    def probe(payload):return invoke_probe(manager,instance,values,payload)
    def provider(mode='success',stage='all',delay=35,backend='pdl'):
        return control(manager,backends[backend],'control',{'mode':mode,'stage':stage,'delay_seconds':delay})
    try:
        values.update(ALBERT_URL=PROVIDER_URL,ALBERT_MODEL='qualification-fixture',RIE_SIMULATED_ALBERT='false')
        restore_needed=True;manager.save_env(instance,values)
        with (output/'up-fixture.log').open('w') as log:
            manager.compose(instance,values,'--profile','demo','--profile','demo-ui','stop','pdl','incidents','portal',stdout=log,stderr=subprocess.STDOUT)
            # Same image/configuration; change only the explicitly temporary provider route.
            manager.compose(instance,values,'up','-d','--wait','--wait-timeout','120','--pull','never','--no-build','--force-recreate','pdl','incidents',stdout=log,stderr=subprocess.STDOUT)
        backends={key:values['RIE_PROJECT']+'-'+key+'-1' for key in ('pdl','incidents')}
        for key,backend in backends.items():
            name=values['RIE_PROJECT']+'-provider-faults-'+key+'-'+nonce;sidecars[key]=name
            start_sidecar(manager,values,backend,name,fixture_source)
        provider();initial=probe({'operation':'pdl'})
        report['checks']['healthy_fixture_runs_real_pdl_compilation_and_search']=successful(initial)
        if not successful(initial):raise ValueError('A healthy controlled baseline is required')
        continuation=initial['continuation_token'];baseline_id=initial['request_id'];baseline_report=initial['report_reference_sha256']
        report['healthy_baseline']=redact(initial)
        provider()
        for operation in ('anonymous','forged'):
            observed=probe({'operation':operation});stats=control(manager,backends['pdl'],'stats')
            report['checks'][operation+'_cannot_trigger_provider']=observed['http_status']==403 and not observed['evidence_present'] and stats['requests']==0
        # Refused TCP connection is distinct from an HTTP provider failure.
        remove_sidecar(manager,sidecars['pdl'],values['RIE_INSTANCE_ID'])
        refused=probe({'operation':'pdl','retry':True,'continuation_token':continuation})
        report['cases'].append({'name':'connection_refused','observation':redact(refused),'checks':{
            'explicit_failure':refused['http_status']==200 and refused['status']=='error',
            'old_evidence_not_reused':not refused['evidence_present'],'deadline_is_bounded':refused['elapsed_seconds']<15}})
        start_sidecar(manager,values,backends['pdl'],sidecars['pdl'],fixture_source)
        for name,mode,stage,delay in CASES:
            provider(mode,stage,delay)
            observed=probe({'operation':'pdl','retry':True,'continuation_token':continuation})
            stats=control(manager,backends['pdl'],'stats')
            checks=evaluate_failure(observed,stats,stage,timeout=mode=='timeout',baseline_request=baseline_id,baseline_report=baseline_report)
            report['cases'].append({'name':name,'observation':redact(observed),'provider':stats,'checks':checks})
            save();print(json.dumps({'case':name,'passed':all(checks.values()),'elapsed_seconds':observed['elapsed_seconds']}),flush=True)
        provider()
        recovered=probe({'operation':'pdl','retry':True,'continuation_token':continuation})
        report['recovered']=redact(recovered)
        report['checks']['real_pdl_search_recovers_after_provider_return']=(successful(recovered) and
            bool(recovered['report_reference_sha256']) and recovered['report_reference_sha256']!=baseline_report)
        provider(backend='incidents')
        first=probe({'operation':'incidents'});stats_first=control(manager,backends['incidents'],'stats')
        second=probe({'operation':'incidents','continuation_token':first.get('continuation_token')});stats_second=control(manager,backends['incidents'],'stats')
        report['admission']={'first':redact(first),'second':redact(second),'first_provider':stats_first,'second_provider':stats_second}
        report['checks']['incident_synthesis_through_fixture_works']=first['status']=='ok' and first['analysis_present'] and stats_first['counts']=={'classification':1,'planner':0,'draft':1,'review':1}
        report['checks']['default_sixty_second_incident_admission_is_preserved']=(second['status']=='rate_limited' and 0<second.get('retry_after_seconds',0)<=60
            # Admission precedes interpretation: a refused turn must not make
            # another classification, draft or review request.
            and not second['evidence_present'] and second['dialogue_calls']==0
            and stats_second['counts']==stats_first['counts']=={'classification':1,'planner':0,'draft':1,'review':1})
        report['passed']=all(report['checks'].values()) and all(all(case['checks'].values()) for case in report['cases'])
    except Exception as error:
        report['error_code']=type(error).__name__;report['passed']=False
    finally:
        for name in sidecars.values():
            try:remove_sidecar(manager,name,values['RIE_INSTANCE_ID'])
            except Exception:report['sidecar_cleanup_failed']=True;report['passed']=False
        if restore_needed:
            temporary=instance/('.env.provider-restore-'+nonce)
            manager.write_new(temporary,before.decode());temporary.replace(instance/'.env')
            report['checks']['original_environment_bytes_restored']=(instance/'.env').read_bytes()==before
            try:
                with (output/'ordinary-up.log').open('w') as log:
                    manager.compose(instance,manager.load(instance),'--profile','demo','--profile','demo-ui','stop','pdl','incidents',stdout=log,stderr=subprocess.STDOUT)
                    result=subprocess.run([sys.executable,str(Path(__file__).with_name('manage.py')),'up',str(instance)],stdout=log,stderr=subprocess.STDOUT)
                if result.returncode:raise ValueError('Ordinary restart failed')
                with (output/'final-acceptance.log').open('w') as log:
                    check=subprocess.run([sys.executable,str(Path(__file__).with_name('manage.py')),'check',str(instance)],stdout=log,stderr=subprocess.STDOUT)
                    acceptance=subprocess.run([sys.executable,str(Path(__file__).with_name('manage.py')),'acceptance',str(instance)],stdout=log,stderr=subprocess.STDOUT)
                report['checks']['ordinary_check_and_twelve_acceptance_cases_pass']=check.returncode==acceptance.returncode==0
                report['passed']=report['passed'] and all(report['checks'].values())
            except Exception:report['ordinary_recovery_failed']=True;report['passed']=False
        lock.unlink(missing_ok=True);report['finished_at']=now()
        (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'cases':len(report['cases']),'report':str(output/'report.json')}),flush=True)
    return 0 if report['passed'] else 2


def main():
    os.umask(0o077)
    if len(sys.argv)>1 and sys.argv[1]=='worker':
        try:result=worker(json.load(sys.stdin))
        except Exception as error:result={'worker_error':type(error).__name__}
        print(json.dumps(result),flush=True);return 0
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('instance',type=Path);parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    try:return run(args.instance,args.output)
    except Exception as error:
        print(json.dumps({'passed':False,'error_code':type(error).__name__,'detail':'Inspect the private report; verify ordinary instance configuration was restored.'}),file=sys.stderr)
        return 2


if __name__=='__main__':raise SystemExit(main())
