"""Optional Ubuntu demonstration portal, independent of the historical Mac UI."""
