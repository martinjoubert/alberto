"""Authenticated mapping administration using the portable engine's contracts.

Drafts are inert, imports stage pending reviews, and explicit approval remains
bound to the displayed review, active version, current schema and live rights.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass
import fnmatch
import json
import os
from pathlib import Path
import re

import requests
import yaml
from dinum_access import AccessDenied
from dinum_access.security import CURRENT
from rie_agent.config import load_settings
from rie_agent.documents import canonical_hash
from rie_agent.inventory import OpenSearchInventory
from rie_agent.operator_mappings import MAX_BYTES, load_bytes, stage_reviews, validate_document
from rie_agent.store import Store, approval_state_hash

from .backend import PortalError


class MappingValidationError(PortalError):
    def __init__(self, issues):
        super().__init__('mapping_invalid_document')
        self.issues = issues


def export_document(document):
    """Use the bounded engine parser for form drafts as well as uploaded YAML."""
    try:
        raw = yaml.safe_dump(document, allow_unicode=True, sort_keys=False).encode('utf-8')
        normalized, digest = load_bytes(raw)
    except (ValueError, TypeError, yaml.YAMLError, RecursionError):
        raise PortalError('mapping_invalid_document') from None
    return normalized, raw, digest


def document_from_snapshot(snapshot):
    """Rebuild an editable operator document without discarding identity options."""
    document = {'version': 1, 'indices': {}, 'relations': {}}
    candidates = {row['index']: row for row in snapshot['catalog'] if row.get('active')}
    for row in reversed(snapshot['reviews']):
        if row['status'] == 'pending':
            candidates[row['index']] = row
    for index, row in sorted(candidates.items()):
        profile = row.get('operator_file', {}).get('profile') or re.sub('[^a-z0-9_]', '_', index)[:54]
        if not profile or not profile[0].isalpha():
            profile = 'index_' + profile
        base, suffix = profile, 1
        while profile in document['indices']:
            suffix += 1
            profile = base + '_' + str(suffix)
        concepts = deepcopy(row.get('proposed_mapping', row.get('concepts', {})))
        for concept, spec in concepts.items():
            namespace = spec.pop('identity_namespace', None)
            if namespace:
                document['relations'].setdefault(namespace, {}).setdefault(profile, []).append(concept)
        document['indices'][profile] = {'match': index, 'concepts': concepts}
    return document


def compatible_fields(inventory, pattern):
    """Offer only fields with the same usable type in every selected index."""
    entries = [entry['fields'] for name, entry in inventory.get('indices', {}).items()
               if fnmatch.fnmatchcase(name, pattern)]
    if not entries:
        return {}
    return {name: cap for name, cap in entries[0].items()
            if cap.get('searchable') and all(name in fields and fields[name].get('searchable')
                and fields[name]['type'] == cap['type']
                and fields[name].get('types', [cap['type']]) == [cap['type']] for fields in entries)}


@dataclass
class _Access:
    session: object
    gate: object
    principal: object
    epoch: int
    settings: object
    store: object

    def recheck(self, indices=()):
        self.session._unchanged(self.epoch)
        gate, principal, _, epoch = self.session._authenticated()
        if epoch != self.epoch:
            raise PortalError('session_changed')
        if not principal.administrator:
            raise AccessDenied('administrator_required')
        if indices:
            gate.store.authorize(principal, list(indices))
        self.session._unchanged(self.epoch)
        return principal


class MappingAdministration:
    def __init__(self, session, *, settings_factory=load_settings, store_factory=Store,
                 inventory_factory=OpenSearchInventory):
        self.session = session
        self.settings_factory = settings_factory
        self.store_factory = store_factory
        self.inventory_factory = inventory_factory

    @contextmanager
    def _access(self):
        gate, principal, _, epoch = self.session._authenticated()
        if not principal.administrator:
            raise AccessDenied('administrator_required')
        self.session._unchanged(epoch)
        settings = self.settings_factory()
        store = self.store_factory(settings.data_dir)
        marker = CURRENT.set((gate, principal))
        try:
            yield _Access(self.session, gate, principal, epoch, settings, store)
            self.session._unchanged(epoch)
        finally:
            CURRENT.reset(marker)

    def _refresh(self, access):
        service = None
        try:
            service = self.inventory_factory(access.settings, access.store)
            return service.refresh()
        except AccessDenied:
            raise
        except (requests.RequestException, OSError, RuntimeError, ValueError):
            raise PortalError('mapping_source_unavailable') from None
        finally:
            client = getattr(service, 'session', None)
            if client is not None:
                client.close()

    @staticmethod
    def _proposals(document, inventory, access):
        issues = []
        profiles = document.get('indices', {})
        for profile, definition in (profiles.items() if isinstance(profiles, dict) else []):
            if (not isinstance(profile, str) or not isinstance(definition, dict)
                    or not re.fullmatch('[a-z][a-z0-9_-]{0,63}', profile)):
                continue
            pattern = definition.get('match', '')
            fields = compatible_fields(inventory, pattern) if isinstance(pattern, str) else {}
            concepts = definition.get('concepts', {})
            for concept, spec in (concepts.items() if isinstance(concepts, dict) else []):
                if (not isinstance(concept, str) or not re.fullmatch('[a-z][a-z0-9_]{0,63}', concept)
                        or not isinstance(spec, dict)):
                    continue
                field = fields.get(spec.get('field')) if isinstance(spec.get('field'), str) else None
                if not field or field['type'] != spec.get('type'):
                    issues.append(f'{profile} / {concept} : choisir un champ découvert compatible.')
        if issues:
            raise MappingValidationError(issues)
        try:
            proposals = validate_document(document, inventory)
        except (ValueError, TypeError, KeyError) as error:
            text = str(error)
            if 'timestamp' in text:
                issue = 'Chaque profil doit définir une heure d’événement de type date ou date_nanos.'
            elif 'anchor namespace' in text:
                issue = 'Les relations exigent un identifiant stable commun, ou un nom/FQDN explicitement confirmé comme ancre.'
            elif 'normalization role' in text:
                issue = 'Un même groupe de correspondance doit utiliser un seul rôle : nom, FQDN, IP, identifiant ou référence.'
            elif 'identity concept' in text or 'Relation references' in text:
                issue = 'Chaque concept d’identité doit appartenir à un groupe de correspondance cohérent.'
            elif 'No authorized physical index' in text:
                issue = 'Un profil ne correspond à aucun index autorisé découvert. Actualisez les sources.'
            else:
                issue = 'Vérifiez les dates, les champs de lecture, les profils et les relations de la proposition.'
            raise MappingValidationError([issue]) from None
        access.gate.store.authorize(access.principal, [row['index'] for row in proposals])
        return proposals

    def overview(self, *, refresh=False):
        with self._access() as access:
            inventory = self._refresh(access) if refresh else access.store.inventory()
            allowed = set(access.gate.store.accessible(access.principal)['allowed_indices'])
            indices = {name: entry for name, entry in inventory.get('indices', {}).items()
                       if name in allowed and any(fnmatch.fnmatchcase(name, p)
                                                 for p in access.settings.allowed_index_patterns)}
            reviews = [row for row in access.store.reviews() if row.get('index') in indices
                       and row.get('kind') == 'operator_mapping']
            catalog = [row for row in access.store.catalog() if row.get('index') in indices]
            access.recheck(indices)
            return {'inventory': {'created_at': inventory.get('created_at'),
                                  'allowed_patterns': sorted(indices), 'indices': indices},
                    'reviews': reviews, 'catalog': catalog}

    def import_document(self, raw):
        with self._access() as access:
            try:
                document, _ = load_bytes(raw)
            except (ValueError, TypeError):
                raise PortalError('mapping_invalid_document') from None
            proposals = self._proposals(document, access.store.inventory(), access)
            access.recheck([row['index'] for row in proposals])
            return document

    def initial_document(self):
        with self._access() as access:
            path = Path(os.getenv('PDL_CONFIG', '/data/config/pdl.yaml')).parent / 'mappings.yaml'
            if path.is_symlink():
                raise PortalError('mapping_invalid_document')
            try:
                with path.open('rb') as stream:
                    raw = stream.read(MAX_BYTES + 1)
            except OSError:
                raise PortalError('mapping_initial_file_missing') from None
            # Re-authenticate through the same entry point used by uploads.
            access.recheck()
            return self.import_document(raw)

    def validate(self, document):
        document, _, digest = export_document(document)
        with self._access() as access:
            self._proposals(document, access.store.inventory(), access)
            inventory = self._refresh(access)
            proposals = self._proposals(document, inventory, access)
            access.recheck([row['index'] for row in proposals])
            hashes = {row['index']: row['schema_hash'] for row in proposals}
            return {'valid': True, 'document_hash': digest, 'inventory_hash': canonical_hash(hashes),
                    'indices': [{'index': row['index'], 'schema_hash': row['schema_hash']} for row in proposals]}

    def stage(self, document, validation, reason):
        document, _, digest = export_document(document)
        if not isinstance(validation, dict) or validation.get('document_hash') != digest:
            raise PortalError('mapping_validation_required')
        if not isinstance(reason, str) or not 1 <= len(reason.strip()) <= 1000:
            raise PortalError('mapping_reason_required')
        with self._access() as access:
            self._proposals(document, access.store.inventory(), access)
            inventory = self._refresh(access)
            proposals = self._proposals(document, inventory, access)
            if validation.get('inventory_hash') != canonical_hash({row['index']: row['schema_hash'] for row in proposals}):
                raise PortalError('mapping_schema_changed')
            with self.session._lock:
                principal = access.recheck([row['index'] for row in proposals])
                rows = stage_reviews(access.store, document, file_hash=digest,
                                     author=principal.email, reason=reason.strip(), skip_unchanged=True)
            return {'status': 'pending', 'reviews': [{key: row[key] for key in ('id', 'index', 'status')}
                                                     for row in rows]}

    def review(self, identifier):
        with self._access() as access:
            if not isinstance(identifier, str) or not 1 <= len(identifier) <= 100:
                raise PortalError('mapping_review_missing')
            try:
                review = access.store.review(identifier)
            except (ValueError, KeyError):
                raise PortalError('mapping_review_missing') from None
            access.gate.store.authorize(access.principal, [review['index']])
            if review.get('kind') != 'operator_mapping':
                raise PortalError('mapping_review_unsupported')
            inventory = access.store.inventory()
            catalog = access.store.catalog()
            current = [row for row in catalog if row.get('active') and row.get('index') == review['index']]
            access.recheck([review['index']])
            return {'review': review, 'active': current,
                    'entry': inventory.get('indices', {}).get(review['index'], {}),
                    'state_hash': approval_state_hash(review, catalog)}

    def approve(self, identifier, state_hash, reason, *, confirmed=False):
        if confirmed is not True:
            raise PortalError('mapping_confirmation_required')
        if not isinstance(reason, str) or not 1 <= len(reason.strip()) <= 1000:
            raise PortalError('mapping_reason_required')
        if not isinstance(state_hash, str) or not re.fullmatch('[a-f0-9]{64}', state_hash):
            raise PortalError('mapping_review_changed')
        with self._access() as access:
            if not isinstance(identifier, str) or not 1 <= len(identifier) <= 100:
                raise PortalError('mapping_review_missing')
            try:
                review = access.store.review(identifier)
            except (ValueError, KeyError):
                raise PortalError('mapping_review_missing') from None
            access.gate.store.authorize(access.principal, [review['index']])
            if review.get('kind') != 'operator_mapping':
                raise PortalError('mapping_review_unsupported')
            inventory = self._refresh(access)
            entry = inventory.get('indices', {}).get(review['index'])
            if not entry or entry['schema_hash'] != review['schema_hash']:
                raise PortalError('mapping_schema_changed')
            with self.session._lock:
                principal = access.recheck([review['index']])
                try:
                    result = access.store.approve(identifier, entry['schema_hash'], author=principal.email,
                        reason=reason.strip(), expected_state_hash=state_hash)
                except ValueError:
                    raise PortalError('mapping_review_changed') from None
            return {'status': 'approved', 'index': result['index'], 'version': result['version']}

    def export(self, document):
        normalized, raw, _ = export_document(document)
        with self._access() as access:
            proposals = self._proposals(normalized, access.store.inventory(), access)
            access.recheck([row['index'] for row in proposals])
            return raw
