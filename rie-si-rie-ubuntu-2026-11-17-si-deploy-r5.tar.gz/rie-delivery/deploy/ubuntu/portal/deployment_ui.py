"""Session-local deployment preparation; never reads a configured instance."""
from __future__ import annotations

from nicegui import ui
import deployment_setup as setup


def page(shell):
    with ui.column().classes('portal-page gap-5'):
        shell('Déploiement · préparer le raccordement au SI')
        ui.label('Préparez les fichiers avec les responsables des sources, puis poursuivez les étapes du guide. Aucun service du SI n’est créé.').classes('portal-note')
        ui.label('Cet espace ne lit pas la configuration de l’instance. La saisie reste propre à cette page et disparaît à la déconnexion. Téléchargez un brouillon pour reprendre.').props('data-deploy-isolation')
        ui.label('Ne saisissez aucun mot de passe, jeton ou clé privée. Les secrets suivent le canal privé du guide.').classes('text-weight-medium')
        with ui.row():
            ui.link('Guide pas à pas · étapes 1 à 12', '/documentation/README')
            ui.link('Fiche et responsabilités du SI', '/documentation/26-si-connection-sheet')
        ui.link('Maintenir le code et publier les images · responsable de livraison', '/documentation/27-development-and-images')
        ui.add_head_html('<style>.deployment-upload{min-height:0!important;box-shadow:none}.deployment-upload .q-uploader__list{display:none}.deployment-upload .q-uploader__subtitle{display:none}</style>')
        notice=ui.label().props('data-deploy-notice')
        values = setup.defaults();files = {};inputs = {};statuses = {}
        output = ui.column().classes('w-full').props('data-deploy-output')
        review = None

        def changed():
            if review is not None:review.value = False
            output.clear();notice.set_text('')

        def collect():
            return {key: str(control.value or '') for key,control in inputs.items()}

        def failed(error):
            notice.set_text(error.issues[0]);ui.notify(error.issues[0],type='negative')
            output.clear()
            with output:
                for issue in error.issues:
                    ui.label(issue).classes('text-red-8').props('data-deploy-issue')

        def fields(sections):
            for section in sections:
                ui.label(section).classes('text-xl font-semibold')
                for group,key,label,default,explanation in setup.FIELDS:
                    if group != section:continue
                    control = (ui.textarea(label) if key in {'pdl_indices','admin_groups','callbacks'} else ui.input(label))
                    control.value = values[key]
                    control.props('autocomplete=off data-deploy-field='+key).classes('w-full')
                    control.on_value_change(lambda _:changed())
                    ui.label(explanation).classes('text-sm text-grey-7')
                    inputs[key] = control

        async def read_file(event):
            data=bytearray()
            async for chunk in event.file.iterate(chunk_size=65536):
                data.extend(chunk)
                if len(data)>setup.MAX_FILE_BYTES:
                    raise setup.PreparationError(['Fichier : maximum 1 Mio.'])
            return bytes(data)

        async def import_draft(event):
            try:
                data=setup.read_draft(await read_file(event))
                for key,control in inputs.items():control.value=data[key]
                changed()
                ui.notify('Brouillon chargé. Les fichiers doivent être redéposés ; aucun réglage appliqué.')
            except setup.PreparationError as error:failed(error)
            finally:event.sender.reset()

        def download_draft():
            try:ui.download.content(setup.draft(collect()),'connection-form.json','application/json')
            except setup.PreparationError as error:failed(error)

        with ui.expansion('Enregistrer ou reprendre la saisie', icon='save').classes('w-full'):
            ui.button('Télécharger le brouillon',on_click=download_draft).props('outline data-deploy-draft-download')
            ui.upload(label='Reprendre un brouillon JSON',auto_upload=True,max_files=1,max_file_size=setup.MAX_FILE_BYTES,on_upload=import_draft,on_rejected=lambda _:failed(setup.PreparationError(['Brouillon : fichier JSON de 1 Mio maximum attendu.']))).props('accept=.json data-deploy-draft-upload').classes('deployment-upload w-full')
            ui.label('Le brouillon contient les paramètres internes saisis, sans les fichiers déposés. Conservez-le dans un emplacement privé.')

        with ui.stepper().props('vertical header-nav').classes('w-full').props('data-deploy-stepper') as stepper:
            with ui.step('1. Cible et images').props('header-nav'):
                fields(('Coordination','Images'))
                with ui.stepper_navigation():ui.button('Suivant',on_click=stepper.next).props('data-deploy-next=1')
            with ui.step('2. Annuaire LDAP').props('header-nav'):
                fields(('LDAP',))
                with ui.stepper_navigation():
                    ui.button('Précédent',on_click=stepper.previous).props('flat')
                    ui.button('Suivant',on_click=stepper.next).props('data-deploy-next=2')
            with ui.step('3. Sources et droits initiaux').props('header-nav'):
                fields(('Sources',))
                ui.label('Les règles restent fermées par défaut. Toute ouverture doit être confirmée avec le responsable des accès.').classes('portal-note')
                for key,label in setup.POLICY_FIELDS:
                    control=ui.select(setup.VISIBILITIES,label=label,value='blocked').classes('w-full').props('data-deploy-field='+key)
                    control.on_value_change(lambda _:changed());inputs[key]=control
                with ui.stepper_navigation():
                    ui.button('Précédent',on_click=stepper.previous).props('flat')
                    ui.button('Suivant',on_click=stepper.next).props('data-deploy-next=3')
            with ui.step('4. Albert et Open WebUI').props('header-nav'):
                fields(('Albert','Open WebUI'))
                ui.label('Les paramètres OAuth peuvent être laissés tous vides pour être préparés à l’étape 10 du guide. Aucun compte partagé ne remplace les utilisateurs.')
                with ui.stepper_navigation():
                    ui.button('Précédent',on_click=stepper.previous).props('flat')
                    ui.button('Suivant',on_click=stepper.next).props('data-deploy-next=4')
            with ui.step('5. Fichiers, vérification et export').props('header-nav'):
                for name,label in setup.UPLOADS.items():
                    with ui.card().classes('w-full'):
                        ui.label(label).classes('font-semibold')
                        statuses[name]=ui.label('À fournir' if name in setup.REQUIRED_FILES else 'Facultatif').props('data-deploy-file-status='+name)
                        async def upload(event,slot=name):
                            files.pop(slot,None);changed()
                            try:
                                raw=await read_file(event)
                                files[slot]=setup.uploaded(slot,raw)
                                statuses[slot].set_text('Reçu et format vérifié · '+slot)
                            except setup.PreparationError as error:
                                statuses[slot].set_text('Fichier refusé · '+slot);failed(error)
                            finally:event.sender.reset()
                        def rejected(slot=name):
                            files.pop(slot,None);changed();statuses[slot].set_text('Fichier refusé · '+slot)
                            failed(setup.PreparationError(['Fichier : format attendu et taille maximale de 1 Mio à respecter.']))
                        def remove(slot=name):
                            files.pop(slot,None);statuses[slot].set_text('Fichier retiré');changed()
                        ui.upload(label='Déposer '+name,auto_upload=True,max_files=1,max_file_size=setup.MAX_FILE_BYTES,on_upload=upload,on_rejected=lambda _,slot=name,handler=rejected:handler(slot)).props('accept='+('.json' if name.endswith('.json') else '.pem,.crt')+' data-deploy-upload='+name).classes('deployment-upload w-full')
                        ui.button('Retirer ce fichier',on_click=remove).props('flat dense data-deploy-remove='+name)
                review=ui.checkbox('Je confirme la revue de ces valeurs, des droits initiaux et des fichiers avec leurs responsables.').props('data-deploy-reviewed')
                def verify():
                    try:
                        result=setup.prepare(collect(),dict(files),reviewed=bool(review.value));output.clear()
                        with output:
                            ui.label('✓ Préparation locale vérifiée — connexions au SI et Albert non testés.').classes('text-green-8 font-semibold').props('data-deploy-valid')
                            for item in result['checks']:ui.label(item)
                            ui.label('À faire dans le guide').classes('font-semibold')
                            for item in result['remaining']:ui.label(item)
                    except setup.PreparationError as error:failed(error)
                def download():
                    try:
                        content=setup.export(collect(),dict(files),reviewed=bool(review.value))
                        ui.download.content(content,'rie-connection.zip','application/zip')
                    except setup.PreparationError as error:failed(error)
                with ui.row():
                    ui.button('Vérifier le dossier',icon='fact_check',on_click=verify).props('data-deploy-validate')
                    ui.button('Télécharger le dossier privé',icon='download',on_click=download).props('outline data-deploy-export')
                output.move(ui.context.slot.parent)
                ui.label('Le ZIP contient la fiche, les paramètres et les fichiers déposés. Il reste interne au SI et ne doit pas être publié sur GitHub ou dans un wiki public.')
                ui.label('Après prepare --mode external, importer ce ZIP à l’étape 6 du guide avec configure-connection. Fournir ensuite les secrets puis lancer validate.').props('data-deploy-import-help')
                with ui.stepper_navigation():ui.button('Précédent',on_click=stepper.previous).props('flat')

        def clear():
            files.clear()
            for control in inputs.values():control.value=''
            output.clear()
        ui.context.client.on_disconnect(clear)
        ui.context.client.on_delete(clear)
