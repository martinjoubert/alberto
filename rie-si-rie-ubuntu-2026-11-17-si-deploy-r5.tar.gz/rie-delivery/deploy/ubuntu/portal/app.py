"""Optional NiceGUI UI for the Ubuntu delivery; no historical Mac imports.

Start with ``PYTHONPATH=/delivery:/app:/app/incidents python -m portal.app``.
The listener is published only on host loopback by the deployment Compose file.
"""
from __future__ import annotations

import json
import os
import re
from urllib.parse import quote

from fastapi import HTTPException
from fastapi.responses import FileResponse, Response
from nicegui import app, run, ui

from dinum_access import AccessDenied
from . import documents, reports
from .backend import Session, PortalError, PDL_QUESTION, INCIDENT_QUESTION

PRIMARY = '#000091'
NAMES = {'pdl': 'PDL', 'incidents': 'Incidents', 'acl': 'ACL'}
ERRORS = {
    'identity_required': 'Connectez-vous avec votre compte LDAP pour lire les données.',
    'administrator_required': 'Administration réservée aux membres du groupe LDAP d’administration des accès.',
    'index_forbidden': 'Lecture refusée par les règles actuelles. Aucune preuve interdite n’est affichée.',
    'resource_forbidden': 'Cette source est interdite pour votre profil. Aucune donnée de cette source n’est lue.',
    'policy_conflict_reload': 'La politique a changé. Actualisez les règles avant de réessayer.',
    'invalid_policy_change': 'Choisissez un index concret ou une source proposée, et une règle valide.',
    'policy_index_not_found': 'La règle n’existe plus. Actualisez les règles.',
    'session_changed': 'La session a changé ; ce résultat a été écarté. Reconnectez-vous puis relancez.',
    'backend_access_denied': 'Le backend refuse cette identité ou cette lecture.',
    'backend_unavailable': 'Le backend est indisponible ou sa réponse est incomplète. Vérifiez les services.',
    'local_state_unavailable': 'Aucune recette ou aucun catalogue lisible dans cette instance.',
    'invalid_question': 'Saisissez une question de 1 à 2 000 caractères.',
    'mapping_invalid_document': 'Proposition incompatible. Vérifiez les champs, les types, les dates et les relations.',
    'mapping_invalid_values': 'Corrigez les valeurs métier incompatibles avec leur type avant de vérifier, enregistrer ou exporter.',
    'mapping_source_unavailable': 'Découverte indisponible ou incomplète. Vérifiez les sources et leurs droits avant de réessayer.',
    'mapping_initial_file_missing': 'Aucun fichier initial fourni. Commencez avec un index découvert ou importez un YAML.',
    'mapping_validation_required': 'Vérifiez la proposition actuelle avant de l’enregistrer.',
    'mapping_reason_required': 'Renseignez une justification de 1 à 1 000 caractères.',
    'mapping_schema_changed': 'Le schéma a changé. Actualisez les sources puis vérifiez à nouveau la proposition.',
    'mapping_review_changed': 'La revue ou la version active a changé. Examinez de nouveau la revue avant de décider.',
    'mapping_review_missing': 'Choisissez une revue existante à examiner.',
    'mapping_review_unsupported': 'Cette revue relève du parcours expert ; elle ne provient pas d’un fichier de correspondances opérateur.',
    'mapping_confirmation_required': 'Confirmez la vérification du sens métier avant d’approuver.',
    'mapping_draft_changed': 'La proposition a été modifiée pendant la vérification. Vérifiez sa nouvelle version.',
}
LABELS = {'blocked': 'Interdit à tous', 'internal': 'Réservé aux internes',
          'authenticated': 'Ouvert aux utilisateurs authentifiés'}
RESOURCE_LABELS = {'incidents.metrics': 'Mesures VictoriaMetrics',
                   'incidents.tickets': 'Tickets et suivi ITSM'}


def message(error):
    if isinstance(error, AccessDenied):
        return ERRORS.get(error.code, 'Session expirée, droits retirés ou annuaire indisponible. Reconnectez-vous.')
    return ERRORS.get(getattr(error, 'code', ''), 'Lecture impossible. Vérifiez les services et la configuration privée.')


def shell(title, *, deployment=False):
    ui.colors(primary=PRIMARY, secondary='#6a6af4', positive='#18753c')
    ui.add_head_html('<style>body{background:#f7f8fc}.portal-page{max-width:1180px;margin:auto;padding:24px;width:100%} .portal-page pre{max-height:620px;overflow:auto} .portal-diagram{max-height:620px;object-fit:contain} .portal-note{border-left:4px solid #6a6af4;padding-left:12px}.nicegui-markdown a[id]{scroll-margin-top:80px}</style>')
    # NiceGUI layout headers must be attached directly to the page content.
    with ui.context.client.content:
        with ui.header().classes('items-center justify-between'):
            ui.link('SI-RIE · recette Ubuntu', '/').classes('text-white font-semibold')
            with ui.row().classes('gap-5'):
                for label, path in [('PDL', '/demo-pdl-5min'), ('Incidents', '/demo-incidents-5min'),
                                    ('ACL', '/demo-acces'), ('Administration ACL', '/admin-acces'),
                                    ('Mappings PDL', '/admin-mappings'), ('Déploiement', '/deployment'),
                                    ('Qualification', '/qualification'), ('Documentation', '/documentation')]:
                    if os.getenv('RIE_DEPLOYMENT_ONLY') != 'true' or path in {'/deployment','/documentation'}:
                        ui.link(label, path).classes('text-white')
    ui.label(title).classes('text-3xl font-semibold').props('data-portal-title')
    if not deployment and os.getenv('RIE_DEPLOYMENT_ONLY') != 'true':
        ui.label('Données, comptes et sources de démonstration fictifs · moteurs et contrôles d’accès réels.').classes('text-sm text-grey-7')


def figure(identifier, title):
    if identifier not in documents.DIAGRAMS:
        return
    relative = 'assets/diagrams/' + identifier + '.svg'
    try:
        documents.public_file(relative)
        documents.public_file('diagrams/' + identifier + '.drawio')
    except documents.DocumentationError:
        ui.label('Le diagramme sera disponible avec le paquet documentaire de cette version.').classes('text-grey-7')
        return
    with ui.card().classes('w-full'):
        ui.label(title).classes('text-lg font-semibold')
        ui.image('/documentation/files/' + relative).classes('portal-diagram w-full').props('data-portal-diagram')
        with ui.dialog().props('maximized') as fullscreen, ui.card().classes('w-full h-full flex-nowrap'):
            with ui.row().classes('w-full items-center justify-between shrink-0'):
                ui.label(title).classes('text-xl font-semibold')
                ui.button('Fermer le diagramme', icon='close', on_click=fullscreen.close)
            with ui.element('div').classes('w-full overflow-auto grow'):
                ui.image('/documentation/files/' + relative).style('min-width:1400px;width:100%;max-width:2000px;margin:auto')
        ui.button('Ouvrir le diagramme en plein écran', icon='fullscreen', on_click=fullscreen.open).props('outline data-portal-fullscreen')
        with ui.row():
            ui.link('Télécharger SVG', '/download/file/' + relative).props('data-portal-svg')
            ui.link('Télécharger draw.io éditable', '/download/file/diagrams/' + identifier + '.drawio').props('data-portal-drawio')


def document_panel(identifier, label='Documentation de référence'):
    with ui.expansion(label, icon='description').classes('w-full'):
        try:
            ui.markdown(documents.markdown(identifier)).classes('w-full')
            ui.link('Télécharger le texte Markdown', '/download/document/' + quote(identifier, safe=''))
        except documents.DocumentationError:
            ui.label('Le contenu documentaire canonique n’est pas installé.').classes('text-grey-7')


def tutorial(identifier):
    """Read the canonical tutorial; copying a prompt never invokes a backend."""
    with ui.expansion('Tutoriel pas à pas · questions et résultats attendus',
                      icon='school', value=True).classes('w-full').props('data-portal-tutorial'):
        ui.link('Ouvrir le tutoriel dans la documentation', '/documentation/' + identifier)
        ui.link('Télécharger le tutoriel en Markdown', '/download/document/' + identifier)
        try:
            content = documents.markdown(identifier).split('\n', 1)[1]
        except (documents.DocumentationError, IndexError):
            ui.label('Le tutoriel sera disponible avec le paquet documentaire de cette version.')
            return
        cursor = 0
        for number, match in enumerate(re.finditer(r'^```text\n(.*?)^```\s*$', content, re.M | re.S), 1):
            ui.markdown(content[cursor:match.start()]).classes('w-full')
            question = match[1].strip()
            with ui.card().classes('w-full min-w-0'):
                ui.label(question).classes('whitespace-pre-wrap break-words').props('data-tutorial-question')
                ui.button('Copier la question', icon='content_copy',
                          on_click=lambda value=question: ui.clipboard.write(value)).props(
                              'outline data-tutorial-copy=' + str(number))
            cursor = match.end()
        ui.markdown(content[cursor:]).classes('w-full')


def show_result(target, result):
    target.clear()
    with target:
        status = result.get('status') or result.get('access_control', {}).get('decision') or 'lecture effectuée'
        ui.label('Résultat · ' + str(status)).classes('font-semibold').props('data-portal-result-status')
        if result.get('status') == 'denied':
            ui.label('Accès refusé : aucune preuve des sources interdites n’est publiée.').classes('text-red-8')
        if result.get('application') == 'observability' and isinstance(result.get('answer'), str):
            ui.markdown(result['answer']).classes('w-full').props('data-incidents-report')
        ui.code(json.dumps(result, ensure_ascii=False, indent=2), language='json').classes('w-full').props('data-portal-result')


def action(label, session, operation, target, *, marker, on_error, generation=False):
    async def execute():
        button.disable()
        target.clear()
        with target:
            ui.label('Lecture en cours…').props('data-portal-pending')
        try:
            epoch = session._epoch
            result = await run.io_bound(operation)
            session._unchanged(epoch)
            show_result(target, result)
        except (AccessDenied, PortalError, OSError, ValueError) as error:
            target.clear()
            with target:
                ui.label(message(error)).classes('text-red-8').props('data-portal-error')
            on_error(error)
        finally:
            if not button.is_deleted:
                button.enable()
    button = ui.button(label, on_click=execute).props(marker)
    if generation:
        button.props('outline')
    return button


def authentication(session, protected):
    """Keep the session in this page client's closure, never in browser storage."""
    ui.context.client.on_disconnect(session.logout)
    ui.context.client.on_delete(session.logout)
    with ui.card().classes('w-full max-w-xl'):
        ui.label('Connexion LDAP à cette instance').classes('text-lg font-semibold')
        ui.label('La session courte reste en mémoire côté serveur pour cette page. Aucun jeton n’est affiché.').classes('text-sm text-grey-7')
        username = ui.input('Identifiant LDAP').props('autocomplete=username data-portal-username').classes('w-full')
        password = ui.input('Mot de passe', password=True, password_toggle_button=True).props('autocomplete=current-password data-portal-password').classes('w-full')
        status = ui.label().props('data-portal-login-status')

        def on_error(error):
            text = message(error)
            if not session.token:
                text = 'Session inactive. Reconnectez-vous pour poursuivre.'
                status.set_text(text)
                panel.refresh()
            elif isinstance(error, AccessDenied) and error.code == 'administrator_required':
                panel.refresh()
            ui.notify(text, type='negative')

        @ui.refreshable
        def panel():
            if not session.token:
                return
            try:
                identity = session.identity()
            except AccessDenied as error:
                status.set_text(message(error))
                return
            ui.label(identity['email'] + ' · ' + ('interne' if identity['category'] == 'internal' else 'externe')).props('data-portal-identity').classes('font-semibold')
            protected(session, identity, on_error)

        async def login():
            session.logout()
            status.set_text('Vérification du compte et des groupes LDAP…')
            try:
                await run.io_bound(session.login, username.value or '', password.value or '')
                status.set_text('Connexion établie. Les groupes seront revérifiés à chaque action.')
            except (AccessDenied, PortalError, OSError, ValueError):
                session.logout()
                status.set_text('Connexion refusée ou annuaire indisponible.')
            finally:
                password.value = ''
                panel.refresh()

        def logout():
            session.logout()
            status.set_text('Déconnecté. Les résultats de cette session ont été retirés.')
            panel.refresh()

        with ui.row():
            ui.button('Se connecter', on_click=login).props('data-portal-login')
            ui.button('Se déconnecter', on_click=logout).props('outline data-portal-logout')
    panel()


@app.get('/healthz')
def healthz():
    return {'status': 'ok', 'service': 'rie-ubuntu-demonstration-portal'}


@app.get('/qualification/view/{identifier}')
def view_qualification(identifier: str, access: str = '', download: bool = False):
    try:
        session, epoch = reports.GRANTS.resolve(access)
        _, _, html = reports.publications.report(reports.root(), identifier, with_html=True)
        session._unchanged(epoch)
    except (AccessDenied, PortalError):
        raise HTTPException(status_code=403, detail='Qualification access denied') from None
    except (OSError, ValueError):
        raise HTTPException(status_code=404, detail='Qualification report unavailable') from None
    headers = dict(reports.HTML_HEADERS)
    if download:
        headers['Content-Disposition'] = 'attachment; filename="' + identifier + '.html"'
    return Response(html if download else reports.viewer_html(html), media_type='text/html', headers=headers)


@app.get('/qualification/export/{identifier}')
def export_qualification(identifier: str, access: str = ''):
    try:
        session, epoch = reports.GRANTS.resolve(access)
        content = reports.publications.export_report(reports.root(), identifier)
        session._unchanged(epoch)
    except (AccessDenied, PortalError):
        raise HTTPException(status_code=403, detail='Qualification access denied') from None
    except (OSError, ValueError):
        raise HTTPException(status_code=404, detail='Qualification report unavailable') from None
    return Response(content, media_type='application/zip', headers={
        'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer',
        'X-Content-Type-Options': 'nosniff',
        'Content-Disposition': 'attachment; filename="' + identifier + '.zip"'})


@ui.page('/qualification')
def qualification_page():
    with ui.column().classes('portal-page'):
        shell('Qualification · campagnes et rapports Allure')
        ui.label('Consulter les résultats datés de qualification et de CI. Aucun test n’est lancé depuis cette page.').classes('portal-note')
        ui.link('Lire le guide des rapports', '/documentation/13-test-reports')

        def protected(session, identity, on_error):
            if identity['category'] != 'internal' or not identity['administrator']:
                ui.label('Rapports réservés aux comptes internes habilités à l’administration.').classes('text-red-8').props('data-qualification-denied')
                return
            try:
                grant = reports.GRANTS.issue(session)
                campaigns, rejected = reports.publications.catalogue(reports.root())
            except (OSError, ValueError, AccessDenied, PortalError):
                ui.label('Les rapports sont indisponibles. Vérifier leur import et les droits de cette session.').classes('text-red-8').props('data-qualification-error')
                return
            if rejected:
                ui.label(str(rejected) + ' publication(s) invalide(s) écartée(s). Vérifier les archives et leurs empreintes.').classes('text-orange-9').props('data-qualification-invalid')
            if not campaigns:
                ui.label('Aucun rapport importé dans cette instance. Le guide explique comment publier un ZIP de qualification.').props('data-qualification-empty')
                return
            ui.label('Les liens de consultation expirent après cinq minutes. Reconnectez-vous pour les renouveler.').classes('text-sm text-grey-7')
            if len(campaigns) > 20:
                ui.label('Affichage des vingt publications les plus récentes sur ' + str(len(campaigns)) + '. Archiver les anciennes campagnes selon le guide.').classes('text-grey-7')
            for row in campaigns[:20]:
                state = reports.publications.outcome(row)
                label, color = {
                    'failed': ('Échec', 'negative'), 'incomplete': ('Incomplet', 'warning'),
                    'not_qualified': ('Périmètres non qualifiés', 'warning'),
                    'passed_with_skips': ('Réussi avec tests sautés', 'warning'),
                    'passed': ('Réussi sur le périmètre exécuté', 'positive')}[state]
                with ui.card().classes('w-full').props('data-qualification-campaign data-report-id=' + row['id']):
                    ui.label(row['title']).classes('text-lg font-semibold')
                    ui.badge(label, color=color).props('data-qualification-outcome')
                    ui.label('Rapport généré le ' + row['created_at'] + ' · ' + row['environment']).classes('text-sm text-grey-7')
                    source = row['source']
                    ui.label('Source : ' + (source['commit'] or 'non identifiée') + (' · fichiers modifiés' if source['dirty'] else '')).classes('text-sm text-grey-7')
                    counts = row['counts']
                    ui.label(' · '.join(f'{counts[key]} {title}' for key, title in (
                        ('passed', 'réussis'), ('failed', 'échecs'), ('broken', 'erreurs'),
                        ('skipped', 'sautés'), ('unknown', 'incomplets'), ('not_qualified', 'non qualifiés')))).props('data-qualification-counts')
                    url = '/qualification/view/' + row['id'] + '?access=' + grant
                    qualification_viewer(url)
                    with ui.row():
                        ui.link('Télécharger le rapport HTML', url + '&download=true').props('data-qualification-html')
                        ui.link('Exporter la campagne ZIP', '/qualification/export/' + row['id'] + '?access=' + grant).props('data-qualification-export')
        authentication(Session(), protected)


def qualification_viewer(url):
    """Load one report only when requested, rather than every stored campaign."""
    with ui.expansion('Ouvrir le rapport Allure', icon='analytics').classes('w-full').props('data-qualification-open') as expansion:
        target = ui.column().classes('w-full')

    def changed(event):
        target.clear()
        if event.value:
            with target:
                ui.html('<iframe title="Rapport Allure" sandbox="allow-scripts allow-downloads" referrerpolicy="no-referrer" src="' + url + '" style="width:100%;height:850px;border:1px solid #ddd"></iframe>', sanitize=False).classes('w-full').props('data-qualification-frame')
    expansion.on_value_change(changed)


@app.get('/documentation/files/{relative:path}')
def public_document_file(relative: str):
    try:
        path = documents.public_file(relative)
    except documents.DocumentationError:
        raise HTTPException(status_code=404, detail='Public document not found') from None
    return FileResponse(path)


@app.get('/download/document/{identifier}')
def download_document(identifier: str):
    try:
        path = documents.document(identifier)
    except documents.DocumentationError:
        raise HTTPException(status_code=404, detail='Public document not found') from None
    return FileResponse(path, filename=path.name, media_type='text/markdown; charset=utf-8')


@app.get('/download/file/{relative:path}')
def download_file(relative: str):
    if not relative.endswith(('.drawio', '.svg', '.png')):
        raise HTTPException(status_code=404, detail='Public diagram not found')
    try:
        path = documents.public_file(relative)
    except documents.DocumentationError:
        raise HTTPException(status_code=404, detail='Public diagram not found') from None
    return FileResponse(path, filename=path.name)


@app.get('/download/wiki.zip')
def download_wiki():
    try:
        content = documents.wiki_zip()
    except documents.DocumentationError:
        raise HTTPException(status_code=503, detail='Documentation export unavailable') from None
    return Response(content, media_type='application/zip', headers={
        'Content-Disposition': 'attachment; filename="si-rie-documentation.zip"'})


@ui.page('/')
def home():
    if os.getenv('RIE_DEPLOYMENT_ONLY') == 'true':
        deployment_page()
        return
    with ui.column().classes('portal-page gap-5'):
        shell('UC PDL, Incidents et ACL — recette Ubuntu')
        ui.label('Le portail présente les parcours ; Open WebUI reste sur chaque poste utilisateur.').classes('text-lg')
        with ui.row().classes('w-full gap-4'):
            for label, text, url in [
                ('PDL', 'PFS, Backbone, PFAING et TACACS : du catalogue approuvé aux preuves.', '/demo-pdl-5min'),
                ('Incidents', 'Mesures VictoriaMetrics, logs PDL et tickets ITSM simulés.', '/demo-incidents-5min'),
                ('ACL', 'Identité LDAP, jeton individuel, règles et refus côté serveur.', '/demo-acces'),
            ]:
                with ui.card().classes('grow basis-72'):
                    ui.label(label).classes('text-xl font-semibold')
                    ui.label(text)
                    ui.link('Ouvrir le parcours', url)
        figure('01-deployment', 'Architecture de cette livraison')
        ui.link('Tutoriels de prise en main · questions et résultats attendus', '/documentation/09-demonstrations#tutoriels-de-prise-en-main').props('data-portal-tutorial-link')
        ui.link('Exporter toute la documentation Wiki.js', '/download/wiki.zip').props('data-portal-wiki-export')


@ui.page('/demo-pdl-5min')
def pdl_demo():
    with ui.column().classes('portal-page gap-5'):
        shell('PDL — quatre familles et preuves contrôlées')
        ui.label('Corpus portable du 12 octobre 2026, 08 h–09 h UTC · périmètre demo-alpha.').props('data-pdl-corpus')
        ui.link('Suivre le tutoriel PDL · questions à copier', '#tutoriel-pdl').props('data-demo-tutorial-link')
        ui.markdown('**PFS** retrouve les refus ; **Backbone** relie les identités ; **PFAING** retrouve la référence ; **TACACS** retrouve les accès par les IP de gestion. Les mappings sont approuvés séparément des droits.')
        ui.code(PDL_QUESTION, language='text').props('data-pdl-question')
        ui.label('MCP à renseigner dans le client local : ' + os.getenv('RIE_PDL_PUBLIC_URL', 'http://127.0.0.1:19910/mcp')).props('data-pdl-mcp-url')
        figure('03-pdl-flow', 'Du message PDL aux nouvelles preuves')
        def protected(session, identity, on_error):
            output = ui.column().classes('w-full').props('data-pdl-output')
            with ui.row():
                action('Lire mon catalogue approuvé', session, lambda: {'status': 'ok', 'catalogue': session.catalogue()}, output, marker='data-pdl-catalogue', on_error=on_error)
                action('Demander mes droits au MCP', session, lambda: session.pdl('Quels sont mes index accessibles ?'), output, marker='data-pdl-own-access', on_error=on_error)
                action('Lire la dernière recette de cette instance', session, session.pdl_receipt, output, marker='data-pdl-receipt', on_error=on_error)
            ui.label('La recette enregistrée est datée ; ce bouton ne relance pas une investigation.').classes('text-sm text-grey-7')
            with ui.expansion('Investiguer avec Albert API', icon='forum', value=True).classes('w-full'):
                ui.label('Cette action appelle le fournisseur IA configuré sur le serveur. Aucun succès de génération n’est présumé.').classes('portal-note')
                question = ui.textarea('Question métier', value=PDL_QUESTION).props('data-pdl-live-question').classes('w-full')
                resume = ui.checkbox('Reprendre cette conversation', value=False).props('data-pdl-resume')
                action('Investiguer la question', session, lambda: session.pdl(question.value or '', resume=resume.value), output, marker='data-pdl-investigate', on_error=on_error, generation=True)
        authentication(Session(), protected)
        ui.link_target('tutoriel-pdl')
        tutorial('16-pdl-tutorial')
        document_panel('04-pdl')


@ui.page('/demo-incidents-5min')
def incidents_demo():
    with ui.column().classes('portal-page gap-5'):
        shell('Incidents — mesures, tickets, logs et sources')
        ui.label('Corpus fictif du 28 septembre 2026 · R1 / OBS-RTR-01 · 10 h–12 h, Europe/Paris.').props('data-incidents-corpus')
        ui.link('Suivre le tutoriel Incidents · questions à copier', '#tutoriel-incidents').props('data-demo-tutorial-link')
        ui.code(INCIDENT_QUESTION, language='text').props('data-incidents-question')
        ui.label('MCP à renseigner dans le client local : ' + os.getenv('RIE_INCIDENTS_PUBLIC_URL', 'http://127.0.0.1:19950/gptoss/assistant/mcp')).props('data-incidents-mcp-url')
        ui.label('Les faits sont calculés par Python. Résolution technique et clôture administrative du ticket restent distinctes.').classes('portal-note')
        figure('04-incidents-flow', 'Du périmètre aux faits du diagnostic')
        def protected(session, identity, on_error):
            output = ui.column().classes('w-full').props('data-incidents-output')
            action('Diagnostiquer avec Albert API', session, lambda: session.diagnose(synthesize=True), output,
                   marker='data-incidents-generate', on_error=on_error, generation=True)
            ui.label('Albert rédige et relit le diagnostic à partir des sources autorisées de cette instance. Les appels réels, leurs erreurs et les modèles sont indiqués dans le rapport.').classes('portal-note')
            with ui.expansion('Contrôle technique des sources, sans génération IA').classes('w-full'):
                action('Lire les preuves maintenant, sans génération IA', session, session.diagnose, output,
                       marker='data-incidents-read', on_error=on_error)
                ui.label('Ce contrôle technique ne valide pas le parcours de génération avec Albert.').classes('text-sm text-grey-7')
        authentication(Session(), protected)
        ui.link_target('tutoriel-incidents')
        tutorial('17-incidents-tutorial')
        document_panel('05-incidents')


@ui.page('/demo-acces')
def acl_demo():
    with ui.column().classes('portal-page gap-5'):
        shell('ACL — identité et droits vérifiés côté serveur')
        ui.markdown('Le serveur remet un **jeton individuel révocable** à chaque utilisateur classé par LDAP. Open WebUI local transmet ce jeton ; il ne détient aucune clé commune lui permettant de choisir une identité. Les groupes LDAP et les règles sont relus à chaque appel.')
        figure('05-identity-acl', 'La frontière d’identité et d’autorisation')
        ui.table(columns=[{'name': k, 'label': label, 'field': k} for k, label in
                          [('rule', 'Règle'), ('internal', 'Interne'), ('external', 'Externe')]], rows=[
            {'rule': 'authenticated', 'internal': 'Autorisé', 'external': 'Autorisé'},
            {'rule': 'internal', 'internal': 'Autorisé', 'external': 'Refusé'},
            {'rule': 'blocked ou règle absente', 'internal': 'Refusé', 'external': 'Refusé'}]).classes('w-full')
        ui.label('Comptes fictifs : alice.martin (interne administratrice), bruno.lecteur (interne lecteur), eric.durand.ext (externe), camille.inconnue (non classé, refusé).')
        ui.label('Incidents contrôle séparément les index de logs, les documents, les mesures et les tickets. Le diagnostic complet exige les quatre droits.').classes('portal-note')
        def protected(session, identity, on_error):
            output = ui.column().classes('w-full').props('data-acl-output')
            with ui.row():
                action('Afficher mes droits actuels', session, session.own_access, output, marker='data-acl-own-access', on_error=on_error)
                action('Tester les preuves Incidents avec mon identité', session, session.diagnose, output, marker='data-acl-incidents', on_error=on_error)
            if identity['administrator']:
                ui.link('Administrer les règles de cette instance', '/admin-acces')
        authentication(Session(), protected)
        document_panel('06-acl')


@ui.page('/admin-acces')
def acl_administration():
    with ui.column().classes('portal-page gap-5'):
        shell('Administrer les règles ACL de cette instance')
        ui.label('Une modification de règle ne crée ni index ni mapping. Une interdiction reste opposable aux administrateurs.').classes('portal-note')
        def protected(session, identity, on_error):
            if not identity['administrator']:
                ui.label('Administration réservée aux membres du groupe LDAP d’administration des accès.').props('data-admin-denied').classes('text-red-8')
                return
            output = ui.column().classes('w-full').props('data-admin-output')
            policy_state = {'revision': None}
            revision_label = ui.label().props('data-admin-revision')
            table = ui.table(columns=[{'name': 'index', 'label': 'Index concret', 'field': 'index', 'align': 'left'},
                                      {'name': 'visibility', 'label': 'Règle', 'field': 'visibility'}], rows=[], row_key='index').classes('w-full').props('data-admin-policy')
            resources = ui.table(columns=[{'name': 'resource', 'label': 'Source Incidents', 'field': 'resource'},
                                          {'name': 'visibility', 'label': 'Règle', 'field': 'visibility'}],
                                 rows=[], row_key='resource').classes('w-full').props('data-admin-resources')
            async def refresh():
                try:
                    policy = await run.io_bound(session.policy)
                    policy_state['revision'] = policy['revision']
                    revision_label.set_text('Révision active : ' + str(policy['revision']))
                    table.rows = [{'index': k, 'visibility': v} for k, v in sorted(policy['indices'].items())]
                    table.update()
                    resources.rows = [{'resource': RESOURCE_LABELS[key],
                                       'visibility': policy.get('resources', {}).get(key, 'blocked')}
                                      for key in RESOURCE_LABELS]
                    resources.update()
                except (AccessDenied, PortalError, OSError, ValueError) as error:
                    output.clear()
                    with output:
                        ui.label(message(error)).props('data-portal-error')
                    on_error(error)
            ui.button('Actualiser les règles', on_click=refresh).props('data-admin-refresh')
            target = ui.toggle({'index': 'Index OpenSearch', 'resource': 'Source Incidents'}, value='index').props('data-admin-target')
            index = ui.input('Nom exact de l’index').props('data-admin-index').classes('w-full')
            resource = ui.select(RESOURCE_LABELS, value='incidents.metrics', label='Source').props('data-admin-resource').classes('w-full')
            resource.set_visibility(False)
            def select_target(event):
                index.set_visibility(event.value == 'index')
                resource.set_visibility(event.value == 'resource')
            target.on_value_change(select_target)
            visibility = ui.select(LABELS, value='blocked', label='Accès').props('data-admin-visibility').classes('w-full')
            async def change(remove=False):
                try:
                    if policy_state['revision'] is None:
                        raise PortalError('policy_not_loaded')
                    is_resource = target.value == 'resource'
                    identifier = resource.value if is_resource else (index.value or '').strip()
                    result = await run.io_bound(session.change_policy, identifier, visibility.value,
                                                policy_state['revision'], remove=remove, resource=is_resource)
                    show_result(output, {'status': 'règle enregistrée', 'policy': result})
                    await refresh()
                except (AccessDenied, PortalError, OSError, ValueError) as error:
                    output.clear()
                    with output:
                        ui.label(message(error)).props('data-portal-error')
                    on_error(error)
            with ui.row():
                ui.button('Enregistrer la règle', on_click=lambda: change()).props('data-admin-save')
                with ui.dialog() as confirm, ui.card():
                    ui.label('Supprimer cette règle ? La source et ses données seront conservées ; leur accès sera refusé par défaut.')
                    async def remove():
                        await change(remove=True)
                        confirm.close()
                    ui.button('Confirmer la suppression', on_click=remove).props('data-admin-confirm-remove')
                    ui.button('Annuler', on_click=confirm.close)
                ui.button('Supprimer la règle', on_click=confirm.open).props('outline data-admin-remove')
            # A one-shot timer renders only after this client has authenticated.
            ui.timer(.05, refresh, once=True)
        authentication(Session(), protected)
        document_panel('06-acl', 'Guide des règles et des jetons')


@ui.page('/deployment')
def deployment_page():
    from .deployment_ui import page
    page(lambda title: shell(title, deployment=True))


@ui.page('/admin-mappings')
def mapping_administration():
    from .mapping_ui import page
    page(Session(), shell, authentication, message, document_panel)


@ui.page('/documentation')
def documentation_index():
    with ui.column().classes('portal-page gap-5'):
        shell('Documentation SI-RIE — texte et diagrammes exportables')
        ui.link('Télécharger le paquet Wiki.js complet', '/download/wiki.zip').props('data-portal-wiki-export')
        try:
            catalogue = documents.catalog()
            guide = next((row for row in catalogue if row['id'] == 'README'), None)
            if guide is None:
                raise documents.DocumentationError('Main deployment guide unavailable')
            with ui.card().classes('w-full').props('data-documentation-primary'):
                ui.label('Commencer ici · un seul parcours de déploiement').classes('text-xl font-semibold')
                ui.link(guide['title'], '/documentation/README').props('data-documentation-start')
                ui.label('Suivre les étapes 1 à 12. Les compléments ci-dessous se consultent à la demande.')
                ui.link('Télécharger le guide en Markdown', '/download/document/README')
            with ui.expansion('Compléments de référence · consulter selon le besoin', icon='library_books').classes('w-full').props('data-documentation-reference'):
                for row in catalogue:
                    if row['id'] == 'README':
                        continue
                    with ui.row().classes('items-center'):
                        ui.link(row['title'], '/documentation/' + quote(row['id'], safe=''))
                        ui.link('Markdown', '/download/document/' + quote(row['id'], safe=''))
        except documents.DocumentationError:
            ui.label('La documentation canonique n’est pas installée.').classes('text-red-8')
        with ui.expansion('Diagrammes éditables · architecture et flux', icon='account_tree').classes('w-full').props('data-documentation-diagrams'):
            for identifier in documents.DIAGRAMS:
                figure(identifier, identifier.split('-', 1)[1].replace('-', ' ').capitalize())


@ui.page('/documentation/{identifier}')
def documentation_page(identifier: str):
    with ui.column().classes('portal-page gap-5'):
        shell('Documentation SI-RIE')
        ui.link('← Guide et compléments', '/documentation')
        try:
            content = documents.markdown(identifier)
        except documents.DocumentationError:
            ui.label('Document introuvable.').classes('text-red-8')
            return
        with ui.row():
            ui.link('Télécharger cette page en Markdown', '/download/document/' + quote(identifier, safe='')).props('data-document-download')
            ui.link('Télécharger tout le dossier Wiki.js', '/download/wiki.zip')
        ui.markdown(content).classes('w-full').props('data-portal-document')
        async def reach_section():
            # The document arrives over NiceGUI's socket after the initial URL.
            # Retry briefly so cross-page section links scroll after rendering.
            await ui.run_javascript('''
                let identifier;
                try { identifier = decodeURIComponent(location.hash.slice(1)); }
                catch { return; }
                if (!identifier) return;
                for (let attempt = 0; attempt < 40; attempt++) {
                    const target = document.getElementById(identifier);
                    if (target) {
                        for (let parent = target.parentElement; parent; parent = parent.parentElement) {
                            if (parent.tagName === 'DETAILS') parent.open = true;
                        }
                        target.scrollIntoView({block: 'start'}); return;
                    }
                    await new Promise(resolve => setTimeout(resolve, 50));
                }
            ''', timeout=3)
        ui.timer(.1, reach_section, once=True)


def main():
    ui.run(host=os.getenv('BIND_ADDRESS', '127.0.0.1'), port=int(os.getenv('PORTAL_INTERNAL_PORT', '8090')),
           title='SI-RIE · PDL, Incidents et ACL', reload=False, show=False, favicon='🔎',
           binding_refresh_interval=.5)


if __name__ == '__main__':
    main()
