"""Read only the canonical public documentation allowlist and build exports."""
from __future__ import annotations

import importlib
import os
from pathlib import Path
import re
import unicodedata
import tempfile
from urllib.parse import quote

DIAGRAMS = (
    '01-deployment', '02-simulation', '03-pdl-flow', '04-incidents-flow',
    '05-identity-acl', '06-index-relations', '07-mapping-approval', '08-backup-recovery',
    '09-pdl-demo-architecture', '10-pdl-demo-flow',
    '11-incidents-demo-architecture', '12-incidents-demo-flow',
)

# Preserve bookmarked page/download URLs while the filesystem and catalogue use
# English names. These exact identifiers grant no additional file access.
DOCUMENT_ALIASES = {
    '24-deploy-walkthrough': 'README',
    '07-exploitation': '07-operations',
    '11-journal-installation': '11-installation-log',
    '12-recette-manuelle': '12-manual-acceptance',
    '13-rapports-tests': '13-test-reports',
    '14-recette-si-rie': '14-si-rie-acceptance',
    '16-tutoriel-pdl': '16-pdl-tutorial',
    '17-tutoriel-incidents': '17-incidents-tutorial',
}


class DocumentationError(ValueError):
    pass


def root():
    return Path(os.getenv('RIE_DOCS_DIR', '/documentation'))


def exporter():
    try:
        return importlib.import_module('wiki_export')
    except ImportError:
        raise DocumentationError('Documentation export module unavailable') from None


def catalog():
    try:
        return exporter().list_documents(root())
    except (OSError, ValueError):
        raise DocumentationError('Canonical documentation unavailable') from None


def canonical_identifier(identifier):
    """Resolve an exact former page identifier without accepting file paths."""
    if not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}', identifier):
        raise DocumentationError('Unknown document')
    return DOCUMENT_ALIASES.get(identifier, identifier)


def document(identifier):
    identifier = canonical_identifier(identifier)
    selected = next((row for row in catalog() if row['id'] == identifier), None)
    if selected is None:
        raise DocumentationError('Unknown document')
    return public_file(selected['path'])


def public_file(relative):
    if not isinstance(relative, str) or not relative or '\\' in relative:
        raise DocumentationError('Unknown public file')
    try:
        return exporter().public_file(root(), relative)
    except (OSError, ValueError):
        raise DocumentationError('Unknown public file') from None


def rewrite_markdown(markdown, relative):
    """Make canonical relative page/image links work without a source checkout."""
    lookup = {str(row['path']): row['id'] for row in catalog()}
    pattern = re.compile(r'(!?\[[^\]]*\]\()([^\s)]+)(\))')

    def replace(match):
        target = match[2].strip('<>')
        # The exporter's allowlist, rather than an arbitrary resolved path, wins.
        try:
            name, fragment = exporter().local_target(relative, target)
            if name is None:
                return match[0]
            public_file(name)
        except (DocumentationError, ValueError):
            return match[1] + '#' + match[3]
        fragment = '#' + fragment if fragment else ''
        if name in lookup:
            dest = '/documentation/' + quote(lookup[name], safe='') + fragment
        else:
            dest = '/documentation/files/' + quote(name, safe='/') + fragment
        return match[1] + dest + match[3]

    return pattern.sub(replace, markdown)


def markdown(identifier):
    identifier = canonical_identifier(identifier)
    selected = next((row for row in catalog() if row['id'] == identifier), None)
    if selected is None:
        raise DocumentationError('Unknown document')
    path = document(identifier)
    return section_anchors(rewrite_markdown(path.read_text(encoding='utf-8'), str(selected['path'])))


def section_anchors(text):
    """Give NiceGUI the same Unicode section targets as the portable Markdown.

    Its default Markdown renderer does not emit heading IDs. Inline anchors keep
    canonical links working without changing the downloaded/exported source.
    """
    result, identifiers, fence = [], set(), None
    for line in text.splitlines(keepends=True):
        marker = re.match(r'^ {0,3}(`{3,}|~{3,})(.*)$', line.rstrip('\r\n'))
        if fence is not None:
            if marker and marker[1][0] == fence[0] and len(marker[1]) >= len(fence) and not marker[2].strip():
                fence = None
        elif marker:
            fence = marker[1]
        else:
            heading = re.match(r'^( {0,3}#{1,6}\s+)(.+?)(\r?\n)?$', line)
            if heading:
                title = re.sub(r'\s+#+\s*$', '', heading[2]).replace('`', '')
                title = re.sub(r'<[^>]*>', '', title)
                title = re.sub(r'!?\[([^\]]*)\]\([^)]*\)', r'\1', title).lower()
                base = ''.join('-' if c.isspace() else c for c in title
                               if c.isspace() or c in '-_' or unicodedata.category(c)[0] in 'LMN')
                identifier, suffix = base, 0
                while identifier in identifiers:
                    suffix += 1
                    identifier = base + '-' + str(suffix)
                identifiers.add(identifier)
                line = heading[1] + '<a id="' + identifier + '"></a>' + heading[2] + (heading[3] or '')
        result.append(line)
    return ''.join(result)


def wiki_zip():
    """Generate a temporary public-only ZIP; no data volume is traversed."""
    try:
        with tempfile.TemporaryDirectory(prefix='rie-wiki-export-') as folder:
            output = Path(folder) / 'si-rie-documentation.zip'
            exporter().export_bundle(root(), output)
            return output.read_bytes()
    except (OSError, ValueError):
        raise DocumentationError('Documentation export unavailable') from None
