"""Per-browser LDAP sessions and fresh backend reads for the Ubuntu portal.

Only a short, server-issued session is kept in this object's memory. Neither a
shared service credential nor user-supplied identity claims authorize a read.
The same backend ACL is checked for each HTTP/MCP request and local policy read.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import json
import os
from pathlib import Path
from threading import RLock
from typing import Callable

import httpx
from dinum_access import AccessDenied, AccessGate

PDL_INDICES = ('rie-pfs-fixture', 'rie-bb-fixture', 'rie-pfaing-fixture', 'rie-tacacs-fixture')
PDL_QUESTION = "Montre les logs de l'équipement edge-a PFS BB PFAING TACACS dans demo-alpha du 12 octobre 2026 de 08:00 à 09:00 UTC."
INCIDENT_QUESTION = 'Examiner les mesures, tickets et logs de R1 le 28 septembre 2026 de 10 h à 12 h, Europe/Paris.'
MAX_FILE_BYTES = 4_000_000


class PortalError(ValueError):
    """Expose a bounded, non-sensitive failure instead of raw network errors."""
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def configured_gate():
    gate = AccessGate.configured()
    if gate is None:
        raise AccessDenied('access_configuration_unavailable')
    return gate


def private_json(path):
    path = Path(path)
    if path.is_symlink():
        raise PortalError('local_state_unavailable')
    try:
        with path.open('rb') as stream:
            raw = stream.read(MAX_FILE_BYTES + 1)
        if len(raw) > MAX_FILE_BYTES:
            raise ValueError()
        return json.loads(raw)
    except (OSError, ValueError):
        raise PortalError('local_state_unavailable') from None


@dataclass
class Session:
    """One instance belongs to exactly one NiceGUI client, never a global user."""
    gate_factory: Callable = configured_gate
    client_factory: Callable = httpx.Client
    token: str = field(default='', repr=False)
    _epoch: int = field(default=0, repr=False)
    _lock: RLock = field(default_factory=RLock, repr=False)
    _continuations: dict = field(default_factory=dict, repr=False)

    def login(self, username, password):
        self.logout()
        with self._lock:
            login_epoch = self._epoch
        gate = self.gate_factory()
        token = gate.login(username, password)
        principal = gate.authenticate({'authorization': 'Bearer ' + token})
        with self._lock:
            if login_epoch != self._epoch:
                raise PortalError('session_changed')
            self.token = token
            self._epoch += 1
            self._continuations.clear()
        return self._identity(principal)

    def logout(self):
        with self._lock:
            self.token = ''
            self._epoch += 1
            self._continuations.clear()

    @staticmethod
    def _identity(principal):
        return {'email': principal.email, 'category': principal.category,
                'administrator': principal.administrator}

    def _authenticated(self):
        with self._lock:
            token, epoch = self.token, self._epoch
        if not token:
            raise AccessDenied('identity_required')
        gate = self.gate_factory()
        try:
            principal = gate.authenticate({'authorization': 'Bearer ' + token})
        except AccessDenied:
            self.logout()
            raise
        return gate, principal, token, epoch

    def _unchanged(self, epoch):
        with self._lock:
            if epoch != self._epoch or not self.token:
                raise PortalError('session_changed')

    def identity(self):
        gate, principal, _, epoch = self._authenticated()
        self._unchanged(epoch)
        return self._identity(principal)

    def own_access(self):
        gate, principal, _, epoch = self._authenticated()
        result = gate.store.accessible(principal)
        self._unchanged(epoch)
        return result

    def catalogue(self):
        gate, principal, _, epoch = self._authenticated()
        allowed = set(gate.store.accessible(principal)['allowed_indices'])
        root = Path(os.getenv('PDL_DATA_DIR', '/data/pdl'))
        catalog = private_json(root / 'catalog/approved.json')
        if not isinstance(catalog, list) or any(not isinstance(row, dict) for row in catalog):
            raise PortalError('local_state_unavailable')
        result = [{key: row.get(key) for key in ('index', 'version', 'schema_hash', 'mapping', 'concepts')}
                  for row in catalog if row.get('active') and row.get('index') in allowed]
        self._unchanged(epoch)
        return result

    def mapping_administration(self):
        from .mapping_admin import MappingAdministration
        return MappingAdministration(self)

    def pdl_receipt(self):
        """Expose a dated local recipe only while all its exact indices are allowed."""
        gate, principal, _, epoch = self._authenticated()
        gate.store.authorize(principal, list(PDL_INDICES))
        report = private_json(os.getenv('RIE_ACCEPTANCE_FILE', '/data/acceptance.json'))
        if not isinstance(report, dict):
            raise PortalError('local_state_unavailable')
        result = {'captured_at_utc': report.get('at_utc'),
                  'source': 'latest_acceptance_of_this_ubuntu_instance',
                  'fresh_investigation': False, 'generation': report.get('generation'),
                  'pdl': report.get('pdl')}
        self._unchanged(epoch)
        return result

    def policy(self):
        gate, principal, _, epoch = self._authenticated()
        if not principal.administrator:
            raise AccessDenied('administrator_required')
        result = gate.store.read()
        self._unchanged(epoch)
        return result

    def change_policy(self, index, visibility, revision, *, remove=False, resource=False):
        gate, principal, _, epoch = self._authenticated()
        if not principal.administrator:
            raise AccessDenied('administrator_required')
        self._unchanged(epoch)
        if resource:
            result = (gate.store.remove_resource(principal, index, revision) if remove else
                      gate.store.update_resource(principal, index, visibility, revision))
        else:
            result = (gate.store.remove(principal, index, revision) if remove else
                      gate.store.update(principal, index, visibility, revision))
        self._unchanged(epoch)
        return result

    def _request(self, url, payload, *, mcp=False):
        _, _, token, epoch = self._authenticated()
        headers = {'Authorization': 'Bearer ' + token}
        if mcp:
            headers.update({'Accept': 'application/json, text/event-stream',
                            'MCP-Protocol-Version': '2025-11-25'})
        try:
            with self.client_factory(timeout=180, trust_env=False, follow_redirects=False) as client:
                response = client.post(url, json=payload, headers=headers)
            self._unchanged(epoch)
            if response.status_code in {401, 403}:
                raise PortalError('backend_access_denied')
            if response.status_code >= 400:
                raise PortalError('backend_unavailable')
            if len(response.content) > MAX_FILE_BYTES:
                raise PortalError('backend_response_too_large')
            result = response.json()
            if not isinstance(result, dict):
                raise ValueError()
            return result
        except (httpx.HTTPError, ValueError) as error:
            if isinstance(error, PortalError):
                raise
            raise PortalError('backend_unavailable') from None

    def pdl(self, question, *, resume=False):
        if not isinstance(question, str) or not 1 <= len(question.strip()) <= 2000:
            raise PortalError('invalid_question')
        with self._lock:
            epoch = self._epoch
            continuation = self._continuations.get('pdl', '') if resume else ''
        payload = {'jsonrpc': '2.0', 'id': 1, 'method': 'tools/call',
                   'params': {'name': 'investigate_pdl', 'arguments': {
                       'question': question, 'continuation_token': continuation}}}
        body = self._request(os.getenv('RIE_PDL_INTERNAL_URL', 'http://pdl:9910').rstrip('/') + '/mcp', payload, mcp=True)
        result = body.get('result')
        if body.get('error'):
            raise PortalError('backend_tool_error')
        if not isinstance(result, dict):
            raise PortalError('backend_response_invalid')
        if result.get('isError'):
            raise PortalError('backend_tool_error')
        content = result.get('structuredContent')
        if content is None:
            rows = result.get('content', [])
            if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
                raise PortalError('backend_response_invalid')
            for row in rows:
                if row.get('type') == 'text':
                    try:
                        content = json.loads(row['text'])
                    except (ValueError, KeyError):
                        continue
                    break
        if not isinstance(content, dict):
            raise PortalError('backend_response_invalid')
        with self._lock:
            self._unchanged(epoch)
            self._continuations['pdl'] = content.get('continuation_token', '')
        return content

    def diagnose(self, *, synthesize=False):
        """Read incident evidence, optionally generating and reviewing with Albert."""
        return self._request(os.getenv('RIE_INCIDENTS_INTERNAL_URL', 'http://incidents:9950').rstrip('/') + '/diagnose', {
            'question': INCIDENT_QUESTION, 'variant': 'gptoss', 'equipment': 'OBS-RTR-01',
            'start': '2026-09-28T10:00:00+02:00', 'end': '2026-09-28T12:00:00+02:00',
            'synthesize': synthesize})
