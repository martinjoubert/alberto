"""Bounded, explicit provider double for load qualification, never a real LLM.

Only the known PDL fixture questions and dialogue classifications are accepted.
No permissions, source evidence or arbitrary model-generated plan is trusted.
The normal runtime still validates/compiles every returned proposal and applies ACL.
"""
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import threading
import time
import uuid

MODEL = 'qualification-fixture'
MAX_BYTES = 1048576


def fixture_questions():
    from rie_agent.acceptance import FIXTURE_PATH, scenarios
    fixture = json.loads(FIXTURE_PATH.read_text())
    return {row['question']: row['proposal'] for row in scenarios(fixture)}


def answer(payload):
    if payload.get('model') != MODEL:
        raise ValueError('qualification_model_required')
    messages = payload.get('messages')
    if not isinstance(messages,list) or not messages or len(messages)>8:
        raise ValueError('invalid_messages')
    context = json.loads(messages[-1]['content'])
    questions=fixture_questions()
    if 'current_message' in context:
        message=context['current_message']
        if message not in questions:
            raise ValueError('unknown_qualification_question')
        return {'action':'new','confidence':1.0,'clarification':'','source_change':'unchanged'}
    question=context.get('question')
    if question not in questions:
        raise ValueError('unknown_qualification_question')
    proposal=deepcopy(questions[question])
    # The provider sees the same inventory/catalog as a real model. A missing
    # or stale approval is handled by the unmodified runtime, never repaired here.
    return proposal


class Handler(BaseHTTPRequestHandler):
    server_version='RIEQualificationProvider/1'
    def log_message(self,*args):pass
    def send(self,status,value):
        data=json.dumps(value,ensure_ascii=False).encode()
        self.send_response(status);self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def do_GET(self):
        if self.path=='/healthz':return self.send(200,{'status':'ok','simulated':True})
        if self.path=='/v1/models':return self.send(200,{'object':'list','data':[{'id':MODEL,'object':'model','owned_by':'qualification-simulator'}]})
        self.send(404,{'error':{'code':'not_found'}})
    def do_POST(self):
        try:
            if self.path!='/v1/chat/completions':return self.send(404,{'error':{'code':'not_found'}})
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=MAX_BYTES:return self.send(413,{'error':{'code':'request_too_large'}})
            proposal=answer(json.loads(self.rfile.read(length)))
            content=json.dumps(proposal,ensure_ascii=False)
            response={'id':'sim-'+uuid.uuid4().hex,'object':'chat.completion','created':int(time.time()),
                      'model':MODEL,'rie_simulation':True,'choices':[{'index':0,'finish_reason':'stop',
                      'message':{'role':'assistant','content':content}}],
                      'usage':{'prompt_tokens':0,'completion_tokens':0,'total_tokens':0}}
            self.send(200,response)
        except (ValueError,KeyError,TypeError,UnicodeError):
            self.send(422,{'error':{'code':'qualification_request_not_supported'}})


def start(port=8123):
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    thread=threading.Thread(target=server.serve_forever,name='qualification-provider',daemon=True)
    thread.start()
    return server
