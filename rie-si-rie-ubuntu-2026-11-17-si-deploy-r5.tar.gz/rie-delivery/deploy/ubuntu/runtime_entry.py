"""Normal PDL entry point with an explicitly enabled loopback-only test provider."""
import os


def main():
    server=None
    if os.getenv('RIE_SIMULATED_ALBERT','false')=='true':
        if os.getenv('PDL_MODE')!='demo' or os.getenv('ALBERT_API_BASE_URL')!='http://127.0.0.1:8123/v1':
            raise ValueError('The qualification provider requires demo mode and its exact loopback endpoint')
        from simulated_provider import start
        server=start()
    try:
        from rie_agent.mcp_app import main as serve
        serve()
    finally:
        if server:
            server.shutdown();server.server_close()


if __name__=='__main__':main()
