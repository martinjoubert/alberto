"""Render qualification results with pinned Allure, then build a portal bundle.

This host/CI tool needs Node and ``npm ci --prefix deploy/ubuntu/reporting``.
It never installs packages, reads application instances or starts services.
Only the standalone HTML and its integrity/provenance metadata are exported.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import uuid
import zipfile

HERE = Path(__file__).resolve().parent
TOOLS = HERE/'reporting'
STATUSES = ('passed', 'failed', 'broken', 'skipped', 'unknown')
SLUG = re.compile(r'[a-z0-9][a-z0-9-]{0,63}\Z')
SAFE_NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,255}\Z')
MAX_RESULTS = 100_000
MAX_RESULT_BYTES = 2*1024*1024
MAX_ATTACHMENT_BYTES = 8*1024*1024
MAX_TOTAL_BYTES = 64*1024*1024
MAX_HTML_BYTES = 32*1024*1024
MAX_ARCHIVE_BYTES = 24*1024*1024
MEDIA = {'image/png', 'image/jpeg', 'application/json', 'text/plain'}
PRIVATE = (
    re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----'),
    re.compile(rb'\b(?:glpat-|ghp_|github_pat_|sk-proj-)[A-Za-z0-9_-]{16,}'),
    re.compile(rb'\bBearer [A-Za-z0-9_-]{40,}'),
)


def plain_text(value, label, limit=200):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or any(ord(c) < 32 for c in value):
        raise ValueError('Invalid '+label)
    return value


def read_regular(path, limit):
    """Refuse selected symlinks and bounded non-regular inputs before reading."""
    path = Path(path).absolute()
    for component in (path, *path.parents):
        if component.is_symlink():
            raise ValueError('Symlink report input refused')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise ValueError('Report input is not a bounded regular file')
        data = stream.read(limit+1)
    if len(data) > limit:
        raise ValueError('Report input is too large')
    return data


def attachments(result):
    for item in result.get('attachments', []):
        if (not isinstance(item, dict) or not SAFE_NAME.fullmatch(item.get('source', ''))
                or '-attachment.' not in item['source'] or item.get('type') not in MEDIA):
            raise ValueError('Unsupported or unsafe report attachment')
        yield item['source']
    for step in result.get('steps', []):
        if not isinstance(step, dict):
            raise ValueError('Invalid report step')
        yield from attachments(step)


def stage_results(source, destination, not_qualified=()):
    """Stage only declared results/attachments, never arbitrary neighbouring files."""
    source = Path(source).absolute()
    if source.is_symlink() or not source.is_dir():
        raise ValueError('A regular Allure results directory is required')
    paths = sorted(source.glob('*-result.json'))
    if not paths or len(paths) > MAX_RESULTS:
        raise ValueError('Missing or excessive test results; no successful report can be inferred')
    destination.mkdir(mode=0o700)
    counts = {key: 0 for key in (*STATUSES, 'not_qualified')}
    copied = set()
    total_bytes = 0
    identifiers = set()
    for path in paths:
        raw = read_regular(path, MAX_RESULT_BYTES)
        if any(pattern.search(raw) for pattern in PRIVATE):
            raise ValueError('Credential-like report content refused')
        row = json.loads(raw)
        if (not isinstance(row, dict) or row.get('status') not in STATUSES
                or row.get('stage') != 'finished' or not isinstance(row.get('uuid'), str)
                or row['uuid'] in identifiers or not row.get('fullName') or not row.get('name')):
            raise ValueError('Incomplete or invalid Allure test result')
        identifiers.add(row['uuid'])
        nq = any(item.get('name') == 'qualification' and item.get('value') == 'not_qualified'
                 for item in row.get('labels', []) if isinstance(item, dict))
        if nq and row['status'] != 'skipped':
            raise ValueError('A non-qualified scenario cannot have a successful execution status')
        counts['not_qualified' if nq else row['status']] += 1
        (destination/path.name).write_bytes(raw)
        total_bytes += len(raw)
        for name in attachments(row):
            if name in copied:
                continue
            data = read_regular(source/name, MAX_ATTACHMENT_BYTES)
            if not name.endswith(('.png', '.jpg', '.jpeg')) and any(pattern.search(data) for pattern in PRIVATE):
                raise ValueError('Credential-like attachment content refused')
            (destination/name).write_bytes(data)
            copied.add(name)
            total_bytes += len(data)
        if total_bytes > MAX_TOTAL_BYTES:
            raise ValueError('Report inputs exceed the qualification size limit')
    for scope in not_qualified:
        plain_text(scope, 'non-qualified scope')
        identifier = str(uuid.uuid4())
        row = {'uuid': identifier, 'name': 'Non qualifié — '+scope,
               'fullName': 'qualification.not_qualified.'+hashlib.sha256(scope.encode()).hexdigest(),
               'status': 'skipped', 'stage': 'finished',
               'statusDetails': {'message': 'Ce périmètre n’a pas été exécuté dans cette campagne.'},
               'labels': [{'name': 'qualification', 'value': 'not_qualified'},
                          {'name': 'suite', 'value': 'Périmètres non qualifiés'}]}
        (destination/(identifier+'-result.json')).write_text(json.dumps(row, ensure_ascii=False))
        counts['not_qualified'] += 1
    return counts


class OfflineHTML(HTMLParser):
    def handle_starttag(self, tag, attrs):
        attributes = dict(attrs)
        if tag in {'script', 'img', 'iframe', 'source', 'video', 'audio', 'link'}:
            for key in ('src', 'href', 'poster'):
                target = attributes.get(key)
                if target and not target.startswith(('data:', 'blob:', '#')):
                    raise ValueError('The report must not load external or companion assets')


def validate_html(data):
    if not data or len(data) > MAX_HTML_BYTES:
        raise ValueError('Invalid standalone report size')
    text = data.decode('utf-8')
    if '<html' not in text.lower() or 'window.reportDataReady' not in text:
        raise ValueError('The renderer did not produce a standalone Allure report')
    if any(marker in text.lower() for marker in ('googletagmanager.com', 'google-analytics.com', "gtag('config'")):
        raise ValueError('Analytics are forbidden in exported qualification reports')
    OfflineHTML().feed(text)


def source_identity(commit=None, dirty=False):
    if commit is not None:
        if not re.fullmatch(r'[a-f0-9]{40}|[a-f0-9]{64}', commit):
            raise ValueError('Source commit must be an exact hexadecimal commit')
        return {'commit': commit, 'dirty': bool(dirty)}
    try:
        commit = subprocess.run(['git', '-C', str(HERE), 'rev-parse', 'HEAD'], capture_output=True,
                                text=True, check=True, timeout=10).stdout.strip()
        changed = subprocess.run(['git', '-C', str(HERE), 'status', '--porcelain'], capture_output=True,
                                 text=True, check=True, timeout=10).stdout
        if not re.fullmatch(r'[a-f0-9]{40}|[a-f0-9]{64}', commit):
            raise ValueError('Invalid Git source identity')
        return {'commit': commit, 'dirty': bool(changed.strip()) or bool(dirty)}
    except (OSError, subprocess.SubprocessError):
        return {'commit': None, 'dirty': None}


def build(results, output, identifier, title, environment, *, commit=None, dirty=False,
          not_qualified=(), node=None):
    if not isinstance(identifier, str) or not SLUG.fullmatch(identifier):
        raise ValueError('Invalid report identifier')
    plain_text(title, 'report title');plain_text(environment, 'environment')
    if len(not_qualified) > 100:
        raise ValueError('Too many non-qualified scopes')
    output = Path(output).absolute()
    if output.exists() or output.is_symlink() or any(p.is_symlink() for p in output.parents):
        raise ValueError('Report output must be a new directory without symlinks')
    provenance = source_identity(commit, dirty)
    expected = json.loads(read_regular(TOOLS/'package.json', 64*1024))['devDependencies']['allure']
    installed = json.loads(read_regular(TOOLS/'node_modules/allure/package.json', 64*1024))['version']
    if installed != expected:
        raise ValueError('Installed Allure differs from the qualification lock; run npm ci')
    executable = str(Path(node).absolute()) if node else shutil.which('node')
    if not executable:
        raise ValueError('Node LTS is required on the qualification host, outside the application images')
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.TemporaryDirectory(prefix='rie-report-', dir=output.parent) as temporary:
        workspace = Path(temporary)
        counts = stage_results(results, workspace/'allure-results', not_qualified)
        child_env = {key: value for key, value in os.environ.items()
                     if key in {'PATH', 'SystemRoot', 'SYSTEMROOT', 'TEMP', 'TMP', 'TMPDIR'}}
        child_env['ALLURE_NO_ANALYTICS'] = 'true'
        configuration = json.loads(read_regular(TOOLS/'allurerc.json',64*1024))
        configuration['plugins']['allure2']['options']['reportName'] = title
        config_path = workspace/'allurerc.json'
        config_path.write_text(json.dumps(configuration,ensure_ascii=False))
        subprocess.run([str(executable), str(TOOLS/'node_modules/allure/cli.js'), 'generate',
                        str(workspace/'allure-results'), '--config', str(config_path),
                        '--output', str(workspace/'generated'), '--cwd', str(workspace),
                        '--report-name', title], env=child_env, cwd=workspace, check=True)
        html = read_regular(workspace/'generated/index.html', MAX_HTML_BYTES)
        validate_html(html)
        rendered = json.loads(read_regular(workspace/'generated/summary.json', 1024*1024))['stats']
        expected_counts = {key: counts[key]+(counts['not_qualified'] if key == 'skipped' else 0)
                           for key in STATUSES}
        if rendered.get('total') != sum(counts.values()) or any(rendered.get(key, 0) != value for key, value in expected_counts.items()):
            raise ValueError('Allure counts differ from the selected executions; use one isolated campaign')
        metadata = {'schema_version': 1, 'kind': 'rie-qualification-report', 'id': identifier,
                    'title': title, 'created_at': datetime.now(timezone.utc).isoformat(),
                    'environment': environment, 'source': provenance, 'counts': counts,
                    'html': {'sha256': hashlib.sha256(html).hexdigest(), 'bytes': len(html)},
                    'renderer': {'name': 'Allure', 'version': expected, 'plugin': 'allure2'}}
        raw = (json.dumps(metadata, ensure_ascii=False, indent=2)+'\n').encode()
        output.mkdir(mode=0o700)
        try:
            (output/'index.html').write_bytes(html)
            (output/'report.json').write_bytes(raw)
            archive = output/'qualification-report.zip'
            with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as stream:
                stream.writestr('report.json', raw);stream.writestr('index.html', html)
            if archive.stat().st_size > MAX_ARCHIVE_BYTES:
                raise ValueError('Report archive exceeds the portal import limit')
            digest = hashlib.sha256(archive.read_bytes()).hexdigest()
            (output/'qualification-report.zip.sha256').write_text(digest+'  '+archive.name+'\n')
            for member in output.iterdir():
                member.chmod(0o600)
        except BaseException:
            shutil.rmtree(output)
            raise
    return {'report': str(output/'report.json'), 'html': str(output/'index.html'),
            'archive': str(archive), 'sha256': digest, 'counts': counts,
            'renderer': metadata['renderer']}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--id', required=True)
    parser.add_argument('--title', required=True)
    parser.add_argument('--environment', required=True)
    parser.add_argument('--source-commit')
    parser.add_argument('--source-dirty', action='store_true')
    parser.add_argument('--not-qualified', action='append', default=[])
    parser.add_argument('--node', help='Optional Node executable on the qualification host')
    args = parser.parse_args(argv)
    os.umask(0o077)
    try:
        result = build(args.results, args.output, args.id, args.title, args.environment,
                       commit=args.source_commit, dirty=args.source_dirty,
                       not_qualified=args.not_qualified, node=args.node)
    except (OSError, ValueError, KeyError, TypeError, RecursionError, subprocess.SubprocessError) as error:
        print('ERROR: '+str(error), file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
