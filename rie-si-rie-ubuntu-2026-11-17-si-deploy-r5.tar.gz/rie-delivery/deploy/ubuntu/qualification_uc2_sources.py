"""Qualify UC2 source ACL through real HTTP on an isolated, non-load demo.

Host tool: the public probe is injected into the existing operator container,
never copied into a business image. Only four policy rules and two disposable
credentials are used. Rule contents are restored through revision-checked edits;
runtime_cli owns credential revocation, audit and removal. No generation call.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import struct
import sys

ACCOUNTS = ('alice.martin', 'eric.durand.ext')
EVIDENCE = ('evidence', 'sources', 'metrics', 'logs', 'events', 'documents', 'results')
SOURCES = ('incidents.metrics', 'incidents.tickets')
BODY = {'question': 'Examiner les mesures et les logs R1 sur cette période.', 'variant': 'gptoss',
        'equipment': 'OBS-RTR-01', 'start': '2026-09-28T10:00:00+02:00',
        'end': '2026-09-28T12:00:00+02:00', 'synthesize': False}


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, ensure_ascii=False,
                                                           separators=(',', ':')).encode()
    return hashlib.sha256(raw).hexdigest()


def contents(policy):
    return {key: value for key, value in policy.items() if key != 'revision'}


def other_rules(policy, collection, target):
    selected = {key: dict(value) if key in {'indices', 'resources'} else value
                for key, value in contents(policy).items()}
    selected.setdefault(collection, {}).pop(target, None)
    return selected


class PolicyEdits:
    """Restore only rules edited by this run, preserving all other content."""
    def __init__(self, store, principal):
        self.store, self.principal = store, principal
        self.owned = {}; self.changes = []

    @staticmethod
    def collection(target):
        return 'resources' if target in SOURCES else 'indices'

    def set(self, target, visibility):
        before = self.store.read(); collection = self.collection(target)
        original = before.get(collection, {}).get(target)
        self.owned.setdefault(target, {'original': original, 'expected': original})
        current = self.owned[target]
        if current['expected'] != original:
            raise ValueError('Concurrent change to a qualification rule; it is not overwritten')
        change = self.store.update_resource if collection == 'resources' else self.store.update
        after = change(self.principal, target, visibility, before['revision'])
        current['expected'] = visibility
        if other_rules(before, collection, target) != other_rules(after, collection, target):
            raise ValueError('An unrelated rule changed')
        self.changes.append({'target': target, 'visibility': visibility, 'revision': after['revision'],
                             'other_rule_content_sha256': digest(other_rules(after, collection, target))})
        return after

    def restore_target(self, target):
        owned = self.owned[target]; before = self.store.read(); collection = self.collection(target)
        if before.get(collection, {}).get(target) != owned['expected']:
            raise ValueError('Concurrent change to a qualification rule; restoration refused')
        if owned['original'] is None:
            remove = self.store.remove_resource if collection == 'resources' else self.store.remove
            after = remove(self.principal, target, before['revision'])
        else:
            change = self.store.update_resource if collection == 'resources' else self.store.update
            after = change(self.principal, target, owned['original'], before['revision'])
        if other_rules(before, collection, target) != other_rules(after, collection, target):
            raise ValueError('Restoration changed an unrelated rule')
        del self.owned[target]
        return after

    def restore_all(self):
        failures = []
        for target in list(self.owned):
            try:
                self.restore_target(target)
            except Exception as error:
                failures.append({'target': target, 'error_code': type(error).__name__})
        return failures


class FileReads:
    """Observe actual cross-container opens of the shared business files on Linux."""
    OPEN_ACCESS = 0x20 | 0x1

    def __init__(self, paths):
        if not sys.platform.startswith('linux'):
            raise ValueError('Native file-read qualification requires Linux inotify')
        import ctypes
        self.libc = ctypes.CDLL(None, use_errno=True)
        self.fd = self.libc.inotify_init1(os.O_NONBLOCK | os.O_CLOEXEC)
        if self.fd < 0:
            raise OSError(ctypes.get_errno(), 'inotify unavailable')
        self.labels = {}; self.names = tuple(paths)
        try:
            for label, path in paths.items():
                wd = self.libc.inotify_add_watch(self.fd, os.fsencode(path), self.OPEN_ACCESS)
                if wd < 0:
                    raise OSError(ctypes.get_errno(), 'business file cannot be watched')
                self.labels[wd] = label
        except Exception:
            self.close(); raise

    def drain(self):
        counts = dict.fromkeys(self.names, 0)
        while True:
            try:
                raw = os.read(self.fd, 65536)
            except BlockingIOError:
                break
            if not raw:
                break
            position = 0
            while position < len(raw):
                wd, mask, _, length = struct.unpack_from('iIII', raw, position)
                position += 16 + length
                if mask & (0x4000 | 0x8000):
                    raise ValueError('File watcher overflowed or lost its target')
                if mask & self.OPEN_ACCESS and wd in self.labels:
                    counts[self.labels[wd]] += 1
        return counts

    def close(self):
        if self.fd >= 0:
            os.close(self.fd); self.fd = -1


def snapshot_files(directory, pattern='*.json'):
    return {path.name: digest(path.read_bytes()) for path in sorted(Path(directory).glob(pattern)) if path.is_file()}


def worker(payload):
    import httpx
    import runtime_cli
    from obs_poc.config import Settings
    from dinum_access.user_tokens import UserTokens
    runtime_cli.require_demo()
    if os.getenv('RIE_LOAD_QUALIFICATION') == 'true' or os.getenv('VICTORIAMETRICS_URL') != 'http://victoriametrics:8428':
        raise ValueError('Use the dedicated non-load synthetic instance')
    passwords = payload.get('passwords', {})
    if set(passwords) != set(ACCOUNTS) or any(not isinstance(value, str) or not value for value in passwords.values()):
        raise ValueError('The two synthetic account credentials are required through stdin')
    settings = Settings(); gate = runtime_cli.configured_gate()
    if gate.config.get('allow_webui_assertions') is not False or gate.config.get('ldap', {}).get('host') != 'ldap':
        raise ValueError('Only the synthetic server-owned identity boundary is allowed')
    baseline = gate.store.read(); targets = (settings.logs_index, settings.docs_index, *SOURCES)
    if any(baseline.get(PolicyEdits.collection(target), {}).get(target) != 'internal' for target in targets):
        raise ValueError('Start with the four UC2 rules explicitly reserved to internal users')
    store = UserTokens(gate.config['user_tokens_directory'])
    tokens_before = snapshot_files(store.directory)
    audit_path = gate.store.audit_directory / 'audit.jsonl'
    audit_before = audit_path.read_bytes() if audit_path.exists() else b''
    report = {'started_at': now(), 'kind': 'native-uc2-source-acl', 'synthetic': True,
              'actual_http_backends': True, 'actual_ldap': True, 'actual_albert_calls': 0,
              'checks': {}, 'probes': [], 'passed': False, 'policy_revision_before': baseline['revision'],
              'observation': 'Linux inotify on shared business files; OpenSearch search query counters',
              'limitations': ['No claim about an unobserved backend outside this isolated fixture.']}
    edits = None; watcher = None

    def mark(name, passed):
        report['checks'][name] = bool(passed)
        if not passed:
            raise ValueError('A native UC2 source expectation failed: ' + name)

    try:
        watcher = FileReads({'manifest': settings.manifest_path, 'metric_mapping': settings.metric_mapping,
                             'tickets': settings.itsm_snapshot})
        with runtime_cli.acting(ACCOUNTS[0]) as (operator_gate, principal):
            edits = PolicyEdits(operator_gate.store, principal)
            with runtime_cli.individual_token(ACCOUNTS[0]) as (internal, _, _), \
                 runtime_cli.individual_token(ACCOUNTS[1]) as (external, _, _), \
                 httpx.Client(timeout=180, trust_env=False, follow_redirects=False) as client:
                session_internal = operator_gate.login(ACCOUNTS[0], passwords[ACCOUNTS[0]])
                session_external = operator_gate.login(ACCOUNTS[1], passwords[ACCOUNTS[1]])

                def searches():
                    response = client.get('http://opensearch:9200/_nodes/stats/indices/search')
                    response.raise_for_status()
                    return sum(row['indices']['search']['query_total'] for row in response.json()['nodes'].values())

                def probe(name, path, token=internal, *, diagnose=False, denied=False):
                    before_reports = snapshot_files(settings.reports)
                    watcher.drain(); before_queries = searches()
                    headers = {'Authorization': 'Bearer ' + token}
                    response = (client.post('http://incidents:9950/diagnose', headers=headers, json=BODY)
                                if diagnose else client.get('http://incidents:9950' + path, headers=headers))
                    reads = watcher.drain(); query_delta = searches() - before_queries
                    value = response.json() if 'application/json' in response.headers.get('content-type', '') else {}
                    receipt = {'name': name, 'http_status': response.status_code, 'status': value.get('status'),
                               'ready': value.get('ready'), 'request_id': value.get('request_id'),
                               'has_evidence': any(value.get(key) for key in EVIDENCE),
                               'metric_count': len(value.get('metrics', [])),
                               'has_generation': bool(value.get('usage')) or value.get('analysis') is not None,
                               'file_read_events': reads, 'opensearch_queries': query_delta,
                               'new_report_files': len(set(snapshot_files(settings.reports)) - set(before_reports))}
                    report['probes'].append(receipt)
                    if denied:
                        mark(name + '_refused', response.status_code == (200 if diagnose else 403)
                             and (value.get('status') == 'denied' if diagnose else value.get('error') == 'access_denied'))
                        mark(name + '_no_evidence', not receipt['has_evidence'] and not receipt['has_generation'])
                        mark(name + '_before_business_reads', not any(reads.values()) and query_delta == 0)
                        mark(name + '_no_report_persisted', before_reports == snapshot_files(settings.reports))
                    elif diagnose:
                        mark(name + '_complete', response.status_code == 200 and value.get('status') == 'ok'
                             and receipt['metric_count'] == 5 and not value.get('errors')
                             and (value.get('logs') or {}).get('total') == 120 and not receipt['has_generation'])
                    else:
                        mark(name + '_readable', response.status_code == 200)
                        if path == '/status':
                            mark(name + '_initialized', value.get('status') == 'ready' and bool(value.get('hosts')))
                        elif path == '/readiness':
                            mark(name + '_ready', value.get('ready') is True and bool(value.get('services')))
                        elif path.startswith('/demo-itsm/tickets/'):
                            mark(name + '_actual_ticket', 'ITSM-001' in response.text and 'Données fictives' in response.text)
                    return receipt

                baseline_probe = probe('baseline_internal_diagnosis', '', diagnose=True)
                mark('file_watchers_observe_all_real_readers', all(baseline_probe['file_read_events'].values()))
                mark('opensearch_counter_observes_real_searches', baseline_probe['opensearch_queries'] >= 2)
                for path in ('/status', '/readiness', '/demo-itsm/tickets/ITSM-001'):
                    label = path.strip('/').replace('/', '_')
                    probe('baseline_internal_' + label, path)
                    probe('baseline_external_' + label, path, external, denied=True)
                probe('baseline_external_diagnosis', '', external, diagnose=True, denied=True)
                probe('short_session_internal', '/status', session_internal)
                probe('short_session_external', '/status', session_external, denied=True)
                specific = {settings.logs_index: '/logs?equipment=OBS-RTR-01&start=2026-09-28T08%3A00%3A00Z&end=2026-09-28T10%3A00%3A00Z',
                            settings.docs_index: '/documents/DOC-001', 'incidents.tickets': '/demo-itsm/tickets/ITSM-001'}
                for target in targets:
                    edits.set(target, 'blocked')
                    label = target.replace('.', '_').replace('-', '_')
                    probe(label + '_status', '/status', denied=True)
                    probe(label + '_readiness', '/readiness', denied=True)
                    probe(label + '_diagnosis', '', diagnose=True, denied=True)
                    if target in specific:
                        probe(label + '_reader', specific[target], denied=True)
                    edits.restore_target(target)
                    probe(label + '_restored', '', diagnose=True)
                edits.set('incidents.tickets', 'authenticated')
                probe('external_ticket_explicitly_opened', '/demo-itsm/tickets/ITSM-001', external)
                probe('external_ticket_only_diagnosis_still_refused', '', external, diagnose=True, denied=True)
                probe('external_ticket_only_logs_still_refused', specific[settings.logs_index], external, denied=True)
                probe('external_ticket_only_docs_still_refused', specific[settings.docs_index], external, denied=True)
                probe('external_ticket_only_readiness_still_refused', '/readiness', external, denied=True)
                # There is no standalone metric HTTP endpoint. In addition to
                # full HTTP refusal, exercise the actual protected reader with
                # a real external LDAP principal; no adapter/service double.
                from obs_poc.clients import Sources as ActualSources, SourceError
                watcher.drain(); before_queries = searches(); refused = False
                with runtime_cli.acting(ACCOUNTS[1], internal=False):
                    metrics = ActualSources(settings)
                    try:
                        metrics.measurements({}, 'cpu', BODY['start'], BODY['end'])
                    except SourceError as error:
                        refused = (error.source, error.code) == ('authorization', 'resource_forbidden')
                    finally:
                        metrics.close()
                mark('external_ticket_only_metrics_reader_refused', refused)
                mark('external_ticket_only_metrics_before_reads', not any(watcher.drain().values()) and searches() == before_queries)
                edits.restore_target('incidents.tickets')
                probe('external_ticket_closed_again', '/demo-itsm/tickets/ITSM-001', external, denied=True)
                mark('all_other_rule_contents_preserved', bool(edits.changes))
    except Exception as error:
        report['error_code'] = type(error).__name__
    finally:
        if edits is not None:
            report['restoration_failures'] = edits.restore_all()
            report['policy_changes'] = edits.changes
        if watcher is not None:
            watcher.close()
        after = gate.store.read()
        audit_after = audit_path.read_bytes() if audit_path.exists() else b''
        report['checks']['policy_contents_restored'] = contents(after) == contents(baseline)
        report['checks']['policy_revision_increased'] = after['revision'] > baseline['revision']
        report['checks']['all_temporary_records_removed_other_credentials_unchanged'] = snapshot_files(store.directory) == tokens_before
        report['checks']['audit_prefix_preserved_and_growing'] = audit_after.startswith(audit_before) and len(audit_after) > len(audit_before)
        new_events = [json.loads(line) for line in audit_after[len(audit_before):].splitlines() if line]
        report['checks']['temporary_revocations_audited'] = sum(row.get('operation') == 'revoke_temporary_user_token' for row in new_events) == 2
        denied_ids = [row['request_id'] for row in report['probes'] if row['status'] == 'denied']
        report['checks']['denied_diagnostics_have_fresh_identifiers'] = bool(denied_ids) and len(denied_ids) == len(set(denied_ids))
        report.update(policy_revision_after=after['revision'], token_records_before=len(tokens_before),
                      token_records_after=len(snapshot_files(store.directory)), audit_bytes_before=len(audit_before),
                      audit_bytes_after=len(audit_after), finished_at=now())
        report['passed'] = bool(report['checks']) and all(report['checks'].values()) and not report.get('error_code') and not report.get('restoration_failures')
    return report


def load_manager(source_root):
    spec = importlib.util.spec_from_file_location('uc2_sources_manage', source_root / 'deploy/ubuntu/manage.py')
    manager = importlib.util.module_from_spec(spec); spec.loader.exec_module(manager)
    return manager


def host(instance, output, source_root=None):
    source_root = Path(source_root).resolve() if source_root else Path(__file__).resolve().parents[2]
    manager = load_manager(source_root)
    instance = Path(instance).expanduser().resolve(); output = Path(output).expanduser().resolve()
    values = manager.load(instance); manager.guard(instance, values)
    if values['RIE_MODE'] != 'demo' or values.get('RIE_LOAD_QUALIFICATION') == 'true':
        raise ValueError('Use the isolated non-load synthetic instance')
    if output.exists() or output.is_relative_to(manager.ROOT):
        raise ValueError('Choose a new private result directory outside sources')
    accounts = json.loads((instance / 'ldap-fixture/private/accounts.json').read_text())
    passwords = {row['uid']: row['password'] for row in accounts['users'] if row['uid'] in ACCOUNTS}
    if set(passwords) != set(ACCOUNTS):
        raise ValueError('The two existing synthetic accounts are required')
    output.mkdir(parents=True, mode=0o700)
    source = Path(__file__).read_text()
    code = 'exec(compile(' + repr(source) + ',"/delivery/qualification_uc2_sources.py","exec"), {"__name__":"__main__","__file__":"/delivery/qualification_uc2_sources.py"})'
    result = manager.tool(instance, values, 'python', '-c', code, 'worker', capture=True,
                          input_text=json.dumps({'passwords': passwords}))
    report = json.loads(result.stdout)
    manifest_path = source_root / 'DELIVERY-MANIFEST.json'
    report['provenance'] = {'tool_sha256': digest(source.encode()), 'injected_public_probe': True,
                            'business_image_changed': False, 'source_root': str(source_root),
                            'delivery_manifest_sha256': digest(manifest_path.read_bytes()) if manifest_path.is_file() else None}
    destination = output / 'report.json'; destination.write_text(json.dumps(report, indent=2) + '\n'); destination.chmod(0o600)
    print(json.dumps({'passed': report['passed'], 'checks': len(report['checks']), 'report': str(destination)}), flush=True)
    return 0 if report['passed'] else 2


def main():
    os.umask(0o077)
    if len(sys.argv) > 1 and sys.argv[1] == 'worker':
        try:
            report = worker(json.load(sys.stdin))
        except Exception as error:
            report = {'passed': False, 'error_code': type(error).__name__, 'checks': {}}
        print(json.dumps(report), flush=True)
        return 0
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('instance', type=Path); parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--source-root', type=Path)
    args = parser.parse_args()
    try:
        return host(args.instance, args.output, args.source_root)
    except Exception as error:
        print(json.dumps({'passed': False, 'error_code': type(error).__name__}), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
