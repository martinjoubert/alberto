# Modèles de raccordement externe — à adapter avant utilisation

Ces fichiers publics décrivent les formats attendus, sans identité, source ou
secret réel. **Ils ne sont pas une configuration prête à déployer.** Le champ
`requires_operator_configuration`, les valeurs `REPLACE_...`, les noms
`replace-...`, les tableaux vides et les visibilités `blocked` imposent une
revue explicite. Ne retirer un marqueur qu'après avoir rempli et relu sa partie.
Ne jamais remplacer un fichier d'une instance déjà initialisée par ces modèles.

Ces modèles configurent **le PoC et ses raccordements aux services existants**.
En particulier, `pdl.json` devient `config/pdl.yaml`, lu par le moteur PDL
pour ses accès OpenSearch, ses recherches et Albert. Ce fichier est propre au
projet ; le fichier natif du serveur OpenSearch est `opensearch.yml`, sous la
responsabilité de son administrateur.

De même, `access.json` devient `config/access.json` : c’est la configuration
du composant d’identité et d’accès partagé par les deux UC du PoC. Son objet
`ldap` indique comment interroger l’annuaire existant et interpréter les groupes.
Ce n’est pas un fichier standard de configuration d’un serveur LDAP ; il ne
crée ni utilisateurs ni groupes dans l’annuaire.

| Modèle public | Destination dans une instance externe neuve | Revue attendue |
| --- | --- | --- |
| `pdl.json` | `config/pdl.yaml` (JSON est un sous-ensemble YAML) | Motifs d'index limités, sources, TLS et limites |
| `access.json` | `config/access.json` | LDAP, CA, DN lecteur, attributs et groupes ; conserver les chemins `/data` |
| `policy.json` | `access/policy.json` | Index physiques, plus `incidents.metrics` et `incidents.tickets` ; absence = refus |
| `incidents-corpus.json` | `config/incidents-corpus.json` | Inventaire admis, fenêtre de contrôle ISO, champs OpenSearch, provenance et cadences |
| `metric-mapping.json` | `config/metric-mapping.json` | Noms de séries, labels communs ou par métrique, échelles ; cibles CPU/pertes/entrées/sorties en %, latence en ms |
| `itsm-tickets.json` | `config/itsm-tickets.json` | Snapshot complet au format compatible, jamais présenté comme une API SI connectée |
| `itsm-history.json` | `config/itsm-history.json` via `configure-itsm-history` | Historique API ITSM-NG 1.6.17 facultatif, URL HTTPS et credentials individuels ; voir la fiche 15 |
| `mappings.yaml` | `config/mappings.yaml` | Correspondance concepts/champs de l'inventaire PDL, revue puis approbation séparées |

Le premier catalogue PDL n'est pas actif : `refresh`, `validate-mappings`,
`load-mappings`, inspection puis approbation d'une revue exacte sont nécessaires.
Le modèle minimal de mapping ne couvre qu'un index ; ne pas inventer une relation
entre champs de même type. Le fichier historique
`deploy/ubuntu/examples/pdl-demo-mappings.yaml` illustre les quatre familles fictives ;
ce n'est pas un modèle de production à approuver tel quel.

Le manifeste Incidents utilise `hosts` avec `equipment`, `aliases`, `scope`,
`allowed`, `hostid` et `interface`. Les labels doivent correspondre aux séries
et documents. Après vérification de l'inventaire et de la provenance, remplacer
`status` par `ready` ; ce libellé ne remplace pas les sondes réelles de `check`.
Ne rendre `allowed: true` que les équipements retenus par le responsable.
Ce périmètre ne crée pas une ACL par équipement : la première livraison applique
les droits par index et par source UC2.

Renseigner `anchor_date` au format `YYYY-MM-DD`, `timezone` (par exemple
`Europe/Paris`) et `start/end` en ISO avec décalage. Cette fenêtre positive de
sept jours maximum sert aux sondes de disponibilité : choisir une période avec
des observations connues. Ce n'est pas une restriction de toutes les recherches.
Le démarrage externe refuse ces champs manquants ou mal formés.

`interval_seconds` est la cadence attendue par défaut, entre 0,001 et 86 400
secondes. `metric_intervals_seconds` permet une cadence par métrique ; le même
objet dans un équipement prime sur le défaut global. La couverture de la fenêtre
principale et celle de comparaison utilisent la cadence effective.

Les champs de logs et documents peuvent être adaptés dans `source_fields`.
Par exemple, `"logs": {"equipment": {"source": "host.name", "query":
"host.name.keyword"}, "@timestamp": "event.created"}` permet de filtrer sur
un champ exact tout en lisant la valeur dans `_source`. Les champs omis gardent
leurs noms actuels. Les formats complets et les limites sont décrits dans
`docs/si-rie/reference/05-incidents.md`.

Dans le mapping métrique, `metrics.cpu.bindings` illustre une sélection sans
interface. Les bindings d'une métrique remplacent les bindings communs ; ses
labels fixes complètent ou remplacent les labels fixes communs. Une série unique
doit être identifiée pour chaque équipement/métrique. Une conversion scalaire
ne remplace pas un calcul de débit, de `rate`, une agrégation de CPU par cœur ou
une conversion d'octets en pourcentage : fournir une jauge normalisée et validée
en amont. Aucun DSL libre n'est exécuté. Vérifier les cinq métriques et leurs
unités avec des exports de référence avant de conclure au raccordement réel.

Le lecteur de tickets attend `simulator: ITSM-NG`, `complete: true` et une liste
`tickets`. Un export relu peut produire une liste vide seulement s'il est
réellement complet pour la période/inventaire annoncés. Chaque ticket utilise
un identifiant local unique `ITSM-001`, un `equipment` du manifeste, `title`,
`alert_started_at` ISO avec fuseau et éventuellement `alert_resolved_at`.
Les champs `status`, `created_at`, `closed_at`, `assignment` et `handling`
(historiques `{at,actor,text}`) conservent la chronologie administrative.
Conserver l'identifiant SI original dans un champ de provenance si nécessaire.
La résolution technique et la clôture administrative sont deux dates distinctes.
La chronologie reste un snapshot ; ne pas le renommer pour faire croire à une
connexion en direct. Le connecteur historique facultatif a sa propre
configuration, son authentification individuelle et sa recette dans
`docs/si-rie/reference/15-itsm-precedents.md`. Il n'active pas une synchronisation des
alertes en cours ni une API d'écriture de tickets.

Les secrets se renseignent séparément dans `secrets/`, avec les modes privés
conservés. Les clés de signature générées par `prepare` ne sont pas à remplacer
par celles d'un autre environnement. La procédure ordonnée et les paramètres
`.env` sont dans `docs/si-rie/reference/02-configuration.md` du paquet remis.

## Matrice de qualification conversationnelle

`openwebui-stability.json` contient les questions et résultats attendus du
laboratoire pour PDL et Incidents : trois fils de dix messages, trois répétitions
et six demandes au mauvais profil Open WebUI. Ce n’est pas un fichier de
configuration du serveur. Il vise uniquement les corpus fictifs datés des
tutoriels, avec Alice et les deux profils Open WebUI de qualification.
Le parcours, les preuves et la consommation réelle d’Albert sont décrits dans
`docs/si-rie/reference/13-test-reports.md`. Ces essais ne se lancent pas au déploiement.
