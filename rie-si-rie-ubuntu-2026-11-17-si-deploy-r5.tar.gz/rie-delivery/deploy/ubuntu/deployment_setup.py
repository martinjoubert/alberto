"""Offline connection preparation shared by NiceGUI and the host operator.

Only submitted values and allowlisted files are processed. No source, instance,
credential store or network is read by the form. Export never includes secrets.
"""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import ssl
import sys
import tempfile
from urllib.parse import urlsplit
import zipfile

HERE = Path(__file__).resolve().parent
MAX_FILE_BYTES = 1024 * 1024
MAX_TOTAL_BYTES = 8 * MAX_FILE_BYTES
VISIBILITIES = {'blocked': 'Interdit', 'internal': 'Internes', 'authenticated': 'Utilisateurs authentifiés'}
# section, key, label, default, explanation. Empty values are never sandbox defaults.
FIELDS = (
 ('Coordination', 'environment', 'Environnement cible', '', 'Nom du SI et de l’environnement ; aucune valeur de laboratoire préremplie.'),
 ('Coordination', 'contact', 'Responsable du raccordement', '', 'Contact chargé de faire confirmer les valeurs par les propriétaires des sources.'),
 ('Coordination', 'admin_login', 'Administrateur LDAP du PoC', '', 'Identifiant réel habilité ; aucun mot de passe utilisateur dans cet assistant.'),
 ('Images', 'runtime_image', 'Image PDL / Incidents / opérateur', '', 'Référence approuvée de la registry avec @sha256: et son digest complet.'),
 ('Images', 'portal_image', 'Image NiceGUI', '', 'Image approuvée de la même livraison, avec @sha256: et digest complet.'),
 ('LDAP', 'ldap_host', 'Serveur LDAP', '', 'DNS couvert par le certificat, sans ldaps:// ni numéro de port.'),
 ('LDAP', 'ldap_port', 'Port LDAPS', '636', 'Connexion TLS vérifiée ; la CA se dépose dans la section Fichiers.'),
 ('LDAP', 'reader_dn', 'DN du lecteur LDAP', '', 'Compte de service en lecture ; exemple de syntaxe : cn=reader,ou=services,dc=organisation,dc=fr.'),
 ('LDAP', 'search_base', 'Base de recherche LDAP', '', 'DN de la branche contenant les utilisateurs.'),
 ('LDAP', 'username_attribute', 'Attribut identifiant', 'uid', 'À confirmer avec l’administrateur LDAP.'),
 ('LDAP', 'mail_attribute', 'Attribut courriel', 'mail', 'Attribut du courriel individuel.'),
 ('LDAP', 'groups_attribute', 'Attribut groupes', 'memberOf', 'Groupes directs ; pas de développement automatique des groupes imbriqués.'),
 ('LDAP', 'subject_attribute', 'Attribut sujet stable', 'entryUUID', 'Identifiant LDAP stable et distinct du login.'),
 ('LDAP', 'internal_group', 'DN du groupe interne', '', 'Les comptes dans aucun groupe ou dans les deux groupes sont refusés.'),
 ('LDAP', 'external_group', 'DN du groupe externe', '', 'Groupe de classification externe, distinct du groupe interne.'),
 ('LDAP', 'admin_groups', 'DN des groupes administrateurs', '', 'Un DN par ligne ; distincts des deux groupes de classification.'),
 ('Sources', 'opensearch_url', 'URL HTTPS OpenSearch', '', 'URL sans identifiant, mot de passe ou paramètre de requête.'),
 ('Sources', 'opensearch_user', 'Lecteur OpenSearch', '', 'Compte technique lecteur ; peut rester vide selon le mécanisme du SI.'),
 ('Sources', 'pdl_indices', 'Index physiques PDL', '', 'Un nom exact par ligne. Aucun index fictif ou joker ajouté automatiquement.'),
 ('Sources', 'logs_index', 'Index des logs Incidents', '', 'Nom exact confirmé par le responsable de la source.'),
 ('Sources', 'docs_index', 'Index documentaire Incidents', '', 'Nom exact des procédures et retours d’expérience.'),
 ('Sources', 'victoria_url', 'URL HTTPS VictoriaMetrics', '', 'Endpoint lecteur approuvé.'),
 ('Albert', 'albert_url', 'URL HTTPS Albert', '', 'Endpoint approuvé, par exemple la base /v1 ; aucune clé dans l’URL.'),
 ('Albert', 'albert_model', 'Modèle PDL et rédaction Incidents', 'gemma-4-31b-it', 'Confirmer disponibilité et quota auprès du fournisseur.'),
 ('Albert', 'dialogue_model', 'Modèle de dialogue Incidents', 'gpt-oss-120b', 'Interprétation des demandes ; aucun appel IA depuis cet assistant.'),
 ('Albert', 'review_model', 'Modèle de relecture Incidents', 'gpt-oss-120b', 'Relecture factuelle, à qualifier avec les données autorisées.'),
 ('Open WebUI', 'oauth_issuer', 'Origine HTTPS de l’émetteur OAuth', '', 'Origine sans chemin ni barre finale ; les trois champs suivants vont ensemble.'),
 ('Open WebUI', 'pdl_resource', 'URL HTTPS MCP PDL', '', 'URL publique exacte terminée par /mcp.'),
 ('Open WebUI', 'incidents_resource', 'URL HTTPS MCP Incidents', '', 'URL publique exacte terminée par /gptoss/assistant/mcp.'),
 ('Open WebUI', 'callbacks', 'Callbacks Open WebUI autorisés', '', 'Une URL exacte par ligne ; HTTP accepté seulement sur localhost, 127.0.0.1 ou ::1.'),
)
POLICY_FIELDS = (
 ('pdl_visibility', 'Index PDL'), ('logs_visibility', 'Logs Incidents'),
 ('docs_visibility', 'Documents Incidents'), ('metrics_visibility', 'Mesures VictoriaMetrics'),
 ('tickets_visibility', 'Tickets Incidents'),
)
UPLOADS = {
 'ldap-ca.crt': 'CA LDAP au format PEM',
 'ca-sources.pem': 'Bundle des CA sources et Albert (facultatif si confiance système)',
 'incidents-corpus.json': 'Inventaire, périmètres et fenêtre de référence Incidents',
 'metric-mapping.json': 'Contrat des cinq mesures, labels et unités',
 'itsm-tickets.json': 'Snapshot autorisé des alertes et traitements courants',
}
REQUIRED_FILES = set(UPLOADS) - {'ca-sources.pem'}
SECRET_KEYS = {'password', 'user_token', 'app_token', 'albert_key', 'private_key', 'authorization', 'api_key'}
SECRET_PATTERN = re.compile(r'-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:glpat-|ghp_|github_pat_|sk-proj-)[A-Za-z0-9_-]{16,}|Bearer [A-Za-z0-9_-]{30,}')


class PreparationError(ValueError):
    """Bounded field errors only; submitted values never enter exception text."""
    def __init__(self, issues):
        self.issues = list(issues)[:100]
        super().__init__('Le dossier de raccordement doit être corrigé.')


def defaults():
    return {**{key: value for _, key, _, value, _ in FIELDS},
            **{key: 'blocked' for key, _ in POLICY_FIELDS}}


def _json(data):
    return (json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()


def values_checked(values):
    if not isinstance(values, dict) or set(values) != set(defaults()):
        raise PreparationError(['Formulaire : version ou champs inconnus.'])
    result = {}
    for key, value in values.items():
        if (not isinstance(value, str) or len(value) > 8192 or '\r' in value
                or any(ord(c) < 32 and c != '\n' for c in value) or SECRET_PATTERN.search(value)):
            raise PreparationError(['Formulaire : valeur invalide ou secret détecté.'])
        result[key] = value.strip()
    return result


def _no_secrets(value):
    if isinstance(value, dict):
        if any(str(key).lower() in SECRET_KEYS for key in value):
            raise PreparationError(['Fichier : les credentials doivent être remis séparément.'])
        for item in value.values(): _no_secrets(item)
    elif isinstance(value, list):
        for item in value: _no_secrets(item)
    elif isinstance(value, str) and SECRET_PATTERN.search(value):
        raise PreparationError(['Fichier : secret ou clé privée refusé.'])


def uploaded(name, raw):
    if name not in UPLOADS or not isinstance(raw, bytes) or not 0 < len(raw) <= MAX_FILE_BYTES:
        raise PreparationError(['Fichier : nom, format ou taille non autorisés (maximum 1 Mio).'])
    try:
        text = raw.decode('utf-8')
        if SECRET_PATTERN.search(text):
            raise PreparationError(['Fichier : secret ou clé privée refusé.'])
        if name.endswith('.json'):
            value = json.loads(text, parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
            if not isinstance(value, dict):raise ValueError()
            _no_secrets(value)
            return _json(value)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.load_verify_locations(cadata=text)
        return raw
    except (UnicodeError, ValueError, RecursionError, ssl.SSLError):
        raise PreparationError([UPLOADS[name] + ' : contenu invalide ou non autorisé.']) from None


def _contracts():
    # The container already has obs_poc; host commands need only this stdlib module.
    path = HERE/'../app/incidents/obs_poc/contracts.py'
    if not path.is_file():
        path = HERE.parents[1]/'use-cases/incidents/observability-demo/obs_poc/contracts.py'
    if not path.is_file():
        from obs_poc import contracts
        return contracts
    spec = importlib.util.spec_from_file_location('deployment_incident_contracts', path)
    result = importlib.util.module_from_spec(spec);spec.loader.exec_module(result)
    return result


def _template(name):
    return json.loads((HERE/'examples'/name).read_text())


def _url(value, *, callback=False):
    try:
        parsed = urlsplit(value)
        return (bool(parsed.hostname) and parsed.port != 0 and not parsed.hostname.endswith(('.invalid', '.example'))
                and not any(c.isspace() for c in value) and not parsed.username and not parsed.password
                and not parsed.query and not parsed.fragment
                and (parsed.scheme == 'https' or callback and parsed.scheme == 'http' and parsed.hostname in {'127.0.0.1', 'localhost', '::1'}))
    except ValueError:
        return False


def _lines(value):
    return [line.strip() for line in value.splitlines() if line.strip()]


def prepare(values, files, *, reviewed=False):
    """Validate a submitted preparation; this never means live readiness."""
    v = values_checked(values);issues = []
    if reviewed is not True:issues.append('Revue : confirmer les valeurs avec les responsables des sources.')
    optional = {'opensearch_user', 'oauth_issuer', 'pdl_resource', 'incidents_resource', 'callbacks'}
    for _, key, label, _, _ in FIELDS:
        if key not in optional and not v[key]:issues.append(label + ' : valeur à fournir.')
    for key in ('opensearch_url', 'victoria_url', 'albert_url'):
        if not _url(v[key]):issues.append(key + ' : URL HTTPS sans credential attendue.')
    for key in ('runtime_image', 'portal_image'):
        if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_./:-]*@sha256:[a-f0-9]{64}', v[key]):
            issues.append(key + ' : image approuvée avec digest SHA-256 complet attendue.')
    if not re.fullmatch(r'[A-Za-z0-9.-]+', v['ldap_host']) or v['ldap_host'].endswith(('.invalid', '.example')):
        issues.append('Serveur LDAP : DNS réel sans schéma ni port attendu.')
    if not v['ldap_port'].isdigit() or len(v['ldap_port']) > 5 or not 1 <= int(v['ldap_port']) <= 65535:
        issues.append('Port LDAP : entier entre 1 et 65535 attendu.')
    groups = [v['internal_group'], v['external_group'], *_lines(v['admin_groups'])]
    if len(groups) < 3 or len(groups) > 34 or len(set(item.casefold() for item in groups)) != len(groups):
        issues.append('Groupes LDAP : internes, externes et administrateurs doivent être distincts.')
    for value in [v['reader_dn'], v['search_base'], *groups]:
        if not re.match(r'^[A-Za-z][A-Za-z0-9;-]*=.', value) or '\n' in value or len(value) > 2048:
            issues.append('LDAP : DN incomplet ; faire confirmer la syntaxe par le responsable LDAP.');break
    for key in ('username_attribute', 'mail_attribute', 'groups_attribute', 'subject_attribute'):
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9;-]{0,127}', v[key]):issues.append(key + ' : nom d’attribut LDAP invalide.')
    for key in ('albert_model', 'dialogue_model', 'review_model'):
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,127}', v[key]):issues.append(key + ' : identifiant de modèle invalide.')
    indices = _lines(v['pdl_indices'])
    if not 1 <= len(indices) <= 20 or len(set(indices)) != len(indices):issues.append('PDL : fournir de 1 à 20 index exacts distincts.')
    for index in [*indices, v['logs_index'], v['docs_index']]:
        if not re.fullmatch(r'[a-z0-9][a-z0-9_.-]{0,254}', index) or '..' in index:
            issues.append('Index : nom physique exact attendu, sans joker ni chemin.');break
    if any(v[key] not in VISIBILITIES for key, _ in POLICY_FIELDS):issues.append('ACL : choisir une des trois visibilités proposées.')
    if not isinstance(files, dict) or set(files) - set(UPLOADS):raise PreparationError(['Fichiers : liste non autorisée.'])
    if any(not isinstance(value,bytes) for value in files.values()) or sum(len(value) for value in files.values()) > MAX_TOTAL_BYTES:raise PreparationError(['Fichiers : taille totale dépassée.'])
    for name in sorted(REQUIRED_FILES - set(files)):issues.append(UPLOADS[name] + ' : fichier à fournir.')
    checked = {}
    for name, raw in files.items():
        try:checked[name] = uploaded(name, raw)
        except PreparationError as error:issues.extend(error.issues)
    contracts = _contracts()
    try:
        if 'incidents-corpus.json' in checked:
            corpus = contracts.validate_manifest(json.loads(checked['incidents-corpus.json']))
            if 'requires_operator_configuration' in corpus:raise ValueError()
            if 'metric-mapping.json' in checked:
                metrics = json.loads(checked['metric-mapping.json']);contracts.validate_metric_mapping(metrics, corpus['hosts'])
                if 'requires_operator_configuration' in metrics:raise ValueError()
    except (ValueError, TypeError, KeyError, AttributeError):issues.append('Incidents : inventaire, fenêtre, champs ou contrat des cinq mesures incompatibles ; revoir les fichiers de référence.')
    if 'itsm-tickets.json' in checked:
        tickets = json.loads(checked['itsm-tickets.json'])
        if (tickets.get('simulator') != 'ITSM-NG' or tickets.get('schema') != 'dinum-demo-ticket-v1'
                or tickets.get('complete') is not True or not isinstance(tickets.get('tickets'), list)
                or not isinstance(tickets.get('provenance'), str) or not tickets['provenance'].strip()
                or 'requires_operator_configuration' in tickets):
            issues.append('Alertes : snapshot complet, provenance et contrat dinum-demo-ticket-v1 attendus.')
    # Match the host .env writer, which intentionally does not evaluate shell syntax.
    env = {'OPENSEARCH_URL': v['opensearch_url'], 'OPENSEARCH_USER': v['opensearch_user'],
           'VICTORIAMETRICS_URL': v['victoria_url'], 'ALBERT_URL': v['albert_url'],
           'ALBERT_MODEL': v['albert_model'], 'OBS_MODEL_GPTOSS': v['albert_model'],
           'OBS_DIALOGUE_MODEL': v['dialogue_model'], 'OBS_REVIEW_MODEL': v['review_model'],
           'INCIDENTS_LOGS_INDEX': v['logs_index'], 'INCIDENTS_DOCS_INDEX': v['docs_index'],
           'RIE_IMAGE': v['runtime_image'], 'RIE_PORTAL_IMAGE': v['portal_image'],
           'SOURCE_CA_FILE': '/data/config/ca-sources.pem' if 'ca-sources.pem' in checked else '',
           'INCIDENTS_MANIFEST': '/data/config/incidents-corpus.json'}
    if any(not re.fullmatch(r'[A-Za-z0-9_./:@+,-]*', value) for value in env.values()):issues.append('Configuration : caractères non pris en charge dans une valeur .env.')
    policy_indices = {}
    for names, visibility in [(indices, 'pdl_visibility'), ([v['logs_index']], 'logs_visibility'), ([v['docs_index']], 'docs_visibility')]:
        for name in names:
            if name in policy_indices and policy_indices[name] != v[visibility]:issues.append('ACL : un même index ne peut pas recevoir deux visibilités différentes.')
            policy_indices[name] = v[visibility]
    if issues:raise PreparationError(issues)
    pdl = _template('pdl.json');pdl.pop('requires_operator_configuration');pdl['discovery']['allowed_index_patterns'] = indices;pdl['discovery']['required_index_patterns'] = indices
    access = _template('access.json');access.pop('requires_operator_configuration');ldap = access['ldap']
    ldap.update(host=v['ldap_host'], port=int(v['ldap_port']), app_dn=v['reader_dn'], search_base=v['search_base'],
                attribute_for_username=v['username_attribute'], attribute_for_mail=v['mail_attribute'],
                attribute_for_groups=v['groups_attribute'], attribute_for_subject=v['subject_attribute'],
                group_dns={'internal': v['internal_group'], 'external': v['external_group']}, administrator_group_dns=_lines(v['admin_groups']))
    policy = {'version': 1, 'revision': 1, 'default': 'blocked', 'indices': policy_indices,
              'resources': {'incidents.metrics': v['metrics_visibility'], 'incidents.tickets': v['tickets_visibility']}}
    output = {'config/pdl.yaml': _json(pdl), 'config/access.json': _json(access), 'access/policy.json': _json(policy),
              **{'config/'+name: raw for name, raw in checked.items()}}
    oauth = ('oauth_issuer', 'pdl_resource', 'incidents_resource', 'callbacks')
    if any(v[key] for key in oauth):
        data = _template('oauth.json');data.update(issuer=v['oauth_issuer'], resources={'pdl': v['pdl_resource'], 'incidents': v['incidents_resource']}, redirect_uris=_lines(v['callbacks']))
        try:
            if not all(v[key] for key in oauth) or not all(_url(v[key]) for key in oauth[:3]):raise ValueError()
            # Reuse exactly the OAuth contract used at deployment, including callbacks.
            try:
                from dinum_access.oauth_store import configuration
            except ModuleNotFoundError:
                sys.path.insert(0,str(HERE.parents[1]/'core/access-control/src'))
                try:from dinum_access.oauth_store import configuration
                finally:sys.path.pop(0)
            with tempfile.TemporaryDirectory(prefix='rie-oauth-prepare-') as folder:
                path=Path(folder).resolve()/'oauth.json';path.write_bytes(_json(data));path.chmod(0o600);configuration(path)
        except (ValueError, OSError):raise PreparationError(['Open WebUI : vérifier origine, ressources MCP et callbacks exacts.']) from None
        output['config/oauth-candidate.json'] = _json(data)
    return {'values': v, 'environment': env, 'files': output, 'uploads': checked,
            'checks': ['Syntaxe et paramètres locaux contrôlés.', 'Contrats Incidents et mesures contrôlés.', 'Politique initiale à refus par défaut préparée.'],
            'remaining': ['Fournir les secrets lecteurs et la clé Albert hors assistant.', 'Lancer validate puis les contrôles de connexion du guide.', 'Confirmer les DN, droits natifs, données et quotas dans le SI.', 'Raccorder ITSM avec les identités individuelles à l’étape 9.', 'Examiner et approuver les mappings PDL à l’étape 8.']}


def draft(values):
    return _json({'version': 1, 'values': values_checked(values)})


def read_draft(raw):
    try:
        if len(raw) > MAX_FILE_BYTES:raise ValueError()
        data = json.loads(raw)
        if set(data) != {'version', 'values'} or type(data['version']) is not int or data['version'] != 1:raise ValueError()
        return values_checked(data['values'])
    except (TypeError, ValueError, KeyError, RecursionError):
        raise PreparationError(['Brouillon : format ou version invalide ; aucun secret attendu.']) from None


def connection_sheet(result):
    v=result['values']
    sheet = '# Fiche de raccordement préparée\n\nPréparation locale validée ; aucune connexion ni génération IA exécutée.\n\n'
    for _, key, label, _, _ in FIELDS:
        sheet += '## '+label+'\n\n'+(v[key] or 'À fournir')+'\n\n'
    sheet += '## Droits initiaux\n\n'+'\n'.join(label+' : '+VISIBILITIES[v[key]] for key,label in POLICY_FIELDS)+'\n\n## À vérifier ensuite\n\n'+'\n'.join('- '+item for item in result['remaining'])+'\n'
    return sheet.encode()


def export(values, files, *, reviewed=False):
    result = prepare(values, files, reviewed=reviewed)
    contents = {**result['files'], 'connection-form.json': draft(result['values']), 'connection-sheet.md': connection_sheet(result), 'environment.json': _json(result['environment'])}
    # No arbitrary path, executable script or secret can enter the preparation ZIP.
    manifest = {name: hashlib.sha256(raw).hexdigest() for name,raw in contents.items()}
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED) as archive:
        for name,raw in sorted({**contents,'MANIFEST.json':_json({'version':1,'files':manifest})}.items()):
            entry=zipfile.ZipInfo(name);entry.external_attr=0o100600<<16;entry.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(entry,raw)
    return buffer.getvalue()


def read_bundle(raw):
    """Verify integrity and regenerate configuration instead of trusting its paths."""
    try:
        if not isinstance(raw,bytes) or len(raw)>MAX_TOTAL_BYTES:raise ValueError()
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            names=archive.namelist();infos=archive.infolist()
            allowed={'MANIFEST.json','connection-form.json','connection-sheet.md','environment.json','config/pdl.yaml','config/access.json','access/policy.json','config/oauth-candidate.json',*('config/'+name for name in UPLOADS)}
            if (len(names)!=len(set(names)) or set(names)-allowed or sum(i.file_size for i in infos)>MAX_TOTAL_BYTES
                    or any(i.file_size>MAX_FILE_BYTES or (i.external_attr>>16)&0o170000!=0o100000 for i in infos)):raise ValueError()
            contents={name:archive.read(name) for name in names};manifest=json.loads(contents.pop('MANIFEST.json'))
            if manifest.get('version')!=1 or manifest.get('files')!={name:hashlib.sha256(value).hexdigest() for name,value in contents.items()}:raise ValueError()
            values=read_draft(contents['connection-form.json']);files={name:contents['config/'+name] for name in UPLOADS if 'config/'+name in contents}
            result=prepare(values,files,reviewed=True)
            if (set(contents)!=set(result['files'])|{'connection-form.json','connection-sheet.md','environment.json'}
                    or contents.get('environment.json')!=_json(result['environment'])
                    or contents.get('connection-sheet.md')!=connection_sheet(result)
                    or any(contents.get(name)!=value for name,value in result['files'].items())):raise ValueError()
            return result
    except (OSError, ValueError, KeyError, TypeError, AttributeError, RuntimeError, RecursionError, zipfile.BadZipFile):
        raise PreparationError(['Archive : contenu, intégrité ou version invalide ; aucun fichier appliqué.']) from None
