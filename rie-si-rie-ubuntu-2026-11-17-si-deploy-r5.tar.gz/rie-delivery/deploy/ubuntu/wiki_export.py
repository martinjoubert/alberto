"""Export the public SI-RIE manual and editable diagrams, without service access.

The portable tree retains relative links; the Wiki.js tree uses a configurable
page prefix. Export never contacts a wiki, renders remotely or opens private
instance files. Only fixed public documentation formats below the chosen root
are accepted, with links checked before creating an archive.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
from urllib.parse import quote, unquote, urlsplit
import xml.etree.ElementTree as ET
import zipfile
import zlib

MODULE_PATH = Path(__file__).resolve()
ROOT = MODULE_PATH.parents[2] if len(MODULE_PATH.parents) > 2 else MODULE_PATH.parent
DEFAULT_DOCS = Path(os.getenv('RIE_DOCS_DIR', '/documentation' if MODULE_PATH.parent.name == 'delivery'
                             else str(ROOT / 'docs/si-rie')))
ALLOWED_SUFFIXES = {'.md', '.svg', '.png', '.drawio', '.mmd', '.puml'}
ALLOWED_DIRECTORIES = {'assets', 'diagrams', 'sources', 'reference'}
LINK = re.compile(r'(!?\[[^\]\n]*\]\()([^\s)]+)(\))')
PRIVATE_PATTERNS = {
    'private_key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----'),
    'provider_token': re.compile(rb'\b(?:glpat-|ghp_|github_pat_|sk-proj-)[A-Za-z0-9_-]{16,}'),
    'jwt': re.compile(rb'\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{16,}'),
    'literal_bearer': re.compile(rb'Bearer [A-Za-z0-9_-]{40,}'),
}


def _root(source_root):
    source_root = Path(source_root).absolute()
    if source_root.is_symlink() or not source_root.is_dir():
        raise ValueError('Documentation root must be a regular directory')
    return source_root.resolve()


def public_file(source_root, relative):
    """Resolve one public document/asset without following links or traversals."""
    source_root = _root(source_root)
    if not isinstance(relative, str) or not relative or '\\' in relative or any(ord(c) < 32 for c in relative):
        raise ValueError('Invalid public documentation path')
    path = PurePosixPath(relative)
    if path.is_absolute() or any(part in {'..', '.'} or part.startswith('.') for part in path.parts):
        raise ValueError('Invalid public documentation path')
    if path.suffix.lower() not in ALLOWED_SUFFIXES:
        raise ValueError('Unsupported public documentation format')
    if len(path.parts) > 1 and path.parts[0] not in ALLOWED_DIRECTORIES:
        raise ValueError('Unknown documentation directory')
    if len(path.parts) == 1 and path.suffix.lower() != '.md':
        raise ValueError('Public root files must be Markdown pages')
    result = source_root
    for part in path.parts:
        result = result / part
        if result.is_symlink():
            raise ValueError('Symlink documentation input refused')
    if not result.exists() or not stat.S_ISREG(result.stat().st_mode):
        raise ValueError('Public documentation file not found')
    if not result.resolve().is_relative_to(source_root):
        raise ValueError('Documentation path leaves the source root')
    return result


def _files(source_root):
    source_root = _root(source_root)
    names = []
    for path in sorted(source_root.rglob('*')):
        relative = path.relative_to(source_root).as_posix()
        if path.is_symlink():
            raise ValueError('Symlink documentation input refused: ' + relative)
        if path.is_file() and path.suffix.lower() in ALLOWED_SUFFIXES:
            public_file(source_root, relative)
            names.append(relative)
    if 'README.md' not in names:
        raise ValueError('The documentation index README.md is required')
    return names


def list_documents(source_root=DEFAULT_DOCS):
    """Return a small stable catalogue suitable for the NiceGUI navigation."""
    source_root = _root(source_root)
    result, identifiers = [], set()
    paths = [*source_root.glob('*.md'), *(source_root / 'reference').glob('*.md')]
    def order(path):
        relative = path.relative_to(source_root).as_posix()
        return ('0' if relative == 'README.md' else '1' if relative == 'reference/README.md' else '2', relative)
    for path in sorted(paths, key=order):
        relative = path.relative_to(source_root).as_posix()
        path = public_file(source_root, relative)
        text = path.read_text(encoding='utf-8')
        heading = re.search(r'^#\s+(.+)$', text, re.M)
        identifier = 'reference-index' if relative == 'reference/README.md' else path.stem
        if identifier in identifiers:
            raise ValueError('Ambiguous public documentation identifier')
        identifiers.add(identifier)
        result.append({'id': identifier, 'title': heading.group(1).strip() if heading else path.stem,
                       'path': relative, 'section': 'guide' if relative == 'README.md' else 'reference'})
    return result


def _prefix(value):
    if not isinstance(value, str) or not re.fullmatch(r'/[a-z0-9][a-z0-9/_-]*', value) or '..' in value or '//' in value:
        raise ValueError('Wiki prefix must be an absolute lowercase page path')
    return value.rstrip('/')


def _source_url(value):
    if value is None:
        return None
    parsed = urlsplit(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('Source base URL must be HTTPS without credentials or query')
    return value.rstrip('/')


def local_target(page, target):
    """Normalize a Markdown-relative link, refusing escapes above the public root."""
    raw, marker, fragment = target.partition('#')
    if not raw:
        return None, fragment
    parsed = urlsplit(raw)
    if parsed.scheme or parsed.netloc:
        if parsed.scheme not in {'https', 'http', 'mailto'} or parsed.username or parsed.password:
            raise ValueError('Unsupported or credential-bearing documentation URL')
        return None, None
    decoded = unquote(raw)
    if decoded.startswith('/') or '\\' in decoded or '?' in decoded or any(ord(c) < 32 for c in decoded):
        raise ValueError('Invalid relative documentation link in ' + page)
    parts = list(PurePosixPath(page).parent.parts)
    for part in PurePosixPath(decoded).parts:
        if part == '..':
            if not parts:
                raise ValueError('Documentation link leaves public root: ' + page)
            parts.pop()
        elif part != '.':
            parts.append(part)
    return PurePosixPath(*parts).as_posix(), fragment if marker else ''


def rewrite_markdown(text, page, names, base_path=None):
    """Validate local links and optionally rewrite them for Wiki.js page paths."""
    selected = set(names)
    prefix = _prefix(base_path) if base_path is not None else None

    def replace(match):
        target = match.group(2)
        relative, fragment = local_target(page, target)
        if relative is None:
            return match.group(0)
        if relative not in selected:
            raise ValueError('Missing documentation link: ' + page + ' -> ' + relative)
        if prefix is None:
            return match.group(0)
        path = PurePosixPath(relative)
        if path.name == 'README.md':
            suffix = '' if path.parent == PurePosixPath('.') else '/' + quote(path.parent.as_posix(), safe='/')
        else:
            suffix = '/' + quote(str(path.with_suffix('')) if path.suffix == '.md' else relative, safe='/')
        if path.suffix != '.md':
            suffix = '/' + quote(relative, safe='/')
        rewritten = prefix + suffix + ('#' + fragment if fragment else '')
        return match.group(1) + rewritten + match.group(3)

    return LINK.sub(replace, text)


def native_diagrams(text, page, names, source_root):
    """Use the Wiki.js 2.x Markdown editor's native diagram storage format.

    A normal SVG asset is sanitized by Wiki.js and loses its embedded model.
    The native editor instead keeps the complete SVG as base64 in a diagram
    fence. Keep this variant separate from the broadly portable image pages.
    """
    selected = set(names)

    def replace(match):
        if not match.group(1).startswith('!['):
            return match.group(0)
        relative, fragment = local_target(page, match.group(2))
        if relative is None or fragment or not relative.endswith('.svg'):
            return match.group(0)
        model = 'diagrams/' + PurePosixPath(relative).stem + '.drawio'
        if relative not in selected or model not in selected:
            return match.group(0)
        data = public_file(source_root, relative).read_bytes()
        _validate_asset(relative, data)
        svg = ET.fromstring(data)
        if not svg.get('content'):
            return match.group(0)
        native_data = public_file(source_root, model).read_bytes()
        _validate_asset(model, native_data)
        if canonical_models(svg.get('content').encode()) != canonical_models(native_data):
            raise ValueError('SVG and native draw.io models differ: ' + relative)
        return '\n```diagram\n' + base64.b64encode(data).decode('ascii') + '\n```\n'

    return LINK.sub(replace, text)


def drawio_models(data):
    """Read native uncompressed or standard compressed draw.io models, bounded."""
    if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
        raise ValueError('External draw.io XML declarations refused')
    root = ET.fromstring(data)
    if root.tag != 'mxfile':
        raise ValueError('Native editable draw.io model required')
    models = []
    for diagram in root.findall('diagram'):
        model = diagram.find('mxGraphModel')
        if model is None:
            try:
                compressed = base64.b64decode(''.join((diagram.text or '').split()), validate=True)
                inflater = zlib.decompressobj(-15)
                decoded = inflater.decompress(compressed, 10 * 1024 * 1024 + 1)
                if len(decoded) > 10 * 1024 * 1024 or not inflater.eof or inflater.unused_data:
                    raise ValueError('Unbounded or invalid diagram')
                text = unquote(decoded.decode('utf-8'), errors='strict')
                if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():
                    raise ValueError('External diagram declaration')
                model = ET.fromstring(text)
            except (ValueError, UnicodeError, zlib.error, ET.ParseError):
                raise ValueError('Native editable draw.io model required') from None
        if model.tag != 'mxGraphModel':
            raise ValueError('Native editable draw.io model required')
        models.append(model)
    if not models:
        raise ValueError('Native editable draw.io model required')
    return models


def canonical_models(data):
    """Compare graph content while ignoring editor viewport and file metadata."""
    result = []
    for model in drawio_models(data):
        for name in ('dx', 'dy'):
            model.attrib.pop(name, None)
        result.append(ET.canonicalize(ET.tostring(model, encoding='unicode'), strip_text=True))
    return result


def _validate_asset(name, data):
    if name.endswith('.png'):
        if not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('Invalid PNG documentation asset: ' + name)
    elif name.endswith(('.svg', '.drawio')):
        if b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
            raise ValueError('External XML declarations refused: ' + name)
        root = ET.fromstring(data)
        if name.endswith('.drawio'):
            models = drawio_models(data)
            cells = [cell for model in models for cell in model.findall('.//mxCell')]
            if not any(cell.get('vertex') == '1' for cell in cells) or not any(cell.get('edge') == '1' for cell in cells):
                raise ValueError('Editable boxes and connectors required: ' + name)
        else:
            if root.tag.rsplit('}', 1)[-1] != 'svg':
                raise ValueError('Invalid SVG documentation asset: ' + name)
            for element in root.iter():
                if element.tag.rsplit('}', 1)[-1] in {'script', 'foreignObject', 'iframe'}:
                    raise ValueError('Active SVG content refused: ' + name)
                for attribute, value in element.attrib.items():
                    if attribute.lower().startswith('on') or attribute.rsplit('}', 1)[-1] in {'href', 'src'} and value.startswith(('http:', 'https:', '//', 'data:')):
                        raise ValueError('External SVG content refused: ' + name)


def source_version(source_root):
    """Identify the checkout when available; do not infer an unpublished release."""
    try:
        root = Path(source_root)
        commit = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'], check=True, capture_output=True,
                                text=True, timeout=10).stdout.strip()
        dirty = subprocess.run(['git', '-C', str(root), 'status', '--porcelain'], check=True,
                               capture_output=True, text=True, timeout=10).stdout.strip()
        if not re.fullmatch(r'[a-f0-9]{40,64}', commit):
            raise ValueError('Invalid commit identity')
        return {'commit': commit, 'dirty': bool(dirty), 'git_available': True}
    except (OSError, subprocess.SubprocessError, ValueError):
        return {'commit': None, 'dirty': None, 'git_available': False}


def export_bundle(source_root, output, base_path='/dinum-rie', source_base_url=None):
    """Write a new private ZIP with portable and Wiki.js-ready public trees."""
    source_root = _root(source_root)
    output = Path(output).expanduser().absolute()
    if output.is_symlink() or output.exists() or output.suffix.lower() != '.zip':
        raise ValueError('Choose a new ZIP output file')
    if output.resolve().is_relative_to(source_root):
        raise ValueError('Export output must be outside the documentation source tree')
    prefix = _prefix(base_path)
    source_url = _source_url(source_base_url)
    names = _files(source_root)
    members = {}
    for name in names:
        data = public_file(source_root, name).read_bytes()
        for rule, pattern in PRIVATE_PATTERNS.items():
            if pattern.search(data):
                raise ValueError('Public documentation audit failed: ' + name + ' (' + rule + ')')
        if name.endswith('.md'):
            portable = rewrite_markdown(data.decode('utf-8'), name, names)
            wiki = rewrite_markdown(portable, name, names, prefix)
            members['portable/' + name] = portable.encode('utf-8')
            members['wikijs/' + name] = wiki.encode('utf-8')
            native = native_diagrams(portable, name, names, source_root)
            members['wikijs-native/' + name] = rewrite_markdown(native, name, names, prefix).encode('utf-8')
        else:
            _validate_asset(name, data)
            members['portable/' + name] = data
            members['wikijs/' + name] = data
    intro = ('# Documentation SI-RIE — PDL, Incidents et ACL\n\n'
             'Ouvrir `portable/README.md` pour lire hors du wiki. Le dossier `portable/` conserve les liens relatifs.\n'
             'Le dossier `wikijs/` contient les pages adaptées au préfixe `' + prefix + '`.\n'
             'Le dossier `wikijs-native/` propose les mêmes pages avec les blocs diagram natifs de l’éditeur Markdown Wiki.js 2.x.\n'
             'Commencer le déploiement dans `portable/README.md` ; les compléments sont dans `portable/reference/`.\n'
             'Importer les pages Markdown et les pièces jointes selon `portable/reference/10-wikijs.md`.\n'
             'Les fichiers `.drawio` sont éditables ; SVG/PNG servent à la lecture sans moteur externe.\n'
             'Le manifeste donne les empreintes exactes des fichiers et distingue un checkout modifié.\n'
             'Aucun envoi au wiki ni installation de service n’est réalisé par cet export.\n')
    members['README.md'] = intro.encode('utf-8')
    manifest = {'schema_version': 1, 'kind': 'si-rie-public-documentation', 'base_path': prefix,
                'wikijs_native_diagrams': 'markdown-diagram-fence-svg-base64',
                'source_base_url': source_url, 'source': source_version(source_root),
                'qualification': 'see-public-qualification-page-not-inferred-from-export',
                'files': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                          for name, data in sorted(members.items())]}
    members['DOCUMENTATION-MANIFEST.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(output, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
                for name, data in sorted(members.items()):
                    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                    info.compress_type = zipfile.ZIP_DEFLATED
                    info.external_attr = 0o644 << 16
                    archive.writestr(info, data)
        with zipfile.ZipFile(output) as archive:
            if archive.testzip() is not None:
                raise ValueError('Archive integrity verification failed')
            for row in manifest['files']:
                if hashlib.sha256(archive.read(row['path'])).hexdigest() != row['sha256']:
                    raise ValueError('Exported content differs from manifest')
    except BaseException:
        output.unlink(missing_ok=True)
        raise
    return {'archive': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
            'pages': sum(name.endswith('.md') for name in names), 'files': len(manifest['files']),
            'base_path': prefix, 'source': manifest['source']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=Path(os.getenv('RIE_DOCS_DIR', str(DEFAULT_DOCS))))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--base-path', default='/dinum-rie')
    parser.add_argument('--source-base-url')
    args = parser.parse_args()
    try:
        result = export_bundle(args.source_root, args.output, args.base_path, args.source_base_url)
    except (ValueError, OSError, ET.ParseError) as error:
        print('ERROR: ' + str(error), file=__import__('sys').stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
