"""Cold backup and isolated restore; validate all input before creating a target.

Archives contain secrets and stay private. A restore creates new Compose and
Docker-engine ownership while preserving the LDAP database and application state.
It never replaces a running instance, existing volume or conflicting image tag.
"""
from __future__ import annotations
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import tarfile
import uuid

MANIFEST = 'BACKUP-MANIFEST.json'
VERSION = 1


def digest(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            value.update(block)
    return value.hexdigest()


def regular_tree(root):
    """Refuse links, special files and escaping components before reading bytes."""
    root=Path(root)
    for path in [root,*root.rglob('*')]:
        info=path.lstat()
        if stat.S_ISLNK(info.st_mode) or not (stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)):
            raise ValueError('Backup inputs must be regular files and directories without symlinks.')
        if not path.resolve().is_relative_to(root.resolve()):
            raise ValueError('Backup path escapes its private directory.')


def validate_tar(path):
    """Only regular files/directories with bounded, relative paths enter a volume."""
    names=set()
    total=0
    with tarfile.open(path, mode='r:') as archive:
        for member in archive:
            relative=PurePosixPath(member.name)
            if relative.is_absolute() or '..' in relative.parts or '\\' in member.name or '\x00' in member.name:
                raise ValueError('Unsafe archive path.')
            normalized=relative.as_posix()
            if normalized in names or not (member.isdir() or member.isfile()) or member.issparse():
                raise ValueError('Archive links, special files, duplicates and sparse files are forbidden.')
            names.add(normalized)
            if member.size<0:raise ValueError('Invalid archive member size.')
            total+=member.size
    # An uncompressed archive cannot legitimately expand beyond its byte length.
    if total>Path(path).stat().st_size:
        raise ValueError('Archive expansion exceeds its stored size.')
    return total


def image_metadata(manager, references):
    inspected=json.loads(manager.docker('image','inspect',*references,capture=True).stdout)
    return [{'reference':reference,'id':row['Id'],'os':row['Os'],'architecture':row['Architecture']}
            for reference,row in zip(references,inspected)]


def platform_identity(manager):
    raw=manager.docker('info','--format','{{.OSType}}/{{.Architecture}}',capture=True).stdout.strip()
    operating,architecture=raw.split('/',1)
    architecture={'aarch64':'arm64','x86_64':'amd64'}.get(architecture,architecture)
    if operating!='linux' or architecture not in {'arm64','amd64'}:
        raise ValueError('Restore requires a Linux ARM64 or AMD64 Docker engine.')
    return {'os':operating,'architecture':architecture}


def inventory_files(root):
    return [{'path':path.relative_to(root).as_posix(),'bytes':path.stat().st_size,'sha256':digest(path)}
            for path in sorted(root.rglob('*')) if path.is_file() and path.relative_to(root).as_posix()!=MANIFEST]


def create_backup(instance, values, destination, manager):
    instance,destination=Path(instance),Path(destination)
    if destination.exists() or destination.is_relative_to(manager.ROOT) or destination.is_relative_to(instance):
        raise ValueError('Choose a new backup directory outside the checkout and instance.')
    regular_tree(instance)
    running=manager.compose(instance,values,'--profile','demo','--profile','demo-ui','--profile','tools',
                            'ps','--status','running','-q',capture=True).stdout.strip()
    if running:raise ValueError('Stop this instance before a consistent cold backup.')
    ids=manager.docker('ps','-aq','--filter','label=com.docker.compose.project='+values['RIE_PROJECT'],capture=True).stdout.split()
    if not ids:raise ValueError('No prepared service containers exist for this instance.')
    containers=json.loads(manager.docker('inspect',*ids,capture=True).stdout)
    references=sorted({row['Config']['Image'] for row in containers})
    images=image_metadata(manager,references)
    ids_by_ref={row['reference']:row['id'] for row in images}
    if any(ids_by_ref[row['Config']['Image']]!=row['Image'] for row in containers):
        raise ValueError('An image tag changed after container creation; start and stop the instance before backup.')
    platform=platform_identity(manager)
    if any(row['os']!=platform['os'] or row['architecture']!=platform['architecture'] for row in images):
        raise ValueError('The source instance contains an image for another architecture.')
    destination.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    stage=destination.with_name(destination.name+'.partial-'+uuid.uuid4().hex)
    stage.mkdir(mode=0o700)
    try:
        shutil.copytree(instance,stage/'instance')
        suffixes=manager.VOLUMES if values['RIE_MODE']=='demo' else ('runtime',)
        for suffix in suffixes:
            name=values['RIE_PROJECT']+'-'+suffix
            manager.docker('volume','inspect',name,capture=True)
            with (stage/(suffix+'.tar')).open('xb') as stream:
                subprocess.run([os.getenv('RIE_DOCKER','docker'),'run','--rm','--pull','never','--network','none',
                                '--user','0:0','--entrypoint','tar','--mount','type=volume,src='+name+',dst=/backup,readonly',
                                values['RIE_IMAGE'],'-C','/backup','-cf','-','.'],check=True,stdout=stream)
            validate_tar(stage/(suffix+'.tar'))
        manager.docker('image','save','--output',str(stage/'images.tar'),*references)
        manifest={'version':VERSION,'created_at':datetime.now(timezone.utc).isoformat(),
                  'source':{'instance_id':values['RIE_INSTANCE_ID'],'project':values['RIE_PROJECT'],'mode':values['RIE_MODE']},
                  'platform':platform,'images':images,'volumes':list(suffixes),'files':inventory_files(stage)}
        manager.write_new(stage/MANIFEST,json.dumps(manifest,indent=2)+'\n')
        for path in [stage,*stage.rglob('*')]:path.chmod(0o700 if path.is_dir() else 0o600)
        stage.rename(destination)
    except BaseException:
        # Only this newly created partial backup is removed; source state is untouched.
        shutil.rmtree(stage)
        raise
    return {'backup':str(destination),'manifest_sha256':digest(destination/MANIFEST),'files':len(manifest['files']),
            'images_included':len(images),'data_archives':len(suffixes)}


def verify_backup(backup):
    backup=Path(backup)
    regular_tree(backup)
    manifest=json.loads((backup/MANIFEST).read_text())
    if manifest.get('version')!=VERSION or manifest.get('source',{}).get('mode') not in {'demo','external'}:
        raise ValueError('Unsupported backup manifest.')
    expected_volumes=['runtime','opensearch','metrics','ldap'] if manifest['source']['mode']=='demo' else ['runtime']
    if manifest.get('volumes')!=expected_volumes:
        raise ValueError('Backup volume list is incomplete or unexpected.')
    expected=set()
    for row in manifest['files']:
        relative=PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or row['path'] in expected or '\\' in row['path']:
            raise ValueError('Unsafe or duplicate manifest path.')
        expected.add(row['path'])
        path=backup/row['path']
        if not path.is_file() or path.stat().st_size!=row['bytes'] or digest(path)!=row['sha256']:
            raise ValueError('Backup integrity check failed: '+row['path'])
    actual={path.relative_to(backup).as_posix() for path in backup.rglob('*') if path.is_file() and path.relative_to(backup).as_posix()!=MANIFEST}
    if actual!=expected:raise ValueError('Backup contains missing or unlisted files.')
    required={'instance/.env','images.tar',*(name+'.tar' for name in expected_volumes)}
    if not required.issubset(expected):raise ValueError('Backup is missing required inputs.')
    for name in expected_volumes:validate_tar(backup/(name+'.tar'))
    for row in manifest.get('images',[]):
        if not re.fullmatch(r'sha256:[a-f0-9]{64}',row.get('id','')) or not row.get('reference'):
            raise ValueError('Invalid backup image identity.')
    if not manifest.get('images'):raise ValueError('Backup has no application images.')
    return manifest


def restore_backup(destination, backup, manager):
    """Restore once into fresh volumes; a failed import is never retried in-place."""
    destination,backup=Path(destination),Path(backup)
    if destination.exists() or destination.is_relative_to(manager.ROOT) or destination.is_relative_to(backup):
        raise ValueError('Restore destination must be a new path outside checkout and backup.')
    manifest=verify_backup(backup)  # All hashes and volume paths before mutation.
    if platform_identity(manager)!=manifest['platform']:
        raise ValueError('Backup architecture differs from the selected Docker engine.')
    for row in manifest['images']:
        result=subprocess.run([os.getenv('RIE_DOCKER','docker'),'image','inspect',row['reference'],'--format','{{.Id}}'],
                              text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
        if result.returncode==0 and result.stdout.strip()!=row['id']:
            raise ValueError('An existing image tag conflicts with the backup; no images or volumes changed.')
    # Restore is allowed to add missing trusted backup images, never replace a tag.
    manager.docker('image','load','--input',str(backup/'images.tar'))
    for image in image_metadata(manager,[row['reference'] for row in manifest['images']]):
        expected=next(row for row in manifest['images'] if row['reference']==image['reference'])
        if image!=expected:raise ValueError('Loaded image identity does not match the backup.')
    shutil.copytree(backup/'instance',destination)
    for path in [destination,*destination.rglob('*')]:path.chmod(0o700 if path.is_dir() else 0o600)
    values=dict(line.split('=',1) for line in (destination/'.env').read_text().splitlines() if line and not line.startswith('#'))
    ident=uuid.uuid4().hex
    values.update(RIE_PROJECT='rie-'+ident[:12],RIE_INSTANCE_ID=ident,RIE_INSTANCE_DIR=str(destination))
    (destination/'docker-id').unlink(missing_ok=True)
    manager.save_env(destination,values)
    manager.guard(destination,values)
    created=[]
    try:
        for suffix in manifest['volumes']:
            name=values['RIE_PROJECT']+'-'+suffix
            present=manager.docker('volume','ls','--filter','name=^'+name+'$','--format','{{.Name}}',capture=True).stdout.strip()
            if present:raise ValueError('Restore never overwrites an existing volume.')
            manager.docker('volume','create','--label','rie.instance='+ident,
                           '--label','com.docker.compose.project='+values['RIE_PROJECT'],
                           '--label','com.docker.compose.volume='+suffix,name)
            created.append(name)
            with (backup/(suffix+'.tar')).open('rb') as stream:
                subprocess.run([os.getenv('RIE_DOCKER','docker'),'run','--rm','--pull','never','--network','none','-i',
                                '--user','0:0','--entrypoint','tar','--mount',
                                'type=volume,src='+name+',dst=/restore,volume-nocopy',values['RIE_IMAGE'],
                                '--numeric-owner','-C','/restore','-xpf','-'],check=True,stdin=stream)
        receipt={'version':VERSION,'restored_at':datetime.now(timezone.utc).isoformat(),
                 'backup_manifest_sha256':digest(backup/MANIFEST),'source_instance_id':manifest['source']['instance_id'],
                 'new_instance_id':ident,'new_project':values['RIE_PROJECT'],'volumes':created,'services_started':False}
        manager.write_new(destination/'restore.json',json.dumps(receipt,indent=2)+'\n')
    except BaseException:
        manager.write_new(destination/'restore-failed.json',json.dumps({'created_volumes':created,'services_started':False})+'\n')
        raise
    return {'instance':str(destination),'project':values['RIE_PROJECT'],'volumes_restored':len(created),'services_started':False}
