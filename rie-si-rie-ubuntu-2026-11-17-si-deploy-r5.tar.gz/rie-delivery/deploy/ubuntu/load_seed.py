"""Reproducible large corpus in a separate synthetic qualification instance.

No fixture in the reference demonstration is changed. Writes require the exact
private demo endpoint, a dedicated load marker, and deterministic create-only IDs.
"""
from __future__ import annotations
from copy import deepcopy
from datetime import datetime,timedelta
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import secrets

TARGET=100000


def prepare_accounts(instance):
    instance=Path(instance)
    values=dict(line.split('=',1) for line in (instance/'.env').read_text().splitlines() if '=' in line)
    if values.get('RIE_MODE')!='demo' or (instance/'docker-id').exists():
        raise ValueError('Prepare load accounts only in a new, dedicated demo before any Docker operation')
    destination=instance/'clients/load-accounts.json'
    if destination.exists():return json.loads(destination.read_text())
    config=json.loads((instance/'config/access.json').read_text())
    base=config['ldap']['search_base'];groups=config['ldap']['group_dns']
    ldif=instance/'config/ldap/seed.ldif'
    text=ldif.read_text();accounts=[]
    for number in range(1,11):
        username=f'load.user{number:02d}'
        category='external' if number in (5,10) else 'internal'
        password=secrets.token_urlsafe(24);salt=secrets.token_bytes(16)
        encoded=base64.b64encode(hashlib.sha1(password.encode()+salt).digest()+salt).decode()
        dn='uid='+username+','+base
        entry=(f'dn: {dn}\nobjectClass: inetOrgPerson\nuid: {username}\ncn: Load User {number}\nsn: User {number}\n'
               f'mail: {username}@qualification.rie.example\nuserPassword: {{SSHA}}{encoded}\nmemberOf: {groups[category]}')
        parts=text.strip().split('\n\n')
        for position,part in enumerate(parts):
            if part.startswith('dn: '+groups[category]+'\n'):parts[position]=part+'\nmember: '+dn
        text='\n\n'.join([*parts,entry])+'\n'
        accounts.append({'username':username,'category':category,'synthetic':True})
    ldif.write_text(text);ldif.chmod(0o600)
    destination.write_text(json.dumps(accounts,indent=2)+'\n');destination.chmod(0o600)
    copy=instance/'config/load-accounts.json'
    copy.write_text(json.dumps(accounts,indent=2)+'\n');copy.chmod(0o600)
    return accounts


def seed():
    import httpx
    import rie_agent
    from obs_poc.config import ROOT as INCIDENT_ROOT
    from seed_incidents import build_corpus,LOGS_INDEX
    if os.getenv('PDL_MODE')!='demo' or os.getenv('RIE_LOAD_QUALIFICATION')!='true' or os.getenv('OPENSEARCH_URL')!='http://opensearch:9200':
        raise ValueError('Load writes require their explicitly marked, separate synthetic instance')
    fixture=json.loads((Path(rie_agent.__file__).parent/'fixtures/pdl_portable.json').read_text())
    _,incident_rows,_=build_corpus(INCIDENT_ROOT)
    families=fixture['indices'];all_counts={}
    with httpx.Client(base_url='http://opensearch:9200',timeout=90,trust_env=False) as client:
        def put_rows(index,rows):
            pending=[]
            for identifier,document in rows:
                pending.append(json.dumps({'create':{'_index':index,'_id':identifier}}))
                pending.append(json.dumps(document,ensure_ascii=False))
                if len(pending)>=2000:
                    flush(pending);pending=[]
            if pending:flush(pending)
        def flush(lines):
            response=client.post('/_bulk',content='\n'.join(lines)+'\n',headers={'Content-Type':'application/x-ndjson'})
            response.raise_for_status();value=response.json()
            if any(row['create']['status'] not in (201,409) for row in value.get('items',[])):
                raise ValueError('A load fixture write failed')
        for index,spec in families.items():
            current=client.post('/'+index+'/_count',json={'query':{'match_all':{}}});current.raise_for_status()
            count=current.json()['count']
            desired=TARGET//len(families)
            if count not in (len(spec['documents']),desired):raise ValueError('Unexpected existing load corpus count')
            def pdl_rows():
                sample=spec['documents'][0]['source']
                for number in range(desired-len(spec['documents'])):
                    row=deepcopy(sample)
                    yield f'qualification-load-{number:06d}',row
            if count!=desired:put_rows(index,pdl_rows())
            all_counts[index]=desired
        original=incident_rows[LOGS_INDEX]
        current=client.post('/'+LOGS_INDEX+'/_count',json={'query':{'match_all':{}}});current.raise_for_status()
        if current.json()['count'] not in (len(original),TARGET):raise ValueError('Unexpected incident load corpus count')
        def incident_data():
            for number in range(TARGET-len(original)):
                row=deepcopy(original[number%len(original)])
                row['record_id']=f'qualification-load-{number:06d}'
                yield row['record_id'],row
        if current.json()['count']!=TARGET:put_rows(LOGS_INDEX,incident_data())
        all_counts[LOGS_INDEX]=TARGET
        for index,expected in all_counts.items():
            client.post('/'+index+'/_refresh').raise_for_status()
            response=client.post('/'+index+'/_count',json={'query':{'match_all':{}}});response.raise_for_status()
            if response.json()['count']!=expected:raise ValueError('Large corpus verification failed')
    receipt={'synthetic':True,'reference_instance_unchanged':True,'pdl_events':TARGET,'incidents_logs':TARGET,'indices':all_counts}
    path=Path('/data/load-corpus.json');path.write_text(json.dumps(receipt,indent=2)+'\n');path.chmod(0o600)
    print(json.dumps(receipt))
    return receipt


def expected_documents(fixture, incident_rows):
    """Independent deterministic oracle for a read-only post-campaign comparison."""
    from seed_incidents import LOGS_INDEX
    for index, spec in fixture['indices'].items():
        wanted = {row['id']: row['source'] for row in spec['documents']}
        for number in range(TARGET // len(fixture['indices']) - len(spec['documents'])):
            wanted[f'qualification-load-{number:06d}'] = spec['documents'][0]['source']
        yield index, wanted
    for index, originals in incident_rows.items():
        wanted = {row['record_id']: row for row in originals}
        if index == LOGS_INDEX:
            for number in range(TARGET - len(originals)):
                row = deepcopy(originals[number % len(originals)])
                row['record_id'] = f'qualification-load-{number:06d}'
                wanted[row['record_id']] = row
        yield index, wanted


def compare_documents(client, index, expected):
    """Read every source row; reject missing, extra, duplicate or changed records."""
    from seed_incidents import canonical
    seen = set(); scroll = None
    try:
        response = client.post('/' + index + '/_search', params={'scroll': '2m'}, json={
            'size': 2000, 'track_total_hits': True, 'sort': ['_doc'], 'query': {'match_all': {}}})
        while True:
            response.raise_for_status(); body = response.json()
            scroll = body.get('_scroll_id') or scroll
            if body.get('timed_out') or body.get('_shards', {}).get('failed', 0):
                raise ValueError('Incomplete load corpus read')
            hits = body['hits']['hits']
            for hit in hits:
                key = hit['_id']
                if key in seen or key not in expected or hit['_source'] != expected[key]:
                    raise ValueError('Load corpus differs from deterministic oracle: ' + index)
                seen.add(key)
            if not hits:
                break
            if not scroll:
                raise ValueError('Missing scroll cursor during full corpus verification')
            response = client.post('/_search/scroll', json={'scroll': '2m', 'scroll_id': scroll})
        if seen != set(expected):
            raise ValueError('Load corpus records are missing: ' + index)
    finally:
        if scroll:
            client.request('DELETE', '/_search/scroll', json={'scroll_id': [scroll]}).raise_for_status()
    digest = hashlib.sha256()
    for key in sorted(expected):
        digest.update((canonical([key, expected[key]]) + '\n').encode())
    return {'documents': len(seen), 'sha256_id_and_source': digest.hexdigest(), 'all_sources_compared': True}


def verify():
    """Never seed or repair: compare the entire corpus after the real-time run."""
    import httpx
    import rie_agent
    from obs_poc.config import ROOT as INCIDENT_ROOT
    from seed_incidents import build_corpus, missing_metrics
    if os.getenv('PDL_MODE') != 'demo' or os.getenv('RIE_LOAD_QUALIFICATION') != 'true' or os.getenv('OPENSEARCH_URL') != 'http://opensearch:9200':
        raise ValueError('Verification requires the separate marked synthetic load instance')
    fixture = json.loads((Path(rie_agent.__file__).parent / 'fixtures/pdl_portable.json').read_text())
    _, incident_rows, metric_rows = build_corpus(INCIDENT_ROOT)
    with httpx.Client(base_url='http://opensearch:9200', timeout=90, trust_env=False) as client:
        indices = {index: compare_documents(client, index, wanted)
                   for index, wanted in expected_documents(fixture, incident_rows)}
        if missing_metrics(client, 'http://victoriametrics:8428', metric_rows):
            raise ValueError('Metric samples are missing after endurance')
    receipt = {'passed': True, 'read_only': True, 'synthetic': True, 'indices': indices,
               'metric_series': len(metric_rows), 'metric_points': sum(len(row['values']) for row in metric_rows),
               'metric_values_and_timestamps_compared': True, 'source_data_repaired': False}
    print(json.dumps(receipt))
    return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-accounts',type=Path)
    parser.add_argument('--verify', action='store_true')
    args=parser.parse_args()
    if args.prepare_accounts:print(json.dumps({'accounts_prepared':len(prepare_accounts(args.prepare_accounts)),'passwords_emitted':False}))
    elif args.verify:verify()
    else:seed()
