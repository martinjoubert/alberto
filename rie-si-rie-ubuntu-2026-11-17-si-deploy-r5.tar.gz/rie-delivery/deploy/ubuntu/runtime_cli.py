"""Server-side maintenance and deterministic delivery acceptance, without Albert.

This CLI is available to the Docker operator, not as an HTTP endpoint. It resolves
an explicitly named LDAP account before entering the shared authorization context.
Only an explicitly authorized LDAP administrator may seed, inspect mappings or change access rules.
User-facing HTTP checks use genuine individual credentials, never client assertions.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import re
from pathlib import Path
import sys
import tempfile
import time

import httpx
import requests

from dinum_access import AccessDenied, AccessGate
from dinum_access.security import CURRENT, Principal
from dinum_access.user_tokens import UserTokens

DELIVERY = Path(__file__).resolve().parent
DATA = Path('/data')
PDL_URL = 'http://pdl:9910'
INCIDENTS_URL = 'http://incidents:9950'


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def configured_gate():
    gate = AccessGate.configured()
    if gate is None:
        raise ValueError('Explicit access configuration required')
    return gate


@contextmanager
def acting(username, *, internal=True):
    """Use live LDAP identity for a trusted server operator command."""
    gate = configured_gate()
    email, category, subject, administrator = gate.directory.lookup(username, username=True, identity=True, authorization=True)
    principal = Principal('ldap:' + hashlib.sha256(subject.encode()).hexdigest(), email,
                          category, administrator)
    if internal and not principal.administrator:
        raise AccessDenied('administrator_required')
    marker = CURRENT.set((gate, principal))
    try:
        yield gate, principal
    finally:
        CURRENT.reset(marker)


def wait_sources(client, endpoints, *, timeout=180):
    """Wait for local sources with a single bounded deadline, without AI calls."""
    pending = dict(endpoints)
    deadline = time.monotonic() + timeout
    while pending:
        for name, url in list(pending.items()):
            try:
                response = client.get(url, timeout=min(3, max(.1, deadline - time.monotonic())))
                if response.status_code == 200:
                    pending.pop(name)
            except httpx.HTTPError:
                pass
        if not pending:
            return
        if time.monotonic() >= deadline:
            raise ValueError('Local services unavailable: ' + ','.join(sorted(pending)))
        time.sleep(min(2, max(.1, deadline - time.monotonic())))


def require_demo():
    if os.environ.get('PDL_MODE') != 'demo' or os.environ.get('OPENSEARCH_URL') != 'http://opensearch:9200':
        raise ValueError('Synthetic writes and acceptance require the dedicated demo profile')


def check(username):
    """Probe actual sources and initialized state; process health alone is not ready."""
    with httpx.Client(timeout=25, trust_env=False, follow_redirects=False) as client:
        wait_sources(client, {'pdl': PDL_URL + '/healthz', 'incidents': INCIDENTS_URL + '/healthz'}, timeout=10)
        with acting(username) as (gate, _):
            policy = gate.store.read()
            from rie_agent.config import load_settings
            from rie_agent.store import Store
            from rie_agent.inventory import OpenSearchInventory, required_source_coverage
            settings = load_settings()
            store = Store(settings.data_dir)
            inventory = store.inventory()
            dependencies = {}
            try:
                inventory = OpenSearchInventory(settings, store).refresh()
                dependencies['pdl_opensearch'] = 'ok'
            except (AccessDenied, ValueError, OSError, RuntimeError, httpx.HTTPError, requests.RequestException):
                dependencies['pdl_opensearch'] = 'unavailable_or_denied'
            active = sum(bool(item.get('active')) for item in store.catalog())
            coverage = required_source_coverage(settings, inventory, store.catalog(), inventory.get('indices', {}))
            pdl_ready = bool(coverage) and all(item['ready'] for item in coverage)
            try:
                manifest = json.loads(Path(os.environ['OBS_MANIFEST']).read_text())
                incident_ready = manifest.get('status') == 'ready'
            except (OSError, ValueError, KeyError):
                incident_ready = False
            if incident_ready:
                with individual_token(username) as (token, _, _):
                    response = client.get(INCIDENTS_URL + '/readiness', headers={'Authorization': 'Bearer ' + token})
                    if response.status_code in (200, 503):
                        readiness = response.json()
                        for row in readiness.get('services', []):
                            if row['service'] != 'albert':
                                dependencies['incidents_' + row['service']] = row['status']
                        if not readiness.get('services'):
                            dependencies['incidents_sources'] = 'unavailable'
                    else:
                        dependencies['incidents_sources'] = 'unavailable_or_denied'
            initialized = pdl_ready and incident_ready
            available = bool(dependencies) and all(value == 'ok' for value in dependencies.values())
            ready = initialized and available
            result = {'status': 'ready' if ready else 'healthy_not_initialized' if not initialized else 'sources_unavailable',
                      'services': {'pdl': 'healthy', 'incidents': 'healthy', 'ldap': 'verified'},
                      'dependencies': dependencies, 'policy_revision': policy['revision'], 'pdl_active_mappings': active,
                      'pdl_required_sources': coverage,
                      'incidents_corpus_ready': incident_ready, 'albert_generation': 'not_tested',
                      'observability': 'not_deployed'}
    print(json.dumps(result, ensure_ascii=False))
    return 0 if ready else 2


def seed(username):
    require_demo()
    with httpx.Client(timeout=5, trust_env=False, follow_redirects=False) as client:
        wait_sources(client, {'opensearch': 'http://opensearch:9200',
                              'victoriametrics': 'http://victoriametrics:8428/health'})
    # All discovery/catalog reads run through the existing authorization code.
    with acting(username):
        demo = load_module('delivery_pdl_demo', DELIVERY / 'demo.py')
        demo.seed()
        incidents = load_module('delivery_incident_seed', DELIVERY / 'seed_incidents.py')
        result = incidents.seed('http://opensearch:9200', 'http://victoriametrics:8428',
                                Path(os.environ['OBS_MANIFEST']))
    print(json.dumps({'pdl': 'bundled_fixture_mappings_ready', 'incidents': result,
                      'albert_called': False}, ensure_ascii=False))


@contextmanager
def individual_token(username):
    """Mint and discard only this operation's temporary transport credential."""
    gate = configured_gate()
    store = UserTokens(gate.config['user_tokens_directory'])
    with tempfile.TemporaryDirectory(prefix='rie-acceptance-') as temporary:
        output = Path(temporary) / 'user.token'
        record = store.issue(gate.directory, username, output, days=1)
        principal = None
        try:
            token = output.read_text().strip()
            identity = store.authenticate(token)
            principal = Principal('ldap:' + hashlib.sha256(identity['ldap_subject'].encode()).hexdigest(),
                                  identity['email'], identity['issued_category'], False)
            yield token, store, record['id']
        finally:
            try:
                store.revoke(record['id'])
                if principal is None:
                    raise ValueError('Temporary credential revoked; identity unavailable for audited removal.')
                gate.store.audit(principal, 'revoke_temporary_user_token', allowed=True,
                                 revision=gate.store.read()['revision'])
                store.discard_revoked(record['id'])
            finally:
                output.unlink(missing_ok=True)


def rpc(client, token, method, params=None, *, protocol='2025-11-25', extra_headers=None):
    headers = {'Accept': 'application/json, text/event-stream', 'Content-Type': 'application/json',
               'MCP-Protocol-Version': protocol}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    if extra_headers:
        headers.update(extra_headers)
    payload = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        payload['params'] = params
    return client.post(PDL_URL + '/mcp', headers=headers, json=payload)


def structured(response):
    body = response.json()
    result = body.get('result', {})
    if result.get('isError') or 'error' in body:
        raise ValueError('MCP returned a protocol or tool error')
    if 'structuredContent' in result:
        return result['structuredContent']
    for content in result.get('content', []):
        if content.get('type') == 'text':
            try:
                return json.loads(content['text'])
            except (ValueError, KeyError):
                continue
    return result


def persist_report(report):
    target = DATA / 'acceptance.json'
    temporary = target.with_suffix('.json.tmp')
    with temporary.open('w') as out:
        json.dump(report, out, indent=2, ensure_ascii=False)
        out.write('\n')
        out.flush()
        os.fsync(out.fileno())
    temporary.chmod(0o600)
    temporary.replace(target)
    return target


def acceptance(username):
    """Exercise real sources, both transports and allow/deny cases without LLMs."""
    require_demo()
    report = {'at_utc': datetime.now(timezone.utc).isoformat(), 'synthetic': True,
              'generation': 'not_tested_no_albert_calls', 'checks': []}

    def record(name, passed, **details):
        report['checks'].append({'name': name, 'passed': bool(passed), **details})

    def case(name, operation):
        try:
            operation()
        except (AccessDenied, ValueError, OSError, KeyError, TypeError, RuntimeError, httpx.HTTPError) as error:
            record(name, False, error=error.code if isinstance(error, AccessDenied) else type(error).__name__)

    from rie_agent.acceptance import ExplicitPlanner, FIXTURE_PATH, run
    from rie_agent.config import load_settings
    from rie_agent.service import RIEAgentService
    fixture = json.loads(FIXTURE_PATH.read_text())

    def internal_sources():
        with acting(username):
            service = RIEAgentService(load_settings(), planner=ExplicitPlanner(fixture['proposal']))
            pdl_result = run(service, fixture)
            report['pdl'] = pdl_result
            record('pdl_internal_six_real_source_scenarios', pdl_result['qualification_passed'],
                   scenarios=len(pdl_result['results']))
    case('pdl_internal_sources', internal_sources)
    # The initial demonstration policy gives these exact PDL fixtures to externals.
    def external_sources():
        with acting('eric.durand.ext', internal=False):
            external_service = RIEAgentService(load_settings(), planner=ExplicitPlanner(fixture['proposal']))
            result = run(external_service, fixture)
            record('pdl_external_six_real_source_scenarios', result['qualification_passed'],
                   scenarios=len(result['results']))
    case('pdl_external_sources', external_sources)
    body = {'question': 'Examiner les mesures et les logs de R1 sur la période demandée.',
            'variant': 'gptoss', 'equipment': 'OBS-RTR-01',
            'start': '2026-09-28T10:00:00+02:00', 'end': '2026-09-28T12:00:00+02:00',
            'synthesize': False}
    with httpx.Client(timeout=180, trust_env=False, follow_redirects=False) as client:
        def unauthorized():
            response = client.post(INCIDENTS_URL + '/diagnose', json=body)
            record('incidents_requires_individual_identity', response.status_code == 403,
                   http_status=response.status_code)
            response = rpc(client, '', 'tools/call', {'name': 'investigate_pdl', 'arguments': {'question': 'Quels sont mes index accessibles ?'}})
            record('pdl_tool_requires_individual_identity', response.status_code == 403,
                   http_status=response.status_code)
            response = client.post(INCIDENTS_URL + '/diagnose', json=body,
                                   headers={'X-OpenWebUI-User-JWT': 'client-asserted-admin'})
            record('local_client_cannot_assert_internal_identity', response.status_code == 403,
                   http_status=response.status_code)
        case('anonymous_and_forged_identity', unauthorized)

        def internal_http():
            with individual_token(username) as (token, _, _):
                response = client.post(INCIDENTS_URL + '/diagnose', json=body,
                                       headers={'Authorization': 'Bearer ' + token})
                response.raise_for_status()
                result = response.json()
                metrics = {item['metric']: item for item in result.get('metrics', [])}
                logs = result.get('logs') if isinstance(result.get('logs'), dict) else {}
                record('incidents_internal_live_evidence', result.get('status') == 'ok'
                       and result.get('errors') == [] and len(metrics) == 5
                       and all(item['coverage_percent'] == 100 for item in metrics.values())
                       and metrics.get('loss', {}).get('max') == 3.0
                       and metrics.get('latency', {}).get('max') == 80.0
                       and logs.get('total') == 120
                       and bool(result.get('events')) and bool(result.get('documents'))
                       and not result.get('usage') and result.get('analysis') is None,
                       business_status=result.get('status'), metric_count=len(metrics),
                       log_count=logs.get('total'))
                response = rpc(client, token, 'initialize', {'protocolVersion': '2025-11-25',
                               'capabilities': {}, 'clientInfo': {'name': 'rie-delivery-acceptance', 'version': '1'}})
                response.raise_for_status()
                initialization = response.json().get('result', {})
                record('pdl_mcp_initialization', bool(initialization.get('serverInfo')),
                       protocol=initialization.get('protocolVersion'))
                protocol = initialization.get('protocolVersion', '2025-11-25')
                response = rpc(client, token, 'tools/list', protocol=protocol)
                response.raise_for_status()
                tools = response.json().get('result', {}).get('tools', [])
                record('pdl_mcp_business_contract', [tool['name'] for tool in tools] == ['investigate_pdl'])
                # A real MCP tool call takes the deterministic access-information route.
                response = rpc(client, token, 'tools/call', {'name': 'investigate_pdl',
                               'arguments': {'question': 'Quels sont mes index accessibles ?'}}, protocol=protocol)
                response.raise_for_status()
                information = structured(response)
                record('pdl_mcp_individual_internal_identity',
                       information.get('access_control', {}).get('category') == 'internal'
                       and information.get('execution', {}).get('albert_calls') == 0)
        case('internal_transport', internal_http)

        def external_http():
            with individual_token('eric.durand.ext') as (token, store, identifier):
                headers = {'Authorization': 'Bearer ' + token, 'X-OpenWebUI-User-JWT': 'client-asserted-admin'}
                response = client.post(INCIDENTS_URL + '/diagnose', json=body, headers=headers)
                response.raise_for_status()
                result = response.json()
                record('incidents_external_denied_without_evidence', result.get('status') == 'denied'
                       and result.get('access_control', {}).get('category') == 'external'
                       and all(not result.get(name) for name in ('metrics', 'events', 'logs', 'documents', 'sources', 'evidence')))
                response = rpc(client, token, 'tools/call', {'name': 'investigate_pdl',
                               'arguments': {'question': 'Quels sont mes index accessibles ?'}},
                               extra_headers={'X-OpenWebUI-User-JWT': 'client-asserted-admin'})
                response.raise_for_status()
                result = structured(response)
                indices = result.get('access_control', {}).get('allowed_indices', [])
                record('pdl_mcp_external_identity_not_upgraded_by_local_header',
                       result.get('access_control', {}).get('category') == 'external'
                       and 'rie-pfs-fixture' in indices and 'pdl-zabbix-observability-demo' not in indices
                       and result.get('execution', {}).get('albert_calls') == 0)
                store.revoke(identifier)
                response = rpc(client, token, 'tools/call', {'name': 'investigate_pdl',
                               'arguments': {'question': 'Quels sont mes index accessibles ?'}})
                record('individual_revocation_effective_on_next_http_call', response.status_code == 403,
                       http_status=response.status_code)
        case('external_transport_and_revocation', external_http)
    report['passed'] = bool(report['checks']) and all(row['passed'] for row in report['checks'])
    destination = persist_report(report)
    print(json.dumps({'passed': report['passed'], 'checks': len(report['checks']),
                      'failed': [row['name'] for row in report['checks'] if not row['passed']],
                      'report': str(destination), 'albert_generation': 'not_tested'}, ensure_ascii=False))
    return 0 if report['passed'] else 2


def policy(username, argv):
    parser = argparse.ArgumentParser(prog='operator policy')
    parser.add_argument('action', choices=['list', 'set', 'remove', 'set-resource', 'remove-resource'])
    parser.add_argument('index', nargs='?')
    parser.add_argument('visibility', nargs='?', choices=['blocked', 'internal', 'authenticated'])
    parser.add_argument('--revision', type=int)
    args = parser.parse_args(argv)
    with acting(username) as (gate, principal):
        if args.action == 'list':
            policy = gate.store.read()
            result = {**policy, 'resources': policy.get('resources', {})}
        else:
            setting = args.action in {'set', 'set-resource'}
            resource = args.action in {'set-resource', 'remove-resource'}
            if not args.index or args.revision is None or setting and args.visibility is None:
                parser.error('An exact target and current --revision are required; set also requires visibility.')
            if resource:
                result = (gate.store.update_resource(principal, args.index, args.visibility, args.revision)
                          if setting else gate.store.remove_resource(principal, args.index, args.revision))
            else:
                result = (gate.store.update(principal, args.index, args.visibility, args.revision)
                          if setting else gate.store.remove(principal, args.index, args.revision))
        print(json.dumps(result, indent=2, ensure_ascii=False))


def pdl(username, argv):
    parser = argparse.ArgumentParser(prog='operator pdl')
    parser.add_argument('action', choices=['inspect', 'refresh', 'approve-review', 'validate-mappings', 'load-mappings'])
    parser.add_argument('review_id', nargs='?')
    parser.add_argument('--review-id', dest='selected_review')
    parser.add_argument('--reason', default='')
    args = parser.parse_args(argv)
    with acting(username) as (_, principal):
        from rie_agent.config import load_settings
        from rie_agent.inventory import OpenSearchInventory
        from rie_agent.store import Store
        settings = load_settings()
        store = Store(settings.data_dir)
        inventory_service = OpenSearchInventory(settings, store)
        if args.action == 'inspect':
            identifier = args.selected_review or args.review_id
            result = store.review(identifier) if identifier else {
                'indices': list(store.inventory().get('indices', {})),
                'active_catalog': [item for item in store.catalog() if item.get('active')],
                'pending_reviews': [item for item in store.reviews() if item['status'] == 'pending']}
        elif args.action == 'refresh':
            inventory = inventory_service.refresh()
            result = {'indices': list(inventory['indices']), 'invalidated_catalog_ids': inventory['invalidated_catalog_ids']}
        elif args.action == 'approve-review':
            identifier = args.selected_review or args.review_id
            if not identifier or not args.reason.strip():
                parser.error('approve-review requires an exact review ID and --reason after review')
            review = store.review(identifier)
            inventory = inventory_service.refresh()
            gate, _ = CURRENT.get()
            gate.store.authorize(principal, [review['index']])
            entry = inventory['indices'][review['index']]
            result = store.approve(identifier, entry['schema_hash'], author=principal.email, reason=args.reason)
        else:
            from rie_agent.operator_mappings import MAX_BYTES, load_bytes, validate_document, stage_reviews
            document, digest = load_bytes(sys.stdin.buffer.read(MAX_BYTES + 1))
            inventory = inventory_service.refresh()
            proposals = validate_document(document, inventory)
            result = {'valid': True, 'file_hash': digest, 'approval_required': True,
                      'indices': [{key: item[key] for key in ('index', 'profile', 'schema_hash')} for item in proposals]}
            if args.action == 'load-mappings':
                if not args.reason.strip():
                    parser.error('load-mappings requires --reason; it only stages pending reviews')
                rows = stage_reviews(store, document, file_hash=digest, author=principal.email, reason=args.reason)
                result['reviews'] = [{key: row[key] for key in ('id', 'index', 'status', 'reused')} for row in rows]
        print(json.dumps(result, indent=2, ensure_ascii=False))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['check', 'seed', 'acceptance', 'policy', 'pdl', 'itsm-subject',
                                          'list-client-sessions', 'revoke-client-session'])
    parser.add_argument('--username', default='alice.martin')
    args, remainder = parser.parse_known_args(argv)
    os.umask(0o077)
    try:
        if args.command in {'list-client-sessions', 'revoke-client-session'}:
            from dinum_access.oauth_store import OAuthStore
            options = argparse.ArgumentParser()
            options.add_argument('--id')
            selected = options.parse_args(remainder)
            with acting(args.username) as (gate, principal):
                store = OAuthStore(Path(gate.config['state_directory'])/'oauth')
                if args.command == 'list-client-sessions':
                    print(json.dumps({'sessions': store.sessions()}))
                else:
                    if not selected.id or not re.fullmatch(r'[A-Za-z0-9_-]{43}', selected.id):
                        raise ValueError('Select a listed OAuth session identifier')
                    gate.store.audit(principal, 'oauth_revoke_session', allowed=True, revision=gate.store.read()['revision'])
                    print(json.dumps({'id': selected.id, 'revoked': store.revoke(selected.id)}))
        elif args.command == 'itsm-subject':
            if remainder:parser.error('Unexpected arguments')
            with acting(args.username, internal=False) as (_, principal):
                print(json.dumps({'subject': principal.subject, 'category': principal.category}))
        elif args.command == 'policy':
            policy(args.username, remainder)
        elif args.command == 'pdl':
            pdl(args.username, remainder)
        else:
            if remainder:
                parser.error('Unexpected arguments: ' + ' '.join(remainder))
            if args.command == 'check':
                return check(args.username)
            elif args.command == 'seed':
                seed(args.username)
            else:
                return acceptance(args.username)
        return 0
    except (AccessDenied, ValueError, OSError, KeyError, TypeError, RuntimeError, httpx.HTTPError) as error:
        # No token, directory detail, source response or secret reaches stdout.
        code = error.code if isinstance(error, AccessDenied) else type(error).__name__
        print(json.dumps({'status': 'failed', 'command': args.command, 'code': code,
                          'detail': 'Check service health, private configuration and current LDAP/policy.'}), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
