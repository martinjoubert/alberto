"""Create isolated Ubuntu qualification guests; never mount the developer checkout.

Host-only helper for a Mac with Lima >=2.2.1. The application installer runs in
Ubuntu and does not depend on this helper. Guest disks stay in the private Lima
home, outside the checkout; only configuration receipts are written to .runtime.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
STATE = ROOT/'.runtime/ubuntu-qualification'
IMAGES = {
 '24.04': ('https://cloud-images.ubuntu.com/releases/noble/release-20260926/ubuntu-24.04-server-cloudimg-arm64.img', '1d6bffe64b848468ac97f821d369a4846d983de1800ccf6b5ec8853e85cefc55'),
 '26.04': ('https://cloud-images.ubuntu.com/releases/resolute/release-20260927/ubuntu-26.04-server-cloudimg-arm64.img', '63a93bd5a8d76e33b15ceb5daa3657bd79be804748051ab178e643b0f5da22e7'),
}


def environment():
    env=dict(os.environ)
    # macOS UNIX-domain sockets have a 104-byte path limit.
    env['LIMA_HOME']=os.environ.get('RIE_VM_HOME',str(ROOT.parent/'.data/uq/lima'))
    return env


def executable():
    return os.environ.get('RIE_LIMACTL') or shutil.which('limactl') or str(ROOT.parent/'.tools/lima/v2.2.1/bin/limactl')


def invoke(*args, **kwargs):
    return subprocess.run([executable(), '--tty=false', *map(str,args)],env=environment(),check=True,**kwargs)


def config(name,release,offset):
    if not re.fullmatch(r'rie-u(?:24|26)-[a-z0-9-]{1,24}',name):raise ValueError('Choose a qualification VM name rie-u24-* or rie-u26-*')
    if offset not in (0,10000,20000):raise ValueError('Port offset must be 0, 10000 or 20000')
    if not name.startswith('rie-u'+release[:2]+'-'):raise ValueError('VM name and Ubuntu release disagree')
    url,digest=IMAGES[release]
    text=f'''minimumLimaVersion: 2.2.1
vmType: vz
arch: aarch64
images:
  - location: {url}
    arch: aarch64
    digest: sha256:{digest}
cpus: 8
memory: 16GiB
disk: 80GiB
mounts: []
upgradePackages: false
propagateProxyEnv: false
containerd: {{system: false, user: false}}
user:
  name: dinum
  home: /home/dinum
  uid: 1000
  shell: /bin/bash
  passwordlessSudo: true
ssh: {{loadDotSSHPubKeys: false, forwardAgent: false}}
hostResolver: {{enabled: true}}
'''
    if release=='26.04':text+='param: {internal_netplanOptional: "true"}\n'
    text+='portForwards:\n'
    for guest,host in ((19910,19910),(19950,19950),(18090,18090),(20010,20010),(20050,20050),(8082,18082),(8083,18083)):
        text+=f'  - guestIP: 127.0.0.1\n    guestPort: {guest}\n    hostIP: 127.0.0.1\n    hostPort: {host+offset}\n'
    text+='  - guestIP: 0.0.0.0\n    guestIPMustBeZero: false\n    guestPortRange: [1, 65535]\n    hostPortRange: [1, 65535]\n    proto: any\n    ignore: true\n'
    return text


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=['create','start','stop','info','shell','copy'])
    parser.add_argument('--name',default='rie-u24-manual')
    parser.add_argument('--release',choices=IMAGES,default='24.04')
    parser.add_argument('--port-offset',type=int,default=0)
    parser.add_argument('arguments',nargs='*')
    argv=sys.argv[1:]
    separator=argv.index('--') if '--' in argv else len(argv)
    args=parser.parse_intermixed_args(argv[:separator])
    args.arguments.extend(argv[separator+1:])
    name=args.name
    if not re.fullmatch(r'rie-u(?:24|26)-[a-z0-9-]{1,24}',name):parser.error('Invalid owned VM name')
    STATE.mkdir(parents=True,exist_ok=True,mode=0o700)
    arguments=args.arguments[1:] if args.arguments[:1]==['--'] else args.arguments
    if args.operation=='create':
        destination=STATE/(name+'.yaml')
        value=config(name,args.release,args.port_offset)
        if destination.exists() and destination.read_text()!=value:raise ValueError('Existing VM configuration differs')
        if not destination.exists():destination.write_text(value)
        invoke('start','--name',name,destination)
    elif args.operation in ('start','stop'):invoke(args.operation,name)
    elif args.operation=='info':invoke('list','--json')
    elif args.operation=='shell':invoke('shell','--workdir=/home/dinum',name,*arguments)
    else:
        if len(arguments)!=2:parser.error('copy requires SOURCE TARGET; prefix guest paths with VM_NAME:')
        if not any(value.startswith(name+':') for value in arguments):parser.error('A copy endpoint must belong to the selected VM')
        invoke('copy','--backend=scp',*arguments)


if __name__=='__main__':main()
