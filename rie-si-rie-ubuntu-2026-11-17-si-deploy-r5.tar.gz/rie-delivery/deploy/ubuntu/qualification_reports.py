"""Bounded immutable Allure publications; no tests, Node or network at runtime.

Only an operator-selected ZIP containing report.json and index.html is accepted.
The containing private instance protects host access; the portal mounts the
published directory read-only and checks its own current LDAP authorization.
"""
from __future__ import annotations

from datetime import datetime, timedelta
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import tempfile
import zipfile

MAX_HTML = 32 * 1024 * 1024
MAX_BUNDLE = 24 * 1024 * 1024
MAX_METADATA = 64 * 1024
IDENTIFIER = re.compile(r'[a-z0-9][a-z0-9-]{0,63}\Z')
COUNTS = {'passed', 'failed', 'broken', 'skipped', 'unknown', 'not_qualified'}


def _path(path):
    path = Path(path).absolute()
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('Qualification publication symlinks are forbidden.')
    return path


def read_file(path, limit):
    path = _path(path)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, 'rb') as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError('Qualification input must be a regular file.')
        content = stream.read(limit + 1)
    if len(content) > limit:
        raise ValueError('Qualification publication exceeds its size limit.')
    return content


def metadata(raw):
    if len(raw) > MAX_METADATA:
        raise ValueError('Qualification metadata exceeds its size limit.')
    try:
        row = json.loads(raw)
        if row['schema_version'] != 1 or row['kind'] != 'rie-qualification-report':
            raise ValueError()
        if not isinstance(row['id'], str) or not IDENTIFIER.fullmatch(row['id']):
            raise ValueError()
        for key in ('title', 'environment'):
            if not isinstance(row[key], str) or not 1 <= len(row[key]) <= 200 or any(ord(c) < 32 for c in row[key]):
                raise ValueError()
        at = datetime.fromisoformat(row['created_at'].replace('Z', '+00:00'))
        if at.utcoffset() != timedelta(0):
            raise ValueError()
        counts = row['counts']
        if set(counts) != COUNTS or any(type(v) is not int or not 0 <= v <= 10_000_000 for v in counts.values()) or not sum(counts.values()):
            raise ValueError()
        source = row['source']
        if source['commit'] is not None and (not isinstance(source['commit'], str) or not re.fullmatch(r'[a-f0-9]{40}|[a-f0-9]{64}', source['commit'])):
            raise ValueError()
        if type(source['dirty']) is not bool and source['dirty'] is not None:
            raise ValueError()
        html = row['html']
        if type(html['bytes']) is not int or not 0 < html['bytes'] <= MAX_HTML or not re.fullmatch(r'[a-f0-9]{64}', html['sha256']):
            raise ValueError()
        renderer = row['renderer']
        if renderer['name'] != 'Allure' or not re.fullmatch(r'\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.-]+)?', renderer['version']):
            raise ValueError()
        if renderer.get('plugin', 'allure2') != 'allure2':
            raise ValueError()
    except (ValueError, KeyError, TypeError, AttributeError):
        raise ValueError('Invalid qualification report metadata.') from None
    return row


def validate_html(row, content):
    if len(content) != row['html']['bytes'] or hashlib.sha256(content).hexdigest() != row['html']['sha256']:
        raise ValueError('Qualification HTML does not match its manifest.')
    if b'<head>' not in content:
        raise ValueError('Qualification HTML has no document head.')


def load_bundle(path):
    raw = read_file(path, MAX_BUNDLE)
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            entries = archive.infolist()
            if len(entries) != 2 or {r.filename for r in entries} != {'report.json', 'index.html'}:
                raise ValueError('Only report.json and index.html may be published.')
            for entry in entries:
                mode = entry.external_attr >> 16
                if entry.flag_bits & 1 or stat.S_ISLNK(mode) or entry.is_dir():
                    raise ValueError('Linked or encrypted report entries are forbidden.')
                if entry.file_size > (MAX_METADATA if entry.filename == 'report.json' else MAX_HTML):
                    raise ValueError('Qualification publication exceeds its size limit.')
            report = archive.read('report.json')
            row = metadata(report)
            html = archive.read('index.html')
            validate_html(row, html)
    except (zipfile.BadZipFile, RuntimeError, NotImplementedError):
        raise ValueError('Invalid qualification report archive.') from None
    return row, report, html


def import_report(instance, archive):
    """Validate everything before creating anything; never replace a campaign."""
    row, report, html = load_bundle(archive)
    root = _path(Path(instance) / 'qualification')
    target = _path(root / row['id'])
    if target.exists():
        raise ValueError('This report ID already exists; choose a new campaign ID.')
    root.mkdir(mode=0o755, exist_ok=True)
    # The instance parent remains private (0700). Docker's read-only bind
    # intentionally makes these selected publications readable by uid 10001.
    root.chmod(0o755)
    with tempfile.TemporaryDirectory(prefix='.import-', dir=root) as temporary:
        staging = Path(temporary)
        for name, data in (('report.json', report), ('index.html', html)):
            path = staging/name
            path.write_bytes(data)
            path.chmod(0o444)
        staging.chmod(0o755)
        staging.rename(target)
    return {'id': row['id'], 'counts': row['counts'], 'html_sha256': row['html']['sha256'],
            'services_restarted': False}


def report(root, identifier, *, with_html=False):
    if not isinstance(identifier, str) or not IDENTIFIER.fullmatch(identifier):
        raise ValueError('Unknown qualification report.')
    folder = _path(Path(root)/identifier)
    raw = read_file(folder/'report.json', MAX_METADATA)
    row = metadata(raw)
    if row['id'] != identifier:
        raise ValueError('Qualification report ID differs from its directory.')
    if not with_html:
        return row
    html = read_file(folder/'index.html', MAX_HTML)
    validate_html(row, html)
    return row, raw, html


def catalogue(root):
    root = _path(root)
    if not root.exists():
        return [], 0
    rows, rejected = [], 0
    for number, folder in enumerate(root.iterdir()):
        if number >= 500:
            raise ValueError('Too many stored campaigns; archive older reports explicitly.')
        if folder.name.startswith('.'):
            continue
        try:
            rows.append(report(root, folder.name))
        except (OSError, ValueError):
            rejected += 1
    return sorted(rows, key=lambda r: (r['created_at'], r['id']), reverse=True), rejected


def outcome(row):
    counts = row['counts']
    if counts['failed'] or counts['broken']:
        return 'failed'
    if counts['unknown']:
        return 'incomplete'
    if counts['not_qualified'] or not counts['passed']:
        return 'not_qualified'
    return 'passed_with_skips' if counts['skipped'] else 'passed'


def export_report(root, identifier):
    _, raw, html = report(root, identifier, with_html=True)
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('report.json', raw)
        archive.writestr('index.html', html)
    return stream.getvalue()
