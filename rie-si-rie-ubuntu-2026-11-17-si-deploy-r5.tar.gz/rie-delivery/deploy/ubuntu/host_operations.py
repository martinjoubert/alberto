"""Small host-only operations; never distribute a complete credential inventory."""
from __future__ import annotations

import json
from pathlib import Path
import stat


SERVICES = frozenset({'pdl', 'incidents', 'portal', 'ldap', 'opensearch', 'victoriametrics'})
MAX_ACCOUNTS_BYTES = 128_000


def _private_regular(path):
    path = Path(path)
    for parent in (path, *path.parents):
        if parent.is_symlink():
            raise ValueError('Private credential paths must not contain symlinks.')
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077:
        raise ValueError('The synthetic credential file must be private and regular.')
    return path


def demo_credentials(instance, values, username, output, manager):
    """Export exactly one generated demo user, without printing its password."""
    if values.get('RIE_MODE') != 'demo':
        raise ValueError('Credential export is reserved for the synthetic demo directory.')
    if not isinstance(username, str) or not username or len(username) > 254:
        raise ValueError('Select one synthetic directory username.')
    source = _private_regular(Path(instance) / 'ldap-fixture/private/accounts.json')
    with source.open('rb') as stream:
        raw = stream.read(MAX_ACCOUNTS_BYTES + 1)
    if len(raw) > MAX_ACCOUNTS_BYTES:
        raise ValueError('The synthetic credential inventory exceeds its bound.')
    try:
        rows = json.loads(raw)['users']
        selected = [row for row in rows if row.get('uid') == username]
        if len(selected) != 1 or not isinstance(selected[0]['password'], str) or not selected[0]['password']:
            raise ValueError()
        password = selected[0]['password']
    except (ValueError, KeyError, TypeError, AttributeError):
        raise ValueError('The selected synthetic account is missing or invalid.') from None
    if output is None:
        # Use the selected inventory value rather than arbitrary CLI path text.
        if not all(c.isalnum() or c in '._-' for c in username):
            raise ValueError('Specify a safe private output filename for this account.')
        output = Path(instance) / 'clients' / (username + '.credentials.json')
    output = Path(output).expanduser().absolute()
    if output.exists() or output.is_symlink() or not output.parent.is_dir():
        raise ValueError('Choose a new credential file in an existing private directory.')
    for path in (output.parent, *output.parent.parents):
        if path.is_symlink():
            raise ValueError('The output path must not contain symlinks.')
    if output.resolve().is_relative_to(manager.ROOT.resolve()):
        raise ValueError('Credentials must be saved outside the source checkout.')
    if output.parent.stat().st_mode & 0o077:
        raise ValueError('The credential output directory must be private (0700).')
    manager.write_new(output, json.dumps({'username': username, 'password': password}, ensure_ascii=False) + '\n')
    output.chmod(0o600)
    return {'credentials_file': str(output), 'username': username, 'synthetic': True,
            'share_only_with_holder': True}


STORAGE_SCRIPT = r'''
from pathlib import Path
import json,os,shutil,stat
root=Path('/data')
def total(folder,exclude_hidden=False):
    counts={'files':0,'bytes':0}
    if folder.is_symlink():raise ValueError('State contains a symlink; no traversal performed')
    if not folder.exists():return counts
    for directory,folders,files in os.walk(folder,followlinks=False):
        folders[:]=[name for name in folders if not (exclude_hidden and name.startswith('.'))]
        for name in [*folders,*files]:
            path=Path(directory)/name
            if path.is_symlink():raise ValueError('State contains a symlink; no traversal performed')
        for name in files:
            path=Path(directory)/name
            try:info=path.stat()
            except FileNotFoundError:continue
            if not stat.S_ISREG(info.st_mode):raise ValueError('State contains a special file')
            counts['files']+=1;counts['bytes']+=info.st_size
    return counts
disk=shutil.disk_usage(root)
print(json.dumps({'read_only':True,'disk':{'total_bytes':disk.total,'used_bytes':disk.used,'free_bytes':disk.free},
    'groups':{'pdl_reports':total(root/'pdl/reports'),
              'incident_reports':total(root/'incidents/investigations',True),
              'pdl_continuations':total(root/'pdl/.dialogue'),
              'incident_continuations':total(root/'incidents/investigations/.continuations'),
              'access_policy_audits_and_tokens':total(root/'access')},
    'automatic_deletion':False}))
'''


def run(command, instance, values, manager, *, username=None, output=None, service='pdl', tail=100):
    if command == 'demo-credentials':
        print(json.dumps(demo_credentials(instance, values, username, output, manager), ensure_ascii=False))
    elif command == 'logs':
        if service not in SERVICES or type(tail) is not int or not 1 <= tail <= 10000:
            raise ValueError('Choose a known service and a log tail between 1 and 10000 lines.')
        manager.compose(instance, values, '--profile', 'demo', '--profile', 'demo-ui',
                        'logs', '--no-color', '--timestamps', '--tail', str(tail), service)
    elif command == 'storage':
        result = manager.tool(instance, values, 'python', '-c', STORAGE_SCRIPT, capture=True)
        try:
            payload = json.loads(result.stdout)
            if payload.get('read_only') is not True or payload.get('automatic_deletion') is not False:
                raise ValueError()
        except (ValueError, TypeError, AttributeError):
            raise ValueError('The read-only storage summary is unavailable.') from None
        print(json.dumps(payload, ensure_ascii=False))
    else:
        raise ValueError('Unknown host operation.')
