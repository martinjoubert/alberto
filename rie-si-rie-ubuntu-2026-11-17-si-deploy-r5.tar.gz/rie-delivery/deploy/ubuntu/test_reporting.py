"""Small, dependency-free adapters for qualification results (never runtime).

Allure's documented result-file format is shared by unittest, pytest JUnit and
the browser/native qualification scripts. Conversion does not run a scenario or
invent an execution time. Raw outputs stay in the private qualification tree.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import logging
import math
import os
from pathlib import Path
import re
import stat
import sys
import time
import unittest
import uuid
import xml.etree.ElementTree as ET

STATUSES = frozenset({'passed', 'failed', 'broken', 'skipped', 'unknown'})
MAX_INPUT = 16 * 1024 * 1024
MAX_DIAGNOSTIC = 64 * 1024
TRUNCATED = '\n[TRONQUÉ : limite de 65536 octets par diagnostic]\n'
MASKED = '[MASQUÉ]'
_ASSIGNMENT = re.compile(r'''(?ix)(["']?\b(?:[a-z0-9]+[_-])*(?:password|passwd|pwd|api[-_]?key|access[-_]?token|refresh[-_]?token|mcp[-_]?token|client[-_]?secret|session[-_]?key|authorization|cookie|secret|token|grant|access)\b["']?\s*[:=]\s*)(?:"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|[^\s,;]+)''')


def sanitize_text(value, *, secrets=(), limit=MAX_DIAGNOSTIC):
    """Bound exported diagnostic text and mask known or explicitly supplied secrets.

    This is deliberately a last disclosure guard, not permission to include
    arbitrary environment variables, service payloads or raw host files.
    """
    text = str(value)
    for secret in sorted({str(s) for s in secrets if s}, key=len, reverse=True):
        text = text.replace(secret, MASKED)
    text = re.sub(r'-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----[\s\S]*?(?:-----END (?:[A-Z ]+ )?PRIVATE KEY-----|\Z)', MASKED, text)
    text = re.sub(r'(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/-]+=*', lambda m: m[1]+' '+MASKED, text)
    text = re.sub(r'\bdinum_(?:ut|oa|or)\d+_[A-Za-z0-9_-]+', MASKED, text)
    text = re.sub(r'\b(?:[0-9a-f]{16}|[0-9a-f]{32})\.[0-9a-f]{32}\b', MASKED, text)
    text = re.sub(r'\b(?:glpat-|ghp_|github_pat_|sk-)[A-Za-z0-9_-]{8,}', MASKED, text)
    text = re.sub(r'\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+', MASKED, text)
    text = _ASSIGNMENT.sub(lambda m: m[1]+MASKED, text)
    text = re.sub(r'(?i)\b(https?://)[^\s/@:]+:[^\s/@]+@', lambda m: m[1]+MASKED+'@', text)
    text = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', text)
    data = text.encode('utf-8', errors='replace')
    if len(data) > limit:
        marker = TRUNCATED.encode()
        available = max(0, limit-len(marker))
        first = available//2
        text = (data[:first].decode('utf-8', errors='ignore')+TRUNCATED+
                data[-(available-first):].decode('utf-8', errors='ignore')) if available else TRUNCATED[:limit]
    return text


class _BoundedText(io.TextIOBase):
    """Keep capture memory bounded even for a very verbose failing test."""
    def __init__(self):
        self.head, self.tail, self.size = b'', b'', 0
        self.capacity = MAX_DIAGNOSTIC-len(TRUNCATED.encode())
        self.first = self.capacity//2

    def write(self, text):
        if not isinstance(text, str):
            raise TypeError('Diagnostic output must be text')
        data = text.encode('utf-8', errors='replace')
        self.size += len(data)
        selected = data[:max(0, self.first-len(self.head))]
        self.head += selected
        self.tail = (self.tail+data[len(selected):])[-(self.capacity-self.first):]
        return len(text)

    def getvalue(self):
        return (self.head.decode('utf-8', errors='ignore')+
                (TRUNCATED if self.size > self.capacity else '')+
                self.tail.decode('utf-8', errors='ignore'))

    @property
    def encoding(self):
        return 'utf-8'

    def flush(self):
        pass


class _LogCapture(logging.Handler):
    def __init__(self, target):
        super().__init__()
        self.target = target
        self.setFormatter(logging.Formatter('%(levelname)s %(name)s: %(message)s'))

    def emit(self, record):
        try:
            self.target.write(self.format(record)+'\n')
        except Exception:
            self.handleError(record)


def _clean_steps(steps, secrets):
    """Clean visible step text without changing statuses or measured timings."""
    output = []
    for step in steps:
        row = dict(step)
        if 'name' in row:
            row['name'] = sanitize_text(row['name'], secrets=secrets)
        if 'statusDetails' in row:
            row['statusDetails'] = {key: sanitize_text(value, secrets=secrets)
                if isinstance(value, str) else value for key, value in row['statusDetails'].items()}
        if 'steps' in row:
            row['steps'] = _clean_steps(row['steps'], secrets)
        output.append(row)
    return output


def private_directory(path):
    path = Path(path).absolute()
    if path.is_symlink():
        raise ValueError('Symlink report directory refused')
    # macOS exposes /var and /tmp as system aliases. Canonicalize the chosen
    # parent, while refusing a redirected report directory itself.
    path = path.resolve()
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not path.is_dir():
        raise ValueError('Report destination must be a directory')
    return path


def _read(path):
    descriptor = os.open(Path(path), os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, 'rb') as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError('Report input must be a regular file')
        data = stream.read(MAX_INPUT + 1)
    if len(data) > MAX_INPUT:
        raise ValueError('Report input is too large')
    return data


def _new(path, data):
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, 'wb') as stream:
        stream.write(data)


def write_result(directory, suite, name, status, *, start=None, stop=None,
                 message='', trace='', steps=(), attachments=(), labels=(), description='',
                 diagnostics=None, secrets=()):
    """Write one actual observation, with only explicitly supplied timing/data.

    ``start``/``stop`` are Unix milliseconds. File attachments are explicitly
    selected PNGs. ``diagnostics`` supplies text, not file paths or a directory.
    """
    if status not in STATUSES or not isinstance(name, str) or not name:
        raise ValueError('Invalid test result')
    if (start is None) != (stop is None) or start is not None and (
            type(start) is not int or type(stop) is not int or start < 0 or stop < start):
        raise ValueError('Invalid execution timestamps')
    directory = private_directory(directory)
    identifier = str(uuid.uuid4())
    full_name = suite + '.' + name
    result = {'uuid': identifier, 'name': sanitize_text(name, secrets=secrets),
              'fullName': sanitize_text(full_name, secrets=secrets),
              'historyId': hashlib.sha256(full_name.encode()).hexdigest(),
              'testCaseId': hashlib.sha256(full_name.encode()).hexdigest(),
              'status': status, 'stage': 'finished',
              'labels': [{'name': 'parentSuite', 'value': 'SI-RIE'},
                         {'name': 'suite', 'value': suite},
                         {'name': 'language', 'value': 'python'}, *labels],
              'steps': _clean_steps(steps, secrets), 'attachments': []}
    if start is not None:
        result.update(start=start, stop=stop)
    if description:
        result['description'] = sanitize_text(description, secrets=secrets)
    if message or trace:
        result['statusDetails'] = {'message': sanitize_text(message, secrets=secrets),
                                   'trace': sanitize_text(trace, secrets=secrets)}
    for path in attachments:
        path = Path(path)
        data = _read(path)
        if path.suffix.lower() != '.png' or not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('Only explicitly selected PNG captures are attached')
        target = str(uuid.uuid4()) + '-attachment.png'
        _new(directory/target, data)
        result['attachments'].append({'name': path.name, 'source': target, 'type': 'image/png'})
    for channel, content in (diagnostics or {}).items():
        if not content:
            continue
        if not isinstance(content, str):
            raise ValueError('Diagnostic attachments must be explicitly supplied text')
        target = str(uuid.uuid4())+'-attachment.txt'
        _new(directory/target, sanitize_text(content, secrets=secrets).encode('utf-8'))
        result['attachments'].append({'name': sanitize_text(channel, secrets=secrets, limit=200),
                                      'source': target, 'type': 'text/plain'})
    _new(directory/(identifier+'-result.json'),
         (json.dumps(result, ensure_ascii=False, indent=2)+'\n').encode())
    return result


class Campaign:
    """Durable broken sentinel until a caller has recorded its final verdict.

    A killed process cannot remove this sentinel. ``finish`` only removes this
    object's own result, never any neighbouring test, log or capture.
    """
    def __init__(self, directory, suite, description='', *, secrets=()):
        self.directory = private_directory(directory)
        self.secrets = tuple(secrets)
        self.started = time.time_ns()//1_000_000
        self.row = write_result(self.directory, suite, 'Campagne non terminée', 'broken',
            message='La campagne n’a pas encore enregistré son verdict final.',
            description=description, secrets=self.secrets,
            labels=[{'name': 'reporting', 'value': 'campaign-incomplete'}])
        self.path = self.directory/(self.row['uuid']+'-result.json')
        self.row['fullName'] += '.'+self.row['uuid']
        identity = hashlib.sha256(self.row['fullName'].encode()).hexdigest()
        self.row['historyId'] = self.row['testCaseId'] = identity
        self.finished = False
        self.row['start'] = self.started  # No stop timestamp is manufactured.
        self.checkpoint('Démarrage de la campagne')

    def checkpoint(self, message, *, secrets=()):
        if self.finished:
            raise ValueError('The campaign is already finished')
        self.row['statusDetails'] = {
            'message': sanitize_text('Campagne non terminée — '+str(message), secrets=(*self.secrets, *secrets)),
            'trace': 'Dernier point de contrôle mesuré : '+str(time.time_ns()//1_000_000)+' ms UTC.'}
        temporary = self.directory/('.'+self.row['uuid']+'-'+uuid.uuid4().hex+'.tmp')
        try:
            _new(temporary, (json.dumps(self.row, ensure_ascii=False, indent=2)+'\n').encode())
            os.replace(temporary, self.path)
        finally:
            temporary.unlink(missing_ok=True)

    def finish(self):
        if not self.finished:
            self.path.unlink()
            self.finished = True


class ReportingResult(unittest.TextTestResult):
    """Retain unittest's semantics, including subtests and fixture failures."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []
        self.current = None
        self._capture_state = None
        self._capture_targets = []
        self._fixture_diagnostics = {}

    def _setupStdout(self):
        if self._capture_state is not None:
            return
        channels = {name: _BoundedText() for name in ('stdout', 'stderr', 'logs')}
        handler = _LogCapture(channels['logs'])
        self._capture_state = (sys.stdout, sys.stderr, channels, handler)
        self._capture_targets = [self.current] if self.current is not None else []
        self._stdout_buffer, self._stderr_buffer = channels['stdout'], channels['stderr']
        sys.stdout, sys.stderr = channels['stdout'], channels['stderr']
        logging.getLogger().addHandler(handler)

    def _restoreStdout(self):
        if self._capture_state is None:
            return
        stdout, stderr, channels, handler = self._capture_state
        sys.stdout, sys.stderr = stdout, stderr
        logging.getLogger().removeHandler(handler)
        diagnostics = {name: value.getvalue() for name, value in channels.items() if value.getvalue()}
        if self._capture_targets:
            for target in self._capture_targets:
                target.setdefault('diagnostics', {}).update(diagnostics)
        else:
            self._fixture_diagnostics.update({'fixture '+key: value for key, value in diagnostics.items()})
        if not self.buffer or self._mirrorOutput:
            for name, stream in (('stdout', stdout), ('stderr', stderr)):
                if name in diagnostics:
                    stream.write(sanitize_text(diagnostics[name]))
                    stream.flush()
        self._mirrorOutput = False
        self._capture_state = None
        self._capture_targets = []
        self._stdout_buffer = self._stderr_buffer = None

    def stopTestRun(self):
        try:
            self._restoreStdout()
        finally:
            super().stopTestRun()

    def startTest(self, test):
        self.current = {'name': test.id(), 'status': 'passed',
                        'start': time.time_ns()//1_000_000,
                        'clock': time.monotonic(), 'steps': [], 'message': '', 'trace': '',
                        'completed': False, 'diagnostics': self._fixture_diagnostics}
        self._fixture_diagnostics = {}
        super().startTest(test)

    def _outcome(self, test, status, message='', trace=''):
        if self.current is None:  # setUpClass/setUpModule errors use _ErrorHolder.
            row = {'name': test.id(), 'status': status, 'duration': 0.0,
                   'message': message, 'trace': trace, 'steps': []}
            self.records.append(row)
            self._capture_targets.append(row)
        else:
            self.current['completed'] = True
            rank = {'passed': 0, 'skipped': 1, 'failed': 2, 'broken': 3}
            if rank[status] >= rank[self.current['status']]:
                self.current.update(status=status, message=message, trace=trace)

    def addSuccess(self, test):
        super().addSuccess(test)
        if self.current is not None:
            self.current['completed'] = True

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self._outcome(test, 'failed', str(err[1]), self._exc_info_to_string(err, test))

    def addError(self, test, err):
        super().addError(test, err)
        self._outcome(test, 'broken', str(err[1]), self._exc_info_to_string(err, test))

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        if self.current is not None and test.id() != self.current['name']:
            self.current['steps'].append({'name': test.id(), 'status': 'skipped', 'stage': 'finished',
                                          'statusDetails': {'message': str(reason)}})
        self._outcome(test, 'skipped', str(reason))

    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err)
        self._outcome(test, 'skipped', 'Expected failure', self._exc_info_to_string(err, test))

    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test)
        self._outcome(test, 'failed', 'Unexpected success of an expected failure')

    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        status = 'passed' if err is None else ('failed' if issubclass(err[0], test.failureException) else 'broken')
        step = {'name': subtest.id(), 'status': status, 'stage': 'finished'}
        if err is not None:
            step['statusDetails'] = {'message': str(err[1]), 'trace': self._exc_info_to_string(err, test)}
            self._outcome(test, status, str(err[1]), self._exc_info_to_string(err, test))
        self.current['steps'].append(step)

    def stopTest(self, test):
        if self.current is not None:
            record = self.current
            if not record.pop('completed'):
                record.update(status='broken', message='Test interrupted before an outcome was recorded')
            record['duration'] = max(0.0, time.monotonic()-record.pop('clock'))
            record['stop'] = record['start'] + round(record['duration']*1000)
            self.records.append(record)
            self.current = None
        super().stopTest(test)


def write_unittest(result, suite, xml_path, allure_directory):
    """Produce matching JUnit/Allure outputs; zero collected tests is an error."""
    records = result.records
    if not records:
        records = [{'name': 'collection', 'status': 'broken', 'duration': 0.0,
                    'message': 'No test was collected', 'steps': [],
                    'diagnostics': getattr(result, '_fixture_diagnostics', {})}]
    counts = {status: sum(row['status'] == status for row in records) for status in STATUSES}
    root = ET.Element('testsuite', name=suite, tests=str(len(records)),
                      failures=str(counts['failed']), errors=str(counts['broken']+counts['unknown']),
                      skipped=str(counts['skipped']), time=f"{sum(row['duration'] for row in records):.6f}")
    for row in records:
        name = row['name']
        node = ET.SubElement(root, 'testcase', classname=name.rpartition('.')[0] or suite,
                             name=name.rpartition('.')[2], time=f"{row['duration']:.6f}")
        kind = {'failed': 'failure', 'broken': 'error', 'unknown': 'error', 'skipped': 'skipped'}.get(row['status'])
        if kind:
            ET.SubElement(node, kind, message=sanitize_text(row.get('message', ''))).text = sanitize_text(row.get('trace', ''))
        for channel in ('stdout', 'stderr'):
            captured = row.get('diagnostics', {}).get(channel)
            if captured:
                ET.SubElement(node, 'system-out' if channel == 'stdout' else 'system-err').text = sanitize_text(captured)
        write_result(allure_directory, suite, name, row['status'], start=row.get('start'),
                     stop=row.get('stop'), message=row.get('message', ''), trace=row.get('trace', ''),
                     steps=row.get('steps', ()), diagnostics=row.get('diagnostics'),
                     labels=[{'name': 'framework', 'value': 'unittest'}])
    path = Path(xml_path)
    private_directory(path.parent)
    _new(path, ET.tostring(root, encoding='utf-8', xml_declaration=True))
    return bool(result.wasSuccessful() and result.testsRun and records
                and not counts['failed'] and not counts['broken'] and not counts['unknown'])


def convert_junit(path, directory, suite):
    """Convert pytest JUnit without accepting a truncated or inconsistent suite.

    JUnit only guarantees a duration for each test, not its execution timestamp.
    Duration remains in the description; no artificial timeline is manufactured.
    """
    raw = _read(path)
    if b'<!DOCTYPE' in raw or b'<!ENTITY' in raw:
        raise ValueError('DTD/entity declarations are refused')
    root = ET.fromstring(raw)
    suites = list(root.iter('testsuite')) if root.tag == 'testsuites' else [root]
    if not suites or any(node.tag != 'testsuite' for node in suites):
        raise ValueError('A JUnit testsuite is required')
    cases = []
    for node in suites:
        children = list(node.findall('testcase'))
        try:
            expected = int(node.attrib['tests'])
            declared_failures = int(node.get('failures', '0'))
            declared_errors = int(node.get('errors', '0'))
            declared_skipped = int(node.get('skipped', '0'))
        except (KeyError, ValueError):
            raise ValueError('Invalid JUnit counters') from None
        if expected != len(children) or min(expected, declared_failures, declared_errors, declared_skipped) < 0:
            raise ValueError('JUnit collection is incomplete')
        actual = {tag: sum(bool(child.findall(tag)) for child in children) for tag in ('failure', 'error', 'skipped')}
        if (declared_failures, declared_errors, declared_skipped) != (actual['failure'], actual['error'], actual['skipped']):
            raise ValueError('JUnit outcome counters differ')
        for child in children:
            name = child.get('name', '')
            if not name:
                raise ValueError('Unnamed JUnit case')
            duration = float(child.get('time', '0'))
            if not math.isfinite(duration) or duration < 0:
                raise ValueError('Invalid JUnit duration')
            failures = [item for item in child if item.tag in {'failure', 'error', 'skipped'}]
            if len(failures) > 1:
                raise ValueError('Conflicting JUnit outcomes')
            failure = failures[0] if failures else None
            status = {'failure': 'failed', 'error': 'broken', 'skipped': 'skipped'}.get(failure.tag, 'passed') if failure is not None else 'passed'
            cases.append({'name': child.get('classname', suite)+'.'+name, 'status': status,
                          'duration': duration, 'message': failure.get('message', '') if failure is not None else '',
                          'trace': ''.join(failure.itertext()) if failure is not None else ''})
    if not cases:
        raise ValueError('No test was collected')
    for case in cases:
        labels = [{'name': 'framework', 'value': 'pytest-junit'}]
        # Per-case start is not in pytest JUnit. Retain only the measured duration
        # as a parameter instead of manufacturing a sequential test timeline.
        write_result(directory, suite, case['name'], case['status'],
                     message=case['message'], trace=case['trace'], labels=labels,
                     description='Durée JUnit mesurée : '+f"{case['duration']:.6f}"+' s. Horodatage individuel non mesuré.')
    return {status: sum(case['status'] == status for case in cases) for status in STATUSES}


class PytestResults:
    """Explicit pytest hook: no plugin autoload and actual phase timestamps."""

    def __init__(self, directory, suite):
        self.directory, self.suite, self.records = directory, suite, {}
        self.finished = False
        self._exceptions = {}

    def pytest_runtest_makereport(self, item, call):
        """Observe the real exception without replacing pytest's own report."""
        if call.excinfo is not None:
            error = call.excinfo.value
            assertion = isinstance(error, AssertionError) or (
                type(error).__name__ == 'Failed' and type(error).__module__ == '_pytest.outcomes')
            self._exceptions[(item.nodeid, call.when)] = 'failed' if assertion else 'broken'
        return None

    @staticmethod
    def _capture_sections(row, report):
        seen = row.setdefault('_seen_sections', set())
        channels = row.setdefault('_channels', {})
        for name, content in getattr(report, 'sections', ()):
            channel = next((key for key in ('stdout', 'stderr', 'log') if name.lower().startswith('captured '+key)), None)
            if channel is None or not content:
                continue
            content = sanitize_text(content)
            identity = (name, hashlib.sha256(content.encode()).hexdigest())
            if identity in seen:
                continue
            seen.add(identity)
            key = 'logs' if channel == 'log' else channel
            target = channels.setdefault(key, _BoundedText())
            target.write('['+name+']\n'+content+'\n')

    def pytest_runtest_logreport(self, report):
        row = self.records.setdefault(report.nodeid, {'status': 'passed', 'steps': [],
            'start': round(report.start*1000), 'stop': round(report.stop*1000), 'phases': set()})
        row.setdefault('phases', set()).add(report.when)
        self._capture_sections(row, report)
        row['start'] = min(row['start'], round(report.start*1000))
        row['stop'] = max(row['stop'], round(report.stop*1000))
        status = (self._exceptions.get((report.nodeid, report.when), 'failed')
                  if report.when == 'call' else 'broken') if report.failed else ('skipped' if report.skipped else 'passed')
        step = {'name': report.when, 'status': status, 'stage': 'finished',
                'start': round(report.start*1000), 'stop': round(report.stop*1000)}
        if status != 'passed':
            detail = report.longreprtext
            step['statusDetails'] = {'message': detail, 'trace': detail}
            # A later teardown skip must never hide a prior failure/error.
            rank = {'passed': 0, 'skipped': 1, 'failed': 2, 'broken': 3}
            if rank[status] >= rank[row['status']]:
                row.update(status=status, message=detail, trace=detail)
        row['steps'].append(step)

    def pytest_collectreport(self, report):
        if report.failed:
            self.records['collection:'+report.nodeid] = {'status': 'broken', 'steps': [],
                'message': report.longreprtext, 'trace': report.longreprtext}
            self._capture_sections(self.records['collection:'+report.nodeid], report)

    def finish(self):
        if self.finished:
            return self._counts()
        if not self.records:
            self.records['collection'] = {'status': 'broken', 'steps': [], 'message': 'No test was collected'}
        for name, row in self.records.items():
            missing = {'setup', 'call', 'teardown'} - row.get('phases', set())
            if row['status'] == 'passed' and missing:
                row.update(status='broken', message='Incomplete pytest execution: missing '+', '.join(sorted(missing)))
            write_result(self.directory, self.suite, name, row['status'], start=row.get('start'),
                stop=row.get('stop'), steps=row['steps'], message=row.get('message', ''), trace=row.get('trace', ''),
                diagnostics={key: value.getvalue() for key, value in row.get('_channels', {}).items()},
                labels=[{'name': 'framework', 'value': 'pytest'}])
        self.finished = True
        return self._counts()

    def _counts(self):
        return {status: sum(row['status'] == status for row in self.records.values()) for status in STATUSES}


def import_checks(path, directory, suite, *, labels=(), import_type=None, diagnostics=None):
    """Import explicit boolean native/browser checks, retaining their evidence date.

    Only check names and decisions are selected. Raw reports, credentials, source
    payloads and caller-supplied paths are never attached by this conversion.
    """
    raw = _read(path)
    report = json.loads(raw)
    if not isinstance(report, dict):
        raise ValueError('A native report object is required')
    if import_type == 'uc2-acl' and report.get('kind') != 'native-uc2-source-acl':
        raise ValueError('Not a native UC2 ACL receipt')
    if import_type == 'browser' and (type(report.get('synthetic_accounts')) is not bool or not isinstance(report.get('checks'), list)):
        raise ValueError('Not a browser receipt')
    if import_type == 'operations' and (not isinstance(report.get('checks'), dict) or not isinstance(report.get('phases'), dict)):
        raise ValueError('Not an operations receipt')
    checks = report.get('checks')
    if isinstance(checks, dict):
        rows = [{'name': name, 'passed': value} for name, value in checks.items()]
    elif isinstance(checks, list):
        rows = checks
    else:
        raise ValueError('A nonempty explicit checks collection is required')
    if not rows or any(not isinstance(row, dict) or not isinstance(row.get('name'), str) or not row['name']
                       or type(row.get('passed')) is not bool for row in rows):
        raise ValueError('Invalid native check')
    if len({row['name'] for row in rows}) != len(rows):
        raise ValueError('Duplicate native check names are refused')
    if type(report.get('passed')) is not bool or report['passed'] != all(row['passed'] for row in rows):
        raise ValueError('Native report aggregate differs from its checks')
    evidence_date = next((report[key] for key in ('at_utc', 'started_at', 'finished_at') if isinstance(report.get(key), str)), None)
    description = ('Preuve importée, non rejouée. Reçu : '+Path(path).name+'. Date du reçu : '+(evidence_date or 'non fournie')+
                   '. Durée individuelle non mesurée ; aucune durée inventée.')
    for row in rows:
        write_result(directory, suite, row['name'], 'passed' if row['passed'] else 'failed',
                     diagnostics=diagnostics if not row['passed'] else None,
                     description=description, labels=[{'name': 'framework', 'value': 'qualification-json'},
                         {'name': 'evidence', 'value': 'imported-not-replayed'},
                         {'name': 'receiptSha256', 'value': hashlib.sha256(raw).hexdigest()},
                         {'name': 'receiptDate', 'value': evidence_date or 'not-provided'}, *labels])
    return {'passed': sum(row['passed'] for row in rows), 'failed': sum(not row['passed'] for row in rows)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--import-type', choices=('browser', 'uc2-acl', 'operations'), required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--allure-results', type=Path, required=True)
    parser.add_argument('--suite', help='Explicit environment-specific suite name')
    parser.add_argument('--log-file', type=Path, help='Optional explicitly selected UTF-8 log, attached only to failed checks')
    args = parser.parse_args(argv)
    try:
        diagnostics = None
        if args.log_file:
            descriptor = os.open(args.log_file, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(descriptor, 'rb') as stream:
                info = os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode):
                    raise ValueError('The selected log must be a regular text file')
                if info.st_size > MAX_DIAGNOSTIC:
                    available = MAX_DIAGNOSTIC-len(TRUNCATED.encode())
                    head = stream.read(available//2)
                    stream.seek(-(available-available//2), os.SEEK_END)
                    tail = stream.read(available-available//2)
                    text = head.decode('utf-8', errors='replace')+TRUNCATED+tail.decode('utf-8', errors='replace')
                else:
                    text = stream.read(MAX_DIAGNOSTIC).decode('utf-8', errors='replace')
            diagnostics = {'Selected log — '+args.log_file.name: text}
        counts = import_checks(args.input, args.allure_results, args.suite or args.import_type,
                               import_type=args.import_type, diagnostics=diagnostics)
    except (OSError, ValueError, TypeError) as error:
        parser.exit(2, 'ERROR: '+str(error)+'\n')
    print(json.dumps({'imported_receipt': True, 'replayed': False, 'checks': counts}))
    return 0 if not counts['failed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
