"""Qualify live LDAP membership and stable identity on the synthetic directory.

Only the disposable `acl.probe` account is created/changed/deleted. Existing
Alice/Eric accounts and groups' other members are preserved. The fixture root
password crosses Docker stdin only; it never enters arguments or reports.
"""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time

DIRECTORY_BASE='dc=demo,dc=rie,dc=example'
USERNAME='acl.probe'
USER_DN='uid='+USERNAME+',ou=people,'+DIRECTORY_BASE
ADMIN_GROUP_DN='cn=RIE-Administrateurs-Acces,ou=groups,'+DIRECTORY_BASE
GROUP_DNS={'internal':'cn=RIE-Internes,ou=groups,'+DIRECTORY_BASE,
           'external':'cn=RIE-Externes,ou=groups,'+DIRECTORY_BASE}
BODY={'question':'Examiner les mesures et les logs de R1 pendant cette période.','variant':'gptoss','equipment':'OBS-RTR-01',
      'start':'2026-09-28T10:00:00+02:00','end':'2026-09-28T12:00:00+02:00','synthesize':False}
EVIDENCE=('sources','evidence','metrics','logs','events','documents','results')


def fixture_configuration(config,mode):
    ldap=config.get('ldap',{})
    if (mode!='demo' or ldap.get('host')!='ldap' or ldap.get('port')!=1636
            or ldap.get('search_base')!='ou=people,'+DIRECTORY_BASE
            or ldap.get('group_dns')!=GROUP_DNS or ldap.get('administrator_group_dns')!=[ADMIN_GROUP_DN]
            or ldap.get('use_tls') is not True or ldap.get('validate_cert') is not True):
        raise ValueError('Live LDAP mutation is restricted to the exact isolated synthetic directory.')
    return ldap


def structured(body):
    if body.get('error'):return body
    result=body.get('result',{})
    if isinstance(result.get('structuredContent'),dict):return result['structuredContent']
    for row in result.get('content',[]):
        if row.get('type')=='text':
            try:return json.loads(row['text'])
            except ValueError:pass
    return result


def probe(client,token,*,incident=False,forged_header=False):
    headers={'Authorization':'Bearer '+token,'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-11-25'}
    if forged_header:headers['X-OpenWebUI-User-JWT']='client-asserted-internal'
    if incident:
        response=client.post('http://incidents:9950/diagnose',headers=headers,json=BODY)
    else:
        response=client.post('http://pdl:9910/mcp',headers=headers,json={'jsonrpc':'2.0','id':1,'method':'tools/call',
            'params':{'name':'investigate_pdl','arguments':{'question':'Quels sont mes index accessibles ?','continuation_token':''}}})
    body=response.json();value=body if incident else structured(body)
    return {'http_status':response.status_code,'category':value.get('access_control',{}).get('category'),
            'business_status':value.get('status'),'has_evidence':any(value.get(name) for name in EVIDENCE),
            'metric_count':len(value.get('metrics',[])),'analysis_present':value.get('analysis') is not None,
            'source_errors':value.get('errors',[]),
            'generation_usage_present':bool(value.get('usage')),'albert_calls':value.get('execution',{}).get('albert_calls',0),
            'error_code':body.get('error')}


def expected(probed,kind,*,incident=False):
    if kind in {'unclassified','replaced','expired'}:
        denied=probed['http_status']==403 and not probed['has_evidence']
        return denied and (kind!='expired' or probed['error_code']=='expired_or_revoked_user_token')
    if incident:
        # The disposable LDAP probe deliberately has no native ITSM account.
        # Missing individual credentials must stay explicit; this is not an
        # authorization bypass or a reason to substitute Alice's credentials.
        internal_ready=(probed['business_status']=='ok' and not probed.get('source_errors'))
        internal_without_itsm=(probed['business_status']=='partial' and
            probed.get('source_errors')==[{'source':'itsm-ng','code':'individual_credential_missing'}])
        return (probed['http_status']==200 and
                ((internal_ready or internal_without_itsm) and probed['metric_count']==5 if kind=='internal' else
                 probed['business_status']=='denied' and probed['category']=='external' and not probed['has_evidence'])
                and not probed['analysis_present'] and not probed['generation_usage_present'])
    return probed['http_status']==200 and probed['category']==kind and probed['albert_calls']==0 and not probed['has_evidence']


def administration_observation(gate, token, session):
    """Refresh both credential types; return only role decisions, never credentials."""
    result = {}
    for name, credential in (('individual_token', token), ('short_session', session)):
        principal = gate.authenticate({'authorization': 'Bearer '+credential})
        result[name] = {'category': principal.category, 'administrator': principal.administrator}
    return result


def administration_expected(observation, administrator):
    return (set(observation) == {'individual_token', 'short_session'}
            and all(value.get('category') == 'internal' and value.get('administrator') is administrator
                    for value in observation.values()))


def worker(payload):
    import secrets,ssl
    import httpx
    from ldap3 import Server,Connection,Tls,NONE,BASE,MODIFY_ADD,MODIFY_DELETE
    from dinum_access import AccessGate
    from dinum_access.user_tokens import UserTokens
    gate=AccessGate.configured()
    if gate is None:raise ValueError('Explicit access configuration required')
    if gate.config.get('allow_webui_assertions') is not False:
        raise ValueError('Stable server sessions require the user-owned client configuration')
    config=fixture_configuration(gate.config,os.getenv('PDL_MODE'))
    password=payload.get('root_password')
    if not isinstance(password,str) or not 16<=len(password)<=1024:raise ValueError('Private fixture administration credential required')
    tls=Tls(validate=ssl.CERT_REQUIRED,ca_certs_file=config['ca_file'])
    server=Server('ldap',port=1636,use_ssl=True,tls=tls,connect_timeout=5,get_info=NONE)
    connection=Connection(server,user='cn=admin,'+DIRECTORY_BASE,password=password,auto_bind=True,
                          receive_timeout=5,raise_exceptions=True)
    store=UserTokens(gate.config['user_tokens_directory']);records=[];created=False
    account_password=secrets.token_urlsafe(32)
    report={'started_at':datetime.now(timezone.utc).isoformat(),'synthetic':True,'account':USERNAME,
            'albert_calls':0,'steps':[],'checks':{},'passed':False,'expiration_test':'controlled timestamps on a qualification token record; system clock unchanged'}
    def group_membership(group_dn, enabled):
        connection.search(group_dn,'(objectClass=groupOfNames)',BASE,attributes=['member'])
        if len(connection.entries)!=1:raise ValueError('Expected fixture group not found')
        members=connection.entries[0].entry_attributes_as_dict.get('member',[])
        exists=USER_DN.casefold() in {str(value).casefold() for value in members}
        if enabled!=exists:
            operation=MODIFY_ADD if enabled else MODIFY_DELETE
            if not connection.modify(group_dn,{'member':[(operation,[USER_DN])]}):
                raise ValueError('Synthetic membership update failed')
    def membership(internal,external):
        for category,enabled in (('internal',internal),('external',external)):
            group_membership(GROUP_DNS[category],enabled)
    def administrator_membership(enabled):
        group_membership(ADMIN_GROUP_DN,enabled)
    def mark_administration(stage, token, session, administrator):
        observed=administration_observation(gate,token,session)
        passed=administration_expected(observed,administrator)
        report['steps'].append({'stage':stage,'expected_administrator':administrator,
                                'observed_roles':observed,'passed':passed})
        report['checks'][stage]=passed
        if not passed:raise ValueError('A live administration role expectation failed')
    def create():
        if not connection.add(USER_DN,['inetOrgPerson'],{'uid':USERNAME,'cn':'Qualification ACL','sn':'Probe',
            'mail':'acl.probe@rie.example','userPassword':account_password}):
            raise ValueError('Synthetic account creation failed')
    def mark(stage,token,kind,client,*,forged=False):
        pd=probe(client,token,forged_header=forged);inc=probe(client,token,incident=True,forged_header=forged)
        passed=expected(pd,kind) and expected(inc,kind,incident=True)
        report['steps'].append({'stage':stage,'expected':kind,'passed':passed,'pdl':pd,'incidents':inc})
        report['checks'][stage]=passed
        if not passed:raise ValueError('A live ACL expectation failed')
    try:
        connection.search(config['search_base'],'(uid='+USERNAME+')',attributes=['entryUUID'],size_limit=2)
        if connection.entries:raise ValueError('The disposable qualification account already exists; it is not overwritten')
        create();created=True;membership(True,False)
        with tempfile.TemporaryDirectory(prefix='rie-acl-lifecycle-') as private, httpx.Client(timeout=90,trust_env=False) as client:
            path=Path(private)/'original.token';record=store.issue(gate.directory,USERNAME,path,days=1);records.append(record)
            token=path.read_text().strip();original_subject=gate.directory.lookup(USERNAME,username=True,identity=True)[2]
            session=gate.login(USERNAME,account_password)
            mark('internal_identity',token,'internal',client)
            mark('short_session_internal_identity',session,'internal',client)
            mark_administration('internal_reader_is_not_administrator',token,session,False)
            administrator_membership(True)
            mark_administration('same_credentials_gain_only_explicit_administrator_membership',token,session,True)
            mark('administrator_still_uses_current_business_acl',token,'internal',client)
            administrator_membership(False)
            mark_administration('same_credentials_lose_administration_without_relogin',token,session,False)
            mark('internal_reader_keeps_business_access_after_administrator_revocation',token,'internal',client)
            mark('short_session_keeps_business_access_after_administrator_revocation',session,'internal',client)
            membership(False,True)
            mark('same_token_reads_fresh_external_membership',token,'external',client,forged=True)
            mark('same_short_session_reads_fresh_external_membership',session,'external',client)
            membership(True,True)
            mark('ambiguous_double_membership_is_refused',token,'unclassified',client)
            mark('short_session_ambiguous_membership_is_refused',session,'unclassified',client)
            membership(True,False)
            mark('restored_internal_membership_is_effective',token,'internal',client)
            mark('short_session_restored_internal_membership_is_effective',session,'internal',client)
            membership(False,False)
            if not connection.delete(USER_DN):raise ValueError('Synthetic account deletion failed')
            created=False;create();created=True;membership(True,False)
            new_subject=gate.directory.lookup(USERNAME,username=True,identity=True)[2]
            report['checks']['recreated_account_has_a_new_ldap_uuid']=original_subject!=new_subject
            mark('same_uid_new_uuid_rejects_old_token',token,'replaced',client)
            mark('same_uid_new_uuid_rejects_old_short_session',session,'replaced',client)
            previous_session=report['steps'][-1]
            report['checks']['old_short_session_refuses_changed_uuid_on_both_backends']=all(
                previous_session[name]['error_code']=='directory_identity_changed' for name in ('pdl','incidents'))
            mark('new_short_login_for_recreated_identity_works',gate.login(USERNAME,account_password),'internal',client)
            fresh=Path(private)/'new.token';record=store.issue(gate.directory,USERNAME,fresh,days=1);records.append(record)
            mark('new_credential_for_recreated_identity_works',fresh.read_text().strip(),'internal',client)
            expired=Path(private)/'expired.token'
            record=store.issue(gate.directory,USERNAME,expired,days=1);records.append(record)
            expiry_token=expired.read_text().strip()
            mark('expiry_probe_initially_works',expiry_token,'internal',client)
            record_path=store.directory/(record['id']+'.json')
            original=json.loads(record_path.read_text());adjusted={**original,'created_at':int(time.time())-120,'expires_at':int(time.time())-1}
            temporary=record_path.with_name(record_path.name+'.expiry-'+secrets.token_hex(8)+'.tmp')
            store._new_file(temporary,json.dumps(adjusted)+'\n');os.replace(temporary,record_path)
            report['checks']['expiry_keeps_token_hash_and_ldap_identity']=all(original[key]==adjusted[key] for key in ('digest','ldap_subject','username','email'))
            mark('controlled_expiration_is_rejected_by_real_backend',expiry_token,'expired',client)
        report['passed']=bool(report['checks']) and all(report['checks'].values())
    except Exception as error:
        report['passed']=False;report['error_code']=type(error).__name__
    finally:
        for row in records:
            try:store.revoke(row['id'])
            except Exception:report['token_cleanup_failed']=True;report['passed']=False
        if created:
            try:
                administrator_membership(False)
                membership(False,False)
                if not connection.delete(USER_DN):raise ValueError('cleanup')
                report['account_removed']=True
            except Exception:report['account_cleanup_failed']=True;report['passed']=False
        connection.unbind();report['finished_at']=datetime.now(timezone.utc).isoformat()
    return report


def host(instance,output):
    spec=importlib.util.spec_from_file_location('acl_lifecycle_manage',Path(__file__).with_name('manage.py'))
    manager=importlib.util.module_from_spec(spec);spec.loader.exec_module(manager)
    instance=Path(instance).expanduser().resolve();output=Path(output).expanduser().resolve()
    values=manager.load(instance);manager.guard(instance,values)
    if values['RIE_MODE']!='demo' or values.get('RIE_LOAD_QUALIFICATION')=='true':
        raise ValueError('Use the separate non-load synthetic instance only')
    if output.exists() or output.is_relative_to(manager.ROOT):raise ValueError('Choose a new private result directory outside sources')
    credentials=json.loads((instance/'ldap-fixture/private/accounts.json').read_text())
    payload={'root_password':credentials['root_password']}
    output.mkdir(parents=True,mode=0o700)
    # Public Python source is an argument; the private LDAP password is stdin only.
    result=manager.compose(instance,values,'run','--rm','--no-deps','--pull','never','-T','--interactive=true','operator',
                           'python','-c',Path(__file__).read_text(),'worker',capture=True,stdin=None,input=json.dumps(payload))
    report=json.loads(result.stdout)
    destination=output/'report.json';destination.write_text(json.dumps(report,indent=2)+'\n');destination.chmod(0o600)
    print(json.dumps({'passed':report['passed'],'checks':len(report['checks']),'account_removed':report.get('account_removed',False),
                      'report':str(destination)}),flush=True)
    return 0 if report['passed'] else 2


def main():
    os.umask(0o077)
    if len(sys.argv)>1 and sys.argv[1]=='worker':
        try:result=worker(json.load(sys.stdin))
        except Exception as error:result={'passed':False,'error_code':type(error).__name__,'checks':{}}
        print(json.dumps(result),flush=True)
        return 0
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('instance',type=Path);parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    try:return host(args.instance,args.output)
    except Exception as error:
        print(json.dumps({'passed':False,'error_code':type(error).__name__,'detail':'Inspect private directory configuration and the isolated fixture state.'}),file=sys.stderr)
        return 2


if __name__=='__main__':raise SystemExit(main())
