"""Host-only endurance wrapper with private, continuous Docker log capture.

No image or business interface imports this tool. Docker rotation stays enabled;
raw streams stay on the qualification host and never enter an Allure export.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import threading
import time

NAME = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}\Z')
DEFAULT_LIMIT = 512 * 1024 * 1024


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    temporary = path.with_suffix('.tmp')
    with temporary.open('w', encoding='utf-8') as stream:
        os.chmod(temporary, 0o600)
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


class Capture:
    """Stream to files without buffering logs in Python; fail on premature EOF."""

    def __init__(self, output, names, *, docker=('docker',), max_bytes=DEFAULT_LIMIT):
        self.output = Path(output).expanduser().absolute()
        self.names = tuple(names)
        if not self.names or len(set(self.names)) != len(self.names) or any(not NAME.fullmatch(n) for n in self.names):
            raise ValueError('Select distinct Docker container names without paths or options')
        if type(max_bytes) is not int or max_bytes < 1:
            raise ValueError('A positive log byte limit is required')
        if self.output.exists() or self.output.is_symlink() or any(p.is_symlink() for p in self.output.parents):
            raise ValueError('Choose a new log directory without symlinks')
        self.docker, self.limit = tuple(docker), max_bytes
        self.processes, self.files, self.errors = {}, {}, {}
        self.event, self.thread = threading.Event(), None
        self.report = {'schema_version': 1, 'status': 'incomplete', 'passed': False,
                       'started_at': now(), 'max_bytes': max_bytes, 'containers': list(self.names),
                       'raw_logs_private': True, 'errors': [], 'logs': {}}

    def checkpoint(self):
        self.report['errors'] = list(self.errors.values())
        write_json(self.output/'report.json', self.report)

    def observe(self):
        total = 0
        for name, process in self.processes.items():
            if process.poll() is not None:
                self.errors.setdefault(name, {'container': name, 'code': 'stream_ended_before_stop',
                                              'exit_code': process.returncode})
            try:
                total += (self.output/(name+'.log')).stat().st_size
            except OSError:
                self.errors.setdefault('files', {'code': 'capture_file_unavailable'})
        if total > self.limit:
            self.errors.setdefault('limit', {'code': 'log_byte_limit_exceeded', 'observed_bytes': total})
            for process in self.processes.values():
                if process.poll() is None:
                    process.terminate()
            self.event.set()
        if self.errors:
            self.checkpoint()

    def watch(self):
        while not self.event.wait(.25):
            self.observe()

    def start(self):
        self.output.mkdir(parents=True, mode=0o700)
        self.checkpoint()  # A killed qualification keeps an incomplete verdict.
        try:
            state = subprocess.check_output([*self.docker, 'inspect', '--format', '{{.State.Running}}',
                                             *self.names], text=True, stderr=subprocess.DEVNULL)
            if state.splitlines() != ['true'] * len(self.names):
                raise ValueError('All selected log containers must be running')
            since = (datetime.now(timezone.utc)-timedelta(seconds=5)).isoformat()
            self.report['since'] = since
            for name in self.names:
                descriptor = os.open(self.output/(name+'.log'), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
                stream = os.fdopen(descriptor, 'wb')
                self.files[name] = stream
                self.processes[name] = subprocess.Popen(
                    [*self.docker, 'logs', '--follow', '--timestamps', '--since', since, name],
                    stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
                    start_new_session=True)
            time.sleep(.2)
            self.observe()
            if self.errors:
                raise RuntimeError('Log stream ended before the workload started')
            self.checkpoint()
            self.thread = threading.Thread(target=self.watch, name='qualification-logs', daemon=True)
            self.thread.start()
            return self
        except BaseException as error:
            self.errors.setdefault('start', {'code': 'capture_start_failed', 'error_type': type(error).__name__})
            self.stop(completed=False)
            raise

    def stop(self, *, completed):
        self.event.set()
        if self.thread:
            self.thread.join(timeout=5)
        self.observe()
        for name, process in self.processes.items():
            if process.poll() is None:
                process.terminate()  # Stop only the Docker log client, never the container.
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
            stream = self.files[name]
            stream.flush()
            os.fsync(stream.fileno())
            stream.close()
            path = self.output/(name+'.log')
            digest = hashlib.sha256()
            with path.open('rb') as source:
                for chunk in iter(lambda: source.read(1024*1024), b''):
                    digest.update(chunk)
            self.report['logs'][name] = {'file': path.name, 'bytes': path.stat().st_size,
                                        'sha256': digest.hexdigest(), 'client_exit_code': process.returncode}
        for stream in self.files.values():
            if not stream.closed:
                stream.close()
        total = sum(row['bytes'] for row in self.report['logs'].values())
        if total > self.limit:
            self.errors.setdefault('limit', {'code': 'log_byte_limit_exceeded', 'observed_bytes': total})
        self.report.update(finished_at=now(), status='complete' if completed else 'incomplete',
                           passed=bool(completed and not self.errors and len(self.processes)==len(self.names)))
        self.checkpoint()
        return self.report


def run(instance, output, duration=7200, period=5, extra=(), *, manager=None, runner=None, capture_type=Capture):
    if manager is None:
        import manage as manager
    if runner is None:
        from qualification import host_endurance as runner
    instance, output = Path(instance).resolve(), Path(output).expanduser().absolute()
    values = manager.load(instance)
    if (values.get('RIE_MODE') != 'demo' or values.get('RIE_LOAD_QUALIFICATION') != 'true'
            or values.get('RIE_SIMULATED_ALBERT') != 'true'):
        raise ValueError('Use the separate, explicitly simulated load instance')
    if output.exists() or output.is_symlink() or output.resolve().is_relative_to(manager.ROOT):
        raise ValueError('Choose a new private output directory outside source checkout')
    if duration < 3 or period < 5:
        raise ValueError('Duration >=3s and request period >=5s required')
    manager.guard(instance, values)
    names = [values['RIE_PROJECT']+'-'+s+'-1' for s in ('pdl','incidents','opensearch','victoriametrics','ldap')]
    names += list(extra)
    output.mkdir(parents=True, mode=0o700)
    capture = capture_type(output/'logs', names, docker=(os.getenv('RIE_DOCKER', 'docker'),))
    report = {'status': 'incomplete', 'passed': False, 'started_at': now(),
              'kind': 'endurance' if duration >= 7200 else 'smoke', 'actual_albert_calls': 0}
    write_json(output/'report.json', report)
    completed, code = False, 2
    try:
        capture.start()
        code = runner(instance, output/'endurance', duration, period)
        completed = True
        time.sleep(1)  # Retain trailing source access-log lines after the final response.
    except (Exception, KeyboardInterrupt) as error:
        report['error_code'] = type(error).__name__
        code = 130 if isinstance(error, KeyboardInterrupt) else 2
    finally:
        # start() already closes partially started streams if it raises.
        logs = capture.stop(completed=completed) if completed or capture.thread else capture.report
    workload = output/'endurance/report.json'
    observed = json.loads(workload.read_text()) if workload.is_file() else {}
    checks = {'workload_completed': completed, 'workload_passed': code == 0 and observed.get('passed') is True,
              'continuous_log_clients_completed': logs.get('passed') is True}
    report.update(finished_at=now(), status='complete' if completed else 'incomplete',
                  checks=checks, passed=all(checks.values()), workload_report='endurance/report.json',
                  private_log_report='logs/report.json')
    write_json(output/'report.json', report)
    print(json.dumps({'passed': report['passed'], 'kind': report['kind'], 'output': str(output), 'checks': checks}), flush=True)
    return 0 if report['passed'] else code or 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('instance', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--duration', type=int, default=7200)
    parser.add_argument('--period', type=float, default=5)
    parser.add_argument('--log-container', action='append', default=[], help='Additional local source container, e.g. native ITSM API/DB')
    args = parser.parse_args()
    os.umask(0o077)
    return run(args.instance, args.output, args.duration, args.period, args.log_container)


if __name__ == '__main__':
    raise SystemExit(main())
