"""Loopback-only deterministic provider for isolated transport-failure recipes.

The fixture never logs or retains authorization headers, prompts or raw request
bodies. It supports only the packaged synthetic planner questions; it is not a
model substitute for real-provider qualification and never retries requests.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
from threading import Lock
import time
from urllib.parse import urlsplit

MAX_BODY = 1_048_576
STAGES = {'classification', 'planner', 'draft', 'review', 'all'}
MODES = {'success', 'http500', 'http429', 'invalid_json', 'timeout'}


def json_bytes(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()


def user_object(payload):
    if not isinstance(payload, dict) or not isinstance(payload.get('messages'), list):
        raise ValueError('invalid_request')
    for message in reversed(payload['messages']):
        if isinstance(message, dict) and message.get('role') == 'user':
            content = message.get('content')
            if not isinstance(content, str):
                raise ValueError('invalid_request')
            try:
                value = json.loads(content)
            except ValueError:
                # Diagnostic correction prompts can append a bounded reminder.
                value, _ = json.JSONDecoder().raw_decode(content.lstrip())
            if not isinstance(value, dict):
                raise ValueError('invalid_request')
            return value
    raise ValueError('invalid_request')


def classify_stage(payload):
    if not isinstance(payload, dict):
        raise ValueError('invalid_request')
    schema = (payload.get('response_format') or {}).get('json_schema') or {}
    if isinstance(schema, dict) and schema.get('name') in {'diagnostic', 'review'}:
        return 'draft' if schema['name'] == 'diagnostic' else 'review'
    request = user_object(payload)
    if 'current_message' in request:
        return 'classification'
    if 'question' in request:
        return 'planner'
    raise ValueError('unsupported_fixture_request')


def bundled_plans():
    from rie_agent.acceptance import FIXTURE_PATH, scenarios
    fixture = json.loads(FIXTURE_PATH.read_text())
    return {case['question']: deepcopy(case['proposal']) for case in scenarios(fixture)}


class Fixture:
    def __init__(self, *, plans=None, sleeper=time.sleep, clock=time.time):
        self._plans = plans
        self.sleeper, self.clock = sleeper, clock
        self.lock = Lock()
        self.mode, self.stage, self.delay = 'success', 'all', 35.0
        self.counts = {stage: 0 for stage in STAGES if stage != 'all'}
        self.attempts = []

    def control(self, value):
        if not isinstance(value, dict) or set(value) - {'mode', 'stage', 'delay_seconds'}:
            raise ValueError('invalid_control')
        mode, stage, delay = value.get('mode'), value.get('stage', 'all'), value.get('delay_seconds', 35)
        if mode not in MODES or stage not in STAGES or type(delay) not in (int, float) or not math.isfinite(delay) or not 1 <= delay <= 75:
            raise ValueError('invalid_control')
        with self.lock:
            self.mode, self.stage, self.delay = mode, stage, float(delay)
            self.counts = {name: 0 for name in self.counts}
            self.attempts = []
        return self.stats()

    def stats(self):
        with self.lock:
            return {'rie_simulation': True, 'mode': self.mode, 'stage': self.stage,
                    'delay_seconds': self.delay, 'counts': dict(self.counts),
                    'attempts': [dict(row) for row in self.attempts], 'requests': sum(self.counts.values())}

    def _content(self, payload, stage):
        if stage == 'classification':
            request = user_object(payload)
            current = request.get('current_message')
            if not isinstance(current, str):
                raise ValueError('invalid_request')
            retry = request.get('prior_request') is not None and current.strip().casefold() == 'tu peux recommencer ?'
            return {'action': 'retry' if retry else 'new', 'confidence': 1.0,
                    'clarification': '', 'source_change': 'unchanged'}
        if stage == 'planner':
            question = user_object(payload).get('question')
            if not isinstance(question, str):
                raise ValueError('unsupported_fixture_question')
            if self._plans is None:
                self._plans = bundled_plans()
            if question.startswith('PDL_DIALOGUE\n'):
                # Only replay an unchanged bundled request. This fixture cannot
                # infer a changed filter or pretend to interpret a conversation.
                context = json.loads(question.split('\n', 1)[1])
                if (not isinstance(context, dict) or set(context) - {'request', 'replies', 'source_start'}
                        or context.get('source_start', 0) != 0
                        or not isinstance(context.get('replies'), list)
                        or not 1 <= len(context['replies']) <= 12
                        or any(not isinstance(reply, str) or reply.strip().casefold() != 'tu peux recommencer ?'
                               for reply in context['replies'])):
                    raise ValueError('unsupported_fixture_question')
                question = context.get('request')
            if not isinstance(question, str):
                raise ValueError('unsupported_fixture_question')
            if question not in self._plans:
                raise ValueError('unsupported_fixture_question')
            return deepcopy(self._plans[question])
        if stage == 'draft':
            return {'situation': 'Les faits du corpus de qualification sont présentés dans les preuves ; la cause reste à confirmer.',
                    'hypotheses': [], 'verifications': []}
        return {'valid': True, 'reason': 'Réponse contrôlée du fournisseur fictif de qualification.'}

    def completion(self, payload):
        stage = classify_stage(payload)
        with self.lock:
            mode = self.mode if self.stage in {'all', stage} else 'success'
            delay = self.delay
            self.counts[stage] += 1
            self.attempts.append({'stage': stage, 'mode': mode, 'sequence': sum(self.counts.values())})
        if mode == 'http500':
            return 500, {}, json_bytes({'error': {'type': 'qualification_provider_failure'}})
        if mode == 'http429':
            return 429, {'Retry-After': '3'}, json_bytes({'error': {'type': 'qualification_rate_limit'}})
        if mode == 'invalid_json':
            return 200, {}, b'{"choices": ['
        if mode == 'timeout':
            self.sleeper(delay)
        content = self._content(payload, stage)
        model = payload.get('model', 'qualification-fixture')
        if not isinstance(model, str) or not model or len(model) > 128:
            raise ValueError('invalid_model')
        return 200, {}, json_bytes({'id': 'qualification-fixture', 'object': 'chat.completion',
            'created': int(self.clock()), 'model': model, 'rie_simulation': True,
            'choices': [{'index': 0, 'message': {'role': 'assistant', 'content': json.dumps(content, ensure_ascii=False)},
                         'finish_reason': 'stop'}],
            'usage': {'prompt_tokens': 0, 'completion_tokens': 0, 'total_tokens': 0}})

    def dispatch(self, method, path, payload=None):
        path = urlsplit(path).path
        try:
            if method == 'GET' and path == '/healthz':
                return 200, {}, json_bytes({'status': 'ok', 'rie_simulation': True})
            if method == 'GET' and path in {'/models', '/v1/models'}:
                return 200, {}, json_bytes({'object': 'list', 'rie_simulation': True,
                    'data': [{'id': value, 'object': 'model'} for value in ('qualification-fixture', 'gpt-oss-120b')]})
            if method == 'GET' and path == '/stats':
                return 200, {}, json_bytes(self.stats())
            if method == 'POST' and path == '/control':
                return 200, {}, json_bytes(self.control(payload))
            if method == 'POST' and path in {'/chat/completions', '/v1/chat/completions'}:
                return self.completion(payload)
            return 404, {}, json_bytes({'error': {'type': 'not_found'}})
        except (ValueError, KeyError, TypeError, AttributeError):
            return 400, {}, json_bytes({'error': {'type': 'invalid_fixture_request'}})


def handler_for(fixture):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass  # Requests may contain secrets and are deliberately never logged.

        def _respond(self, status, headers, body):
            try:
                self.send_response(status)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                for key, value in headers.items():
                    self.send_header(key, value)
                self.end_headers()
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            self._respond(*fixture.dispatch('GET', self.path))

        def do_POST(self):
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if self.headers.get('Transfer-Encoding') or not 0 < length <= MAX_BODY:
                    raise ValueError()
                body = self.rfile.read(length)
                if len(body) != length:
                    raise ValueError()
                payload = json.loads(body)
            except (ValueError, UnicodeError):
                self._respond(400, {}, json_bytes({'error': {'type': 'invalid_fixture_request'}}))
                return
            self._respond(*fixture.dispatch('POST', self.path, payload))
    return Handler


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=['serve'])
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8124)
    args = parser.parse_args(argv)
    if args.host != '127.0.0.1' or not 1024 <= args.port <= 65535:
        parser.error('Only an explicit loopback qualification listener is allowed')
    class Server(ThreadingHTTPServer):
        daemon_threads = True
    server = Server((args.host, args.port), handler_for(Fixture()))
    server.serve_forever(poll_interval=.25)


if __name__ == '__main__':
    main()
