"""Inject one fault at a time into an owned synthetic delivery instance.

Run on the Ubuntu Docker host, outside the endurance instance. Only named
containers in this instance are stopped. Individual credentials are issued by
the trusted server operator, revoked afterwards, and never written to reports.
No request enables synthesis or consumes an Albert call.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid

SERVICES=('pdl','incidents','ldap','opensearch','victoriametrics')
INCIDENT={'question':'Examiner les mesures et les logs de R1 sur cette période.', 'variant':'gptoss',
          'equipment':'OBS-RTR-01','start':'2026-09-28T10:00:00+02:00','end':'2026-09-28T12:00:00+02:00','synthesize':False}
EVIDENCE=('evidence','sources','metrics','logs','events','documents','results')


def now():return datetime.now(timezone.utc).isoformat()


def load_manager():
    spec=importlib.util.spec_from_file_location('resilience_delivery_manage',Path(__file__).with_name('manage.py'))
    manager=importlib.util.module_from_spec(spec);spec.loader.exec_module(manager);return manager


def response(base,path,payload=None,token='',*,timeout=75):
    headers={'Accept':'application/json, text/event-stream','Content-Type':'application/json','MCP-Protocol-Version':'2025-11-25'}
    if token:headers['Authorization']='Bearer '+token
    request=urllib.request.Request(base+path,data=json.dumps(payload).encode() if payload is not None else None,headers=headers)
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with opener.open(request,timeout=timeout) as incoming:
            status=incoming.status;raw=incoming.read(2*1024*1024+1)
    except urllib.error.HTTPError as error:
        status=error.code;raw=error.read(2*1024*1024+1)
    except (urllib.error.URLError,TimeoutError,OSError) as error:
        return {'http_status':0,'response':{},'transport_error':type(error).__name__}
    if len(raw)>2*1024*1024:return {'http_status':status,'response':{},'transport_error':'response_too_large'}
    try:body=json.loads(raw)
    except (ValueError,UnicodeError):body={'error':'non_json_response'}
    return {'http_status':status,'response':body}


def structured(body):
    if body.get('error'):return {'status':'protocol_error'}
    value=body.get('result',{})
    if value.get('isError'):return {'status':'protocol_error'}
    if isinstance(value.get('structuredContent'),dict):return value['structuredContent']
    for row in value.get('content',[]):
        if row.get('type')=='text':
            try:return json.loads(row['text'])
            except ValueError:pass
    return value


def no_evidence(value):return all(not value.get(key) for key in EVIDENCE)


def evaluate_fault(service, probes):
    """Independent expected outcomes for each single injected dependency fault."""
    internal=probes['incidents_internal'];external=probes['incidents_external']
    internal_body=internal['response'];external_body=external['response']
    pdl=probes['pdl_internal'];pdl_body=structured(pdl['response'])
    checks={}
    if service=='pdl':
        checks['stopped_pdl_is_unreachable']=pdl['http_status']==0
        checks['unrelated_incidents_remains_readable']=internal['http_status']==200 and internal_body.get('status')=='ok'
    elif service=='incidents':
        checks['stopped_incidents_is_unreachable']=internal['http_status']==external['http_status']==0
        checks['unrelated_pdl_still_authenticates']=pdl['http_status']==200 and pdl_body.get('access_control',{}).get('category')=='internal'
    elif service=='ldap':
        checks['pdl_fails_closed']=pdl['http_status']==403 and no_evidence(pdl_body)
        checks['incidents_internal_fails_closed']=internal['http_status']==403 and no_evidence(internal_body)
    elif service=='opensearch':
        errors=internal_body.get('errors',[])
        checks['source_outage_is_explicit']=internal['http_status']==200 and internal_body.get('status')=='partial' and any(r.get('source')=='opensearch' for r in errors)
        checks['old_logs_and_documents_are_not_reused']=not internal_body.get('logs') and not internal_body.get('documents')
    elif service=='victoriametrics':
        errors=internal_body.get('errors',[])
        checks['source_outage_is_explicit']=internal['http_status']==200 and internal_body.get('status')=='partial' and any(r.get('source')=='victoriametrics' for r in errors)
        checks['old_measurements_are_not_reused']=not internal_body.get('metrics')
    else:raise ValueError('Unknown fault service')
    if service!='incidents':
        checks['external_has_no_incident_evidence']=no_evidence(external_body) and (
            external['http_status']==403 if service=='ldap' else external['http_status']==200 and external_body.get('status')=='denied')
    checks['no_synthesis']=not internal_body.get('usage') and internal_body.get('analysis') is None
    return checks


def probes(values, credentials):
    pdl='http://127.0.0.1:'+values['PDL_PORT'];incidents='http://127.0.0.1:'+values['INCIDENTS_PORT']
    rpc={'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':'investigate_pdl',
         'arguments':{'question':'Quels sont mes index accessibles ?','continuation_token':''}}}
    return {'pdl_internal':response(pdl,'/mcp',rpc,credentials['internal']),
            'incidents_internal':response(incidents,'/diagnose',INCIDENT,credentials['internal']),
            'incidents_external':response(incidents,'/diagnose',INCIDENT,credentials['external'])}


def healthy(probed):
    pdl=probed['pdl_internal'];pdl_body=structured(pdl['response'])
    internal=probed['incidents_internal'];internal_body=internal['response']
    external=probed['incidents_external'];external_body=external['response']
    return (pdl['http_status']==200 and pdl_body.get('access_control',{}).get('category')=='internal'
            and pdl_body.get('execution',{}).get('albert_calls')==0
            and internal['http_status']==200 and internal_body.get('status')=='ok' and internal_body.get('errors')==[]
            and len(internal_body.get('metrics',[]))==5 and not internal_body.get('usage') and internal_body.get('analysis') is None
            and external['http_status']==200 and external_body.get('status')=='denied' and no_evidence(external_body))


def runtime_check(manager,instance,values):
    try:
        manager.tool(instance,values,'python','/delivery/runtime_cli.py','check','--username','alice.martin',capture=True)
        return 0
    except subprocess.CalledProcessError as error:return error.returncode


def issue_credentials(manager,instance,values,private):
    nonce=uuid.uuid4().hex
    accounts={'internal':'alice.martin','external':'eric.durand.ext'}
    paths={role:'/data/access/resilience-'+nonce+'-'+role+'.token' for role in accounts}
    code=('from dinum_access import AccessGate; from dinum_access.user_tokens import UserTokens; import json; '
          'g=AccessGate.configured(); s=UserTokens(g.config["user_tokens_directory"]); rows={}; '+
          '\n'.join('rows['+repr(role)+']=s.issue(g.directory,'+repr(username)+','+repr(paths[role])+',days=1)' for role,username in accounts.items())+
          '\nprint(json.dumps(rows))')
    raw=manager.tool(instance,values,'python','-c',code,capture=True).stdout
    metadata=json.loads(raw)
    credentials={}
    try:
        for role,remote in paths.items():
            target=private/(role+'.token')
            manager.compose(instance,values,'cp','pdl:'+remote,str(target),capture=True)
            target.chmod(0o600)
            credentials[role]=target.read_text().strip()
    except BaseException:
        revoke_credentials(manager,instance,values,metadata,paths)
        raise
    return credentials,metadata,paths


def revoke_credentials(manager,instance,values,metadata,paths):
    identifiers=[row['id'] for row in metadata.values()]
    code=('from dinum_access import AccessGate; from dinum_access.user_tokens import UserTokens; from pathlib import Path; '
          'g=AccessGate.configured(); s=UserTokens(g.config["user_tokens_directory"]); '+
          '\n'.join('s.revoke('+repr(identifier)+')' for identifier in identifiers)+'\n'+
          '\n'.join('Path('+repr(path)+').unlink(missing_ok=True)' for path in paths.values()))
    manager.tool(instance,values,'python','-c',code,capture=True)


def run(instance,output,*,services=SERVICES,recovery_timeout=180,manager=None):
    manager=manager or load_manager();instance=Path(instance).expanduser().resolve();output=Path(output).expanduser().resolve()
    values=manager.load(instance);manager.guard(instance,values)
    if values['RIE_MODE']!='demo' or values.get('RIE_LOAD_QUALIFICATION')=='true':
        raise ValueError('Fault injection is restricted to a separate non-load synthetic instance.')
    if not services or any(service not in SERVICES for service in services):raise ValueError('Choose only known delivery services.')
    if output.exists() or output.is_relative_to(manager.ROOT):raise ValueError('Choose a new private output directory outside the checkout.')
    lock=instance/'.resilience.lock'
    report={'started_at':now(),'kind':'single_fault_resilience','synthetic':True,'albert_calls':0,'cases':[],'passed':False}
    output.mkdir(parents=True,mode=0o700)
    private=output/'.credentials';private.mkdir(mode=0o700)
    try:
        fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(fd)
    except BaseException:
        shutil.rmtree(output)
        raise
    metadata={};paths={};stopped=None
    try:
        credentials,metadata,paths=issue_credentials(manager,instance,values,private)
        baseline=probes(values,credentials)
        if not healthy(baseline) or runtime_check(manager,instance,values)!=0:
            raise ValueError('The complete healthy reference recipe must pass before fault injection.')
        with (output/'api-evidence.jsonl').open('x') as evidence:
            evidence.write(json.dumps({'at':now(),'phase':'baseline','probes':baseline})+'\n');evidence.flush()
            for service in services:
                case={'service':service,'started_at':now(),'checks':{}}
                stopped=service
                try:
                    manager.compose(instance,values,'--profile','demo','stop','--timeout','45',service,capture=True)
                    during=probes(values,credentials)
                    case['checks']=evaluate_fault(service,during)
                    case['check_exit_during_fault']=runtime_check(manager,instance,values)
                    case['checks']['readiness_signals_failure']=case['check_exit_during_fault']==2
                    evidence.write(json.dumps({'at':now(),'phase':'fault','service':service,'probes':during})+'\n');evidence.flush()
                finally:
                    manager.compose(instance,values,'--profile','demo','start',service,capture=True)
                    started=time.monotonic();last={};recovered=False
                    while time.monotonic()-started<recovery_timeout:
                        last=probes(values,credentials)
                        if healthy(last) and runtime_check(manager,instance,values)==0:
                            recovered=True;break
                        time.sleep(2)
                    case['recovery_seconds']=round(time.monotonic()-started,3)
                    case['checks']['automatic_recovery_after_dependency_return']=recovered
                    evidence.write(json.dumps({'at':now(),'phase':'recovered','service':service,'probes':last})+'\n');evidence.flush()
                    if recovered:stopped=None
                case['passed']=bool(case['checks']) and all(case['checks'].values())
                report['cases'].append(case)
                (output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
                print(json.dumps({'service':service,'passed':case['passed'],'recovery_seconds':case['recovery_seconds']}),flush=True)
                if stopped:raise ValueError('A dependency failed to recover; stop injecting additional faults.')
        report['passed']=bool(report['cases']) and all(case['passed'] for case in report['cases'])
    except Exception as error:
        report['error_code']=type(error).__name__
        report['passed']=False
    finally:
        if stopped:
            try:manager.compose(instance,values,'--profile','demo','start',stopped,capture=True)
            except Exception:report['recovery_cleanup_failed']=True
        if metadata:
            try:revoke_credentials(manager,instance,values,metadata,paths)
            except Exception:report['credential_cleanup_failed']=True;report['passed']=False
        shutil.rmtree(private)
        lock.unlink(missing_ok=True)
        report['finished_at']=now();report['credentials_in_report']=False
        (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'cases':len(report['cases']),'report':str(output/'report.json')}),flush=True)
    return 0 if report['passed'] else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('instance',type=Path)
    parser.add_argument('--output',type=Path,required=True);parser.add_argument('--services',nargs='+',choices=SERVICES,default=list(SERVICES))
    parser.add_argument('--recovery-timeout',type=float,default=180)
    args=parser.parse_args();os.umask(0o077)
    if args.recovery_timeout<1:parser.error('Recovery timeout must be positive.')
    try:return run(args.instance,args.output,services=tuple(args.services),recovery_timeout=args.recovery_timeout)
    except (ValueError,OSError,subprocess.CalledProcessError) as error:
        print(json.dumps({'passed':False,'code':type(error).__name__,'detail':'Inspect the private report and restore the reference service health.'}),file=sys.stderr)
        return 2


if __name__=='__main__':raise SystemExit(main())
