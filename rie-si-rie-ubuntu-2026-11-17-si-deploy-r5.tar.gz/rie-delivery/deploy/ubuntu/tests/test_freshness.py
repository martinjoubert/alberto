"""The independent freshness oracle detects stale evidence and restoration loss."""
import importlib.util
from pathlib import Path
from copy import deepcopy
import unittest
import subprocess
import sys
spec=importlib.util.spec_from_file_location('freshness_tested',Path(__file__).resolve().parents[1]/'qualification_freshness.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


class FreshnessTests(unittest.TestCase):
 def test_cleanup_rejects_unowned_or_injectable_series_names_before_network(self):
  for marker in ('','all','qualification-fresh-not-a-uuid','qualification-fresh-'+'a'*32+'"}'):
   with self.assertRaises(ValueError):module.remove_test_series(None,marker,set())
 def test_embedded_public_harness_preserves_future_imports_and_packaged_filename(self):
  source="from __future__ import annotations\nassert __file__ == '/delivery/qualification_freshness.py'\nprint('public_harness_ok')"
  result=subprocess.run([sys.executable,'-c',module.embedded_code(source)],check=True,capture_output=True,text=True)
  self.assertEqual(result.stdout.strip(),'public_harness_ok')
 def baseline(self):
  return {'status':'ok','errors':[],'request_id':'one','metrics':[{'metric':key,'max':80.0 if key=='latency' else 1} for key in ('cpu','latency','loss','in','out')],
          'events':[{'title':'Initial'}],'logs':{'total':120},'usage':[],'analysis':None}
 def test_fresh_sources_and_restoration_are_all_required(self):
  before=self.baseline();changed=deepcopy(before);changed['request_id']='two';changed['metrics'][1]['max']=85.;changed['events'][0]['title']='marker'
  restored=deepcopy(before);restored['request_id']='three'
  self.assertTrue(all(module.compare(before,changed,restored,'marker').values()))
 def test_reused_old_result_cannot_pass_as_fresh(self):
  original=self.baseline();checks=module.compare(original,deepcopy(original),deepcopy(original),'marker')
  self.assertFalse(checks['fresh_request_ids']);self.assertFalse(checks['metric_source_change_visible']);self.assertFalse(checks['ticket_source_change_visible'])
 def test_a_failed_restore_is_detected(self):
  before=self.baseline();changed=deepcopy(before);changed['request_id']='two';changed['metrics'][1]['max']=85.;changed['events'][0]['title']='marker'
  restored=deepcopy(changed);restored['request_id']='three'
  self.assertFalse(module.compare(before,changed,restored,'marker')['baseline_restored'])
