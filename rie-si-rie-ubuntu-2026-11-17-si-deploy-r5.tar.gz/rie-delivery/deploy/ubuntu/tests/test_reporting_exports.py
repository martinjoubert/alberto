"""Exercise reporting failures; a pretty report must not hide a failed test."""
import hashlib
import importlib.util
import io
import json
import logging
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
import xml.etree.ElementTree as ET
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('qualification_test_reporting',
    Path(__file__).resolve().parents[1]/'test_reporting.py')
reporting = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reporting)


def read_results(path):
    return [json.loads(p.read_text()) for p in Path(path).glob('*-result.json')]


class ReportingExportTests(unittest.TestCase):
    def test_continuation_handles_are_masked_even_in_escaped_tool_arguments(self):
        for length in (16,32):
            token='a'*length+'.'+'b'*32
            value=json.dumps({'arguments':json.dumps({'continuation_token':token})})
            self.assertNotIn(token,reporting.sanitize_text(value))

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.results = self.root/'results'

    def test_unittest_preserves_subtest_failures_errors_skips_and_unexpected_success(self):
        class Examples(unittest.TestCase):
            def test_pass(self):
                self.assertTrue(True)

            def test_subtests(self):
                for n in (0, 1, 2):
                    with self.subTest(n=n):
                        if n == 0:
                            self.fail('first subtest failed')
                        if n == 1:
                            self.skipTest('later skip must not hide failure')

            def test_error(self):
                raise RuntimeError('example error')

            @unittest.skip('Linux-only example')
            def test_skip(self):
                pass

            @unittest.expectedFailure
            def test_expected(self):
                self.fail('expected')

            @unittest.expectedFailure
            def test_unexpected(self):
                pass

        result = unittest.TextTestRunner(stream=io.StringIO(), resultclass=reporting.ReportingResult).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(Examples))
        self.assertFalse(reporting.write_unittest(result, 'examples', self.root/'examples.xml', self.results))
        rows = {row['name'].rsplit('.', 1)[-1]: row for row in read_results(self.results)}
        self.assertEqual({name: row['status'] for name, row in rows.items()}, {
            'test_pass': 'passed', 'test_subtests': 'failed', 'test_error': 'broken',
            'test_skip': 'skipped', 'test_expected': 'skipped', 'test_unexpected': 'failed'})
        self.assertEqual([row['status'] for row in rows['test_subtests']['steps']], ['failed', 'skipped', 'passed'])
        self.assertTrue(all(row['stop'] >= row['start'] for row in rows.values()))
        self.assertTrue(all({'name': 'qualification', 'value': 'not_qualified'} not in row['labels'] for row in rows.values()))
        xml = ET.parse(self.root/'examples.xml').getroot()
        self.assertEqual((xml.get('tests'), xml.get('failures'), xml.get('errors'), xml.get('skipped')), ('6', '2', '1', '2'))

    def test_zero_tests_and_setup_class_failure_cannot_produce_a_green_report(self):
        class BrokenFixture(unittest.TestCase):
            @classmethod
            def setUpClass(cls):
                raise RuntimeError('fixture unavailable')

            def test_not_run(self):
                self.fail('unreachable')

        for name, suite in [('empty', unittest.TestSuite()), ('fixture', unittest.defaultTestLoader.loadTestsFromTestCase(BrokenFixture))]:
            result = unittest.TextTestRunner(stream=io.StringIO(), resultclass=reporting.ReportingResult).run(suite)
            self.assertFalse(reporting.write_unittest(result, name, self.root/(name+'.xml'), self.results/name))
            self.assertEqual(read_results(self.results/name)[0]['status'], 'broken')
            xml = ET.parse(self.root/(name+'.xml')).getroot()
            self.assertEqual(xml.get('errors'), '1')

    def test_pytest_phase_timing_is_measured_and_a_later_skip_cannot_hide_failure(self):
        plugin = reporting.PytestResults(self.results, 'incidents')
        for phase, outcome, start, stop in [('setup', 'passed', 100.0, 100.1),
                                           ('call', 'failed', 100.1, 100.4),
                                           ('teardown', 'skipped', 100.4, 100.5)]:
            plugin.pytest_runtest_logreport(SimpleNamespace(nodeid='tests/example.py::test_one', when=phase,
                failed=outcome=='failed', skipped=outcome=='skipped', start=start, stop=stop, longreprtext='example'))
        counts = plugin.finish()
        row = read_results(self.results)[0]
        self.assertEqual(row['status'], 'failed')
        self.assertEqual((row['start'], row['stop']), (100000, 100500))
        self.assertEqual([step['name'] for step in row['steps']], ['setup', 'call', 'teardown'])
        self.assertEqual(counts['failed'], 1)

    def test_pytest_empty_or_failed_collection_is_broken(self):
        for name, failed in [('empty', False), ('collection', True)]:
            plugin = reporting.PytestResults(self.results/name, 'incidents')
            if failed:
                plugin.pytest_collectreport(SimpleNamespace(failed=True, nodeid='test_import.py', longreprtext='ImportError'))
            self.assertEqual(plugin.finish()['broken'], 1)
            self.assertEqual(read_results(self.results/name)[0]['status'], 'broken')

    def test_junit_conversion_retains_outcomes_but_does_not_invent_individual_timestamps(self):
        source = self.root/'cases.xml'
        source.write_text('<testsuites><testsuite tests="3" failures="1" errors="0" skipped="1">'
            '<testcase classname="a" name="ok" time="0.12"/><testcase classname="a" name="bad" time="0.2">'
            '<failure message="failure">details</failure></testcase><testcase classname="a" name="skip" time="0">'
            '<skipped message="platform"/></testcase></testsuite></testsuites>')
        self.assertEqual(reporting.convert_junit(source, self.results, 'incidents'),
            {'passed': 1, 'failed': 1, 'broken': 0, 'skipped': 1, 'unknown': 0})
        rows = read_results(self.results)
        self.assertTrue(all('start' not in row and 'stop' not in row for row in rows))
        self.assertTrue(all('Horodatage individuel non mesuré' in row['description'] for row in rows))

    def test_truncated_inconsistent_or_entity_junit_is_rejected_before_any_export(self):
        source = self.root/'cases.xml'
        for text in ['<testsuite tests="2"><testcase name="only-one"/></testsuite>',
                     '<testsuite tests="1" failures="1"><testcase name="no-failure"/></testsuite>',
                     '<!DOCTYPE a [<!ENTITY x "oops">]><testsuite tests="0"/>',
                     '<testsuite tests="0"/>']:
            source.write_text(text)
            with self.subTest(text=text), self.assertRaises(ValueError):
                reporting.convert_junit(source, self.results, 'incidents')
        self.assertEqual(read_results(self.results), [])

    def test_native_import_selects_only_checks_and_preserves_original_receipt_identity(self):
        path = self.root/'native.json'
        data = {'kind': 'native-uc2-source-acl', 'started_at': '2026-11-07T11:00:00+00:00',
                'checks': {'denied_before_read': True, 'recovery': True}, 'passed': True,
                'secrets': {'password': 'do-not-publish-this'}, 'evidence': 'private business payload'}
        path.write_text(json.dumps(data))
        self.assertEqual(reporting.import_checks(path, self.results, 'ubuntu24-acl', import_type='uc2-acl'),
                         {'passed': 2, 'failed': 0})
        rows = read_results(self.results)
        for row in rows:
            self.assertNotIn('start', row)
            self.assertIn({'name': 'receiptSha256', 'value': hashlib.sha256(path.read_bytes()).hexdigest()}, row['labels'])
            self.assertIn({'name': 'receiptDate', 'value': data['started_at']}, row['labels'])
            self.assertIn('non rejouée', row['description'])
            self.assertEqual(row['attachments'], [])
        serialized = json.dumps(rows)
        self.assertNotIn('do-not-publish-this', serialized)
        self.assertNotIn('private business payload', serialized)

    def test_native_partial_or_mistyped_checks_do_not_become_successes(self):
        path = self.root/'native.json'
        for payload in [{'checks': {'partial': True}, 'passed': False},
                        {'checks': {'a': 'true'}, 'passed': True},
                        {'checks': [{'name': 'twice', 'passed': True}, {'name': 'twice', 'passed': True}], 'passed': True},
                        {'checks': [], 'passed': True}]:
            path.write_text(json.dumps(payload))
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                reporting.import_checks(path, self.results, 'native')
        self.assertEqual(read_results(self.results), [])

    def test_attachment_symlinks_and_symlink_report_directories_are_refused(self):
        secret = self.root/'secret.txt'
        secret.write_bytes(b'private')
        capture = self.root/'capture.png'
        capture.symlink_to(secret)
        with self.assertRaises(OSError):
            reporting.write_result(self.results, 'browser', 'one', 'passed', attachments=[capture])
        target = self.root/'linked'
        target.symlink_to(self.results, target_is_directory=True)
        with self.assertRaises(ValueError):
            reporting.write_result(target, 'browser', 'one', 'passed')
        self.assertEqual(secret.read_bytes(), b'private')

    def test_unittest_failure_exports_stdout_stderr_logs_and_redacted_trace(self):
        class DiagnosticFailure(unittest.TestCase):
            def test_fail(self):
                print('stdout-marker password=stdout-secret')
                print('stderr-marker api_key=stderr-secret', file=sys.stderr)
                logging.getLogger('qualification.fixture').warning('log-marker Authorization: Bearer logger-secret')
                self.fail('assertion-marker token=trace-secret')

        stream = io.StringIO()
        result = unittest.TextTestRunner(stream=stream, resultclass=reporting.ReportingResult).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(DiagnosticFailure))
        self.assertFalse(reporting.write_unittest(result, 'failure-logs', self.root/'logs.xml', self.results))
        row = read_results(self.results)[0]
        self.assertEqual(row['status'], 'failed')
        self.assertIn('AssertionError', row['statusDetails']['trace'])
        attached = {entry['name']: (self.results/entry['source']).read_text() for entry in row['attachments']}
        self.assertIn('stdout-marker', attached['stdout'])
        self.assertIn('stderr-marker', attached['stderr'])
        self.assertIn('log-marker', attached['logs'])
        exported = json.dumps(row)+'\n'+''.join(attached.values())+(self.root/'logs.xml').read_text()
        for secret in ('stdout-secret','stderr-secret','logger-secret','trace-secret'):
            self.assertNotIn(secret, exported)
        self.assertIn('[MASQUÉ]', exported)

    def test_capture_is_bounded_preserves_last_error_and_restores_streams(self):
        class VeryVerbose(unittest.TestCase):
            def test_error(self):
                print('begin-marker '+'é'*100_000+' end-marker')
                raise RuntimeError('final-error-marker')
        original = sys.stdout, sys.stderr
        with patch('sys.stdout', io.StringIO()), patch('sys.stderr', io.StringIO()):
            result = unittest.TextTestRunner(stream=io.StringIO(), resultclass=reporting.ReportingResult).run(
                unittest.defaultTestLoader.loadTestsFromTestCase(VeryVerbose))
        self.assertEqual((sys.stdout,sys.stderr),original)
        reporting.write_unittest(result,'verbose',self.root/'verbose.xml',self.results)
        row = read_results(self.results)[0]
        text = next((self.results/e['source']).read_bytes() for e in row['attachments'] if e['name']=='stdout')
        self.assertLessEqual(len(text),reporting.MAX_DIAGNOSTIC)
        self.assertIn('TRONQUÉ'.encode(),text)
        self.assertIn(b'begin-marker',text);self.assertIn(b'end-marker',text)
        self.assertIn('final-error-marker',row['statusDetails']['trace'])

    def test_fixture_failure_logs_are_retained_and_unittest_interrupt_is_not_passed(self):
        class FixtureError(unittest.TestCase):
            @classmethod
            def setUpClass(cls):
                print('fixture-log-marker')
                raise RuntimeError('fixture-error-marker')
            def test_unreachable(self):pass
        result = unittest.TextTestRunner(stream=io.StringIO(),resultclass=reporting.ReportingResult).run(
            unittest.defaultTestLoader.loadTestsFromTestCase(FixtureError))
        self.assertFalse(reporting.write_unittest(result,'fixture-log',self.root/'fixture.xml',self.results))
        row=read_results(self.results)[0]
        self.assertEqual(row['status'],'broken')
        self.assertTrue(any('fixture-log-marker' in (self.results/e['source']).read_text() for e in row['attachments']))
        class Interrupted(unittest.TestCase):
            def test_interrupt(self):raise KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt):
            interrupted = reporting.ReportingResult(io.StringIO(), True, 1)
            unittest.defaultTestLoader.loadTestsFromTestCase(Interrupted).run(interrupted)
        self.assertEqual(interrupted.records[0]['status'],'broken')

    def test_pytest_incomplete_passed_phases_are_broken_and_normal_setup_skip_is_preserved(self):
        for name, phases in [('setup-only',['setup']),('missing-teardown',['setup','call'])]:
            plugin=reporting.PytestResults(self.results/name,'pytest')
            for phase in phases:
                plugin.pytest_runtest_logreport(SimpleNamespace(nodeid='one',when=phase,failed=False,skipped=False,start=1,stop=2))
            self.assertEqual(plugin.finish()['broken'],1)
            self.assertIn('Incomplete pytest execution',read_results(self.results/name)[0]['statusDetails']['message'])
            self.assertEqual(plugin.finish()['broken'],1)
            self.assertEqual(len(read_results(self.results/name)),1)
        plugin=reporting.PytestResults(self.results/'skip','pytest')
        plugin.pytest_runtest_logreport(SimpleNamespace(nodeid='one',when='setup',failed=False,skipped=True,start=1,stop=2,longreprtext='platform skip'))
        self.assertEqual(plugin.finish()['skipped'],1)

    def test_pytest_captures_phase_logs_once_and_distinguishes_technical_exceptions(self):
        plugin=reporting.PytestResults(self.results,'pytest')
        plugin.pytest_runtest_makereport(SimpleNamespace(nodeid='one'),SimpleNamespace(when='call',excinfo=SimpleNamespace(value=ValueError('technical'))))
        sections=[('Captured stdout setup','setup-marker password=setup-secret'),('Captured log call','log-marker token=log-secret')]
        for phase,failed in [('setup',False),('call',True),('teardown',False)]:
            plugin.pytest_runtest_logreport(SimpleNamespace(nodeid='one',when=phase,failed=failed,skipped=False,start=1,stop=2,
                sections=sections,longreprtext='ValueError: call-error-marker api_key=call-secret'))
        self.assertEqual(plugin.finish()['broken'],1)
        row=read_results(self.results)[0]
        texts={e['name']:(self.results/e['source']).read_text() for e in row['attachments']}
        self.assertEqual(texts['stdout'].count('setup-marker'),1)
        self.assertEqual(texts['logs'].count('log-marker'),1)
        for secret in ('setup-secret','log-secret','call-secret'):
            self.assertNotIn(secret,json.dumps(row)+''.join(texts.values()))

    def test_pytest_assertion_and_explicit_fail_are_failed_while_timeout_is_broken(self):
        failed_type = type('Failed', (BaseException,), {'__module__':'_pytest.outcomes'})
        for name,error,expected in [('assertion',AssertionError('assertion'),'failed'),
                                    ('explicit-fail',failed_type('pytest fail'),'failed'),
                                    ('timeout',TimeoutError('backend timed out'),'broken')]:
            plugin=reporting.PytestResults(self.results/name,'pytest')
            plugin.pytest_runtest_makereport(SimpleNamespace(nodeid=name),SimpleNamespace(when='call',excinfo=SimpleNamespace(value=error)))
            for phase in ('setup','call','teardown'):
                plugin.pytest_runtest_logreport(SimpleNamespace(nodeid=name,when=phase,failed=phase=='call',skipped=False,start=1,stop=2,longreprtext=str(error)))
            self.assertEqual(plugin.finish()[expected],1)

    def test_explicit_secrets_are_masked_in_text_steps_and_names(self):
        row=reporting.write_result(self.results,'browser','case bare-secret','broken',message='bare-secret',
            trace='trace bare-secret',steps=[{'name':'step bare-secret','status':'broken','statusDetails':{'message':'bare-secret'}}],
            diagnostics={'stdout':'bare-secret'},secrets=['bare-secret'])
        body=json.dumps(row)+''.join((self.results/e['source']).read_text() for e in row['attachments'])
        self.assertNotIn('bare-secret',body)

    def test_prefixed_environment_and_json_credentials_are_masked(self):
        original=('ALBERT_API_KEY=provider-secret OPENSEARCH_PASSWORD="database secret" '
                  'LDAP_BIND_PASSWORD=ldap-secret {"reader_password":"reader-secret"} '
                  'OPENAI_API_KEY=openai-secret MCP_TOKEN=mcp-secret')
        cleaned=reporting.sanitize_text(original)
        for secret in ('provider-secret','database secret','ldap-secret','reader-secret','openai-secret','mcp-secret'):
            self.assertNotIn(secret,cleaned)
        self.assertEqual(cleaned.count('[MASQUÉ]'),6)

    def test_campaign_sentinel_is_durable_and_finish_removes_only_its_own_result(self):
        existing=reporting.write_result(self.results,'one','already completed','passed')
        campaign=reporting.Campaign(self.results,'campaign','Interrupted campaign')
        campaign.checkpoint('password=checkpoint-secret')
        row=json.loads(campaign.path.read_text())
        self.assertEqual(row['status'],'broken');self.assertIn('start',row);self.assertNotIn('stop',row)
        self.assertNotIn('checkpoint-secret',json.dumps(row))
        self.assertEqual(len(read_results(self.results)),2)
        other=reporting.Campaign(self.results,'campaign','Another interrupted campaign')
        self.assertNotEqual(campaign.row['historyId'],other.row['historyId'])
        other.finish()
        campaign.finish();campaign.finish()
        self.assertFalse(campaign.path.exists())
        self.assertTrue((self.results/(existing['uuid']+'-result.json')).is_file())

    def test_explicit_native_log_attaches_only_to_failed_checks(self):
        source=self.root/'receipt.json';source.write_text(json.dumps({'at_utc':'2026-11-07T12:00:00Z',
            'checks':{'ok':True,'failed':False},'passed':False}))
        reporting.import_checks(source,self.results,'native',diagnostics={'selected-log':'native-marker password=native-secret'})
        rows={r['name']:r for r in read_results(self.results)}
        self.assertEqual(rows['ok']['attachments'],[])
        self.assertEqual(len(rows['failed']['attachments']),1)
        text=(self.results/rows['failed']['attachments'][0]['source']).read_text()
        self.assertIn('native-marker',text);self.assertNotIn('native-secret',text)

    def test_selected_log_cli_preserves_head_and_tail_and_rejects_links(self):
        source=self.root/'native.json';source.write_text(json.dumps({'kind':'native-uc2-source-acl',
            'checks':{'failed':False},'passed':False}))
        log=self.root/'selected.log';log.write_text('begin-marker\n'+'x'*100_000+'\nfinal-error-marker password=selected-secret')
        args=['--import-type','uc2-acl','--input',str(source),'--allure-results',str(self.results),'--log-file',str(log)]
        with patch('sys.stdout',io.StringIO()):self.assertEqual(reporting.main(args),1)
        row=read_results(self.results)[0]
        text=(self.results/row['attachments'][0]['source']).read_bytes()
        self.assertLessEqual(len(text),reporting.MAX_DIAGNOSTIC)
        self.assertIn(b'begin-marker',text);self.assertIn(b'final-error-marker',text)
        self.assertNotIn(b'selected-secret',text);self.assertIn('TRONQUÉ'.encode(),text)
        alias=self.root/'link.log';alias.symlink_to(log)
        with patch('sys.stderr',io.StringIO()),self.assertRaises(SystemExit):reporting.main(args[:-1]+[str(alias)])


if __name__ == '__main__':
    unittest.main()
