"""The qualification oracle must accept valid contracts and reject misleading facts."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('stability_oracle',Path(__file__).with_name('browser_stability.py'))
oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
report_spec=importlib.util.spec_from_file_location('stability_assessment',Path(__file__).with_name('report_stability.py'))
assessment=importlib.util.module_from_spec(report_spec);report_spec.loader.exec_module(assessment)


class QualificationOracleTests(unittest.TestCase):
    def saved(self,uc):
        return {'done':True,'content':'Précisez la période.',
                'output':[{'type':'function_call','name':'test_'+('investigate_pdl' if uc=='pdl' else 'diagnose_observability'),'status':'completed'}]}

    def checks(self,uc,expected,result):
        return oracle.checks_for({'uc':uc,'expect':expected},result,self.saved(uc),{'model':oracle.MODELS[uc]})

    def test_incidents_uses_its_declared_clarification_status(self):
        result={'status':'clarification','answer':'Précisez la période.','application':'observability'}
        self.assertTrue(all(c['passed'] for c in self.checks('incidents',{'kind':'clarification'},result)))

    def test_pdl_uses_its_declared_clarification_status(self):
        self.assertTrue(all(c['passed'] for c in self.checks('pdl',{'kind':'clarification'},
                            {'status':'needs_clarification','route':None})))

    def test_matching_count_cannot_hide_an_expanded_time_window(self):
        result={'status':'success','plan':{'time_range':{'gte':'2026-10-12T00:00:00Z','lt':'2026-10-13T00:00:00Z'},
                'filters':[{'concept':'network_scope','value':'demo-alpha'}]},'evidence':{'total':2},
                'planner':{'kind':'AlbertPlanner','returned_model':'real-model'}}
        checks=self.checks('pdl',{'kind':'pdl_count','total':2,'scope':'demo-alpha'},result)
        self.assertFalse(next(c for c in checks if c['name']=='correct_pdl_period')['passed'])
        self.assertTrue(next(c for c in checks if c['name']=='exact_total')['passed'])

    def test_unexpected_clarification_with_null_plan_is_a_business_failure(self):
        checks=self.checks('pdl',{'kind':'pdl_equipment','families':'all'},
                           {'status':'needs_clarification','plan':None,'evidence':None,'planner':None})
        self.assertFalse(next(c for c in checks if c['name']=='business_success')['passed'])
        self.assertFalse(next(c for c in checks if c['name']=='correct_pdl_period')['passed'])

    def test_zero_is_not_an_unknown_mean_for_a_collection_gap(self):
        result={'status':'partial','answer':'Précisez la période.','context':{'equipment_ids':['OBS-RTR-03'],
                'start':oracle.INC_START,'end':oracle.INC_END},'metrics':[{'equipment':'OBS-RTR-03',
                'metric':'latency','count':0,'expected':120,'mean':0}],'sources':[{'source_id':'S1'}]}
        checks=self.checks('incidents',{'kind':'incident_missing','equipment':['OBS-RTR-03'],'metric':'latency'},result)
        self.assertFalse(next(c for c in checks if c['name']=='missing_mean_is_unknown_not_zero')['passed'])

    def test_client_error_cannot_be_a_success_despite_native_data(self):
        saved=self.saved('pdl');saved['error']={'content':'Tool-call limit reached'}
        checks=oracle.checks_for({'uc':'pdl','expect':{'kind':'rights'}},
                 {'status':'success'},saved,{'model':oracle.MODELS['pdl']})
        self.assertFalse(next(c for c in checks if c['name']=='client_finished')['passed'])

    def test_explicit_inability_does_not_excuse_unrelated_business_reads(self):
        result={'status':'partial','answer':'Les sources ne permettent pas de répondre à cette demande.',
                'metrics':[{'equipment':'OTHER'}]}
        checks=self.checks('incidents',{'kind':'wrong_uc'},result)
        self.assertTrue(next(c for c in checks if c['name']=='wrong_domain_explicitly_explained')['passed'])
        self.assertFalse(next(c for c in checks if c['name']=='wrong_domain_request_has_no_business_evidence')['passed'])

    def test_export_masks_continuations_but_preserves_usage_counts(self):
        value={'continuation_token':'a'*16+'.'+'b'*32,'total_tokens':123,'nested':{'token':'secret'}}
        cleaned=oracle.clean(value)
        self.assertEqual(cleaned['continuation_token'],'[MASQUÉ]')
        self.assertEqual(cleaned['total_tokens'],123)
        self.assertEqual(cleaned['nested']['token'],'[MASQUÉ]')
        for length in (16,32):
            serialized=json.dumps({'continuation_token':'a'*length+'.'+'b'*32})
            self.assertNotIn('a'*length+'.',oracle.clean(serialized))

    def test_visible_count_cap_is_not_inferred_from_the_search_display_limit(self):
        result={'status':'success','plan':{'index':'rie-pfs-fixture','filters':[
            {'concept':'action','operator':'eq','value':'deny'}]},'evidence':{'complete_for_query':True}}
        checks=assessment.fidelity({'expect':{'kind':'pdl_count'}},result,
                                   'Le comptage est limité à 100\u202f000 documents (max_rows).')
        self.assertFalse(next(c for c in checks if c['name']=='no_invented_count_cap_in_visible_answer')['passed'])

    def test_correct_total_from_the_wrong_source_is_rejected(self):
        result={'status':'success','plan':{'index':'rie-pfaing-fixture','filters':[]},
                'evidence':{'total':2,'complete_for_query':True}}
        checks=assessment.fidelity({'expect':{'kind':'pdl_count'}},result,'Deux refus.')
        self.assertFalse(next(c for c in checks if c['name']=='source_matches_the_question')['passed'])

    def test_incomplete_campaign_cannot_produce_a_final_assessment(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder);(path/'progress.json').write_text(json.dumps({'status':'running'}))
            (path/'matrix.json').write_text('{}')
            with self.assertRaisesRegex(ValueError,'not complete'):
                assessment.assess(path)

    def prepare_failed_oracle_receipt(self,path,*,message_id='message-owned'):
        stamp='2026-11-11T10:00:00+00:00'
        turn={'id':'return','number':1,'uc':'pdl','question':'Revenir au sujet initial',
              'expected':{'kind':'pdl_equipment','families':'all'},'started_at_utc':stamp,
              'finished_at_utc':stamp,'seconds':0,'state':'error','request_id':'message-owned',
              'checks':[],'error_detail':'plan was null'}
        matrix={'suites':[{'id':'mixed','turns':[{'id':'return','uc':'pdl','expect':turn['expected']}]}],
                'wrong_preset_probes':[]}
        progress={'started_at_utc':stamp,'matrix_sha256':'fixture','status':'running',
                  'completed_browser_posts':1,'cases':[{'suite':'mixed','repetition':1,
                  'chat_id':'chat-owned','turns':[turn]}]}
        receipt={'chat_id':'chat-owned','request_id':message_id,
                 'message':{**self.saved('pdl'),'model':oracle.MODELS['pdl']},
                 'output':self.saved('pdl')['output'],
                 'native_result':{'status':'needs_clarification','plan':None,'evidence':None}}
        for name,value in [('matrix.json',matrix),('progress.json',progress),('r1-mixed-01.json',receipt)]:
            (path/name).write_text(json.dumps(value))

    def test_same_message_receipt_recovers_oracle_error_but_keeps_business_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder);self.prepare_failed_oracle_receipt(path)
            row=assessment.assess(path,allow_incomplete=True,receipts=path)['rows'][0]
            self.assertTrue(row['receipt_recovered_after_oracle_error'])
            self.assertFalse(row['passed'])
            self.assertIn('unexpected_clarification',row['categories'])
            self.assertNotIn('client_or_transport',row['categories'])
            self.assertEqual(row['initial_harness_error'],'plan was null')

    def test_a_receipt_from_another_message_cannot_replace_the_failed_turn(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder);self.prepare_failed_oracle_receipt(path,message_id='another-message')
            with self.assertRaisesRegex(ValueError,'does not belong'):
                assessment.assess(path,allow_incomplete=True,receipts=path)

    def test_native_planner_timeout_is_reported_as_provider_failure_and_stays_failed(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder);self.prepare_failed_oracle_receipt(path)
            progress=json.loads((path/'progress.json').read_text())
            progress['cases'][0]['turns'][0]['state']='finished'
            (path/'progress.json').write_text(json.dumps(progress))
            receipt=json.loads((path/'r1-mixed-01.json').read_text())
            receipt['native_result']={'status':'error','plan':None,'evidence':None,
                'error':{'code':'AlbertPlannerError','message':'Albert timeout'}}
            (path/'r1-mixed-01.json').write_text(json.dumps(receipt))
            report=assessment.assess(path,allow_incomplete=True,receipts=path);row=report['rows'][0]
            self.assertFalse(row['passed'])
            self.assertIn('business_success',row['failed_checks'])
            self.assertIn('provider_failure',row['categories'])
            self.assertNotIn('other_business_mismatch',row['categories'])
            self.assertEqual(row['error_codes'],[{'source':'albert','phase':'pdl_planning','code':'timeout'}])
            self.assertIn('pdl_planning',assessment.markdown(report))

    def test_provider_error_metadata_does_not_copy_unrecognized_exception_prose(self):
        for message in ('private-provider-body api_key=secret',{'private':'secret'},['secret'],None):
            with self.subTest(message_type=type(message).__name__):
                result={'error':{'code':'AlbertPlannerError','message':message},
                        'errors':[{'source':'albert','code':'timeout','phase':'dialogue_interpretation','provider_code':'timeout'}]}
                errors=assessment.reported_errors(result)
                self.assertNotIn('secret',json.dumps(errors))
                self.assertEqual(errors[-1],{'source':'albert','phase':'pdl_planning','code':'planner_provider_error'})
                self.assertEqual(errors[0]['phase'],'dialogue_interpretation')
