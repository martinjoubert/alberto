"""The human-facing helpers disclose one demo account and never mutate state."""
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location('host_operations_tests', ROOT / 'deploy/ubuntu/host_operations.py')
operations = importlib.util.module_from_spec(spec)
spec.loader.exec_module(operations)


class HostOperationsTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        self.instance = self.root / 'private'
        self.accounts = self.instance / 'ldap-fixture/private/accounts.json'
        self.accounts.parent.mkdir(parents=True, mode=0o700)
        (self.instance / 'clients').mkdir(mode=0o700)
        self.accounts.write_text(json.dumps({'root_password': 'ROOT-SECRET', 'reader_password': 'READER-SECRET',
            'users': [{'uid': 'alice.martin', 'password': 'ALICE-SECRET'}, {'uid': 'eric.ext', 'password': 'ERIC-SECRET'}]}))
        self.accounts.chmod(0o600)
        def write_new(path, content):
            with path.open('x') as stream:stream.write(content)
            path.chmod(0o600)
        self.manager = SimpleNamespace(ROOT=ROOT, write_new=write_new, compose=Mock(), tool=Mock())

    def test_only_selected_synthetic_account_is_exported_without_any_secret_on_stdout(self):
        before = self.accounts.read_bytes()
        console = io.StringIO()
        with redirect_stdout(console):
            operations.run('demo-credentials', self.instance, {'RIE_MODE': 'demo'}, self.manager, username='alice.martin')
        receipt = json.loads(console.getvalue())
        output = Path(receipt['credentials_file'])
        self.assertEqual(json.loads(output.read_text()), {'username': 'alice.martin', 'password': 'ALICE-SECRET'})
        self.assertEqual(output.stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.accounts.read_bytes(), before)
        for secret in ('ROOT-SECRET', 'READER-SECRET', 'ALICE-SECRET', 'ERIC-SECRET'):
            self.assertNotIn(secret, console.getvalue())
        self.manager.compose.assert_not_called()
        self.manager.tool.assert_not_called()

    def test_external_mode_and_unknown_account_never_create_an_output(self):
        for mode, username in (('external', 'alice.martin'), ('demo', 'root'), ('demo', 'missing')):
            with self.subTest(mode=mode, username=username), self.assertRaises(ValueError):
                operations.demo_credentials(self.instance, {'RIE_MODE': mode}, username, None, self.manager)
        self.assertEqual(list((self.instance / 'clients').iterdir()), [])

    def test_existing_file_and_symlink_are_preserved_and_public_parent_is_refused(self):
        output = self.instance / 'clients/existing.json'
        output.write_text('preserve')
        with self.assertRaises(ValueError):
            operations.demo_credentials(self.instance, {'RIE_MODE': 'demo'}, 'alice.martin', output, self.manager)
        self.assertEqual(output.read_text(), 'preserve')
        alias = self.instance / 'clients/link.json'
        alias.symlink_to(output)
        with self.assertRaises(ValueError):
            operations.demo_credentials(self.instance, {'RIE_MODE': 'demo'}, 'alice.martin', alias, self.manager)
        public = self.root / 'public';public.mkdir(mode=0o755);public.chmod(0o755)
        with self.assertRaises(ValueError):
            operations.demo_credentials(self.instance, {'RIE_MODE': 'demo'}, 'alice.martin', public/'credential.json', self.manager)
        self.assertFalse((public/'credential.json').exists())

    def test_unbounded_logs_or_unknown_service_never_reach_docker(self):
        for service, tail in (('other-project', 100), ('pdl', 0), ('pdl', 10001), ('pdl', True)):
            with self.subTest(service=service, tail=tail), self.assertRaises(ValueError):
                operations.run('logs', self.instance, {}, self.manager, service=service, tail=tail)
        self.manager.compose.assert_not_called()
        operations.run('logs', self.instance, {}, self.manager, service='incidents', tail=50)
        self.assertEqual(self.manager.compose.call_args.args[-3:], ('--tail', '50', 'incidents'))

    def test_storage_scan_counts_reports_separately_from_continuations_and_does_not_write(self):
        root = self.root / 'runtime'
        contents = {'pdl/reports/report.json': b'123', 'incidents/investigations/report.json': b'4567',
            'incidents/investigations/.continuations/state.json': b'89012', 'access/audit.jsonl': b'abcdef'}
        for name, data in contents.items():
            path = root/name;path.parent.mkdir(parents=True, exist_ok=True);path.write_bytes(data)
        script = operations.STORAGE_SCRIPT.replace("Path('/data')", 'Path(' + repr(str(root)) + ')')
        result = subprocess.run([sys.executable, '-B', '-c', script], capture_output=True, text=True, check=True)
        summary = json.loads(result.stdout)
        self.assertEqual(summary['groups']['incident_reports'], {'files': 1, 'bytes': 4})
        self.assertEqual(summary['groups']['incident_continuations'], {'files': 1, 'bytes': 5})
        self.assertFalse(summary['automatic_deletion'])
        self.assertEqual({p.relative_to(root).as_posix(): p.read_bytes() for p in root.rglob('*') if p.is_file()}, contents)
        outside = self.root / 'outside';outside.mkdir();(outside/'secret').write_text('PRIVATE')
        (root/'pdl/reports/link').symlink_to(outside, target_is_directory=True)
        refused = subprocess.run([sys.executable, '-B', '-c', script], capture_output=True, text=True)
        self.assertNotEqual(refused.returncode, 0)
        self.assertNotIn('PRIVATE', refused.stdout)


if __name__ == '__main__':
    unittest.main()
