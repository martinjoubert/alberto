"""Exercise mapping administration with live role/policy checks and real stores."""
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
for path in ('deploy/ubuntu', 'core/access-control/src', 'core/albert-client/src', 'use-cases/pdl/agentic-pdl'):
    sys.path.insert(0, str(ROOT / path))
from dinum_access import AccessDenied, AccessGate
from portal.backend import Session, PortalError
from portal.mapping_admin import MappingAdministration, document_from_snapshot, export_document
from rie_agent.store import Store


class Directory:
    administrator = True
    def lookup(self, value, *, username=False, identity=False, authorization=False, **kwargs):
        name = value if username else value.split('@')[0]
        category = 'external' if name == 'eric' else 'internal'
        result = (name + '@example.test', category)
        if identity: result += (name + '-stable-object',)
        return (*result, name == 'alice' and self.administrator) if authorization else result


class MappingFixture:
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(); self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        access = self.root / 'access'; access.mkdir()
        self.policy_path = access / 'policy.json'
        self.policy = {'version': 1, 'revision': 1, 'default': 'blocked',
                       'indices': {'pfs-prod': 'internal', 'bb-prod': 'internal', 'secret-prod': 'blocked'}}
        self.policy_path.write_text(json.dumps(self.policy))
        key = self.root / 'session.key'; key.write_text('mapping-fixture-material-of-at-least-32-characters')
        self.directory = Directory()
        config = {'version': 1, 'ldap': {}, 'state_directory': str(access),
                  'session_key_file': str(key), 'allow_webui_assertions': False}
        self.gate = lambda: AccessGate(config, self.directory)
        self.session = Session(gate_factory=self.gate)
        self.session.login('alice', 'fictional-password')
        self.store = Store(self.root / 'pdl')
        fields = {name: {'type': kind, 'types': [kind], 'searchable': True, 'aggregatable': True}
                  for name, kind in [('@timestamp', 'date'), ('event.action', 'keyword'),
                                      ('asset.id', 'keyword'), ('other.action', 'keyword')]}
        self.inventory = {'allowed_patterns': ['pfs-*', 'bb-*', 'secret-*'], 'indices': {
            index: {'schema_hash': str(number) * 64, 'fields': deepcopy(fields),
                    'bounded_values': {'event.action': [{'value': 'FORBIDDEN_VALUE' if index == 'secret-prod' else 'deny', 'count': 1}]}}
            for number, index in enumerate(('pfs-prod', 'bb-prod', 'secret-prod'), 1)}}
        self.store.save_inventory(self.inventory)
        self.document = {'version': 1, 'indices': {'pfs': {'match': 'pfs-prod', 'concepts': {
            'timestamp': {'field': '@timestamp', 'type': 'date'},
            'action': {'field': 'event.action', 'type': 'keyword', 'values': ['deny', 'allow']}}}}, 'relations': {}}
        self.refreshes = 0
        self.after_refresh = lambda: None
        owner = self
        class Inventory:
            def __init__(self, settings, store): self.store = store
            def refresh(self):
                owner.refreshes += 1
                self.store.save_inventory(deepcopy(owner.inventory))
                owner.after_refresh()
                return deepcopy(owner.inventory)
        self.inventory_factory = Inventory
        self.settings = SimpleNamespace(data_dir=self.store.root, allowed_index_patterns=('pfs-*', 'bb-*', 'secret-*'))
        self.admin = MappingAdministration(self.session, settings_factory=lambda: self.settings,
                                           inventory_factory=self.inventory_factory)

    def stage(self, reason='Approved source dictionary to review'):
        validation = self.admin.validate(self.document)
        return self.admin.stage(self.document, validation, reason)['reviews'][0]['id']


class MappingAdministrationTests(MappingFixture, unittest.TestCase):
    def test_unchanged_pending_mapping_reuses_review_despite_yaml_author_or_reason_changes(self):
        from rie_agent.operator_mappings import stage_reviews
        identifier = stage_reviews(self.store, self.document, file_hash='a' * 64,
                                   author='original-operator', reason='Original YAML import')[0]['id']
        snapshot = self.admin.overview()
        draft = document_from_snapshot(snapshot)
        validation = self.admin.validate(draft)
        result = self.admin.stage(draft, validation, 'Same correspondence from the form')
        self.assertEqual([row['id'] for row in result['reviews']], [identifier])
        self.assertEqual(len(self.store.reviews()), 1)
        self.assertEqual(self.store.review(identifier)['operator_file']['author'], 'original-operator')

    def test_readers_and_external_accounts_are_denied_before_settings_or_store_reads(self):
        for name in ('bruno', 'eric'):
            self.session.login(name, 'fictional-password')
            with patch.object(self.admin, 'settings_factory', side_effect=AssertionError('No protected read')):
                with self.assertRaisesRegex(AccessDenied, 'administrator_required'):
                    self.admin.overview(refresh=True)

    def test_expired_session_cannot_inspect_cached_schemas(self):
        self.session.logout()
        with self.assertRaisesRegex(AccessDenied, 'identity_required'):
            self.admin.overview()
        self.assertEqual(self.refreshes, 0)

    def test_forbidden_index_names_samples_and_reviews_are_not_returned(self):
        snapshot = self.admin.overview()
        self.assertNotIn('secret-prod', json.dumps(snapshot))
        self.assertNotIn('FORBIDDEN_VALUE', json.dumps(snapshot))

    def test_blocked_draft_is_refused_before_source_refresh(self):
        self.document['indices']['pfs']['match'] = 'secret-prod'
        with self.assertRaisesRegex(AccessDenied, 'index_forbidden'):
            self.admin.validate(self.document)
        self.assertEqual(self.refreshes, 0)

    def test_validation_and_export_never_stage_or_activate(self):
        result = self.admin.validate(self.document)
        self.assertTrue(result['valid'])
        exported = self.admin.export(self.document)
        self.assertEqual(self.admin.import_document(exported), self.document)
        self.assertEqual(self.store.reviews(), [])
        self.assertEqual(self.store.catalog(), [])

    def test_stage_is_pending_and_requires_an_explicit_confirmation_to_approve(self):
        identifier = self.stage()
        self.assertEqual(self.store.review(identifier)['status'], 'pending')
        self.assertEqual(self.store.catalog(), [])
        inspected = self.admin.review(identifier)
        with self.assertRaisesRegex(PortalError, 'mapping_confirmation_required'):
            self.admin.approve(identifier, inspected['state_hash'], 'Reviewed with source owner')
        result = self.admin.approve(identifier, inspected['state_hash'], 'Reviewed with source owner', confirmed=True)
        self.assertEqual(result, {'status': 'approved', 'index': 'pfs-prod', 'version': 1})
        self.assertEqual(self.store.catalog()[0]['approved_by'], 'alice@example.test')

    def test_changed_draft_must_be_validated_again(self):
        validation = self.admin.validate(self.document)
        self.document['indices']['pfs']['concepts']['action']['values'] = ['drop']
        with self.assertRaisesRegex(PortalError, 'mapping_validation_required'):
            self.admin.stage(self.document, validation, 'Changed')
        self.assertEqual(self.store.reviews(), [])

    def test_schema_change_between_validation_and_staging_is_rejected(self):
        validation = self.admin.validate(self.document)
        self.inventory['indices']['pfs-prod']['schema_hash'] = 'a' * 64
        with self.assertRaisesRegex(PortalError, 'mapping_schema_changed'):
            self.admin.stage(self.document, validation, 'Review changed schema')
        self.assertEqual(self.store.reviews(), [])

    def test_review_changes_after_inspection_cannot_be_approved(self):
        identifier = self.stage(); inspected = self.admin.review(identifier)
        changed = deepcopy(inspected['review']['proposed_mapping'])
        changed['action']['field'] = 'other.action'
        self.store.update_review(identifier, {'proposed_mapping': changed})
        with self.assertRaisesRegex(PortalError, 'mapping_review_changed'):
            self.admin.approve(identifier, inspected['state_hash'], 'Old decision', confirmed=True)
        self.assertEqual(self.store.catalog(), [])

    def test_another_active_version_requires_reading_the_diff_again(self):
        first = self.stage('First proposal'); first_view = self.admin.review(first)
        second = self.stage('Second proposal'); second_view = self.admin.review(second)
        self.admin.approve(second, second_view['state_hash'], 'Review second proposal', confirmed=True)
        with self.assertRaisesRegex(PortalError, 'mapping_review_changed'):
            self.admin.approve(first, first_view['state_hash'], 'Stale active-version comparison', confirmed=True)
        self.assertEqual(len(self.store.catalog()), 1)

    def test_approval_rechecks_source_schema(self):
        identifier = self.stage(); view = self.admin.review(identifier)
        self.inventory['indices']['pfs-prod']['schema_hash'] = 'b' * 64
        with self.assertRaisesRegex(PortalError, 'mapping_schema_changed'):
            self.admin.approve(identifier, view['state_hash'], 'Old schema', confirmed=True)
        self.assertEqual(self.store.catalog(), [])

    def test_revoked_admin_group_cannot_commit_after_source_refresh(self):
        validation = self.admin.validate(self.document)
        self.after_refresh = lambda: setattr(self.directory, 'administrator', False)
        with self.assertRaisesRegex(AccessDenied, 'administrator_required'):
            self.admin.stage(self.document, validation, 'Must not stage')
        self.assertEqual(self.store.reviews(), [])

    def test_source_blocked_during_refresh_cannot_be_approved(self):
        identifier = self.stage(); view = self.admin.review(identifier)
        def block():
            self.policy['indices']['pfs-prod'] = 'blocked'
            self.policy['revision'] += 1
            self.policy_path.write_text(json.dumps(self.policy))
        self.after_refresh = block
        with self.assertRaisesRegex(AccessDenied, 'index_forbidden'):
            self.admin.approve(identifier, view['state_hash'], 'Must not approve', confirmed=True)
        self.assertEqual(self.store.catalog(), [])

    def test_logout_during_refresh_cannot_stage_under_a_different_session(self):
        validation = self.admin.validate(self.document)
        self.after_refresh = self.session.logout
        with self.assertRaisesRegex(PortalError, 'session_changed'):
            self.admin.stage(self.document, validation, 'Must not stage')
        self.assertEqual(self.store.reviews(), [])

    def test_duplicate_click_never_creates_another_catalog_version(self):
        identifier = self.stage(); view = self.admin.review(identifier)
        self.admin.approve(identifier, view['state_hash'], 'First click', confirmed=True)
        with self.assertRaisesRegex(PortalError, 'mapping_review_changed'):
            self.admin.approve(identifier, view['state_hash'], 'Second click', confirmed=True)
        self.assertEqual(len(self.store.catalog()), 1)

    def test_unchanged_active_correspondences_do_not_create_new_reviews(self):
        identifier = self.stage(); view = self.admin.review(identifier)
        self.admin.approve(identifier, view['state_hash'], 'Validated', confirmed=True)
        validation = self.admin.validate(self.document)
        result = self.admin.stage(self.document, validation, 'No configuration change')
        self.assertEqual(result['reviews'], [])
        self.assertEqual(len(self.store.reviews()), 1)

    def test_invalid_yaml_duplicates_aliases_and_large_imports_are_rejected(self):
        for raw in (b'version: 1\nversion: 1', b'a: &example []\nb: *example', b'[' * 50, b'x' * (1024 * 1024 + 1)):
            with self.subTest(size=len(raw)), self.assertRaisesRegex(PortalError, 'mapping_invalid_document'):
                self.admin.import_document(raw)
        self.assertEqual(self.store.reviews(), [])

    def test_unknown_fields_have_an_actionable_error_without_echoing_the_value(self):
        self.document['indices']['pfs']['concepts']['action']['field'] = 'accidentally-pasted-private-value'
        with self.assertRaises(PortalError) as caught:
            self.admin.validate(self.document)
        self.assertIn('pfs / action', caught.exception.issues[0])
        self.assertNotIn('accidentally-pasted-private-value', str(caught.exception.issues))

    def test_source_failure_keeps_a_safe_error_and_does_not_activate(self):
        with patch.object(self.admin, 'inventory_factory', side_effect=RuntimeError('private-source-address')):
            with self.assertRaisesRegex(PortalError, 'mapping_source_unavailable'):
                self.admin.validate(self.document)
        self.assertEqual(self.store.catalog(), [])

    def test_reconstructed_document_preserves_relations_and_business_values(self):
        self.document['indices']['bb'] = {'match': 'bb-prod', 'concepts': {
            'timestamp': {'field': '@timestamp', 'type': 'date'},
            'stable_id': {'field': 'asset.id', 'type': 'keyword', 'identity_role': 'id'}}}
        self.document['indices']['pfs']['concepts']['stable_id'] = {
            'field': 'asset.id', 'type': 'keyword', 'identity_role': 'id'}
        self.document['relations'] = {'asset-id': {'pfs': ['stable_id'], 'bb': ['stable_id']}}
        self.stage()
        reconstructed = document_from_snapshot(self.admin.overview())
        self.assertEqual(reconstructed, self.document)
        self.assertEqual(self.admin.import_document(self.admin.export(reconstructed)), self.document)


if __name__ == '__main__':
    unittest.main()
