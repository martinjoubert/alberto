"""The status transport accepts the actual deterministic seed manifest offline."""
from copy import deepcopy
from contextlib import contextmanager
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock,patch

ROOT=Path(__file__).resolve().parents[3]
for relative in ('core/access-control/src','core/albert-client/src','use-cases/incidents/observability-demo'):
    sys.path.insert(0,str(ROOT/relative))
from dinum_access.security import AccessGate,CURRENT,Principal
from obs_poc.config import Settings
from obs_poc import server
from starlette.testclient import TestClient

spec=importlib.util.spec_from_file_location('incident_status_seed',ROOT/'deploy/ubuntu/seed_incidents.py')
seed=importlib.util.module_from_spec(spec);spec.loader.exec_module(seed)


class IncidentStatusTransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.seed_manifest,_,_=seed.build_corpus(ROOT/'use-cases/incidents/observability-demo')

    def setUp(self):
        private=tempfile.TemporaryDirectory();self.addCleanup(private.cleanup)
        root=Path(private.name);self.manifest_path=root/'corpus.json'
        self.settings=Settings(mcp_token='technical-only',albert_key='unused',zabbix_token='unused',
                               os_password='',manifest_path=self.manifest_path,reports=root/'reports',logs_index=seed.LOGS_INDEX)
        self.principal=Principal('test-internal','alice@example.org','internal',True)
        (root/'policy.json').write_text(json.dumps({'version':1,'revision':1,'default':'blocked',
            'indices':{self.settings.logs_index:'internal',self.settings.docs_index:'internal'},
            'resources':{'incidents.metrics':'internal','incidents.tickets':'internal'}}))
        self.gate=AccessGate({'state_directory':str(root)},directory=object())
        self.gate.authenticate=Mock(return_value=self.principal)
        self.settings.manifest=Mock(wraps=self.settings.manifest)

    @contextmanager
    def transport(self):
        with patch('dinum_access.security.AccessGate.configured',return_value=self.gate),\
             patch.object(server,'Sources',side_effect=AssertionError('Status must never query a backend')),\
             patch('socket.create_connection',side_effect=AssertionError('No network permitted')):
            client=TestClient(server.create_app(self.settings),raise_server_exceptions=False)
            try:yield client
            finally:client.close()

    def get_status(self,manifest=None,*,raw=None,client=None):
        self.gate.authenticate.reset_mock();self.settings.manifest.reset_mock()
        if manifest is not None:self.manifest_path.write_text(json.dumps(manifest))
        elif raw is not None:self.manifest_path.write_text(raw)
        if client is not None:response=client.get('/status',headers={'Authorization':'Bearer individual-person'})
        else:
            with self.transport() as client:
                response=client.get('/status',headers={'Authorization':'Bearer individual-person'})
        self.gate.authenticate.assert_called_once()
        return response

    def assert_denied_without_corpus(self,response):
        self.assertEqual(response.status_code,403,response.text)
        self.assertNotIn('OBS-RTR-',response.text)
        self.assertNotIn('anchor_date',response.text)
        self.assertNotIn('hosts',response.json())
        self.settings.manifest.assert_not_called()

    def test_external_identity_cannot_read_status_metadata_or_manifest(self):
        self.gate.authenticate.return_value=Principal('test-external','outside@example.org','external',False)
        response=self.get_status(self.seed_manifest)
        self.assert_denied_without_corpus(response)

    def test_both_index_rules_are_checked_before_file_access_on_every_request(self):
        with self.transport() as client:
            for index in (self.settings.logs_index,self.settings.docs_index):
                with self.subTest(index=index):
                    response=self.get_status(self.seed_manifest,client=client)
                    self.assertEqual(response.status_code,200)
                    self.settings.manifest.assert_called_once()
                    revision=self.gate.store.read()['revision']
                    self.gate.store.update(self.principal,index,'blocked',revision)
                    self.assert_denied_without_corpus(self.get_status(client=client))
                    revision=self.gate.store.read()['revision']
                    self.gate.store.update(self.principal,index,'internal',revision)
                    self.assertEqual(self.get_status(client=client).status_code,200)
                    self.settings.manifest.assert_called_once()
        audits=[json.loads(line) for line in (self.manifest_path.parent/'audit.jsonl').read_text().splitlines()]
        reads=[row for row in audits if row['operation']=='read_indices']
        self.assertEqual(len(reads),6)
        self.assertTrue(any(not row['allowed'] for row in reads))
        self.assertTrue(all(set(row['indices'])=={self.settings.logs_index,self.settings.docs_index} for row in reads))

    def test_no_acl_configuration_preserves_historical_status(self):
        self.manifest_path.write_text(json.dumps(self.seed_manifest))
        with patch('dinum_access.security.AccessGate.configured',return_value=None),\
             patch.dict('os.environ',{},clear=True):
            client=TestClient(server.create_app(self.settings),raise_server_exceptions=False)
            try:response=client.get('/status')
            finally:client.close()
        self.assertEqual(response.status_code,200)
        self.assertIsNone(CURRENT.get())

    def test_real_seed_without_prepared_at_returns_200_and_explicit_null(self):
        self.assertNotIn('prepared_at',self.seed_manifest)
        response=self.get_status(self.seed_manifest)
        self.assertEqual(response.status_code,200,response.text)
        result=response.json()
        self.assertIsNone(result['prepared_at'])
        for field in ('status','anchor_date','start','end','data_flow'):
            self.assertEqual(result[field],self.seed_manifest[field])
        self.assertEqual(result['hosts'],[h for h in self.seed_manifest['hosts'] if h['allowed']])
        self.assertNotIn('OBS-RTR-04',response.text)

    def test_historical_prepared_at_is_preserved(self):
        response=self.get_status({**self.seed_manifest,'prepared_at':'2026-11-06T12:30:00+00:00'})
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json()['prepared_at'],'2026-11-06T12:30:00+00:00')

    def test_before_initialization_and_corrupt_json_return_generic_503(self):
        for raw in (None,'{private_directory: /private/secret/corpus.json}'):
            with self.subTest(raw=raw):
                self.gate.authenticate.reset_mock();self.manifest_path.unlink(missing_ok=True)
                response=self.get_status(raw=raw)
                self.assertEqual(response.status_code,503)
                self.assertEqual(response.json(),{'status':'not_prepared'})

    def test_required_business_metadata_is_not_silently_optional(self):
        for field in ('status','anchor_date','start','end','hosts'):
            manifest=deepcopy(self.seed_manifest);del manifest[field]
            with self.subTest(field=field):
                self.gate.authenticate.reset_mock()
                response=self.get_status(manifest)
                self.assertEqual(response.status_code,503)
                self.assertEqual(response.json(),{'status':'not_prepared'})

    def test_invalid_manifest_and_host_shapes_return_generic_503(self):
        cases=[[],False,{'hosts':[]},
               {**self.seed_manifest,'hosts':'private host source'},
               {**self.seed_manifest,'hosts':[{'equipment':'private-host-without-visibility'}]},
               {**self.seed_manifest,'hosts':[None]},
               {**self.seed_manifest,'hosts':[{**self.seed_manifest['hosts'][0],'allowed':'false'}]},
               {**self.seed_manifest,'start':None},
               {**self.seed_manifest,'prepared_at':{'secret':'private-source'}},
               {**self.seed_manifest,'data_flow':['private-source']}]
        for manifest in cases:
            with self.subTest(manifest=manifest):
                self.gate.authenticate.reset_mock()
                response=self.get_status(manifest)
                self.assertEqual(response.status_code,503)
                self.assertEqual(response.json(),{'status':'not_prepared'})


if __name__=='__main__':unittest.main()
