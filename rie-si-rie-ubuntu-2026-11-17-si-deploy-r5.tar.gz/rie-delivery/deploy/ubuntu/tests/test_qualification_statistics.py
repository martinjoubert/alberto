from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from qualification_statistics import byte_count, resource_summary


class MeasurementsTests(unittest.TestCase):
    def test_docker_decimal_and_binary_units_are_distinguished(self):
        self.assertEqual(byte_count('1.5MB'), 1500000)
        self.assertEqual(byte_count('1.5MiB'), 1572864)
        self.assertEqual(byte_count('1GiB'), 1073741824)
        with self.assertRaises(ValueError):
            byte_count('unknown')

    def test_multicore_cpu_is_not_clipped_and_memory_is_working_set(self):
        data = [{'containers': [{'Name': 'rie-123-opensearch-1', 'CPUPerc': '175.5%',
                                'MemUsage': '1GiB / 2GiB'}]}]
        row = resource_summary(data)['opensearch']
        self.assertEqual(row['cpu_peak_percent_of_one_cpu'], 175.5)
        self.assertEqual(row['working_set_peak_bytes'], 1073741824)
