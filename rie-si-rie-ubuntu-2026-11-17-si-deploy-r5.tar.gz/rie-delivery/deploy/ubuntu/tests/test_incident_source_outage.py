"""Unavailable source resolution must not masquerade as a policy refusal."""
from contextlib import contextmanager
import json
from pathlib import Path
import sys
import tempfile
import unittest

import httpx

ROOT=Path(__file__).resolve().parents[3]
for folder in ('core/access-control/src','core/albert-client/src','use-cases/incidents/observability-demo'):
    sys.path.insert(0,str(ROOT/folder))
from dinum_access.security import AccessGate,CURRENT,Principal
from obs_poc.clients import Sources,SourceError
from obs_poc.config import Settings


class SourceResolutionTests(unittest.TestCase):
    @contextmanager
    def source(self,category,handler):
        with tempfile.TemporaryDirectory() as directory:
            state=Path(directory)
            (state/'policy.json').write_text(json.dumps({'version':1,'revision':1,'default':'blocked',
                'indices':{'pdl-zabbix-observability-demo':'internal','obs-network-docs':'internal'}}))
            gate=AccessGate({'state_directory':str(state)},directory=object())
            marker=CURRENT.set((gate,Principal('user','user@example.org',category,category=='internal')))
            source=Sources(Settings(metrics_provider='victoriametrics',logs_index='pdl-zabbix-observability-demo',
                                    albert_key='unused',zabbix_token='unused',mcp_token='unused',os_password=''))
            source.source_transport=httpx.MockTransport(handler)
            try:yield source,gate
            finally:source.close();CURRENT.reset(marker)

    def test_connection_failure_stays_source_unavailable_without_marking_access_denied(self):
        def serve(request):raise httpx.ConnectError('private source address',request=request)
        with self.source('internal',serve) as (source,gate):
            with self.assertRaises(SourceError) as error:source.os(source.s.logs_index,{'size':0})
            self.assertEqual(error.exception.source,'opensearch')
            self.assertEqual(error.exception.code,'connection_failed')
            self.assertFalse(gate.store.denied)

    def test_forbidden_concrete_index_never_reaches_the_network(self):
        def serve(request):raise AssertionError('Forbidden index must not even be resolved')
        with self.source('external',serve) as (source,gate):
            with self.assertRaises(SourceError) as error:source.os(source.s.logs_index,{'size':0})
            self.assertEqual(error.exception.source,'authorization');self.assertTrue(gate.store.denied)

    def test_authorized_alias_is_still_rejected_without_search(self):
        paths=[]
        def serve(request):
            paths.append(request.url.path)
            return httpx.Response(200,json={'indices':[],'aliases':[{'name':'pdl-zabbix-observability-demo'}]})
        with self.source('internal',serve) as (source,gate):
            with self.assertRaises(SourceError) as error:source.os(source.s.logs_index,{'size':0})
            self.assertEqual(error.exception.source,'authorization');self.assertTrue(gate.store.denied)
        self.assertEqual(paths,['/_resolve/index/pdl-zabbix-observability-demo'])


if __name__=='__main__':unittest.main()
