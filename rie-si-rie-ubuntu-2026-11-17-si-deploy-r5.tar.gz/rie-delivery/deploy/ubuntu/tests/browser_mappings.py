"""Qualify guided mappings on an explicitly identified disposable Ubuntu instance.

Uses the real portal and LDAP. May approve one review only with the explicit
--exercise-approval flag and a matching instance identity. Never calls Albert.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', required=True)
    parser.add_argument('--expected-instance-id', required=True)
    credentials = parser.add_mutually_exclusive_group(required=True)
    credentials.add_argument('--accounts-stdin', action='store_true')
    credentials.add_argument('--accounts-file', type=Path)
    parser.add_argument('--exercise-approval', action='store_true')
    parser.add_argument('--browser-executable', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--allure-results', type=Path)
    args = parser.parse_args()
    if not args.url.startswith(('http://127.0.0.1:', 'https://')):
        parser.error('Use local HTTP or authenticated HTTPS')
    if len(args.expected_instance_id) != 32 or not all(c in '0123456789abcdef' for c in args.expected_instance_id):
        parser.error('A precise instance identity is required')
    os.umask(0o077)
    args.output.mkdir(parents=True, exist_ok=True)
    accounts = json.load(sys.stdin) if args.accounts_stdin else json.loads(args.accounts_file.read_text())
    users = {row['uid']: row['password'] for row in accounts['users']}
    from playwright.sync_api import sync_playwright, expect
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from browser_diagnostics import BrowserDiagnostics
    from test_reporting import write_result
    diagnostics = BrowserDiagnostics(args.output, secrets=users.values())
    checks, pages = [], []
    start = time.time_ns() // 1_000_000

    def checked(name, captures=()):
        checks.append({'name': name, 'passed': True})
        if args.allure_results:
            write_result(args.allure_results, 'browser-mappings', name, 'passed', start=start,
                         stop=time.time_ns() // 1_000_000, secrets=users.values(),
                         attachments=[args.output / file for file in captures],
                         labels=[{'name': 'framework', 'value': 'playwright-python'},
                                 {'name': 'backends', 'value': 'deployed-ubuntu'}])
        print(json.dumps({'check': name, 'passed': True}), flush=True)

    def page_for(browser, username):
        context = browser.new_context(viewport={'width': 1440, 'height': 1080}, accept_downloads=True)
        page = context.new_page(); pages.append(page); diagnostics.watch(page)
        page.goto(args.url.rstrip('/') + '/admin-mappings')
        page.locator('[data-portal-username] input, input[data-portal-username]').fill(username)
        page.locator('[data-portal-password] input, input[data-portal-password]').fill(users[username])
        page.locator('[data-portal-login]').click()
        expect(page.locator('[data-portal-login-status]')).to_contain_text('Connexion établie', timeout=30000)
        return page

    def idle(page):
        expect(page.locator('[data-mapping-busy]')).to_have_text('', timeout=60000)

    def choose(page, selector, label):
        control = page.locator(selector)
        control.click()
        page.get_by_role('option', name=label, exact=True).click()

    report = {'at_utc': datetime.now(timezone.utc).isoformat(), 'instance_id': args.expected_instance_id,
              'backend': 'real-ubuntu-and-ldap-with-fictional-si-data', 'albert_called': False,
              'approval_enabled': args.exercise_approval, 'checks': checks, 'credentials_emitted': False}
    status = 1
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path=str(args.browser_executable), headless=True)
        try:
            for username in ('bruno.lecteur', 'eric.durand.ext'):
                page = page_for(browser, username)
                expect(page.locator('[data-mapping-denied]')).to_be_visible(timeout=30000)
                expect(page.locator('[data-mapping-editor]')).to_have_count(0)
                expect(page.locator('[data-mapping-indices]')).to_have_count(0)
                checked('administrator_required_' + username)
                page.context.close(); pages.remove(page)
            page = page_for(browser, 'alice.martin')
            expect(page.locator('[data-mapping-instance]')).to_have_text('Instance : ' + args.expected_instance_id)
            expect(page.locator('[data-mapping-pending-count]')).to_have_text('4 revue(s) en attente.', timeout=30000)
            checked('existing_pending_reviews_recovered')
            page.locator('[data-mapping-refresh]').click()
            expect(page.locator('[data-mapping-busy]')).to_have_text('Vérification en cours…', timeout=30000)
            idle(page)
            expect(page.locator('[data-mapping-indices]')).to_contain_text('rie-pfs-fixture')
            checked('authorized_inventory_refreshed')
            choose(page, '[data-mapping-profile]', 'pfs · rie-pfs-fixture')
            expect(page.locator('[data-mapping-type=timestamp]')).to_contain_text('date')
            expect(page.locator('[data-mapping-relations]')).to_contain_text('equipment')
            checked('guided_fields_types_and_relations')
            page.locator('[data-mapping-validate]').click()
            expect(page.locator('[data-mapping-validation]')).to_contain_text('Proposition valide techniquement', timeout=60000)
            if args.exercise_approval:
                page.locator('[data-mapping-stage-reason] input, input[data-mapping-stage-reason]').fill('Qualification navigateur : proposition inchangée à examiner')
                page.locator('[data-mapping-stage]').click()
                expect(page.locator('[data-mapping-validation]')).to_contain_text('aucun mapping activé', timeout=60000)
                expect(page.locator('[data-mapping-pending-count]')).to_have_text('4 revue(s) en attente.', timeout=30000)
                checked('staging_reuses_pending_reviews_without_activation')
            with page.expect_download() as download:
                page.locator('[data-mapping-export]').click()
            path = args.output / 'exported-pdl-mappings.yaml'
            download.value.save_as(path)
            assert path.stat().st_size > 100
            checked('portable_yaml_export')
            upload = page.locator('[data-mapping-upload] input[type=file]')
            upload.set_input_files({'name': 'invalid.yaml', 'mimeType': 'application/yaml', 'buffer': b'version: 1\nversion: 2\n'})
            expect(page.locator('[data-portal-error]')).to_contain_text('Proposition incompatible', timeout=30000)
            checked('malformed_import_refused')
            upload.set_input_files(path)
            expect(page.get_by_text('Proposition chargée dans le formulaire ; aucune approbation effectuée.', exact=True)).to_be_visible(timeout=30000)
            checked('export_import_round_trip')
            # Review selection is explicit; never infer an ID from a user's main instance.
            page.locator('[data-mapping-review-select]').click()
            option = page.get_by_role('option').filter(has_text='rie-pfs-fixture').first
            option.click()
            page.locator('[data-mapping-inspect]').click()
            expect(page.locator('[data-mapping-diff]')).to_be_visible(timeout=30000)
            checked('human_readable_review_diff')
            diagnostics.captures([(page, 'mapping-review-20261116.png')])
            if args.exercise_approval:
                page.locator('[data-mapping-approve]').click()
                expect(page.locator('[data-portal-error]')).to_contain_text('Confirmez la vérification', timeout=30000)
                expect(page.locator('[data-mapping-pending-count]')).to_have_text('4 revue(s) en attente.')
                checked('approval_without_confirmation_refused')
                page.locator('[data-mapping-inspect]').click()
                expect(page.locator('[data-mapping-diff]')).to_be_visible(timeout=30000)
                page.locator('[data-mapping-confirm]').click()
                page.locator('[data-mapping-approval-reason] input, input[data-mapping-approval-reason]').fill('Qualification isolée : sens métier confirmé sur le corpus fictif')
                page.locator('[data-mapping-approve]').click()
                expect(page.locator('[data-mapping-validation]')).to_contain_text('Mapping approuvé pour rie-pfs-fixture.', timeout=60000)
                expect(page.locator('[data-mapping-pending-count]')).to_have_text('3 revue(s) en attente.', timeout=30000)
                checked('one_explicit_approval_on_qualification_instance_only')
            diagnostics.captures([(page, 'mapping-editor-20261116.png')])
            page.locator('[data-portal-logout]').click()
            expect(page.locator('[data-mapping-editor]')).to_have_count(0, timeout=30000)
            expect(page.locator('[data-mapping-diff]')).to_have_count(0)
            checked('logout_clears_schemas_and_review_controls')
            status = 0
        except Exception as error:
            failure = diagnostics.failure(error)
            report['failure'] = failure
            captures = diagnostics.captures([(p, 'failure-' + str(i) + '.png') for i, p in enumerate(pages)])
            if args.allure_results:
                write_result(args.allure_results, 'browser-mappings', 'parcours restant', 'failed',
                             start=start, stop=time.time_ns() // 1_000_000, message=failure['message'],
                             trace=failure['trace'], diagnostics=diagnostics.channels(), secrets=users.values(),
                             attachments=[args.output / file for file in captures])
        finally:
            diagnostics.save(); browser.close()
    report['passed'] = status == 0
    (args.output / 'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'passed': status == 0, 'checks': len(checks), 'report': str(args.output / 'summary.json')}))
    return status


if __name__ == '__main__':
    raise SystemExit(main())
