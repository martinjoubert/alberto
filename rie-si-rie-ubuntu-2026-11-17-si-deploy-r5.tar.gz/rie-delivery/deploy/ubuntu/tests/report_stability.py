"""Offline assessment of the real Open WebUI stability receipts.

Never calls a model or rewrites the original receipts. A corrected qualification
assertion is applied uniformly to every repetition, with original checks kept.
"""
from __future__ import annotations

import argparse
from collections import Counter,defaultdict
import csv
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent
CATEGORIES={
    'wrong_period':'Période exécutée différente de la demande',
    'wrong_scope_or_filter':'Source, périmètre ou filtre différent de la demande',
    'unexpected_clarification':'Clarification superflue',
    'cross_uc_context_return':'Retour implicite à une autre UC non satisfait',
    'generation_not_validated':'Génération exigée par le scénario non validée',
    'client_or_transport':'Client, transport ou protocole d’outil',
    'provider_failure':'Fournisseur IA indisponible ou délai d’attente dépassé',
    'visible_answer_fidelity':'Explication visible non étayée',
    'wrong_domain_handling':'Mauvais profil : absence de guidage ou lecture hors sujet',
    'other_business_mismatch':'Autre écart au contrat attendu',
}


def oracle():
    spec=importlib.util.spec_from_file_location('stability_report_oracle',HERE/'browser_stability.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def percentile(values,percent):
    if not values:return None
    ordered=sorted(values);return round(ordered[max(0,math.ceil(len(ordered)*percent)-1)],3)


def reported_errors(result):
    """Normalize both UC error contracts without exporting provider error prose."""
    errors=[{k:e[k] for k in ('source','code','phase','provider_code') if k in e}
            for e in (result.get('errors') or []) if isinstance(e,dict)]
    failure=result.get('error')
    if isinstance(failure,dict) and failure.get('code')=='AlbertPlannerError':
        message=failure.get('message')
        code=({'Albert timeout':'timeout','Albert unavailable':'unavailable'}.get(
            message,'planner_provider_error') if isinstance(message,str) else 'planner_provider_error')
        errors.append({'source':'albert','phase':'pdl_planning','code':code})
    return errors


def fidelity(spec,result,answer):
    """Additional semantic invariants fixed by the source contracts and fixture."""
    expected=spec['expect'];kind=expected['kind'];result=result or {};checks=[]
    plan=result.get('plan') or {};evidence=result.get('evidence') or {}
    def check(name,passed,actual=None,wanted=None):checks.append({'name':name,'passed':bool(passed),'actual':actual,'expected':wanted})
    if kind in ('pdl_count','pdl_pfaing') and result.get('status')=='success':
        index='rie-pfs-fixture' if kind=='pdl_count' else 'rie-pfaing-fixture'
        check('source_matches_the_question',plan.get('index')==index,plan.get('index'),index)
        filters=plan.get('filters',[])
        scope=expected.get('scope','demo-alpha')
        check('scope_filter_matches_the_question',any(f.get('concept')=='network_scope' and
              f.get('operator','eq')=='eq' and f.get('value')==scope for f in filters),filters,scope)
        if kind=='pdl_count':
            check('denial_filter_is_present',any(f.get('concept')=='action' and f.get('operator','eq')=='eq' and f.get('value')=='deny' for f in filters),filters,'action eq deny')
            # max_rows limits displayed search rows, not an exact size=0 count.
            unsupported=bool(re.search(r'comptage\s+est\s+limit[ée]',answer,re.I))
            check('no_invented_count_cap_in_visible_answer',not unsupported,
                  [line for line in answer.splitlines() if re.search(r'comptage.{0,20}limit',line,re.I)],'no invented count cap')
        else:
            check('client_ip_filter_is_present',any(f.get('concept')=='source_ip' and f.get('value')=='192.0.2.25' for f in filters),filters,'source_ip eq 192.0.2.25')
        check('complete_count_or_search_not_assumed_from_partial_evidence',evidence.get('complete_for_query') is True,evidence.get('complete_for_query'),True)
    if kind=='pdl_equipment' and result.get('status')=='success':
        allowed={'rie-pfs-fixture','rie-bb-fixture','rie-pfaing-fixture','rie-tacacs-fixture'}
        read={r.get('index') for r in evidence.get('resources',[]) if r.get('index')}
        check('only_declared_pdl_indices_read',bool(read) and read<=allowed,sorted(read),sorted(allowed))
        check('complete_identity_and_log_resolution',evidence.get('complete_for_query') is True,evidence.get('complete_for_query'),True)
    if kind.startswith('incident_') and result.get('metrics'):
        actual={m.get('equipment') for m in result['metrics']};wanted=set(expected['equipment'])
        check('metric_equipment_matches_context',actual==wanted,sorted(actual),sorted(wanted))
        if kind=='incident_missing':
            check('missing_data_does_not_publish_high_diagnostic_confidence',(result.get('confidence') or {}).get('level')!='élevée',(result.get('confidence') or {}).get('level'),'not elevated')
    return checks


def assess(state,*,allow_incomplete=False,receipts=None):
    raw=(state/'progress.json').read_bytes();progress=json.loads(raw);matrix=json.loads((state/'matrix.json').read_text())
    if progress['status']!='completed' and not allow_incomplete:raise ValueError('Campaign is not complete')
    definitions={(s['id'],t['id']):t for s in matrix['suites'] for t in s['turns']}
    definitions.update({('wrong_'+t['id'],t['id']):t for t in matrix['wrong_preset_probes']})
    checker=oracle();rows=[]
    for case in progress['cases']:
        for turn in case['turns']:
            if turn.get('state') not in ('finished','error'):continue
            spec=definitions[case['suite'],turn['id']];result=turn.get('native_result') or {}
            # Reconstruction includes only fields actually captured by the runner.
            observed_done=next((c['passed'] for c in turn['checks'] if c['name']=='client_finished'),False)
            saved={'done':observed_done,
                   'error':turn.get('client_error'),'content':turn.get('rendered_answer',''),
                   'output':[{'type':'function_call',**call} for call in turn.get('tool_calls',[])]}
            receipt_path=(receipts/f'r{case["repetition"]}-{case["suite"]}-{turn["number"]:02d}.json') if receipts else None
            recovered=False
            if receipt_path and receipt_path.exists():
                receipt=json.loads(receipt_path.read_text())
                if receipt['chat_id']!=case['chat_id'] or receipt['request_id']!=turn.get('request_id'):
                    raise ValueError('Receipt does not belong to the recorded campaign turn')
                saved={**receipt['message'],'output':receipt['output']}
                result=receipt.get('native_result') or {}
                recovered=turn.get('state')=='error' and saved.get('done') is True
            model_sent=turn.get('model_sent') or (saved.get('model') if recovered else None)
            functional=checker.checks_for(spec,result,saved,{'model':model_sent})
            if turn.get('state')=='error' and not recovered:
                functional.append({'name':'browser_turn_completed','passed':False})
            extra=fidelity(spec,result,saved.get('content',''))
            failed=[c['name'] for c in [*functional,*extra] if not c['passed']]
            taxonomy=[];error_codes=reported_errors(result)
            if any((e.get('source')=='albert' and e.get('code') in
                    ('timeout','unavailable','planner_provider_error')) or e.get('provider_code') in
                   ('timeout','unavailable','deadline_exceeded','rate_limited','http_error','invalid_key','forbidden')
                   for e in error_codes):
                taxonomy.append('provider_failure')
            if saved.get('error') or (turn.get('state')=='error' and not recovered) or not result:taxonomy.append('client_or_transport')
            if result.get('status') in ('clarification','needs_clarification') and spec['expect']['kind'] not in ('clarification','wrong_uc'):
                taxonomy.append('unexpected_clarification')
            if spec['expect']['kind']=='wrong_uc' and failed:taxonomy.append('wrong_domain_handling')
            executed=any(result.get(k) for k in ('evidence','metrics','events','logs'))
            if executed and ('correct_pdl_period' in failed or 'correct_incident_period' in failed):taxonomy.append('wrong_period')
            if executed and any(name in failed for name in ('scope_filter_matches_the_question','source_matches_the_question','denial_filter_is_present','client_ip_filter_is_present')):
                taxonomy.append('wrong_scope_or_filter')
            if (spec['expect'].get('generation') and result.get('synthesis_mode')=='generated'
                    and (result.get('review') or {}).get('valid') is not True):taxonomy.append('generation_not_validated')
            if spec['expect'].get('cross_uc_memory') and failed:taxonomy.append('cross_uc_context_return')
            if 'no_invented_count_cap_in_visible_answer' in failed:taxonomy.append('visible_answer_fidelity')
            if not taxonomy and failed:taxonomy.append('other_business_mismatch')
            row={'repetition':case['repetition'],'suite':case['suite'],'turn':turn['number'],'id':turn['id'],
                 'uc':turn['uc'],'question':turn['question'],'expected':turn['expected'],'chat_id':case['chat_id'],
                 'started_at_utc':turn['started_at_utc'],'finished_at_utc':turn['finished_at_utc'],
                 'seconds':turn['seconds'],'state':turn['state'],'business_status':result.get('status'),
                 'receipt_recovered_after_oracle_error':recovered,
                 'initial_harness_error':turn.get('error_detail'),
                 'initial_checks':turn['checks'],'functional_checks':functional,'fidelity_checks':extra,
                 'functional_passed':all(c['passed'] for c in functional),
                 'passed':not failed,'failed_checks':failed,'categories':taxonomy,
                 'client_error':saved.get('error'),'clarification':result.get('clarification'),
                 'error_codes':error_codes,
                 'dialogue_model':(result.get('dialogue') or {}).get('actual_model'),
                 'planner_model':(result.get('planner') or {}).get('returned_model'),
                 'generation_usage':[{k:u.get(k) for k in ('stage','attempt','actual_model','total_tokens')} for u in result.get('usage',[])],
                 'synthesis_attempts':result.get('synthesis_attempts',[]),
                 'context_budget':result.get('context_budget'),
                 'visible_answer':saved.get('content','')}
            rows.append(row)
    grouped=defaultdict(list)
    for r in rows:grouped[(r['suite'],r['id'])].append(r)
    questions=[{'suite':s,'id':key,'question':rr[0]['question'],'attempts':len(rr),
                'functional_passes':sum(r['functional_passed'] for r in rr),'strict_passes':sum(r['passed'] for r in rr),
                'statuses':[r['business_status'] for r in rr],'failed_checks':dict(Counter(c for r in rr for c in r['failed_checks']))}
               for (s,key),rr in grouped.items()]
    latencies=[r['seconds'] for r in rows]
    by_suite=[]
    for suite in dict.fromkeys(r['suite'] for r in rows):
        selected=[r for r in rows if r['suite']==suite]
        by_suite.append({'suite':suite,'turns':len(selected),
            'functional_passes':sum(r['functional_passed'] for r in selected),
            'strict_passes':sum(r['passed'] for r in selected)})
    conversations=[]
    for case in progress['cases']:
        observed=[r for r in rows if r['repetition']==case['repetition'] and r['suite']==case['suite']]
        if not observed:continue
        conversations.append({'repetition':case['repetition'],'suite':case['suite'],
            'chat_id':case['chat_id'],'turns':len(observed),
            'functional_passes':sum(r['functional_passed'] for r in observed),
            'strict_passes':sum(r['passed'] for r in observed),
            'uc_changes':sum(a['uc']!=b['uc'] for a,b in zip(observed,observed[1:]))})
    report={'created_at_utc':datetime.now(timezone.utc).isoformat(),'started_at_utc':progress['started_at_utc'],
            'finished_at_utc':progress.get('finished_at_utc'),'campaign_status':progress['status'],
            'original_progress_sha256':hashlib.sha256(raw).hexdigest(),'matrix_sha256':progress['matrix_sha256'],
            'oracle_sha256':hashlib.sha256((HERE/'browser_stability.py').read_bytes()).hexdigest(),
            'assessment_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'planned_posts':96,'submitted_posts':progress['completed_browser_posts'],'assessed_turns':len(rows),
            'functional_passes':sum(r['functional_passed'] for r in rows),'strict_passes':sum(r['passed'] for r in rows),
            'failures':sum(not r['passed'] for r in rows),'categories':dict(Counter(c for r in rows for c in r['categories'])),
            'latency_seconds':{'p50':percentile(latencies,.5),'p95':percentile(latencies,.95),'p99':percentile(latencies,.99)},
            'latency_seconds_by_uc':{uc:{'p50':percentile([r['seconds'] for r in rows if r['uc']==uc],.5),
                'p95':percentile([r['seconds'] for r in rows if r['uc']==uc],.95),
                'p99':percentile([r['seconds'] for r in rows if r['uc']==uc],.99)} for uc in ('pdl','incidents')},
            'recovered_harness_errors':sum(r['receipt_recovered_after_oracle_error'] for r in rows),
            'known_backend_generation_tokens':sum(u.get('total_tokens') or 0 for r in rows for u in r['generation_usage']),
            'known_backend_generation_calls':sum(len(r['generation_usage']) for r in rows),
            'backend_stage_calls':dict(Counter(u['stage'] for r in rows for u in r['generation_usage'])),
            'responses_with_generation_repairs':sum(any((u.get('attempt') or 1)>1 for u in r['generation_usage']) for r in rows),
            'responses_with_unvalidated_synthesis':sum(any(e['code'] in ('synthesis_constraints_failed',
                'factual_review_failed','review_context_budget_exceeded') for e in r['error_codes']) for r in rows),
            'limits':['Trois répétitions par question ; aucune garantie statistique de fiabilité.',
                      'Une seule identité interne fictive ; ce n’est pas une nouvelle recette des profils ACL externes ni une réception du SI-RIE réel.',
                      'Le fil mixte change explicitement de preset ; aucun routage automatique entre UC n’est revendiqué.',
                      'Les tokens comptés couvrent les usages métier de rédaction/relecture retournés, pas tous les appels de relais, dialogue ou planification.',
                      'Le contrôle initial de clarification Incidents est aligné sur son statut déclaré clarification ; les assertions initiales sont conservées.',
                      'Les invariants de restitution sont ciblés ; ils ne prouvent pas exhaustivement chaque affirmation ni une causalité.'],
            'by_suite':by_suite,'conversations':conversations,'questions':questions,'rows':rows}
    if not allow_incomplete:
        report['complete_requested_matrix']=(progress['status']=='completed' and progress['completed_browser_posts']==96
                                           and len(rows)==96 and len(grouped)==32 and all(len(v)==3 for v in grouped.values()))
    return report


def markdown(report):
    def safe(value):return str(value).replace('|','\\|').replace('\n',' ')
    started=datetime.fromisoformat(report['started_at_utc']).astimezone(ZoneInfo('Europe/Paris')).strftime('%d/%m/%Y')
    lines=['# Qualification Open WebUI et Albert API — stabilité et conversations longues',
           '', f'Campagne du {started} (Europe/Paris) sur le SI-RIE simulé Ubuntu ARM64. Données fictives, fournisseur Albert réel.',
           '',f"État : **{report['campaign_status']}**. Messages envoyés : **{report['submitted_posts']}/96**.",
           f"Contrôles fonctionnels satisfaits : **{report['functional_passes']}/{report['assessed_turns']}** ; avec les invariants de restitution : **{report['strict_passes']}/{report['assessed_turns']}**.",
           '', '## Méthode et périmètre', '',
           'Trois jeux de dix messages, chacun répété trois fois à l’identique : PDL, Incidents, puis fil mixte avec reformulations. Deux demandes au mauvais preset complètent chaque répétition. Les messages passent par le navigateur Open WebUI ; les réponses natives MCP et les textes affichés sont conservés. Le harnais ne renvoie aucun message en échec ; les reprises de rédaction bornées du moteur restent actives et tracées.',
           '', 'Les changements de modèle PDL/Incidents se font explicitement dans le même fil. Le test du retour implicite à un ancien sujet reste une attente métier exigeante : une clarification prudente protège les données mais ne satisfait pas cette attente de continuité.',
           '', 'Le code, les modèles et les paramètres métier restent figés pendant les répétitions. Les assertions sont séparées des réponses du système. Le statut de clarification Incidents est `clarification`, celui de PDL `needs_clarification` ; les assertions initiales et leur normalisation sont traçables.',
           '', ('Les erreurs du harnais initial ont été réévaluées à partir des reçus des mêmes messages, sans nouvel appel au modèle. Les reçus sont appariés par identifiants de conversation et de message ; les erreurs initiales restent conservées.'
                if report['recovered_harness_errors'] else
                'Aucun échange n’a été récupéré après une erreur du harnais. Les reçus consultés appartiennent aux mêmes messages ; leur lecture ne réémet aucune question.'),
           '', '## Résultats par jeu', '',
           '| Jeu | Messages | Fonctionnel | Restitution comprise |', '| --- | ---: | ---: | ---: |']
    for s in report['by_suite']:
        lines.append(f"| {safe(s['suite'])} | {s['turns']} | {s['functional_passes']} | {s['strict_passes']} |")
    lines+=['', 'Les trois premiers jeux correspondent aux 90 échanges principaux. Les deux lignes wrong correspondent aux six contrôles du mauvais choix de profil.',
           '', '## Résultats par conversation', '',
           '| Répétition | Jeu | Messages | Fonctionnel | Restitution comprise | Changements d’UC dans le fil |',
           '| ---: | --- | ---: | ---: | ---: | ---: |']
    for c in report['conversations']:
        lines.append(f"| {c['repetition']} | {safe(c['suite'])} | {c['turns']} | {c['functional_passes']} | {c['strict_passes']} | {c['uc_changes']} |")
    lines+=['', '## Résultats par question', '',
           '| Jeu / question | Essais | Fonctionnel | Restitution comprise | Statuts observés |',
           '| --- | ---: | ---: | ---: | --- |']
    for q in report['questions']:
        lines.append(f"| {safe(q['suite'])} / {safe(q['id'])} | {q['attempts']} | {q['functional_passes']} | {q['strict_passes']} | {safe(', '.join(str(s) for s in q['statuses']))} |")
    lines+=['','## Écarts observés','','| Famille d’écart | Occurrences |','| --- | ---: |']
    for k,v in sorted(report['categories'].items()):lines.append(f'| {safe(CATEGORIES.get(k,k))} (`{k}`) | {v} |')
    lines+=['','Les catégories peuvent se recouvrir. Un échec au début d’un fil peut expliquer plusieurs suites de questions ; ces occurrences ne représentent pas autant de bugs indépendants.',
            '', '## Durées et consommation observées', '',
            f"Durées de bout en bout par message : p50 {report['latency_seconds']['p50']} s, p95 {report['latency_seconds']['p95']} s, p99 {report['latency_seconds']['p99']} s. L’attente imposée entre deux demandes Incidents est exclue de ces durées, mais reste comprise dans la durée totale de campagne.",
            f"Générations métier documentées : {report['known_backend_generation_calls']} appels de rédaction/relecture, {report['known_backend_generation_tokens']} tokens totaux connus. Les appels de relais, dialogue et planification non chiffrés dans les reçus ne sont pas inclus.",
            f"Appels par étape : {report['backend_stage_calls']}. Réponses ayant nécessité une reprise bornée de génération : {report['responses_with_generation_repairs']}.",
            f"Synthèses non validées au total : {report['responses_with_unvalidated_synthesis']}. Ce compteur inclut les demandes factuelles où les observations peuvent être correctes malgré une synthèse refusée ; la catégorie des générations exigées par le scénario les distingue.",
            '', '| UC | p50 (s) | p95 (s) | p99 (s) |', '| --- | ---: | ---: | ---: |']
    for uc,values in report['latency_seconds_by_uc'].items():
        lines.append(f"| {uc} | {values['p50']} | {values['p95']} | {values['p99']} |")
    lines+=['', 'Ces durées mélangent des types de demandes différents et leurs échecs. Elles ne constituent ni un débit sous charge ni un engagement de temps de réponse du SI-RIE.',
            '', '## Détail des échanges', '']
    for r in report['rows']:
        lines += [f"### Répétition {r['repetition']} — {r['suite']} — message {r['turn']}", '',
                  '**Question :** '+r['question'], '',
                  f"**Résultat :** {r['business_status']} ; fonctionnel {'réussi' if r['functional_passed'] else 'échoué'} ; durée {r['seconds']} s.",
                  '**Contrôles non satisfaits :** '+(', '.join(r['failed_checks']) or 'aucun'),
                  '**Attendu :** `'+json.dumps(r['expected'],ensure_ascii=False)+'`',
                  '**Conversation de preuve :** `'+str(r['chat_id'])+'`', '']
        if r['clarification']:lines+=['**Clarification retournée :** '+str(r['clarification']),'']
        if r['client_error']:lines+=['**Erreur client :** `'+safe(json.dumps(r['client_error'],ensure_ascii=False))+'`','']
        if r['error_codes']:lines+=['**Erreurs retournées :** `'+safe(json.dumps(r['error_codes'],ensure_ascii=False))+'`','']
    lines+=['## Limites de la qualification','',*['- '+s for s in report['limits']],
            '', 'Les états des services, les versions et les empreintes des configurations sont joints au dossier de preuves. Les mesures de cette VM ne constituent pas un dimensionnement du SI-RIE ni une qualification de ses données réelles.']
    return '\n'.join(lines)+'\n'


def allure_results(report,state,destination,receipts=None):
    """Render the reassessed real messages, retaining the original assertions."""
    if not report.get('complete_requested_matrix'):
        raise ValueError('An incomplete matrix cannot become a final Allure campaign')
    if destination.exists():raise ValueError('Use a new reassessed Allure directory')
    reporting=oracle().load_module(HERE.parent/'test_reporting.py','stability_export_reporting')
    attached=set()
    for row in report['rows']:
        checks=[*row['functional_checks'],*row['fidelity_checks']]
        failed=[c for c in checks if not c['passed']]
        attachments=[]
        signature=(row['repetition'],tuple(row['categories']))
        # A selected screenshot per failure family and each ten-message ending
        # keeps the standalone report bounded; all captures stay in the receipts.
        if (not row['passed'] and signature not in attached) or row['turn']==10:
            capture=state/f'r{row["repetition"]}-{row["suite"]}-{row["turn"]:02d}.png'
            if capture.exists():attachments=[capture];attached.add(signature)
        stamp=lambda key:int(datetime.fromisoformat(row[key]).timestamp()*1000)
        tool_output=''
        if receipts:
            receipt=json.loads((receipts/f'r{row["repetition"]}-{row["suite"]}-{row["turn"]:02d}.json').read_text())
            if receipt['chat_id']!=row['chat_id']:
                raise ValueError('Tool receipt does not belong to the campaign conversation')
            tool_output=json.dumps(receipt['output'],ensure_ascii=False,indent=2)
        steps=[{'name':c['name'],'status':'passed' if c['passed'] else 'failed',
                'statusDetails':{'message':json.dumps({k:c.get(k) for k in ('actual','expected')},ensure_ascii=False)}} for c in checks]
        reporting.write_result(destination,f'Répétition {row["repetition"]} — {row["suite"]}',
            f'{row["turn"]:02d} — {row["id"]}', 'passed' if row['passed'] else 'failed',
            start=stamp('started_at_utc'),stop=stamp('finished_at_utc'),
            message=', '.join(row['failed_checks']),steps=steps,attachments=attachments,
            labels=[{'name':'feature','value':row['uc']},{'name':'thread','value':row['chat_id']}],
            description='Albert réel, données fictives. Même message que le reçu initial ; aucune relance. Question : '+row['question'],
            diagnostics={
                'Attendu et obtenu':json.dumps({'question':row['question'],'expected':row['expected'],
                    'status':row['business_status'],'checks':checks},ensure_ascii=False,indent=2),
                'Réponse affichée dans Open WebUI':row['visible_answer'],
                'Appel MCP et reçu natif, sans raisonnement interne':tool_output,
                'Fournisseur et erreurs':json.dumps({k:row[k] for k in ('dialogue_model','planner_model','generation_usage','synthesis_attempts','context_budget','error_codes','client_error')},ensure_ascii=False,indent=2),
                'Assertions initiales conservées':json.dumps({'initial_checks':row['initial_checks'],
                    'initial_harness_error':row['initial_harness_error'],
                    'receipt_recovered_after_oracle_error':row['receipt_recovered_after_oracle_error']},ensure_ascii=False,indent=2)})


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--allow-incomplete',action='store_true')
    parser.add_argument('--receipts',type=Path,help='Sanitized receipts read from the same owned messages; never reruns a question')
    parser.add_argument('--allure-results',type=Path,help='New destination for reassessed real-message results; requires a complete campaign')
    args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    report=assess(args.state,allow_incomplete=args.allow_incomplete,receipts=args.receipts)
    if args.allure_results:allure_results(report,args.state,args.allure_results,args.receipts)
    (args.output/'assessment.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (args.output/'report.md').write_text(markdown(report))
    with (args.output/'exchanges.csv').open('w',newline='') as stream:
        fields=['repetition','suite','turn','id','uc','question','business_status','functional_passed','passed','seconds','failed_checks','categories','chat_id']
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in report['rows']:
            writer.writerow({key:('; '.join(row[key]) if isinstance(row[key],list) else row[key]) for key in fields})
    print(json.dumps({k:report[k] for k in ('campaign_status','submitted_posts','assessed_turns','functional_passes','strict_passes','failures','categories')},ensure_ascii=False))


if __name__=='__main__':main()
