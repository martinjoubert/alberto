"""Incident evidence works without historical Zabbix IDs or optional readers."""
from datetime import datetime, timedelta
from dataclasses import replace
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parents[3]
for folder in ('core/access-control/src', 'core/albert-client/src', 'use-cases/incidents/observability-demo'):
    sys.path.insert(0, str(ROOT / folder))
from obs_poc.config import Settings
from obs_poc.domain import links
from obs_poc.service import Service
from obs_poc.telemetry import metric_url, tickets

START = '2026-09-28T10:00:00+02:00'
END = '2026-09-28T12:00:00+02:00'
HOST = {'equipment': 'OBS-RTR-01', 'aliases': ['R1'], 'interface': 'uplink0',
        'hostid': 'synthetic-1', 'number': 1, 'scope': 'Site de Rennes', 'allowed': True}


class FakeSources:
    def __init__(self, settings):
        self.settings = settings
        self.measurement_reads = 0

    def measurements(self, host, key, start, end):
        self.measurement_reads += 1
        begin = datetime.fromisoformat(start)
        end = datetime.fromisoformat(end)
        minutes = int((end - begin).total_seconds() / 60)
        value = {'cpu': 65., 'latency': 80., 'loss': 3., 'in': 95., 'out': 90.}[key]
        return [{'clock': int((begin + timedelta(minutes=n)).timestamp()), 'value': value} for n in range(minutes)]

    def events(self, hosts, start, end):
        return tickets(self.settings, hosts, start, end)

    def logs(self, *args):
        return {'total': 120, 'counts': {'congestion': 75, 'heartbeat': 45}, 'rows': [], 'truncated': False}

    def documents(self, *args):
        return json.loads((ROOT / 'use-cases/incidents/observability-demo/corpus-documents.json').read_text())[:1]

    def request(self, *args, **kwargs):
        raise AssertionError('A source-only diagnosis must never call Albert')


class IncidentLinkTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.settings = Settings(metrics_provider='victoriametrics', events_provider='itsm-ng-simulator',
                                 grafana='', portal='', opensearch_public='', itsm_public='',
                                 manifest_path=self.root / 'manifest.json', reports=self.root / 'investigations')
        self.settings.manifest_path.write_text(json.dumps({'status': 'ready', 'synthetic': True, 'hosts': [HOST],
            'timezone':'Europe/Paris','anchor_date':'2026-09-28','start':START,'end':END,'interval_seconds':60}))

    def tearDown(self):
        self.temporary.cleanup()

    def test_victoria_and_simulator_links_require_no_historical_zabbix_identifiers(self):
        for arguments in ({'metric': 'cpu'}, {'event': {'eventid': 'ITSM-001'}}, {}):
            with self.subTest(arguments=arguments):
                self.assertEqual(links(self.settings, HOST, START, END, **arguments), {'grafana': '', 'zabbix': ''})

    def test_mixed_providers_only_require_their_own_zabbix_identifiers(self):
        settings = replace(self.settings, events_provider='zabbix', zabbix_public='https://zabbix.example')
        url = links(settings, HOST, START, END, event={'eventid': 'event-1', 'objectid': 'trigger-1'})['zabbix']
        self.assertEqual(urlsplit(url).path, '/tr_events.php')
        self.assertEqual(links(settings, HOST, START, END, metric='cpu')['zabbix'], '')
        settings = replace(self.settings, metrics_provider='zabbix', zabbix_public='https://zabbix.example')
        host = {**HOST, 'items': {'cpu': 'item-1'}}
        query = parse_qs(urlsplit(links(settings, host, START, END, metric='cpu')['zabbix']).query)
        self.assertEqual(query['itemids[]'], ['item-1'])
        self.assertEqual(links(settings, HOST, START, END, event={'eventid': 'ITSM-001'})['zabbix'], '')

    def test_public_metric_override_can_suppress_or_explicitly_expose_a_reader(self):
        settings = replace(self.settings, grafana='https://grafana.example')
        with patch.dict(os.environ, {'VICTORIAMETRICS_PUBLIC_URL': ''}):
            self.assertEqual(metric_url(settings, HOST, 'cpu', START, END), '')
        with patch.dict(os.environ, {'VICTORIAMETRICS_PUBLIC_URL': 'https://metrics.example'}):
            value = urlsplit(metric_url(self.settings, HOST, 'cpu', START, END))
            self.assertEqual((value.netloc, value.path), ('metrics.example', '/api/v1/export'))
            parameters = parse_qs(value.query)
            self.assertEqual(datetime.fromisoformat(parameters['end'][0]), datetime.fromisoformat(END) - timedelta(milliseconds=1))
        with patch.dict(os.environ, clear=False):
            os.environ.pop('VICTORIAMETRICS_PUBLIC_URL', None)
            self.assertEqual(urlsplit(metric_url(settings, HOST, 'cpu', START, END)).path,
                             '/api/datasources/proxy/uid/obs-victoria/api/v1/export')
            self.assertEqual(metric_url(self.settings, HOST, 'cpu', START, END), '')

    def test_simulator_omits_unconfigured_ticket_reader(self):
        result = tickets(self.settings, [HOST], START, END)
        self.assertTrue(result)
        self.assertTrue(all(row['url'] == '' for row in result))

    def test_real_diagnosis_without_zabbix_ids_preserves_evidence_and_has_no_fabricated_links(self):
        source = FakeSources(self.settings)
        with patch.dict(os.environ, {'VICTORIAMETRICS_PUBLIC_URL': ''}):
            result = Service(self.settings, source).diagnose('gptoss', 'Diagnostic sur la période demandée.',
                         equipment='R1', start=START, end=END, synthesize=False)
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['errors'], [])
        self.assertEqual(source.measurement_reads, 5)
        self.assertEqual(len(result['metrics']), 5)
        self.assertEqual(result['logs']['total'], 120)
        self.assertTrue(result['events'])
        self.assertTrue(result['documents'])
        self.assertTrue(all(row['url'] == '' for row in result['sources']))
        self.assertTrue(all(row['grafana'] == '' for row in result['metrics']))
        self.assertNotIn('Courbes Grafana', result['answer'])
        for unwanted in ('/history.php', '/tr_events.php', '/diagnostic-reseau/', '/api/datasources/',
                         'http://127.0.0.1:', 'http://victoriametrics:'):
            self.assertNotIn(unwanted, result['answer'])
        self.assertEqual(result['usage'], [])
        self.assertIsNone(result['analysis'])

    def test_comparison_uses_victoria_reference_without_zabbix_ids_or_reader(self):
        source = FakeSources(self.settings)
        with patch.dict(os.environ, {'VICTORIAMETRICS_PUBLIC_URL': ''}):
            result = Service(self.settings, source).diagnose('gptoss', "Compare avec l'heure précédente.",
                         equipment='R1', start=START, end=END, synthesize=False)
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(source.measurement_reads, 10)
        self.assertTrue(all(row['reference']['coverage_percent'] == 100 for row in result['metrics']))
        self.assertTrue(all(row['url'] == '' for row in result['sources']))


if __name__ == '__main__':
    unittest.main()
