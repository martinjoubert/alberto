"""The transferred package is checked before its sources are built."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location('verify_delivery', Path(__file__).parents[1]/'verify_delivery.py')
verifier = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(verifier)


class DeliveryVerificationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)/'delivery'
        self.root.mkdir()
        (self.root/'public.md').write_bytes(b'# Public\n')
        self.item = {'path': 'public.md', 'bytes': 9,
                     'sha256': hashlib.sha256(b'# Public\n').hexdigest()}
        self.write_manifest()

    def tearDown(self):
        self.temporary.cleanup()

    def write_manifest(self, items=None):
        (self.root/verifier.MANIFEST).write_text(json.dumps(
            {'schema_version': 1, 'files': [self.item] if items is None else items}))

    def test_complete_delivery_is_verified_without_writing(self):
        before = {p.name: p.read_bytes() for p in self.root.iterdir()}
        report = verifier.verify_delivery(self.root)
        self.assertTrue(report['passed'])
        self.assertEqual(report['files'], 1)
        self.assertEqual(report['authenticity'], 'not_verified_by_checksum')
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.root.iterdir()})

    def test_changed_missing_or_added_files_are_refused(self):
        file = self.root/'public.md'
        file.write_bytes(b'# Forged\n')
        with self.assertRaisesRegex(ValueError, 'integrity'):
            verifier.verify_delivery(self.root)
        file.unlink()
        with self.assertRaisesRegex(ValueError, 'missing or unlisted'):
            verifier.verify_delivery(self.root)
        file.write_bytes(b'# Public\n')
        (self.root/'extra.py').write_text('print("unlisted")')
        with self.assertRaisesRegex(ValueError, 'missing or unlisted'):
            verifier.verify_delivery(self.root)

    def test_dangerous_duplicate_paths_and_invalid_hashes_are_refused(self):
        for name in ('../outside', '/absolute', 'a/../public.md', 'a//public.md', 'a\\public.md', 'C:/public.md'):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'Unsafe'):
                self.write_manifest([{**self.item, 'path': name}])
                verifier.verify_delivery(self.root)
        self.write_manifest([self.item, self.item])
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            verifier.verify_delivery(self.root)
        self.write_manifest([{**self.item, 'sha256': 'bad'}])
        with self.assertRaisesRegex(ValueError, 'SHA-256'):
            verifier.verify_delivery(self.root)

    def test_source_and_manifest_symlinks_are_refused(self):
        outside = self.root.parent/'outside.md'
        outside.write_text('Private')
        (self.root/'public.md').unlink()
        (self.root/'public.md').symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'Links'):
            verifier.verify_delivery(self.root)
        (self.root/'public.md').unlink()
        (self.root/'public.md').write_bytes(b'# Public\n')
        (self.root/verifier.MANIFEST).unlink()
        (self.root/verifier.MANIFEST).symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'Links'):
            verifier.verify_delivery(self.root)

    def test_directory_symlink_cannot_hide_unlisted_content(self):
        outside = self.root.parent/'private'
        outside.mkdir()
        (outside/'secret.key').write_text('Private')
        (self.root/'nested').symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'Links'):
            verifier.verify_delivery(self.root)


if __name__ == '__main__':
    unittest.main()
