"""Exercise native OAuth HTTP, LDAP identity, refresh and both resource boundaries."""
import asyncio
import base64
from copy import deepcopy
import hashlib
from html.parser import HTMLParser
import json
import os
import shutil
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'core/access-control/src'))
from dinum_access import AccessGate, AccessDenied, protect
from dinum_access.security import CURRENT, require_indices
from dinum_access.oauth import OAuthBoundary, Provider
from dinum_access.oauth_store import OAuthStore, configuration, digest
import httpx
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route


class Directory:
    available = True
    subject = 'stable-directory-object'
    category = 'internal'
    def lookup(self, value, *, username=False, password=None, authorization=False, **kwargs):
        if not self.available:
            raise AccessDenied('directory_unavailable_or_denied')
        if value != 'alice' or password is not None and password != 'test-only-password':
            raise AccessDenied('invalid_credentials')
        result = ('alice@example.test', self.category, self.subject)
        return (*result, self.category == 'internal') if authorization else result


class Inputs(HTMLParser):
    def __init__(self, html):
        super().__init__(); self.values = {}; self.feed(html)
    def handle_starttag(self, tag, attrs):
        row = dict(attrs)
        if tag == 'input' and row.get('type') == 'hidden':
            self.values[row['name']] = row.get('value', '')


class OAuthAccessTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temporary = tempfile.TemporaryDirectory(); self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        self.config = {'version': 1, 'issuer': 'http://127.0.0.1:19910',
            'resources': {'pdl': 'http://127.0.0.1:19910/mcp', 'incidents': 'http://127.0.0.1:19950/gptoss/assistant/mcp'},
            'redirect_uris': ['http://127.0.0.1:8080/oauth/clients/mcp:dinum-pdl-agent/callback'],
            'access_seconds': 60, 'refresh_seconds': 600, 'login_seconds': 300}
        self.directory = Directory()
        (self.root / 'policy.json').write_text(json.dumps({'version':1, 'revision':1, 'default':'blocked', 'indices':{'allowed-index':'internal'}}))
        self.gate = AccessGate({'version':1, 'state_directory':str(self.root), 'allow_webui_assertions':False, 'ldap':{}}, self.directory)
        self.clock = time.time()
        self.store = OAuthStore(self.root / 'oauth', clock=lambda: self.clock)
        self.provider = Provider(self.config, gate_factory=lambda:self.gate, store=self.store)
        self.factory = patch.object(AccessGate, 'configured', return_value=self.gate)
        self.factory.start(); self.addCleanup(self.factory.stop)
        # Gate creates an ordinary clock store; directory authorization remains live.
        async def resource(request):
            gate, principal = CURRENT.get()
            try:
                require_indices('allowed-index')
            except AccessDenied:
                return JSONResponse({'error':'index_forbidden'},status_code=403)
            return JSONResponse({'subject':principal.subject,'category':principal.category})
        app = Starlette(routes=[Route('/mcp',resource),Route('/gptoss/assistant/mcp',resource)])
        self.client = httpx.AsyncClient(transport=httpx.ASGITransport(app=OAuthBoundary(protect(app),self.config,'pdl',provider=self.provider)),
                                       base_url=self.config['issuer'], follow_redirects=False)
        await self.client.__aenter__(); self.addAsyncCleanup(self.client.aclose)
        self.incidents = httpx.AsyncClient(transport=httpx.ASGITransport(app=OAuthBoundary(protect(app),self.config,'incidents')),
                                           base_url='http://127.0.0.1:19950',follow_redirects=False)
        await self.incidents.__aenter__(); self.addAsyncCleanup(self.incidents.aclose)
        self.verifier = 'a' * 64
        self.challenge = base64.urlsafe_b64encode(hashlib.sha256(self.verifier.encode()).digest()).decode().rstrip('=')

    async def register(self, **extra):
        response = await self.client.post('/register',json={'client_name':'Open WebUI',
            'redirect_uris':self.config['redirect_uris'],'token_endpoint_auth_method':'client_secret_post',
            'grant_types':['authorization_code','refresh_token'],'response_types':['code'], **extra})
        self.assertEqual(response.status_code,201,response.text)
        return response.json()

    async def form(self, client, **extra):
        response = await self.client.get('/authorize',params={'response_type':'code','client_id':client['client_id'],
            'redirect_uri':self.config['redirect_uris'][0],'code_challenge':self.challenge,'code_challenge_method':'S256',
            'scope':'mcp:read','resource':self.config['resources']['pdl'],'state':'browser-owned-state',**extra})
        self.assertIn(response.status_code,(302,303),response.text)
        page = await self.client.get(response.headers['location'])
        self.assertEqual(page.status_code,200,page.text)
        return Inputs(page.text).values

    async def authorize(self, client):
        form = await self.form(client)
        form.update(username='alice',password='test-only-password')
        response = await self.client.post('/login',data=form,headers={'Origin':self.config['issuer']})
        self.assertEqual(response.status_code,303,response.text)
        query = parse_qs(urlsplit(response.headers['location']).query)
        self.assertEqual(query['state'],['browser-owned-state'])
        return query['code'][0]

    async def token(self, client, **extra):
        return await self.client.post('/token',data={'grant_type':'authorization_code',
            'client_id':client['client_id'],'client_secret':client['client_secret'],
            'redirect_uri':self.config['redirect_uris'][0],'code_verifier':self.verifier,
            'resource':self.config['resources']['pdl'], **extra})

    async def credentials(self):
        client = await self.register(); code = await self.authorize(client)
        response = await self.token(client,code=code)
        self.assertEqual(response.status_code,200,response.text)
        return client,response.json()

    async def refresh(self, client, token, **extra):
        return await self.token(client,grant_type='refresh_token',refresh_token=token['refresh_token'],**extra)

    async def test_discovery_and_native_login_without_copying_an_operator_token(self):
        response = await self.client.get('/mcp')
        self.assertEqual(response.status_code,401)
        self.assertIn('resource_metadata=',response.headers['www-authenticate'])
        metadata = (await self.client.get('/.well-known/oauth-protected-resource/mcp')).json()
        self.assertEqual(metadata['authorization_servers'],[self.config['issuer']])
        client,tokens = await self.credentials()
        response = await self.client.get('/mcp',headers={'Authorization':'Bearer '+tokens['access_token']})
        self.assertEqual(response.status_code,200,response.text)
        self.assertEqual(response.json()['subject'],'ldap:'+digest(self.directory.subject))
        self.assertNotIn('test-only-password',(self.root/'oauth/state.sqlite3').read_bytes().decode(errors='ignore'))

    async def test_wrong_password_unclassified_or_unavailable_directory_refused(self):
        client = await self.register()
        for password,available in [('wrong',True),('test-only-password',False)]:
            self.directory.available = available
            form = await self.form(client);form.update(username='alice',password=password)
            response = await self.client.post('/login',data=form,headers={'Origin':self.config['issuer']})
            self.assertEqual(response.status_code,403)
            self.assertEqual(self.store.sessions(),[])

    async def test_unapproved_redirect_and_wider_scope_refused_before_ldap(self):
        response = await self.client.post('/register',json={'redirect_uris':['https://attacker.invalid/callback']})
        self.assertEqual(response.status_code,400)
        client = await self.register()
        response = await self.client.get('/authorize',params={'client_id':client['client_id'],'response_type':'code',
            'redirect_uri':'https://attacker.invalid/callback','code_challenge':self.challenge,'code_challenge_method':'S256'})
        self.assertEqual(response.status_code,400)

    async def test_csrf_origin_and_missing_consent_refused(self):
        client = await self.register()
        for changed in ({'csrf':'forged'},{'confirm':''}):
            form = await self.form(client);form.update(username='alice',password='test-only-password',**changed)
            response = await self.client.post('/login',data=form,headers={'Origin':self.config['issuer']})
            self.assertEqual(response.status_code,403)
        form = await self.form(client);form.update(username='alice',password='test-only-password')
        self.assertEqual((await self.client.post('/login',data=form,headers={'Origin':'https://attacker.invalid'})).status_code,403)

    async def test_pkce_client_binding_and_single_use_code(self):
        client = await self.register();code = await self.authorize(client)
        self.assertEqual((await self.token(client,code=code,code_verifier='b'*64)).status_code,400)
        other = await self.register()
        self.assertEqual((await self.token(other,code=code)).status_code,400)
        self.assertEqual((await self.token(client,code=code)).status_code,200)
        self.assertEqual((await self.token(client,code=code)).status_code,400)

    async def test_resource_is_bound_at_authorization_exchange_refresh_and_use(self):
        client = await self.register();code = await self.authorize(client)
        self.assertEqual((await self.token(client,code=code,resource=self.config['resources']['incidents'])).status_code,400)
        response = await self.token(client,code=code);self.assertEqual(response.status_code,200,response.text)
        token = response.json()
        self.assertEqual((await self.refresh(client,token,resource=self.config['resources']['incidents'])).status_code,400)
        response = await self.incidents.get('/gptoss/assistant/mcp',headers={'Authorization':'Bearer '+token['access_token']})
        self.assertEqual(response.status_code,401)

    async def test_automatic_refresh_rotates_and_replay_revokes_the_family(self):
        client,token = await self.credentials()
        response = await self.refresh(client,token);self.assertEqual(response.status_code,200,response.text)
        renewed = response.json();self.assertNotEqual(renewed['refresh_token'],token['refresh_token'])
        self.assertEqual((await self.refresh(client,token)).status_code,400)
        self.assertEqual((await self.client.get('/mcp',headers={'Authorization':'Bearer '+renewed['access_token']})).status_code,401)

    async def test_groups_stable_identity_and_native_revocation_remain_effective(self):
        client,token = await self.credentials();headers={'Authorization':'Bearer '+token['access_token']}
        self.directory.category='external'
        self.assertEqual((await self.client.get('/mcp',headers=headers)).status_code,403)
        self.directory.subject='recreated-object'
        self.assertEqual((await self.client.get('/mcp',headers=headers)).status_code,401)
        self.assertEqual((await self.refresh(client,token)).status_code,400)
        self.directory.subject='stable-directory-object';self.directory.category='internal'
        response = await self.client.post('/revoke',data={'client_id':client['client_id'],'client_secret':client['client_secret'],'token':token['refresh_token']})
        self.assertEqual(response.status_code,200,response.text)
        self.assertEqual((await self.client.get('/mcp',headers=headers)).status_code,401)

    async def test_second_resource_uses_the_ldap_session_with_explicit_identity_confirmation(self):
        client,token = await self.credentials()
        form = await self.form(client,resource=self.config['resources']['incidents'])
        self.assertEqual(form['reuse'],'yes')
        response = await self.client.post('/login',data=form,headers={'Origin':self.config['issuer']})
        self.assertEqual(response.status_code,303,response.text)
        code=parse_qs(urlsplit(response.headers['location']).query)['code'][0]
        response=await self.token(client,code=code,resource=self.config['resources']['incidents'])
        self.assertEqual(response.status_code,200,response.text)
        response=await self.incidents.get('/gptoss/assistant/mcp',headers={'Authorization':'Bearer '+response.json()['access_token']})
        self.assertEqual(response.status_code,200,response.text)

    async def test_configuration_requires_exact_callbacks_https_and_bounded_lifetimes(self):
        path=self.root/'oauth.json'
        for changes in [{'issuer':'http://example.org'}, {'redirect_uris':['https://example.org/*']}, {'access_seconds':0}]:
            path.write_text(json.dumps({**self.config,**changes}));path.chmod(0o600)
            with self.assertRaises(ValueError):configuration(path)
        path.write_text(json.dumps(self.config));path.chmod(0o600)
        self.assertEqual(configuration(path),self.config)

    async def test_parallel_code_exchange_has_one_winner(self):
        client=await self.register();code=await self.authorize(client)
        responses=await asyncio.gather(self.token(client,code=code),self.token(client,code=code))
        self.assertEqual(sorted(r.status_code for r in responses),[200,400])
        self.assertEqual(len(self.store.sessions()),1)

    async def test_expired_access_refresh_and_code_are_refused_without_extending_the_grant(self):
        client,token=await self.credentials()
        original=self.store.sessions()[0]['expires']
        self.clock+=61
        with self.assertRaises(AccessDenied):self.store.authenticate(token['access_token'],self.config['resources']['pdl'])
        renewed=await self.refresh(client,token)
        self.assertEqual(renewed.status_code,200,renewed.text)
        self.assertEqual(self.store.sessions()[0]['expires'],original)
        self.clock+=600
        self.assertEqual((await self.refresh(client,renewed.json())).status_code,400)
        self.assertEqual(self.store.sessions(),[])
        # Protocol cleanup removes spent state; no permanent per-request file grows.
        with self.store.transaction() as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM objects WHERE kind IN ('grant','access','refresh','code','flow')").fetchone()[0],0)

    async def test_cold_copy_preserves_sessions_and_revocations(self):
        client,token=await self.credentials()
        destination=self.root/'restored-oauth';destination.mkdir(mode=0o700)
        shutil.copyfile(self.store.directory/'state.sqlite3',destination/'state.sqlite3')
        (destination/'state.sqlite3').chmod(0o600)
        restored=OAuthStore(destination)
        record=restored.authenticate(token['access_token'],self.config['resources']['pdl'])
        restored.revoke(record['id'])
        with self.assertRaises(AccessDenied):restored.authenticate(token['access_token'],self.config['resources']['pdl'])
        self.assertEqual((await self.client.get('/mcp',headers={'Authorization':'Bearer '+token['access_token']})).status_code,200)

    async def test_wrong_client_cannot_refresh_or_revoke_another_users_grant(self):
        client,token=await self.credentials();other=await self.register()
        self.assertEqual((await self.refresh(other,token)).status_code,400)
        response=await self.client.post('/revoke',data={'client_id':other['client_id'],'client_secret':other['client_secret'],'token':token['refresh_token']})
        self.assertEqual(response.status_code,200)
        self.assertEqual((await self.client.get('/mcp',headers={'Authorization':'Bearer '+token['access_token']})).status_code,200)

    async def test_large_protocol_body_duplicate_fields_and_missing_resource_refused(self):
        response=await self.client.post('/register',content=b'x'*16385)
        self.assertEqual(response.status_code,400)
        response=await self.client.post('/token',content='resource=a&resource=b',headers={'Content-Type':'application/x-www-form-urlencoded'})
        self.assertEqual(response.status_code,400)
        client=await self.register();code=await self.authorize(client)
        self.assertEqual((await self.token(client,code=code,resource='')).status_code,400)

    async def test_ldap_outage_denies_existing_access_and_refresh(self):
        client,token=await self.credentials();self.directory.available=False
        self.assertEqual((await self.client.get('/mcp',headers={'Authorization':'Bearer '+token['access_token']})).status_code,401)
        self.assertEqual((await self.refresh(client,token)).status_code,503)
        self.directory.available=True
        self.assertEqual((await self.refresh(client,token)).status_code,200)

    async def test_refresh_capacity_preserves_updates_and_recovers_after_expiry(self):
        from dinum_access import oauth_store
        with patch.dict(oauth_store.LIMITS,{'refresh':2}):
            self.store.save('refresh','old',{'used':False},self.clock+1)
            self.store.save('refresh','live',{'used':False},self.clock+100)
            self.store.save('refresh','live',{'used':True},self.clock+100)
            with self.assertRaises(AccessDenied):self.store.save('refresh','next',{'used':False},self.clock+100)
            self.assertTrue(self.store.read('refresh','live')['used'])
            self.clock+=2
            self.store.save('refresh','next',{'used':False},self.clock+100)
            self.assertIsNone(self.store.read('refresh','old'))


if __name__ == '__main__':unittest.main()
