"""Operational probes leave personal credentials and audit history intact."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'core/access-control/src')]
from dinum_access import AccessDenied
from dinum_access.security import AccessGate
from dinum_access.user_tokens import UserTokens

spec = importlib.util.spec_from_file_location('temporary_token_cli', ROOT / 'deploy/ubuntu/runtime_cli.py')
cli = importlib.util.module_from_spec(spec); spec.loader.exec_module(cli)


class Directory:
    def lookup(self, value, **options):
        result = value + '@example.invalid', 'internal', 'directory-object-' + value
        return (*result, value != 'eric') if options.get('authorization') else result


class TemporaryTokenTests(unittest.TestCase):
    def setUp(self):
        private = tempfile.TemporaryDirectory(); self.addCleanup(private.cleanup)
        self.root = Path(private.name); self.directory = Directory()
        self.store = UserTokens(self.root / 'tokens')
        self.personal = self.store.issue(self.directory, 'alice', self.root / 'personal.token')
        revoked = self.store.issue(self.directory, 'alice', self.root / 'old.token')
        self.store.revoke(revoked['id'])
        self.audit = self.root / 'audit.jsonl'; self.audit.write_text('{"historical":true}\n')
        (self.root / 'policy.json').write_text(json.dumps({'version': 1, 'revision': 1, 'default': 'blocked', 'indices': {}}))
        self.baseline = {path.name: path.read_bytes() for path in self.store.directory.iterdir()}
        self.gate = AccessGate({'state_directory': str(self.root), 'ldap': {},
                               'user_tokens_directory': str(self.store.directory)}, self.directory)

    def assert_existing_records_preserved(self):
        self.assertEqual({path.name: path.read_bytes() for path in self.store.directory.iterdir()}, self.baseline)
        self.assertTrue(self.audit.read_text().startswith('{"historical":true}\n'))

    def test_repeated_probes_leave_no_record_growth_or_plaintext(self):
        with patch.object(cli, 'configured_gate', return_value=self.gate):
            for _ in range(20):
                with cli.individual_token('alice') as (token, store, identifier):
                    self.assertEqual(store.authenticate(token)['id'], identifier)
                    self.assertEqual(len(store.list()), len(self.baseline) + 1)
                with self.assertRaises(AccessDenied):
                    self.store.authenticate(token)
                self.assertFalse((self.store.directory / (identifier + '.json')).exists())
                self.assert_existing_records_preserved()
        rows = [json.loads(line) for line in self.audit.read_text().splitlines()]
        self.assertEqual(rows[0], {'historical': True})
        self.assertEqual(len(rows), 21)
        self.assertTrue(all(row['operation'] == 'revoke_temporary_user_token' and row['allowed'] for row in rows[1:]))
        self.assertEqual(len({row['subject_hash'] for row in rows[1:]}), 1)
        self.assertTrue(all(row['revision'] == 1 for row in rows[1:]))
        self.assertNotIn('alice@', self.audit.read_text())
        self.assertNotIn('dinum_ut1_', self.audit.read_text())
        self.assertNotIn('digest', self.audit.read_text())
        self.store.authenticate((self.root / 'personal.token').read_text().strip())

    def test_body_exception_and_already_revoked_probe_remove_only_own_record(self):
        with patch.object(cli, 'configured_gate', return_value=self.gate):
            with self.assertRaisesRegex(RuntimeError, 'business probe failed'):
                with cli.individual_token('alice') as (token, store, identifier):
                    store.revoke(identifier)
                    raise RuntimeError('business probe failed')
        self.assert_existing_records_preserved()
        self.assertEqual(json.loads(self.audit.read_text().splitlines()[-1])['operation'], 'revoke_temporary_user_token')
        with self.assertRaises(AccessDenied):
            self.store.authenticate(token)

    def test_existing_token_without_issuance_metadata_keeps_working_unchanged(self):
        personal_path = self.store.directory / (self.personal['id'] + '.json')
        record = json.loads(personal_path.read_text()); record.pop('issued_category')
        personal_path.write_text(json.dumps(record))
        self.baseline[personal_path.name] = personal_path.read_bytes()
        token = (self.root / 'personal.token').read_text().strip()
        self.assertEqual(self.gate.authenticate({'authorization': 'Bearer ' + token}).category, 'internal')
        with patch.object(cli, 'configured_gate', return_value=self.gate):
            with cli.individual_token('alice'):
                pass
        self.assert_existing_records_preserved()

    def test_plaintext_is_erased_even_if_revocation_cannot_complete(self):
        created = []
        original = UserTokens.issue
        def issue(store, directory, username, output, **options):
            created.append(Path(output))
            return original(store, directory, username, output, **options)
        with patch.object(cli, 'configured_gate', return_value=self.gate), \
             patch.object(UserTokens, 'issue', issue), \
             patch.object(UserTokens, 'revoke', side_effect=OSError('private storage unavailable')):
            with self.assertRaises(OSError):
                with cli.individual_token('alice'):
                    pass
        self.assertTrue(created)
        self.assertFalse(created[0].exists())
        # A failed revocation is reported; active records must never be silently purged.
        self.assertEqual(len(self.store.list()), len(self.baseline) + 1)
        self.assertEqual(self.audit.read_text(), '{"historical":true}\n')

    def test_only_a_revoked_record_can_be_discarded(self):
        with self.assertRaises(ValueError):
            self.store.discard_revoked(self.personal['id'])
        self.assert_existing_records_preserved()
        with self.assertRaises(AccessDenied):
            self.store.discard_revoked('../audit')
        self.assert_existing_records_preserved()

    def test_failed_audit_retains_the_revoked_record_and_existing_history(self):
        with patch.object(cli, 'configured_gate', return_value=self.gate), \
             patch.object(self.gate.store, 'audit', side_effect=OSError('audit unavailable')):
            with self.assertRaises(OSError):
                with cli.individual_token('alice') as (token, store, identifier):
                    pass
        with self.assertRaises(AccessDenied):
            self.store.authenticate(token)
        self.assertTrue((self.store.directory / (identifier + '.json')).is_file())
        self.assertTrue(self.store._read(identifier)['revoked'])
        self.assertEqual(self.audit.read_text(), '{"historical":true}\n')
        for name, original in self.baseline.items():
            self.assertEqual((self.store.directory / name).read_bytes(), original)


if __name__ == '__main__':
    unittest.main()
