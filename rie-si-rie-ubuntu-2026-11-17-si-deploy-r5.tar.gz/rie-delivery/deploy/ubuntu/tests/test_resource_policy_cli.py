"""The existing operator command edits source rules with the shared revision."""
from contextlib import redirect_stdout, redirect_stderr
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'core/access-control/src'))
from dinum_access import AccessGate

spec = importlib.util.spec_from_file_location('resource_policy_cli', ROOT / 'deploy/ubuntu/runtime_cli.py')
cli = importlib.util.module_from_spec(spec); spec.loader.exec_module(cli)


class Directory:
    def lookup(self, value, **options):
        result = value + '@example.invalid', 'external' if value == 'external' else 'internal', 'subject-' + value
        return (*result, value not in {'external', 'reader'}) if options.get('authorization') else result


class ResourcePolicyCliTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name); self.path = self.root / 'policy.json'
        self.policy = {'version': 1, 'revision': 1, 'default': 'blocked', 'indices': {'pdl-index': 'internal'}}
        self.path.write_text(json.dumps(self.policy))
        self.gate = AccessGate({'state_directory': str(self.root)}, Directory())

    def invoke(self, *arguments, username='operator'):
        output, errors = io.StringIO(), io.StringIO()
        with patch.object(cli, 'configured_gate', return_value=self.gate), redirect_stdout(output), redirect_stderr(errors):
            code = cli.main(['policy', '--username', username, *arguments])
        return code, output.getvalue(), errors.getvalue()

    def test_list_shows_both_collections_without_migrating_the_policy(self):
        before = self.path.read_bytes()
        code, output, _ = self.invoke('list')
        self.assertEqual(code, 0); self.assertEqual(json.loads(output)['resources'], {})
        self.assertEqual(self.path.read_bytes(), before)

    def test_set_and_remove_resource_preserve_indices_and_check_the_revision(self):
        self.assertEqual(self.invoke('set-resource', 'incidents.metrics', 'internal', '--revision', '1')[0], 0)
        self.assertEqual(self.invoke('remove-resource', 'incidents.metrics', '--revision', '1')[0], 2)
        self.assertEqual(self.invoke('remove-resource', 'incidents.metrics', '--revision', '2')[0], 0)
        policy = json.loads(self.path.read_text())
        self.assertEqual(policy['indices'], self.policy['indices'])
        self.assertEqual(policy['resources'], {}); self.assertEqual(policy['revision'], 3)

    def test_optional_object_rules_share_policy_revision_and_strict_names(self):
        for resource, revision in (('pdl.zabbix.host.10001', '1'), ('pdl.grafana.dashboard.rie-network', '2')):
            self.assertEqual(self.invoke('set-resource', resource, 'internal', '--revision', revision)[0], 0)
        for resource in (
            'pdl.zabbix.host.*',
            'pdl.zabbix.host.0',
            'pdl.grafana.dashboard.../secret',
            'pdl.zabbix.item.1',
        ):
            before = self.path.read_bytes()
            self.assertEqual(self.invoke('set-resource', resource, 'internal', '--revision', '3')[0], 2)
            self.assertEqual(self.path.read_bytes(), before)
        self.assertEqual(self.invoke('remove-resource', 'pdl.zabbix.host.10001', '--revision', '3')[0], 0)

    def test_external_and_unknown_source_changes_fail_without_mutation(self):
        before = self.path.read_bytes()
        self.assertEqual(self.invoke('set-resource', 'incidents.metrics', 'authenticated', '--revision', '1', username='external')[0], 2)
        self.assertEqual(self.invoke('set-resource', 'incidents.unknown', 'internal', '--revision', '1')[0], 2)
        self.assertEqual(self.path.read_bytes(), before)


if __name__ == '__main__':
    unittest.main()
