"""Explicit Docker qualification: prove that follow survives actual log rotation.

Creates one isolated, disposable canary using an already installed image. No
business container, volume, account, model, source or logging setting is changed.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from qualification_logs import Capture, write_json


def run(output, image, docker='docker'):
    output = Path(output).expanduser().absolute()
    if output.exists() or output.is_symlink() or any(p.is_symlink() for p in output.parents):
        raise ValueError('Choose a new private output directory without links')
    output.mkdir(parents=True, mode=0o700)
    name = 'rie-log-rotation-'+uuid.uuid4().hex[:12]
    report = {'kind':'docker-log-rotation-canary','started_at':datetime.now(timezone.utc).isoformat(),
              'passed':False,'checks':{},'image':image,'business_containers_changed':False,'actual_albert_calls':0}
    write_json(output/'report.json', report)
    def command(*args):
        return subprocess.check_output([docker,*args],text=True,stderr=subprocess.STDOUT)
    generator = """from pathlib import Path
import time
while not Path('/tmp/start').exists():time.sleep(.02)
for number in range(500):
 print('ROTATION_LINE %06d '%number+'x'*320,flush=True);time.sleep(.003)
print('ROTATION_END',flush=True)
Path('/tmp/done').write_text('done')
time.sleep(3600)
"""
    cap = negative = None
    created = False
    try:
        command('run','-d','--rm','--pull','never','--name',name,'--network','none','--read-only',
                '--tmpfs','/tmp:rw,noexec,nosuid,size=1m,mode=1777','--cap-drop','ALL','--memory','64m',
                '--pids-limit','32','--log-driver','json-file','--log-opt','max-size=1k',
                '--log-opt','max-file=2','--entrypoint','python',image,'-u','-c',generator)
        created = True
        cap = Capture(output/'continuous',[name],docker=(docker,)).start()
        command('exec',name,'python','-c',"from pathlib import Path;Path('/tmp/start').write_text('start')")
        deadline = time.monotonic()+30
        while 'ROTATION_END' not in (cap.output/(name+'.log')).read_text():
            if time.monotonic()>deadline:
                raise TimeoutError('Canary did not complete within30s')
            time.sleep(.05)
        captured = cap.stop(completed=True)
        raw = (cap.output/(name+'.log')).read_bytes()
        sequence = [int(n) for n in re.findall(rb'ROTATION_LINE (\d+)',raw)]
        suffix = command('logs','--timestamps',name)
        retained = [int(n) for n in re.findall(r'ROTATION_LINE (\d+)',suffix)]
        report['checks']['all_five_hundred_lines_captured_once_in_order'] = sequence == list(range(500))
        report['checks']['capture_completed_without_stream_error'] = captured['passed']
        report['checks']['rotation_actually_discarded_early_docker_lines'] = bool(retained) and len(retained)<500 and retained==list(range(retained[0],500))
        report['counts'] = {'streamed_lines':len(sequence),'retained_by_docker':len(retained),
                            'raw_stream_bytes':len(raw),'raw_stream_sha256':hashlib.sha256(raw).hexdigest()}
        negative = Capture(output/'terminated-client',[name],docker=(docker,)).start()
        negative.processes[name].terminate();negative.processes[name].wait(timeout=5)
        failed = negative.stop(completed=True)
        report['checks']['premature_client_exit_is_a_failed_capture'] = (not failed['passed'] and
            any(row['code']=='stream_ended_before_stop' for row in failed['errors']))
        report['checks']['client_stop_does_not_stop_source_container'] = command('inspect','--format','{{.State.Running}}',name).strip()=='true'
        report['passed'] = all(report['checks'].values())
    except (Exception,KeyboardInterrupt) as error:
        report['error_code'] = type(error).__name__
    finally:
        for capture in (cap,negative):
            if capture and any(not f.closed for f in capture.files.values()):
                capture.stop(completed=False)
        if created:
            command('stop','--time','2',name)
        report['finished_at'] = datetime.now(timezone.utc).isoformat()
        write_json(output/'report.json',report)
    print(json.dumps(report),flush=True)
    return 0 if report['passed'] else 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--image',required=True,help='An existing local image containing Python; never pulled')
    args = parser.parse_args();os.umask(0o077)
    return run(args.output,args.image,os.getenv('RIE_DOCKER','docker'))


if __name__=='__main__':raise SystemExit(main())
