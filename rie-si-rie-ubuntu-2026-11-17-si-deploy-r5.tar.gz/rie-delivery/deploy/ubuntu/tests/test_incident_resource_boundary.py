"""Real policy and HTTP boundaries cover the four independently protected sources."""
from contextlib import contextmanager
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[3]
for relative in ('core/access-control/src', 'core/albert-client/src', 'use-cases/incidents/observability-demo'):
    sys.path.insert(0, str(ROOT / relative))
from dinum_access import AccessGate, AccessDenied, require_indices, require_resources
from dinum_access.security import CURRENT, Principal
from dinum_access.user_tokens import UserTokens
from obs_poc.config import Settings
from obs_poc.clients import Sources, SourceError
from obs_poc.service import Service
from obs_poc import server, telemetry
from starlette.testclient import TestClient

spec = importlib.util.spec_from_file_location('resource_boundary_seed', ROOT / 'deploy/ubuntu/seed_incidents.py')
seed = importlib.util.module_from_spec(spec); spec.loader.exec_module(seed)


class Directory:
    def __init__(self):
        self.kinds = {'alice': 'internal', 'eric': 'external'}

    def lookup(self, value, **options):
        result = value + '@example.invalid', self.kinds[value], 'directory-object-' + value
        return (*result, value != 'eric') if options.get('authorization') else result


class IncidentResourceBoundaryTests(unittest.TestCase):
    def setUp(self):
        private = tempfile.TemporaryDirectory(); self.addCleanup(private.cleanup)
        self.root = Path(private.name); self.directory = Directory()
        self.manifest, _, _ = seed.build_corpus(ROOT / 'use-cases/incidents/observability-demo')
        self.manifest_path = self.root / 'manifest.json'; self.manifest_path.write_text(json.dumps(self.manifest))
        self.settings = Settings(mcp_token='technical-test-only', albert_key='unused', zabbix_token='unused', os_password='',
            metrics_provider='victoriametrics', events_provider='itsm-ng-simulator', grafana='',
            opensearch_public='', manifest_path=self.manifest_path, reports=self.root / 'reports',
            logs_index='custom-incident-logs', docs_index='custom-incident-docs')
        self.settings.manifest = Mock(wraps=self.settings.manifest)
        self.policy = {'version': 1, 'revision': 1, 'default': 'blocked',
            'indices': {self.settings.logs_index: 'internal', self.settings.docs_index: 'internal'},
            'resources': {'incidents.metrics': 'internal', 'incidents.tickets': 'internal'}}
        self.policy_path = self.root / 'policy.json'; self.policy_path.write_text(json.dumps(self.policy))
        self.config = {'version': 1, 'ldap': {}, 'state_directory': str(self.root),
                       'allow_webui_assertions': False, 'user_tokens_directory': str(self.root / 'user-tokens')}
        tokens = UserTokens(self.config['user_tokens_directory']); self.credentials = {}
        for name in ('alice', 'eric'):
            output = self.root / (name + '.token'); tokens.issue(self.directory, name, output)
            self.credentials[name] = output.read_text().strip()
        self.admin = Principal('admin', 'inside@example.invalid', 'internal', True)
        self.reads = []

    def gate(self):
        return AccessGate(self.config, self.directory)

    def headers(self, name='alice'):
        return {'Authorization': 'Bearer ' + self.credentials[name]}

    @contextmanager
    def transport(self):
        reads = self.reads
        class SyntheticSources:
            def __init__(self, settings): self.settings = settings; reads.append('construct_sources')
            def measurements(self, *args):
                require_resources('incidents.metrics'); reads.append('metrics'); return [{'value': 1}]
            def os(self, index, *args):
                require_indices(index); reads.append('index:' + index); return {'hits': {'total': {'value': 0}}}
            def logs(self, *args):
                require_indices(self.settings.logs_index); reads.append('logs')
                return {'total': 0, 'rows': [], 'counts': {}}
            def document(self, *args):
                require_indices(self.settings.docs_index); reads.append('document'); return None
            def request(self, *args): raise AssertionError('No optional Grafana or AI request')
            def close(self): pass
        with patch('dinum_access.security.AccessGate.configured', side_effect=self.gate), \
             patch.object(server, 'Sources', SyntheticSources):
            with TestClient(server.create_app(self.settings)) as client:
                yield client

    def change(self, target, visibility):
        store = self.gate().store; revision = store.read()['revision']
        return (store.update_resource(self.admin, target, visibility, revision) if target.startswith('incidents.')
                else store.update(self.admin, target, visibility, revision))

    def assert_denied_before_reads(self, client, path, name='alice'):
        self.settings.manifest.reset_mock(); self.reads.clear()
        with patch.object(telemetry, 'tickets', side_effect=AssertionError('Forbidden tickets must not be read')) as tickets:
            response = client.get(path, headers=self.headers(name))
        self.assertEqual(response.status_code, 403, response.text)
        self.assertEqual(response.json(), {'error': 'access_denied'})
        self.settings.manifest.assert_not_called(); tickets.assert_not_called()
        self.assertEqual(self.reads, [])

    def test_complete_readers_require_all_four_sources_before_any_read(self):
        with self.transport() as client:
            for target in (*self.policy['indices'], *self.policy['resources']):
                with self.subTest(target=target):
                    self.change(target, 'blocked')
                    for path in ('/status', '/readiness'):
                        self.assert_denied_before_reads(client, path)
                    self.change(target, 'internal')
                    self.assertEqual(client.get('/status', headers=self.headers()).status_code, 200)
                    self.assertEqual(client.get('/readiness', headers=self.headers()).status_code, 200)

    def test_external_and_live_group_change_cannot_read_complete_perimeter(self):
        with self.transport() as client:
            for path in ('/status', '/readiness'):
                self.assert_denied_before_reads(client, path, 'eric')
            self.assertEqual(client.get('/status', headers=self.headers()).status_code, 200)
            self.directory.kinds['alice'] = 'external'
            self.assert_denied_before_reads(client, '/status')
            self.directory.kinds['alice'] = 'internal'
            self.assertEqual(client.get('/status', headers=self.headers()).status_code, 200)

    def test_ticket_reader_has_its_own_rule_independent_of_indices_and_metrics(self):
        with self.transport() as client:
            self.assert_denied_before_reads(client, '/demo-itsm/tickets/ITSM-001', 'eric')
            self.change('incidents.tickets', 'authenticated')
            response = client.get('/demo-itsm/tickets/ITSM-001', headers=self.headers('eric'))
            self.assertEqual(response.status_code, 200); self.assertIn('ITSM-001', response.text)
            self.assert_denied_before_reads(client, '/status', 'eric')
            self.change('incidents.tickets', 'blocked')
            self.assert_denied_before_reads(client, '/demo-itsm/tickets/ITSM-001')

    def test_log_and_document_readers_check_only_their_index_before_manifest(self):
        with self.transport() as client:
            self.change('incidents.metrics', 'blocked'); self.change('incidents.tickets', 'blocked')
            self.change(self.settings.docs_index, 'blocked')
            self.assert_denied_before_reads(client, '/documents/DOC-001')
            query = '?equipment=OBS-RTR-01&start=2026-09-28T08:00:00Z&end=2026-09-28T10:00:00Z'
            self.assertEqual(client.get('/logs' + query, headers=self.headers()).status_code, 200)
            self.change(self.settings.logs_index, 'blocked')
            self.assert_denied_before_reads(client, '/logs' + query)
            self.change(self.settings.docs_index, 'internal')
            self.assertEqual(client.get('/documents/DOC-001', headers=self.headers()).status_code, 404)

    def test_diagnostic_refuses_each_required_source_before_manifest_or_evidence(self):
        for target in (*self.policy['indices'], *self.policy['resources']):
            with self.subTest(target=target):
                self.change(target, 'blocked'); self.settings.manifest.reset_mock()
                sources = Mock(); gate = self.gate(); marker = CURRENT.set((gate, self.admin))
                try:
                    result = Service(self.settings, sources).diagnose('gptoss', 'Examiner R1', synthesize=False)
                finally:
                    CURRENT.reset(marker)
                self.assertEqual(result['status'], 'denied')
                self.assertTrue(result['request_id'])
                for field in ('metrics', 'events', 'logs', 'documents', 'sources', 'evidence'):
                    self.assertFalse(result[field])
                self.settings.manifest.assert_not_called(); self.assertEqual(sources.mock_calls, [])
                self.change(target, 'internal')

    def test_old_policy_is_safe_closed_for_complete_diagnosis(self):
        self.policy_path.write_text(json.dumps({key: value for key, value in self.policy.items() if key != 'resources'}))
        original = self.policy_path.read_bytes()
        with self.transport() as client:
            self.assert_denied_before_reads(client, '/readiness')
        self.assertEqual(self.policy_path.read_bytes(), original)

    def test_denial_during_collection_never_reaches_synthesis_or_report_persistence(self):
        owner = self
        class RevokedDuringCollection:
            def measurements(self, *args):
                owner.change('incidents.metrics', 'blocked')
                try:
                    require_resources('incidents.metrics')
                except AccessDenied:
                    raise SourceError('authorization', 'resource_forbidden') from None
            def events(self, *args): return []
            def logs(self, *args): return {'total': 0, 'rows': [], 'counts': {}}
            def documents(self, *args): return []
            def request(self, *args): raise AssertionError('No synthesis after an authorization refusal')
        marker = CURRENT.set((self.gate(), self.admin))
        try:
            result = Service(self.settings, RevokedDuringCollection()).diagnose('gptoss', 'Examiner R1',
                equipment='OBS-RTR-01', start=self.manifest['start'], end=self.manifest['end'])
        finally:
            CURRENT.reset(marker)
        self.assertEqual(result['status'], 'denied')
        self.assertFalse(result['sources']); self.assertFalse(result['logs'])
        self.assertNotIn('context', result)
        self.assertFalse(self.settings.reports.exists())

    def test_low_level_metrics_and_tickets_refuse_before_mapping_file_or_network(self):
        self.change('incidents.metrics', 'blocked'); self.change('incidents.tickets', 'blocked')
        gate = self.gate(); marker = CURRENT.set((gate, self.admin))
        source = Sources(self.settings)
        try:
            with patch.object(source, 'history', side_effect=AssertionError('No source read')), \
                 patch.object(telemetry, 'raw_samples', side_effect=AssertionError('No mapping or network read')):
                with self.assertRaises(SourceError) as failure:
                    source.measurements({}, 'cpu', '', '')
                self.assertEqual((failure.exception.source, failure.exception.code), ('authorization', 'resource_forbidden'))
            snapshot = Mock(); snapshot.read_text.side_effect = AssertionError('No ticket snapshot read')
            self.settings.itsm_snapshot = snapshot
            with self.assertRaises(SourceError) as failure:
                telemetry.tickets(self.settings, [])
            self.assertEqual(failure.exception.source, 'authorization'); snapshot.read_text.assert_not_called()
        finally:
            source.close(); CURRENT.reset(marker)

    def test_legacy_without_acl_keeps_ticket_and_readiness_behaviour(self):
        with self.transport() as client, patch('dinum_access.security.AccessGate.configured', return_value=None), \
             patch.dict(os.environ, {}, clear=True):
            self.assertEqual(client.get('/demo-itsm/tickets/ITSM-001').status_code, 200)
            self.assertEqual(client.get('/readiness', headers={'Authorization': 'Bearer technical-test-only'}).status_code, 200)
        self.assertIsNone(CURRENT.get())


class IncidentDocumentIndexTests(unittest.TestCase):
    def test_index_setting_is_read_per_instance_and_explicit_value_wins(self):
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(Settings().docs_index, 'obs-network-docs')
        with patch.dict(os.environ, {'OBS_DOCS_INDEX': 'si-rie-documents-v2'}):
            self.assertEqual(Settings().docs_index, 'si-rie-documents-v2')
            self.assertEqual(Settings(docs_index='explicit-documents').docs_index, 'explicit-documents')


if __name__ == '__main__':
    unittest.main()
