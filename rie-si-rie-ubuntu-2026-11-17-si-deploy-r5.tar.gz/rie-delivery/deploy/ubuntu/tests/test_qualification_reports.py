"""Qualification publications preserve failures, isolation and file boundaries."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch
import zipfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT/'deploy/ubuntu'))
import qualification_reports as reports
from portal.reports import ViewingGrants, HTML_HEADERS
from dinum_access import AccessDenied


class PublicationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()
        self.instance = self.root/'instance'
        self.instance.mkdir(mode=0o700)
        self.html = b'<!doctype html><html><head><title>Allure</title></head><body>Result</body></html>'
        self.row = {'schema_version': 1, 'kind': 'rie-qualification-report', 'id': 'test-20261107',
            'title': 'Tests de qualification', 'environment': 'Ubuntu 24.04 ARM64',
            'created_at': '2026-11-07T12:00:00+00:00', 'source': {'commit': 'a'*40, 'dirty': True},
            'counts': dict(passed=1, failed=0, broken=0, skipped=0, unknown=0, not_qualified=0),
            'html': {'bytes': len(self.html), 'sha256': hashlib.sha256(self.html).hexdigest()},
            'renderer': {'name': 'Allure', 'version': '3.33.0', 'plugin': 'allure2'}}

    def bundle(self, name='report.zip', extra=None):
        output = self.root/name
        with zipfile.ZipFile(output, 'w') as archive:
            archive.writestr('report.json', json.dumps(self.row))
            archive.writestr('index.html', self.html)
            if extra:
                archive.writestr(*extra)
        return output

    def test_import_is_readable_by_portal_and_preserves_private_instance_and_original(self):
        archive = self.bundle();before = archive.read_bytes()
        result = reports.import_report(self.instance, archive)
        self.assertFalse(result['services_restarted'])
        folder = self.instance/'qualification'/self.row['id']
        self.assertEqual(self.instance.stat().st_mode & 0o777, 0o700)
        self.assertEqual((folder/'index.html').stat().st_mode & 0o777, 0o444)
        self.assertEqual(archive.read_bytes(), before)
        self.assertEqual(reports.report(folder.parent, self.row['id'], with_html=True)[2], self.html)
        with self.assertRaises(ValueError):reports.import_report(self.instance, archive)
        self.assertEqual((folder/'index.html').read_bytes(), self.html)

    def test_bad_archive_or_manifest_creates_no_publication(self):
        for change in ('hash', 'size', 'counts', 'path', 'date', 'renderer'):
            original = json.loads(json.dumps(self.row))
            if change == 'hash':self.row['html']['sha256'] = '0'*64
            if change == 'size':self.row['html']['bytes'] += 1
            if change == 'counts':self.row['counts']['passed'] = True
            if change == 'path':self.row['id'] = '../secrets'
            if change == 'date':self.row['created_at'] = '2026-11-07T12:00:00'
            if change == 'renderer':self.row['renderer']['name'] = 'Unknown renderer'
            archive = self.bundle(change+'.zip')
            with self.subTest(change=change), self.assertRaises(ValueError):reports.import_report(self.instance, archive)
            self.assertFalse((self.instance/'qualification').exists())
            self.row = original

    def test_extra_paths_duplicates_and_symlink_entries_are_refused(self):
        for extra in (('../secrets', b'PRIVATE'), ('index.html', b'duplicate')):
            with self.subTest(extra=extra[0]), self.assertRaises(ValueError):reports.load_bundle(self.bundle(extra=extra))
        archive = self.root/'symlink.zip'
        with zipfile.ZipFile(archive, 'w') as stream:
            stream.writestr('report.json', json.dumps(self.row))
            entry = zipfile.ZipInfo('index.html');entry.external_attr = 0o120777 << 16
            stream.writestr(entry, 'elsewhere')
        with self.assertRaises(ValueError):reports.load_bundle(archive)

    def test_linked_store_or_input_cannot_publish(self):
        archive = self.bundle();alias = self.root/'alias.zip';alias.symlink_to(archive)
        with self.assertRaises(ValueError):reports.import_report(self.instance, alias)
        outside = self.root/'outside';outside.mkdir()
        (self.instance/'qualification').symlink_to(outside, target_is_directory=True)
        with self.assertRaises(ValueError):reports.import_report(self.instance, archive)
        self.assertEqual(list(outside.iterdir()), [])

    def test_html_tampering_is_detected_before_view_and_export(self):
        reports.import_report(self.instance, self.bundle())
        root = self.instance/'qualification'
        html = root/self.row['id']/'index.html';html.chmod(0o644);html.write_bytes(b'altered')
        for operation in (lambda:reports.report(root,self.row['id'],with_html=True), lambda:reports.export_report(root,self.row['id'])):
            with self.assertRaises(ValueError):operation()

    def test_failed_incomplete_nonqualified_and_skipped_results_are_not_green(self):
        for key, expected in [('failed','failed'),('broken','failed'),('unknown','incomplete'),
                              ('not_qualified','not_qualified'),('skipped','passed_with_skips')]:
            row = json.loads(json.dumps(self.row));row['counts'][key] = 1
            self.assertEqual(reports.outcome(row), expected)
        self.assertEqual(reports.outcome(self.row), 'passed')

    def test_catalogue_reports_invalid_entries_and_exports_exact_files(self):
        reports.import_report(self.instance, self.bundle())
        root = self.instance/'qualification';bad = root/'corrupt';bad.mkdir();(bad/'report.json').write_text('{}')
        rows, rejected = reports.catalogue(root)
        self.assertEqual([r['id'] for r in rows], [self.row['id']]);self.assertEqual(rejected,1)
        archive = self.root/'export.zip';archive.write_bytes(reports.export_report(root,self.row['id']))
        row, _, html = reports.load_bundle(archive)
        self.assertEqual(row, self.row);self.assertEqual(html,self.html)

    def test_operator_import_needs_no_docker_or_backend(self):
        spec = importlib.util.spec_from_file_location('report_manager_test', ROOT/'deploy/ubuntu/manage.py')
        manager = importlib.util.module_from_spec(spec);spec.loader.exec_module(manager)
        archive = self.bundle()
        with patch.object(sys,'argv',['manage.py','import-report',str(self.instance),'--input',str(archive)]), \
                patch.object(manager,'load',return_value={}), patch.object(manager,'docker') as docker:
            manager.main()
        docker.assert_not_called()
        self.assertTrue((self.instance/'qualification'/self.row['id']/'report.json').is_file())


class ViewingGrantsTests(unittest.TestCase):
    def session(self):
        session = Mock();session._epoch = 1
        session.identity.return_value = {'category':'internal','administrator':True}
        return session

    def test_direct_view_needs_a_current_authorized_grant(self):
        grants = ViewingGrants(clock=lambda:0);session = self.session()
        for token in ('', 'invented', 'x'*65):
            with self.assertRaises(AccessDenied):grants.resolve(token)
        token = grants.issue(session)
        self.assertEqual(grants.resolve(token), (session,1))
        self.assertEqual(session.identity.call_count,2)
        session.identity.return_value = {'category':'external','administrator':False}
        with self.assertRaises(AccessDenied):grants.resolve(token)

    def test_expiry_logout_and_identity_switch_invalidate_viewing_urls(self):
        now = [0];grants = ViewingGrants(clock=lambda:now[0]);session = self.session()
        token = grants.issue(session);now[0] = 301
        with self.assertRaises(AccessDenied):grants.resolve(token)
        now[0] = 0;token = grants.issue(session)
        session._unchanged.side_effect = AccessDenied('identity_required')
        with self.assertRaises(AccessDenied):grants.resolve(token)

    def test_nonadministrator_never_obtains_a_viewing_grant(self):
        for category,admin in [('external',False),('internal',False),('unknown',True)]:
            session = self.session();session.identity.return_value = {'category':category,'administrator':admin}
            with self.subTest(category=category,admin=admin),self.assertRaises(AccessDenied):ViewingGrants().issue(session)

    def test_html_is_opaque_and_restricts_external_resource_loads(self):
        csp = HTML_HEADERS['Content-Security-Policy']
        self.assertIn('sandbox allow-scripts',csp)
        self.assertNotIn('allow-same-origin',csp)
        self.assertIn("default-src 'none'",csp)
        self.assertIn("connect-src blob: data:",csp)
        self.assertEqual(HTML_HEADERS['Cache-Control'],'no-store')


if __name__ == '__main__':unittest.main()
