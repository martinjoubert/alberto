"""Provider faults are staged, counted once, and never retain prompt secrets."""
from __future__ import annotations
import importlib.util
import io
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

PATH = Path(__file__).resolve().parents[1] / 'provider_fault_fixture.py'
spec = importlib.util.spec_from_file_location('provider_fault_fixture_tests', PATH)
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)


def payload(value=None, *, stage=None):
    result = {'model': 'gpt-oss-120b', 'messages': [{'role': 'user', 'content': json.dumps(value or {})}]}
    if stage:
        result['response_format'] = {'type': 'json_schema', 'json_schema': {'name': stage}}
    return result


def content(response):
    status, _, raw = response
    if status != 200:
        raise AssertionError('Expected successful provider response')
    body = json.loads(raw)
    return json.loads(body['choices'][0]['message']['content'])


class ProviderFaultFixtureTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.plan = {'source': 'opensearch', 'index': 'rie-pfs-fixture', 'operation': 'count', 'filters': []}
        self.app = fixture.Fixture(plans={'known packaged question': self.plan}, sleeper=self.calls.append, clock=lambda: 12345)

    def test_stage_detection_and_classification_do_not_rewrite_user_intent(self):
        body = payload({'current_message': 'known packaged question', 'prior_request': None})
        self.assertEqual(fixture.classify_stage(body), 'classification')
        self.assertEqual(content(self.app.dispatch('POST', '/v1/chat/completions', body)), {
            'action': 'new', 'confidence': 1.0, 'clarification': '', 'source_change': 'unchanged'})
        body = payload({'current_message': 'Tu peux recommencer ?', 'prior_request': {'request': 'old'}})
        self.assertEqual(content(self.app.dispatch('POST', '/v1/chat/completions', body))['action'], 'retry')
        self.assertEqual(self.app.stats()['counts']['classification'], 2)

    def test_planner_only_returns_an_exact_packaged_intent_and_copies_it(self):
        request = payload({'question': 'known packaged question'})
        returned = content(self.app.dispatch('POST', '/v1/chat/completions', request))
        self.assertEqual(returned, self.plan)
        returned['filters'].append({'untrusted': True})
        self.assertEqual(content(self.app.dispatch('POST', '/v1/chat/completions', request)), self.plan)
        rejected = self.app.dispatch('POST', '/v1/chat/completions', payload({'question': 'invent a free plan'}))
        self.assertEqual(rejected[0], 400)
        self.assertEqual(self.app.stats()['counts']['planner'], 3)

    def test_draft_and_review_are_distinct_stages_with_safe_deterministic_content(self):
        draft = content(self.app.dispatch('POST', '/v1/chat/completions', payload({'facts': []}, stage='diagnostic')))
        self.assertEqual(draft['hypotheses'], [])
        self.assertEqual(draft['verifications'], [])
        self.assertFalse(any(c.isdigit() for c in draft['situation']))
        review = content(self.app.dispatch('POST', '/v1/chat/completions', payload({'answer': {}}, stage='review')))
        self.assertTrue(review['valid'])
        self.assertEqual(self.app.stats()['counts']['draft'], 1)
        self.assertEqual(self.app.stats()['counts']['review'], 1)

    def test_retry_only_reuses_an_unchanged_packaged_question(self):
        context={'request':'known packaged question','replies':['Tu peux recommencer ?']}
        question='PDL_DIALOGUE\n'+json.dumps(context)
        self.assertEqual(content(self.app.dispatch('POST','/v1/chat/completions',payload({'question':question}))),self.plan)
        for changed in ({**context,'replies':['Change le périmètre']},
                        {**context,'request':'unknown question'},
                        {**context,'replies':[]},{**context,'replies':'Tu peux recommencer ?'},
                        {**context,'source_start':1},{**context,'untrusted':'ignored?'}):
            with self.subTest(context=changed):
                status,_,_=self.app.dispatch('POST','/v1/chat/completions',payload({'question':'PDL_DIALOGUE\n'+json.dumps(changed)}))
                self.assertEqual(status,400)

    def test_selected_stage_fault_does_not_affect_classification_or_repeat_requests(self):
        self.app.control({'mode': 'http500', 'stage': 'planner'})
        classifier = self.app.dispatch('POST', '/v1/chat/completions', payload({'current_message': 'start'}))
        failed = self.app.dispatch('POST', '/v1/chat/completions', payload({'question': 'known packaged question'}))
        self.assertEqual(classifier[0], 200)
        self.assertEqual(failed[0], 500)
        stats = self.app.stats()
        self.assertEqual(stats['requests'], 2)
        self.assertEqual(stats['counts']['planner'], 1)
        self.assertEqual(stats['attempts'][-1]['mode'], 'http500')

    def test_429_invalid_json_and_timeout_are_counted_before_the_effect(self):
        request = payload({'question': 'known packaged question'})
        self.app.control({'mode': 'http429', 'stage': 'all'})
        status, headers, _ = self.app.dispatch('POST', '/v1/chat/completions', request)
        self.assertEqual(status, 429)
        self.assertEqual(headers['Retry-After'], '3')
        self.app.control({'mode': 'invalid_json', 'stage': 'planner'})
        status, _, body = self.app.dispatch('POST', '/v1/chat/completions', request)
        self.assertEqual(status, 200)
        with self.assertRaises(ValueError):
            json.loads(body)
        observed = []
        self.app.sleeper = lambda seconds: observed.append((seconds, self.app.stats()['counts']['planner']))
        self.app.control({'mode': 'timeout', 'stage': 'planner', 'delay_seconds': 65})
        self.assertEqual(content(self.app.dispatch('POST', '/v1/chat/completions', request)), self.plan)
        self.assertEqual(observed, [(65.0, 1)])
        self.assertEqual(self.app.stats()['requests'], 1)

    def test_stats_never_include_headers_questions_or_prompt_bodies(self):
        secret = 'private-provider-and-question-sentinel'
        self.app.dispatch('POST', '/v1/chat/completions', payload({'current_message': secret, 'authorization': secret}))
        stats = self.app.dispatch('GET', '/stats')[2]
        self.assertNotIn(secret.encode(), stats)
        self.assertNotIn(b'authorization', stats.lower())
        self.assertEqual(json.loads(stats)['counts']['classification'], 1)
        self.app.control({'mode': 'success'})
        self.assertEqual(self.app.stats()['requests'], 0)
        self.assertEqual(self.app.stats()['attempts'], [])

    def test_control_rejects_unknown_modes_unbounded_delays_and_extra_fields(self):
        invalid = [{'mode': 'redirect'}, {'mode': 'success', 'stage': 'secret'},
                   {'mode': 'timeout', 'delay_seconds': 0}, {'mode': 'timeout', 'delay_seconds': 76},
                   {'mode': 'timeout', 'delay_seconds': True}, {'mode': 'timeout', 'delay_seconds': float('inf')},
                   {'mode': 'success', 'authorization': 'never-store-this'}]
        for value in invalid:
            with self.subTest(value=value):
                self.assertEqual(self.app.dispatch('POST', '/control', value)[0], 400)
        self.assertEqual(self.app.stats()['requests'], 0)

    def test_health_and_models_are_explicitly_simulated_and_requests_are_bounded(self):
        self.assertTrue(json.loads(self.app.dispatch('GET', '/healthz')[2])['rie_simulation'])
        models = json.loads(self.app.dispatch('GET', '/v1/models')[2])
        self.assertIn('gpt-oss-120b', [row['id'] for row in models['data']])
        self.assertEqual(self.app.dispatch('GET', '/private')[0], 404)
        self.assertEqual(fixture.MAX_BODY, 1_048_576)
        malformed = payload({'current_message': 'start'})
        malformed['messages'][0]['content'] = 'not JSON'
        self.assertEqual(self.app.dispatch('POST', '/v1/chat/completions', malformed)[0], 400)

    def test_oversized_http_body_is_rejected_before_reading_any_prompt(self):
        handler_type = fixture.handler_for(self.app)
        handler = object.__new__(handler_type)
        handler.headers = {'Content-Length': str(fixture.MAX_BODY + 1),
                           'Authorization': 'private-header-must-never-be-read'}
        class NeverRead:
            def read(self, _length):
                raise AssertionError('An oversized request body must not be read')
        handler.rfile = NeverRead()
        observed = []
        handler._respond = lambda *args: observed.append(args)
        handler_type.do_POST(handler)
        self.assertEqual(observed[0][0], 400)
        self.assertEqual(self.app.stats()['requests'], 0)

    def test_bundled_plans_match_the_real_packaged_acceptance_questions(self):
        root = PATH.parents[2]
        for relative in ('use-cases/pdl/agentic-pdl', 'core/access-control/src', 'core/albert-client/src'):
            sys.path.insert(0, str(root / relative))
        plans = fixture.bundled_plans()
        self.assertEqual(len(plans), 6)
        self.assertTrue(all(isinstance(question, str) and isinstance(plan, dict)
                            for question, plan in plans.items()))
        app = fixture.Fixture(plans=plans)
        question = next(question for question in plans if 'pfs_count' in question)
        self.assertEqual(content(app.dispatch('POST', '/v1/chat/completions', payload({'question': question}))),
                         plans[question])

    def test_listener_rejects_non_loopback_before_constructing_a_server(self):
        with patch.object(fixture, 'ThreadingHTTPServer', side_effect=AssertionError('No socket permitted')):
            with self.assertRaises(SystemExit) as refused:
                fixture.main(['serve', '--host', '0.0.0.0'])
        self.assertEqual(refused.exception.code, 2)


if __name__ == '__main__':
    unittest.main()
