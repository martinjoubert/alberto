"""Provider fault oracles and resource boundaries without Docker or sockets."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location('provider_campaign_tests', ROOT / 'deploy/ubuntu/qualification_provider_faults.py')
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)


def observation(**overrides):
    return {'http_status': 200, 'status': 'error', 'elapsed_seconds': .5, 'evidence_present': False,
            'request_id': 'new-request', **overrides}


def counts(stage):
    return {'counts': {'classification': 1, 'planner': int(stage == 'planner'), 'draft': 0, 'review': 0}}


class OracleTests(unittest.TestCase):
    def test_error_requires_new_request_without_old_evidence_or_retries(self):
        for stage in ('classification', 'planner'):
            with self.subTest(stage=stage):
                expected = campaign.evaluate_failure(observation(), counts(stage), stage, baseline_request='old-request')
                self.assertTrue(all(expected.values()), expected)
                for change, rejected in (({'status': 'success'}, 'explicit_failure'),
                                         ({'evidence_present': True}, 'old_evidence_not_reused'),
                                         ({'request_id': 'old-request'}, 'old_result_identifier_not_reused'),
                                         ({'http_status': 500}, 'explicit_failure')):
                    checks = campaign.evaluate_failure(observation(**change), counts(stage), stage, baseline_request='old-request')
                    self.assertFalse(checks[rejected])
                no_report = campaign.evaluate_failure(observation(request_id=None), counts(stage), stage,
                                                       baseline_request='old-request')
                self.assertTrue(no_report['old_result_identifier_not_reused'])
                retried = counts(stage)
                retried['counts'][stage] += 1
                self.assertFalse(campaign.evaluate_failure(observation(), retried, stage)['one_attempt_per_stage_no_retry'])

    def test_native_timeouts_have_lower_and_upper_bounds(self):
        for stage, minimum, maximum in (('classification', 58, 76), ('planner', 58, 76)):
            for elapsed, expected in ((minimum - .1, False), (minimum, True), (maximum, True), (maximum + .1, False)):
                with self.subTest(stage=stage, elapsed=elapsed):
                    checks = campaign.evaluate_failure(observation(elapsed_seconds=elapsed), counts(stage), stage, timeout=True)
                    self.assertEqual(checks['deadline_is_bounded'], expected)
        self.assertFalse(campaign.evaluate_failure(observation(elapsed_seconds=15), counts('planner'), 'planner')['deadline_is_bounded'])

    def test_timeout_injection_outlasts_both_documented_sixty_second_budgets(self):
        for name,mode,stage,delay in campaign.CASES:
            if mode=='timeout':
                with self.subTest(stage=stage):
                    self.assertGreater(delay,60)
                    self.assertFalse(campaign.evaluate_failure(observation(elapsed_seconds=35),counts(stage),stage,timeout=True)['deadline_is_bounded'])

    def test_domain_report_path_fingerprint_distinguishes_pdl_executions(self):
        first=campaign.safe_observation(200, {'status':'success','report':'/private/reports/first.json'},.1)
        second=campaign.safe_observation(200, {'status':'error','report':'/private/reports/second.json'},.1)
        self.assertNotIn('/private/',json.dumps(first))
        self.assertIsNone(first['request_id'])
        self.assertNotEqual(first['report_reference_sha256'],second['report_reference_sha256'])
        good=campaign.evaluate_failure(second,counts('planner'),'planner',baseline_report=first['report_reference_sha256'])
        self.assertTrue(good['old_result_identifier_not_reused'])
        reused={**second,'report_reference_sha256':first['report_reference_sha256']}
        self.assertFalse(campaign.evaluate_failure(reused,counts('planner'),'planner',baseline_report=first['report_reference_sha256'])['old_result_identifier_not_reused'])

    def test_healthy_baseline_requires_the_exact_two_real_documents(self):
        original = observation(status='success', evidence_present=True, evidence_total=2)
        self.assertTrue(campaign.successful(original))
        for update in ({'evidence_total': 1}, {'evidence_present': False}, {'status': 'limited'}, {'http_status': 503}):
            self.assertFalse(campaign.successful({**original, **update}))

    def test_observation_excludes_raw_questions_headers_evidence_and_model_answer(self):
        private = 'PRIVATE_QUESTION_SOURCE_AND_AUTHORIZATION'
        result = {'status': 'error', 'request_id': 'safe-id', 'continuation_token': 'PRIVATE_CONTINUATION',
                  'error': {'code': 'provider_unavailable', 'message': private},
                  'question': private, 'headers': {'Authorization': private}, 'answer': private,
                  'dialogue': {'error_code': 'classification_failed', 'question': private},
                  'evidence': {'total': 1, 'rows': [{'document': private}]}, 'usage': [{'prompt': private}]}
        observed = campaign.safe_observation(200, result, 1.2345)
        public = campaign.redact(observed)
        self.assertTrue(public['evidence_present'])
        self.assertEqual(public['evidence_total'], 1)
        self.assertEqual(public['error_code'], 'provider_unavailable')
        self.assertNotIn('PRIVATE_', json.dumps(public))
        self.assertIn('continuation_token', observed)
        self.assertNotIn('continuation_token', public)

    def test_unstructured_provider_error_text_is_never_a_report_code(self):
        result = {'status': 'error', 'error': 'Bearer PRIVATE_SECRET from https://provider.invalid/question',
                  'dialogue': {'error_code': 'Private provider text containing a question'}}
        observed = campaign.safe_observation(200, result, .1)
        self.assertIsNone(observed['error_code'])
        self.assertIsNone(observed['dialogue_error'])
        self.assertNotIn('PRIVATE_SECRET', json.dumps(observed))


class IsolationTests(unittest.TestCase):
    def test_exception_restores_exact_environment_before_ordinary_acceptance(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);instance=root/'private';instance.mkdir();before=b'ORIGINAL_ENV_BYTES=preserved\n'
            (instance/'.env').write_bytes(before)
            values={'RIE_MODE':'demo','RIE_PROJECT':'rie-test','RIE_INSTANCE_ID':'1'*32,'RIE_IMAGE':'existing:image'}
            def save_env(path,changed):(path/'.env').write_text('TEMPORARY_PROVIDER_ROUTE\n')
            def write_new(path,value):path.write_text(value)
            manager=SimpleNamespace(ROOT=ROOT,load=lambda _:dict(values),guard=Mock(),compose=Mock(),
                save_env=save_env,write_new=write_new)
            with patch.object(campaign,'start_sidecar',side_effect=RuntimeError('controlled failure')),\
                 patch.object(campaign,'remove_sidecar'),\
                 patch.object(campaign.subprocess,'run',return_value=SimpleNamespace(returncode=0)) as command:
                result=campaign.run(instance,root/'output',manager=manager)
            self.assertEqual(result,2)
            self.assertEqual((instance/'.env').read_bytes(),before)
            self.assertFalse((instance/'.provider-faults.lock').exists())
            report=json.loads((root/'output/report.json').read_text())
            self.assertTrue(report['checks']['original_environment_bytes_restored'])
            self.assertTrue(report['checks']['ordinary_check_and_twelve_acceptance_cases_pass'])
            self.assertEqual([call.args[0][-2] for call in command.call_args_list],['up','check','acceptance'])

    def test_external_and_endurance_instances_are_rejected_before_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for values in ({'RIE_MODE': 'external'}, {'RIE_MODE': 'demo', 'RIE_LOAD_QUALIFICATION': 'true'}):
                manager = SimpleNamespace(ROOT=ROOT, load=Mock(return_value=values), guard=Mock(),
                                          docker=Mock(), compose=Mock(), save_env=Mock())
                output = root / 'must-not-exist'
                with self.subTest(values=values), self.assertRaisesRegex(ValueError, 'Never inject'):
                    campaign.run(root / 'instance', output, manager=manager)
                self.assertFalse(output.exists())
                manager.docker.assert_not_called()
                manager.compose.assert_not_called()
                manager.save_env.assert_not_called()

    def test_sidecar_only_joins_backend_namespace_without_ports_mounts_or_secrets(self):
        manager = SimpleNamespace(docker=Mock())
        values = {'RIE_INSTANCE_ID': 'a' * 32, 'RIE_IMAGE': 'application:qualified'}
        with patch.object(campaign, 'control', return_value={'rie_simulation': True}):
            campaign.start_sidecar(manager, values, 'owned-backend', 'owned-sidecar', 'PUBLIC_FIXTURE_SOURCE')
        argv = manager.docker.call_args.args
        self.assertEqual(argv[:2], ('run', '-d'))
        self.assertEqual(argv[argv.index('--network') + 1], 'container:owned-backend')
        for forbidden in ('--volume', '-v', '--mount', '--publish', '-p', '--env', '-e', '--env-file', '--privileged'):
            self.assertNotIn(forbidden, argv)
        self.assertIn('--read-only', argv)
        self.assertEqual(argv[argv.index('--cap-drop') + 1], 'ALL')
        self.assertEqual(argv[argv.index('--user') + 1], '10001:10001')
        self.assertEqual(argv[argv.index('--memory') + 1], '128m')
        self.assertEqual(argv[-5:], ('-c', 'PUBLIC_FIXTURE_SOURCE', 'serve', '--port', '8124'))

    def test_cleanup_checks_both_ownership_labels_before_stop(self):
        for labels in ({}, {'rie.qualification.owner': 'owner'},
                       {'rie.qualification.owner': 'other', 'rie.qualification.purpose': 'provider-fault'}):
            manager = SimpleNamespace(docker=Mock())
            with patch.object(campaign, 'owner_labels', return_value=labels), self.assertRaisesRegex(ValueError, 'unrelated'):
                campaign.remove_sidecar(manager, 'sidecar', 'owner')
            manager.docker.assert_not_called()
        manager = SimpleNamespace(docker=Mock())
        labels = {'rie.qualification.owner': 'owner', 'rie.qualification.purpose': 'provider-fault'}
        with patch.object(campaign, 'owner_labels', return_value=labels):
            campaign.remove_sidecar(manager, 'sidecar', 'owner')
        self.assertEqual([row.args for row in manager.docker.call_args_list],
                         [('stop', '--time', '5', 'sidecar'), ('rm', 'sidecar')])

    def test_fixture_control_endpoint_allowlist_rejects_arbitrary_url(self):
        manager = SimpleNamespace(docker=Mock())
        for path in ('http://external.test', '../control', 'v1/chat/completions'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                campaign.control(manager, 'backend', path)
        manager.docker.assert_not_called()


if __name__ == '__main__':
    unittest.main()
