"""Reject unsafe IA admission/model configuration before touching Docker."""
from contextlib import redirect_stdout
import importlib.util
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location('admission_config_manage', ROOT/'deploy/ubuntu/manage.py')
manage = importlib.util.module_from_spec(spec); spec.loader.exec_module(manage)


class AdmissionConfigurationTests(unittest.TestCase):
    def test_invalid_interval_and_model_are_rejected_before_lifecycle_mutations(self):
        with tempfile.TemporaryDirectory() as temporary:
            instance = Path(temporary).resolve()/'instance'
            with redirect_stdout(io.StringIO()):
                manage.bootstrap(instance, 'external')
            original = manage.load(instance)
            cases = [('OBS_MIN_TURN_INTERVAL_SECONDS', value) for value in ('-1', 'nan', 'inf', '86401', '')]
            cases += [(key, 'invalid model') for key in
                      ('ALBERT_MODEL', 'OBS_MODEL_GPTOSS', 'OBS_MODEL_GEMMA', 'OBS_MODEL_DEEPSEEK', 'OBS_DIALOGUE_MODEL', 'OBS_REVIEW_MODEL')]
            for key, value in cases:
                with self.subTest(key=key, value=value), patch.object(manage, 'docker') as docker:
                    with self.assertRaisesRegex(ValueError, key):
                        manage.preflight_up(instance, {**original, key: value})
                    docker.assert_not_called()
            self.assertEqual(manage.load(instance), original)


if __name__ == '__main__':
    unittest.main()
