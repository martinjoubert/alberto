"""Readiness checks use the caller identity even in source-probe worker threads."""
from dataclasses import replace
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[3]
for folder in ('core/access-control/src','core/albert-client/src','use-cases/incidents/observability-demo'):
    sys.path.insert(0,str(ROOT/folder))
from dinum_access.security import AccessGate,CURRENT,Principal
from obs_poc.config import Settings
from obs_poc import server
from starlette.testclient import TestClient


class ReadinessTransportTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        root=Path(self.temp.name)
        manifest=root/'manifest.json'
        manifest.write_text(json.dumps({'hosts':[{'equipment':'OBS-RTR-01','hostid':'1','scope':'SITE','allowed':True}],
            'status':'ready','synthetic':True,'timezone':'Europe/Paris','anchor_date':'2026-09-28','interval_seconds':60,
            'start':'2026-09-28T10:00:00+02:00','end':'2026-09-28T12:00:00+02:00'}))
        self.settings=Settings(mcp_token='technical-only',albert_key='unused',zabbix_token='unused',os_password='',
                               metrics_provider='victoriametrics',events_provider='itsm-ng-simulator',
                               grafana='',itsm_public='',manifest_path=manifest,reports=root/'reports')
        self.principal=Principal('test-internal','alice@example.org','internal',True)
        (root/'policy.json').write_text(json.dumps({'version':1,'revision':1,'default':'blocked',
            'indices':{self.settings.logs_index:'internal',self.settings.docs_index:'internal'},
            'resources':{'incidents.metrics':'internal','incidents.tickets':'internal'}}))
        self.gate=AccessGate({'state_directory':str(root)},directory=object())
        self.gate.authenticate=lambda headers:self.principal

    def probe(self, *, empty_metrics=False, fail_opensearch=False):
        identity=self.principal
        from obs_poc.clients import SourceError
        class Sources:
            def __init__(self,*args):pass
            def measurements(self,*args):
                assert CURRENT.get()[1] is identity,'Authenticated context was lost in the thread pool'
                return [] if empty_metrics else [{'clock':'test','value':1}]
            def os(self,*args):
                assert CURRENT.get()[1] is identity,'Authenticated context was lost in the thread pool'
                if fail_opensearch:raise SourceError('opensearch','unavailable')
                return {'hits':{'total':{'value':0,'relation':'eq'}}}
            def request(self,*args):raise AssertionError('No Grafana or Albert call may occur')
            def close(self):pass
        with patch('dinum_access.security.AccessGate.configured',return_value=self.gate),patch.object(server,'Sources',Sources):
            with TestClient(server.create_app(self.settings)) as client:
                return client.get('/readiness',headers={'Authorization':'Bearer individual-client'})

    def test_no_optional_grafana_probe_and_context_reaches_real_worker_threads(self):
        response=self.probe()
        self.assertEqual(response.status_code,200)
        result=response.json();self.assertTrue(result['ready'])
        self.assertNotIn('grafana',[r['service'] for r in result['services']])
        self.assertEqual(next(r['status'] for r in result['services'] if r['service']=='albert'),'not_probed')

    def test_missing_measurements_or_source_outage_return_503(self):
        for options in ({'empty_metrics':True},{'fail_opensearch':True}):
            with self.subTest(options=options):
                response=self.probe(**options)
                self.assertEqual(response.status_code,503)
                self.assertFalse(response.json()['ready'])


if __name__=='__main__':unittest.main()
