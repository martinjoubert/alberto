"""A stage transition must not reset a user's last request start."""
import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('qualification_cadence',Path(__file__).resolve().parents[1]/'qualification.py')
recipe=importlib.util.module_from_spec(spec);spec.loader.exec_module(recipe)


class Clock:
    def __init__(self,current):self.current=current;self.sleeps=[]
    def now(self):return self.current
    def sleep(self,seconds):self.sleeps.append(seconds);self.current+=seconds
    def start(self,previous,deadline):
        return recipe.next_client_start(previous,5,deadline,clock=self.now,sleeper=self.sleep)


class CadenceTests(unittest.TestCase):
    def test_transition_waits_until_previous_identity_start_plus_period(self):
        clock=Clock(8.9)
        last=clock.start(None,10)
        self.assertEqual(last,8.9)
        self.assertIsNone(clock.start(last,10))
        self.assertEqual(clock.current,10)
        # The next phase starts at10; the same identity must wait until13.9.
        resumed=clock.start(last,20)
        self.assertEqual(resumed,13.9)
        self.assertGreaterEqual(resumed-last,5)
        self.assertAlmostEqual(clock.sleeps[-1],3.9)

    def test_new_identity_does_not_wait_for_existing_identity(self):
        clock=Clock(10)
        self.assertEqual(clock.start(None,20),10)
        self.assertEqual(clock.start(8.9,20),13.9)

    def test_short_phase_finishes_without_forcing_an_early_request(self):
        clock=Clock(10)
        self.assertIsNone(clock.start(8.9,12))
        self.assertEqual(clock.current,12)
        self.assertEqual(clock.sleeps,[2])

    def test_slow_request_never_adds_an_extra_period_after_its_completion(self):
        clock=Clock(9)
        self.assertEqual(clock.start(0,12),9)
        self.assertFalse(clock.sleeps)

    def test_early_wakeup_is_rechecked_before_the_request_can_start(self):
        clock=Clock(10)
        def half_sleep(seconds):clock.current+=seconds/2 if seconds>.01 else seconds
        began=recipe.next_client_start(8.9,5,20,clock=clock.now,sleeper=half_sleep)
        self.assertGreaterEqual(began,13.9)
        self.assertLess(began,20)

    def test_native_cadence_detects_a_transition_reset_across_all_stages(self):
        rows=[{'client':1,'stage':1,'start_monotonic_seconds':8.9},
              {'client':1,'stage':2,'start_monotonic_seconds':10},
              {'client':2,'stage':2,'start_monotonic_seconds':10},
              {'client':2,'stage':2,'start_monotonic_seconds':15.5}]
        measured=recipe.cadence_summary(rows,5)
        self.assertEqual(measured['violations'],1)
        self.assertEqual(measured['minimum_start_gap_seconds'],1.1)
        self.assertEqual(measured['intervals_checked'],2)
        rows[1]['start_monotonic_seconds']=13.9
        corrected=recipe.cadence_summary(rows,5)
        self.assertEqual(corrected['violations'],0)
        self.assertEqual(corrected['minimum_start_gap_seconds'],5)


if __name__=='__main__':unittest.main()
