"""Catch local Markdown section links left behind by a human-manual rewrite."""
from pathlib import Path
import re
import tempfile
import unicodedata
import unittest
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[3]
LINK = re.compile(r'!?\[[^\]\n]*\]\(([^\s)]+)\)')
FENCE = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
HEADING = re.compile(r'^ {0,3}#{1,6}\s+(.+?)\s*$')


def visible_lines(text, *, strip_inline=True):
    """Keep source line numbers while ignoring fenced examples and inline code."""
    fence = None
    for number, line in enumerate(text.splitlines(), 1):
        match = FENCE.match(line)
        if fence is not None:
            if match and match[1][0] == fence[0] and len(match[1]) >= len(fence) and not match[2].strip():
                fence = None
            continue
        if match:
            fence = match[1]
            continue
        yield number, re.sub(r'(`+).*?\1', '', line) if strip_inline else line


def section_ids(text):
    """ATX headings use GitHub-style Unicode slugs and duplicate-title suffixes."""
    identifiers = set()
    # Headings need code text for their id, so only remove backtick delimiters.
    for _number, line in visible_lines(text, strip_inline=False):
        match = HEADING.match(line)
        if match is None:
            continue
        title = re.sub(r'\s+#+\s*$', '', match[1]).replace('`', '')
        title = re.sub(r'<[^>]*>', '', title)
        title = re.sub(r'!?\[([^\]]*)\]\([^)]*\)', r'\1', title).lower()
        base = ''.join('-' if character.isspace() else character
                       for character in title
                       if character.isspace() or character in '-_'
                       or unicodedata.category(character)[0] in 'LMN')
        identifier, suffix = base, 0
        while identifier in identifiers:
            suffix += 1
            identifier = base + '-' + str(suffix)
        identifiers.add(identifier)
    return identifiers


def broken_fragments(root):
    root = Path(root).resolve()
    pages = {page.resolve(): page.read_text() for page in root.rglob('*.md')}
    anchors = {page: section_ids(text) for page, text in pages.items()}
    failures = []
    for page, text in pages.items():
        for number, line in visible_lines(text):
            for match in LINK.finditer(line):
                url = urlsplit(match[1])
                if url.scheme or url.netloc or not url.fragment:
                    continue
                target = (page.parent / unquote(url.path)).resolve() if url.path else page
                if target.suffix.lower() != '.md':
                    continue
                fragment = unquote(url.fragment)
                if target not in anchors or fragment not in anchors[target]:
                    failures.append((page.relative_to(root).as_posix(), number, match[1]))
    return failures


class DocumentFragmentTests(unittest.TestCase):
    def test_unicode_percent_encoding_and_duplicate_titles_reach_their_sections(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'install.md').write_text('# Préparer la séance\n## Préparer la séance\n')
            (root / 'index.md').write_text('[Premier](install.md#pr%C3%A9parer-la-s%C3%A9ance)\n'
                                           '[Second](install.md#préparer-la-séance-1)\n')
            self.assertEqual(broken_fragments(root), [])

    def test_stale_numbered_section_is_reported_after_heading_rewrite(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'install.md').write_text('# Raccorder le poste utilisateur — après A ou B\n')
            (root / 'index.md').write_text('[Ancienne](install.md#7-raccorder-le-poste-utilisateur)\n')
            self.assertEqual(broken_fragments(root), [('index.md', 1, 'install.md#7-raccorder-le-poste-utilisateur')])

    def test_fenced_examples_inline_code_and_remote_fragments_are_ignored(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'index.md').write_text('# Ici\n[Valide](#ici)\n'
                                           '```md\n# Exemple uniquement\n[Code](missing.md#absent)\n```\n'
                                           '~~~md\n[Code](missing.md#absent)\n~~~\n'
                                           '`[Inline](missing.md#absent)`\n'
                                           '[Externe](https://example.org/guide.md#ailleurs)\n')
            self.assertEqual(broken_fragments(root), [])
            self.assertEqual(section_ids((root / 'index.md').read_text()), {'ici'})

    def test_canonical_manual_links_reach_existing_markdown_sections(self):
        self.assertEqual(broken_fragments(ROOT / 'docs/si-rie'), [])


if __name__ == '__main__':
    unittest.main()
