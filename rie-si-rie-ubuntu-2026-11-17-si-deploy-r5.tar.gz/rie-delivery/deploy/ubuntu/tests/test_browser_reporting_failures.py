"""A crashed browser must leave a diagnostic report even without screenshots.

The Playwright double completes one actual harness checkpoint, then fails at
navigation. No browser, server, credential or application service is needed.
"""
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parents[3]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class BrowserFailureReportingTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name).resolve()
        self.output, self.allure = self.root/'browser', self.root/'allure-results'
        self.accounts = self.root/'accounts.json'
        self.accounts.write_text(json.dumps({'users': [
            {'uid': name, 'password': 'synthetic-test-password'} for name in (
                'alice.martin', 'eric.durand.ext', 'camille.inconnue')]}))
        self.page, self.other = MagicMock(name='internal_page'), MagicMock(name='external_page')
        self.page.url = self.other.url = 'http://127.0.0.1:18090/'
        self.page.locator.return_value.count.return_value = 0
        self.page.locator.return_value.all.return_value = []
        self.page.screenshot.side_effect = RuntimeError('screenshot target is closed')
        self.other.screenshot.side_effect = RuntimeError('external screenshot target is closed')
        self.inside, self.outside = MagicMock(), MagicMock()
        self.inside.new_page.return_value = self.page
        self.outside.new_page.return_value = self.other
        self.browser = MagicMock()
        self.browser.new_context.side_effect = [self.inside, self.outside]
        engine, manager = MagicMock(), MagicMock()
        self.engine = engine
        engine.chromium.launch.return_value = self.browser
        manager.__enter__.return_value = engine
        self.playwright = types.ModuleType('playwright.sync_api')
        self.playwright.sync_playwright = lambda: manager
        self.playwright.expect = MagicMock()

    def exercise(self, primary, *, close_error=False):
        self.page.goto.side_effect = [None, primary]
        if close_error:
            self.inside.close.side_effect = RuntimeError('internal context close failed')
            self.outside.close.side_effect = RuntimeError('external context close failed')
            self.browser.close.side_effect = RuntimeError('browser close failed')
        script = load('browser_failure_harness', ROOT/'deploy/ubuntu/tests/browser_portal.py')
        argv = ['browser_portal.py', '--url', 'http://127.0.0.1:18090',
                '--accounts-file', str(self.accounts), '--output', str(self.output),
                '--allure-results', str(self.allure)]
        with patch.dict(sys.modules, {'playwright.sync_api': self.playwright}), \
                patch.object(sys, 'argv', argv), redirect_stdout(io.StringIO()):
            try:
                exit_code = script.main()
            except KeyboardInterrupt:
                # Propagating Ctrl-C is acceptable only after durable evidence.
                exit_code = 130
        self.assertNotEqual(exit_code, 0)
        receipt = json.loads((self.output/'browser-results.json').read_text())
        self.assertFalse(receipt['passed'])
        self.assertTrue(any(not row['passed'] for row in receipt['checks']))
        results = [json.loads(path.read_text()) for path in self.allure.glob('*-result.json')]
        self.assertTrue(any(row['name'] == 'page_home' and row['status'] == 'passed' for row in results))
        failures = [row for row in results if row['status'] in {'failed', 'broken', 'unknown'}]
        self.assertTrue(failures, 'Partial successful checkpoints must not become an entirely green report')
        serialized = json.dumps(failures, ensure_ascii=False)
        self.assertIn(type(primary).__name__, serialized)
        if str(primary):
            self.assertIn(str(primary), serialized)
        self.assertTrue(any(row.get('statusDetails', {}).get('trace') for row in failures),
                        'The primary traceback must remain available without a screenshot')
        renderer = load('browser_failure_renderer', ROOT/'deploy/ubuntu/build_report.py')
        counts = renderer.stage_results(self.allure, self.root/'staged')
        self.assertGreater(counts['failed'] + counts['broken'] + counts['unknown'], 0)
        self.inside.close.assert_called()
        self.outside.close.assert_called()
        self.browser.close.assert_called()

    def test_crash_and_unavailable_screenshots_preserve_the_primary_failure(self):
        self.exercise(RuntimeError('navigation failed because the page crashed'))

    def test_cleanup_errors_cannot_erase_a_navigation_failure(self):
        self.exercise(RuntimeError('primary navigation failure'), close_error=True)

    def test_assertion_remains_failed_when_both_screenshots_are_unavailable(self):
        self.exercise(AssertionError('expected portal title was not found'))

    def test_keyboard_interruption_after_a_successful_checkpoint_is_not_green(self):
        self.exercise(KeyboardInterrupt('qualification interrupted deliberately'))

    def test_chromium_launch_failure_has_a_durable_diagnostic_before_any_checkpoint(self):
        self.engine.chromium.launch.side_effect = RuntimeError('Chromium executable is unavailable')
        script = load('browser_startup_failure_harness', ROOT/'deploy/ubuntu/tests/browser_portal.py')
        argv = ['browser_portal.py', '--url', 'http://127.0.0.1:18090',
                '--accounts-file', str(self.accounts), '--output', str(self.output),
                '--allure-results', str(self.allure)]
        with patch.dict(sys.modules, {'playwright.sync_api': self.playwright}), \
                patch.object(sys, 'argv', argv), redirect_stdout(io.StringIO()):
            exit_code = script.main()
        self.assertNotEqual(exit_code, 0)
        receipt = json.loads((self.output/'browser-results.json').read_text())
        self.assertFalse(receipt['passed'])
        results = [json.loads(path.read_text()) for path in self.allure.glob('*-result.json')]
        self.assertTrue(results)
        self.assertTrue(all(row['status'] in {'failed', 'broken', 'unknown'} for row in results))
        self.assertTrue(any('Chromium executable is unavailable' in row.get('statusDetails', {}).get('trace', '')
                            for row in results))
        self.assertFalse(any({'name':'reporting','value':'campaign-incomplete'} in row.get('labels', [])
                             for row in results), 'The durable failure receipt is the final campaign verdict')
        self.inside.close.assert_not_called()
        self.outside.close.assert_not_called()
        self.browser.close.assert_not_called()

    def test_qualification_campaign_tracking_survives_selecting_a_report_card(self):
        # The execution tracker and a report's browser Locator must stay distinct.
        # Run four checkpoints, then fail the next export request deliberately.
        for page in (self.page, self.other):
            page.locator.return_value.input_value.return_value = ''
        self.page.locator.return_value.locator.return_value.get_attribute.return_value = '/qualification/export/fault-report'
        denied = types.SimpleNamespace(status=403)
        self.inside.request.get.side_effect = [denied, denied, denied, denied,
            RuntimeError('controlled export channel unavailable')]

        def capture(*, path, **_kwargs):
            if str(path).endswith('qualification-catalogue.png'):
                # PNG selection is validated separately by reporting tests. The
                # catalogue checkpoint only requires a produced PNG signature.
                Path(path).write_bytes(b'\x89PNG\r\n\x1a\n')
            else:
                raise RuntimeError('screenshot target is closed')

        self.page.screenshot.side_effect = capture
        script = load('qualification_tracker_failure_harness', ROOT/'deploy/ubuntu/tests/browser_qualification.py')
        argv = ['browser_qualification.py', '--url', 'http://127.0.0.1:18090',
                '--accounts-file', str(self.accounts), '--output', str(self.output),
                '--allure-results', str(self.allure), '--report-id', 'fault-report']
        with patch.dict(sys.modules, {'playwright.sync_api': self.playwright}), \
                patch.object(sys, 'argv', argv), redirect_stdout(io.StringIO()):
            exit_code = script.main()
        self.assertNotEqual(exit_code, 0)
        receipt = json.loads((self.output/'browser-results.json').read_text())
        self.assertFalse(receipt['passed'])
        self.assertEqual(sum(row['passed'] for row in receipt['checks']), 4)
        self.assertIn('controlled export channel unavailable', json.dumps(receipt))
        rows = [json.loads(path.read_text()) for path in self.allure.glob('*-result.json')]
        self.assertEqual(sum(row['status'] == 'passed' for row in rows), 4)
        self.assertTrue(any(row['status'] == 'broken' and
                            'controlled export channel unavailable' in row.get('statusDetails', {}).get('trace', '')
                            for row in rows))
        self.assertFalse(any({'name':'reporting','value':'campaign-incomplete'} in row.get('labels', [])
                             for row in rows))
        self.inside.close.assert_called()
        self.outside.close.assert_called()
        self.browser.close.assert_called()


if __name__ == '__main__':
    unittest.main()
