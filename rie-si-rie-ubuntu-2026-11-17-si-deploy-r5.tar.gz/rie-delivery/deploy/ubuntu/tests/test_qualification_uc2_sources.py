"""Host/probe safeguards; native HTTP results are produced separately on Ubuntu."""
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import stat
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'core/access-control/src'))
from dinum_access import PolicyStore, AccessDenied
from dinum_access.security import Principal

spec = importlib.util.spec_from_file_location('qualification_uc2_sources_test', ROOT / 'deploy/ubuntu/qualification_uc2_sources.py')
recipe = importlib.util.module_from_spec(spec); spec.loader.exec_module(recipe)


class PolicyRestorationTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name); self.path = self.root / 'policy.json'
        self.policy = {'version': 1, 'revision': 1, 'default': 'blocked',
                      'indices': {'logs': 'internal', 'docs': 'internal', 'pdl': 'authenticated'},
                      'resources': {'incidents.metrics': 'internal', 'incidents.tickets': 'internal'}}
        self.path.write_text(json.dumps(self.policy))
        self.store = PolicyStore(self.root)
        self.admin = Principal('admin', 'unused@example.invalid', 'internal', True)
        self.edits = recipe.PolicyEdits(self.store, self.admin)

    def test_finally_restores_each_owned_rule_after_failure_and_keeps_other_bytes(self):
        try:
            self.edits.set('logs', 'blocked'); self.edits.set('incidents.metrics', 'blocked')
            self.store.update(self.admin, 'pdl', 'internal', self.store.read()['revision'])
            raise RuntimeError('HTTP probe failed')
        except RuntimeError:
            self.assertEqual(self.edits.restore_all(), [])
        after = self.store.read()
        self.assertEqual(after['indices']['pdl'], 'internal')
        self.assertEqual(after['indices']['logs'], 'internal')
        self.assertEqual(after['resources'], self.policy['resources'])
        self.assertEqual(after['revision'], 6)
        self.assertEqual(self.edits.owned, {})

    def test_concurrent_change_of_owned_rule_is_never_overwritten(self):
        self.edits.set('incidents.tickets', 'authenticated')
        self.store.update_resource(self.admin, 'incidents.tickets', 'blocked', self.store.read()['revision'])
        failures = self.edits.restore_all()
        self.assertEqual(failures, [{'target': 'incidents.tickets', 'error_code': 'ValueError'}])
        self.assertEqual(self.store.read()['resources']['incidents.tickets'], 'blocked')

    def test_absent_rule_is_removed_on_restore_without_touching_existing_targets(self):
        before = recipe.contents(self.store.read())
        self.edits.set('disposable-index', 'blocked')
        self.edits.restore_target('disposable-index')
        self.assertEqual(recipe.contents(self.store.read()), before)
        self.assertEqual(self.edits.owned, {})

    def test_canonical_other_rule_hash_changes_only_for_an_unrelated_edit(self):
        before = recipe.other_rules(self.policy, 'resources', 'incidents.metrics')
        changed = json.loads(json.dumps(self.policy)); changed['resources']['incidents.metrics'] = 'blocked'; changed['revision'] += 1
        self.assertEqual(recipe.digest(before), recipe.digest(recipe.other_rules(changed, 'resources', 'incidents.metrics')))
        changed['indices']['pdl'] = 'blocked'
        self.assertNotEqual(recipe.digest(before), recipe.digest(recipe.other_rules(changed, 'resources', 'incidents.metrics')))


class HostBoundaryTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name); self.source = self.root / 'delivery'; self.source.mkdir()
        (self.source / 'DELIVERY-MANIFEST.json').write_text('{"source":"fixture"}')
        self.instance = self.root / 'instance'
        (self.instance / 'ldap-fixture/private').mkdir(parents=True)
        self.passwords = {name: 'synthetic-private-password-' + str(position) for position, name in enumerate(recipe.ACCOUNTS)}
        (self.instance / 'ldap-fixture/private/accounts.json').write_text(json.dumps({
            'users': [{'uid': name, 'password': password} for name, password in self.passwords.items()],
            'root_password': 'UNRELATED_PRIVATE_ROOT_PASSWORD'}))
        self.output = self.root / 'results'
        self.manager = SimpleNamespace(ROOT=self.source, load=Mock(return_value={'RIE_MODE': 'demo'}), guard=Mock(),
            tool=Mock(return_value=SimpleNamespace(stdout=json.dumps({'passed': True, 'checks': {'fixture': True}}))))

    def test_host_sends_selected_passwords_only_through_stdin_and_keeps_probe_out_of_image(self):
        with patch.object(recipe, 'load_manager', return_value=self.manager), redirect_stdout(io.StringIO()):
            self.assertEqual(recipe.host(self.instance, self.output, self.source), 0)
        arguments, options = self.manager.tool.call_args
        self.assertEqual(arguments[2:4], ('python', '-c'))
        source = arguments[4]
        for password in self.passwords.values():
            self.assertNotIn(password, source)
        self.assertNotIn('UNRELATED_PRIVATE_ROOT_PASSWORD', options['input_text'])
        self.assertEqual(json.loads(options['input_text']), {'passwords': self.passwords})
        report = json.loads((self.output / 'report.json').read_text())
        self.assertTrue(report['provenance']['injected_public_probe'])
        self.assertFalse(report['provenance']['business_image_changed'])
        self.assertEqual(stat.S_IMODE((self.output / 'report.json').stat().st_mode), 0o600)

    def test_external_load_and_existing_result_directory_fail_before_probe(self):
        for values in ({'RIE_MODE': 'external'}, {'RIE_MODE': 'demo', 'RIE_LOAD_QUALIFICATION': 'true'}):
            self.manager.load.return_value = values
            with patch.object(recipe, 'load_manager', return_value=self.manager), self.assertRaises(ValueError):
                recipe.host(self.instance, self.output, self.source)
        self.manager.tool.assert_not_called(); self.assertFalse(self.output.exists())
        self.manager.load.return_value = {'RIE_MODE': 'demo'}; self.output.mkdir()
        with patch.object(recipe, 'load_manager', return_value=self.manager), self.assertRaises(ValueError):
            recipe.host(self.instance, self.output, self.source)
        self.manager.tool.assert_not_called()


@unittest.skipUnless(sys.platform.startswith('linux'), 'Linux inotify is exercised natively in the Ubuntu guests')
class NativeFileWatcherTests(unittest.TestCase):
    def test_positive_actual_open_then_quiet_window(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'business.json'; path.write_text('{}')
            watcher = recipe.FileReads({'business': path})
            try:
                self.assertEqual(watcher.drain(), {'business': 0})
                self.assertEqual(path.read_text(), '{}')
                self.assertGreater(watcher.drain()['business'], 0)
                self.assertEqual(watcher.drain(), {'business': 0})
            finally:
                watcher.close()


if __name__ == '__main__':
    unittest.main()
