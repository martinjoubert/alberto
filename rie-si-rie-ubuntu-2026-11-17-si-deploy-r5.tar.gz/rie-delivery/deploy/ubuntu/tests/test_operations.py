"""Exercise resumable install, real readiness semantics and safe backup transport."""
from __future__ import annotations
from contextlib import contextmanager, redirect_stdout
import importlib.util
import io
import json
import os
import shlex
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import httpx

ROOT=Path(__file__).resolve().parents[3]
for relative in ('core/access-control/src','core/albert-client/src','use-cases/pdl/agentic-pdl','use-cases/incidents/observability-demo'):
    sys.path.insert(0,str(ROOT/relative))


def load(name):
    spec=importlib.util.spec_from_file_location('ubuntu_ops_'+name,ROOT/'deploy/ubuntu'/(name+'.py'))
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result


manage=load('manage')
recovery=load('backup_restore')
cli=load('runtime_cli')


class InstallTests(unittest.TestCase):
    def test_dry_run_never_creates_instance_or_contacts_docker(self):
        with tempfile.TemporaryDirectory() as directory:
            instance=Path(directory).resolve()/'new'
            env={**os.environ,'RIE_PYTHON':sys.executable,'RIE_DOCKER':'/must-not-be-executed'}
            result=subprocess.run(['bash',str(ROOT/'deploy/ubuntu/install.sh'),'--instance',str(instance),
                                   '--with-demo-ui','--install-prerequisites','--dry-run'],env=env,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertFalse(instance.exists())
            self.assertIn('prerequisites.py --install',result.stdout)
            self.assertIn('configure-ui',result.stdout)
            commands=[shlex.split(line) for line in result.stdout.splitlines() if line.startswith('  ')]
            phases=[command[index+1] for command in commands
                    for index,value in enumerate(command[:-1]) if Path(value).name=='manage.py']
            self.assertLess(phases.index('validate'),phases.index('build'))

    def test_external_resume_preserves_inputs_and_never_seeds(self):
        with tempfile.TemporaryDirectory() as directory:
            instance=Path(directory).resolve()/'existing'
            with redirect_stdout(io.StringIO()):manage.bootstrap(instance,'external')
            before={p.relative_to(instance):p.read_bytes() for p in instance.rglob('*') if p.is_file()}
            result=subprocess.run(['bash',str(ROOT/'deploy/ubuntu/install.sh'),'--instance',str(instance),'--dry-run'],
                                  env={**os.environ,'RIE_PYTHON':sys.executable},text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('mode=external',result.stdout)
            self.assertNotIn(' seed ',result.stdout)
            self.assertNotIn(' acceptance ',result.stdout)
            self.assertNotIn(' prepare ',result.stdout)
            self.assertEqual(before,{p.relative_to(instance):p.read_bytes() for p in instance.rglob('*') if p.is_file()})
            mismatch=subprocess.run(['bash',str(ROOT/'deploy/ubuntu/install.sh'),'--instance',str(instance),'--mode','demo','--dry-run'],
                                    env={**os.environ,'RIE_PYTHON':sys.executable},text=True,capture_output=True)
            self.assertEqual(mismatch.returncode,2)

    def test_unconfigured_external_sources_fail_before_startup(self):
        with tempfile.TemporaryDirectory() as directory:
            instance=Path(directory).resolve()/'external'
            with redirect_stdout(io.StringIO()):manage.bootstrap(instance,'external')
            with self.assertRaisesRegex(ValueError,'placeholders'):
                manage.validate_instance(instance,manage.load(instance))

    def test_dialogue_capacity_is_bounded_before_startup(self):
        with tempfile.TemporaryDirectory() as directory:
            instance=Path(directory).resolve()/'external'
            with redirect_stdout(io.StringIO()):manage.bootstrap(instance,'external')
            values=manage.load(instance)
            for capacity in ('','0','-1','32769','8192.0','true',' 8192','1e4',8192,True):
                with self.subTest(capacity=capacity),self.assertRaisesRegex(ValueError,'DINUM_DIALOGUE_MAX_STATES'):
                    manage.validate_instance(instance,{**values,'DINUM_DIALOGUE_MAX_STATES':capacity})
            for capacity in ('1','8192','32768'):
                with self.subTest(capacity=capacity),self.assertRaisesRegex(ValueError,'placeholders'):
                    manage.validate_instance(instance,{**values,'DINUM_DIALOGUE_MAX_STATES':capacity})

    def test_pdl_scale_configuration_is_rejected_before_any_docker_operation(self):
        with tempfile.TemporaryDirectory() as directory:
            instance=Path(directory).resolve()/'external'
            with redirect_stdout(io.StringIO()):manage.bootstrap(instance,'external')
            values=manage.load(instance)
            path=instance/'config/pdl.yaml'
            original=json.loads(path.read_text())
            cases=(('discovery','required_index_patterns','rie-pfs-*'),
                   ('discovery','allowed_index_patterns',['rie-*','../outside']),
                   ('discovery','max_indices',True),('discovery','max_fields_per_index',10001),
                   ('limits','max_identity_documents',10001),('limits','max_context_bytes','1048576'))
            for section,key,value in cases:
                with self.subTest(key=key):
                    document=json.loads(json.dumps(original));document[section][key]=value
                    path.write_text(json.dumps(document))
                    with patch.object(manage,'docker') as docker,self.assertRaisesRegex(ValueError,key):
                        manage.preflight_up(instance,values)
                    docker.assert_not_called()


class ReadinessTests(unittest.TestCase):
    def run_check(self, *, initialized=True, source_failure=False, incident_status='ok', missing_family=False, obsolete_family=False):
        from rie_agent.inventory import required_source_coverage
        with tempfile.TemporaryDirectory() as directory:
            manifest=Path(directory).resolve()/'manifest.json';manifest.write_text(json.dumps({'status':'ready' if initialized else 'not_ready'}))
            inventory={'indices':{'rie-pfs-fixture':{'schema_hash':'pfs-current'},
                                  'rie-tacacs-fixture':{'schema_hash':'tacacs-current'}}}
            class Store:
                def __init__(self,*args):pass
                def inventory(self):return inventory
                def catalog(self):
                    if not initialized:return []
                    result=[{'active':True,'index':'rie-pfs-fixture','schema_hash':'pfs-current'}]
                    if not missing_family:
                        result.append({'active':True,'index':'rie-tacacs-fixture',
                                       'schema_hash':'obsolete' if obsolete_family else 'tacacs-current'})
                    return result
            class Inventory:
                def __init__(self,*args):pass
                def refresh(self):
                    if source_failure:raise RuntimeError('PRIVATE_SOURCE_DETAILS')
                    return inventory
            @contextmanager
            def acting(username):yield SimpleNamespace(store=SimpleNamespace(read=lambda:{'revision':3})),None
            @contextmanager
            def token(username):yield 'private-token',None,None
            def respond(request):
                if request.url.path=='/healthz':return httpx.Response(200,json={'status':'ok'})
                self.assertEqual(request.headers['authorization'],'Bearer private-token')
                return httpx.Response(200 if incident_status=='ok' else 503,
                                      json={'services':[{'service':'opensearch','status':incident_status},
                                                        {'service':'albert','status':'not_probed'}]})
            real_client=httpx.Client
            modules={'rie_agent.config':SimpleNamespace(load_settings=lambda:SimpleNamespace(data_dir=Path(directory).resolve(),
                         allowed_index_patterns=('rie-*',),required_index_patterns=('rie-pfs-*','rie-tacacs-*'))),
                     'rie_agent.store':SimpleNamespace(Store=Store),
                     'rie_agent.inventory':SimpleNamespace(OpenSearchInventory=Inventory,required_source_coverage=required_source_coverage)}
            output=io.StringIO()
            with patch.dict(os.environ,{'OBS_MANIFEST':str(manifest)}),patch.dict(sys.modules,modules), \
                 patch.object(cli,'acting',acting),patch.object(cli,'individual_token',token), \
                 patch.object(cli.httpx,'Client',side_effect=lambda **kw:real_client(transport=httpx.MockTransport(respond),**kw)),redirect_stdout(output):
                code=cli.check('operator')
            return code,json.loads(output.getvalue())

    def test_healthy_processes_without_initialization_return_failure(self):
        code,result=self.run_check(initialized=False)
        self.assertEqual(code,2);self.assertEqual(result['status'],'healthy_not_initialized')

    def test_cached_catalogue_cannot_hide_a_source_outage(self):
        code,result=self.run_check(source_failure=True)
        self.assertEqual(code,2);self.assertEqual(result['status'],'sources_unavailable')
        self.assertNotIn('PRIVATE_SOURCE_DETAILS',json.dumps(result))

    def test_incident_unavailable_or_complete_sources_are_distinguished(self):
        code,result=self.run_check(incident_status='unavailable')
        self.assertEqual(code,2);self.assertEqual(result['dependencies']['incidents_opensearch'],'unavailable')
        code,result=self.run_check()
        self.assertEqual(code,0);self.assertEqual(result['status'],'ready')
        self.assertEqual(result['albert_generation'],'not_tested')

    def test_one_mapping_or_obsolete_family_cannot_validate_two_required_families(self):
        for options in ({'missing_family':True},{'obsolete_family':True}):
            with self.subTest(options=options):
                code,result=self.run_check(**options)
                self.assertEqual(code,2)
                self.assertEqual(result['status'],'healthy_not_initialized')
                self.assertEqual(result['pdl_required_sources'],[{'pattern':'rie-pfs-*','ready':True},
                                                               {'pattern':'rie-tacacs-*','ready':False}])


class BackupRestoreTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.base=Path(self.temporary.name).resolve();self.backup=self.base/'backup';self.backup.mkdir()
        private=self.backup/'instance';private.mkdir()
        self.values={'RIE_PROJECT':'rie-'+'a'*12,'RIE_INSTANCE_ID':'a'*32,'RIE_INSTANCE_DIR':'/old/private',
                     'RIE_MODE':'demo','RIE_IMAGE':'dinum/app:test','RIE_LDAP_IMAGE':'dinum/ldap:test'}
        (private/'.env').write_text(''.join(k+'='+v+'\n' for k,v in self.values.items()))
        (private/'docker-id').write_text('old-engine')
        (private/'config').mkdir();(private/'config/access.json').write_text('{"server_only":"key paths"}')
        self.volume_data={
            'runtime':{'access/policy.json':b'{"revision":9}', 'access/user-tokens/test.json':b'{"revoked":true}',
                       'secrets/session-signing.key':b'preserved-server-key', 'pdl/catalog.json':b'approved'},
            'opensearch':{'indices/data':b'fictional-index-bytes'},'metrics':{'samples/data':b'measured'},
            'ldap':{'data.mdb':b'entryUUID-preserved'}}
        for suffix,files in self.volume_data.items():self.write_tar(self.backup/(suffix+'.tar'),files)
        self.write_tar(self.backup/'images.tar',{'images.json':b'placeholder-for-mocked-Docker-load'})
        self.images=[{'reference':'dinum/app:test','id':'sha256:'+'1'*64,'os':'linux','architecture':'arm64'},
                     {'reference':'dinum/ldap:test','id':'sha256:'+'2'*64,'os':'linux','architecture':'arm64'}]
        self.refresh_manifest()

    def write_tar(self,path,files):
        with tarfile.open(path,'w') as archive:
            for name,data in files.items():
                row=tarfile.TarInfo(name);row.size=len(data);row.uid=row.gid=10001;row.mode=0o600
                archive.addfile(row,io.BytesIO(data))

    def refresh_manifest(self):
        value={'version':1,'source':{'mode':'demo','project':self.values['RIE_PROJECT'],'instance_id':self.values['RIE_INSTANCE_ID']},
               'platform':{'os':'linux','architecture':'arm64'},'images':self.images,
               'volumes':['runtime','opensearch','metrics','ldap'],'files':recovery.inventory_files(self.backup)}
        (self.backup/recovery.MANIFEST).write_text(json.dumps(value))

    def manager(self):
        created=[];extracted={};events=[]
        def docker(*args,**kwargs):
            events.append(args)
            if args[:1]==('info',):return SimpleNamespace(stdout='linux/aarch64\n')
            if args[:2]==('image','load'):return SimpleNamespace(stdout='')
            if args[:2]==('image','inspect'):
                by_ref={row['reference']:row for row in self.images}
                return SimpleNamespace(stdout=json.dumps([{'Id':by_ref[ref]['id'],'Os':'linux','Architecture':'arm64'} for ref in args[2:]]))
            if args[:2]==('volume','ls'):return SimpleNamespace(stdout='')
            if args[:2]==('volume','create'):created.append(args[-1]);return SimpleNamespace(stdout=args[-1])
            self.fail('Unexpected Docker command '+repr(args))
        def guard(instance,values):
            manage.write_new(instance/'docker-id','new-engine\n')
        manager=SimpleNamespace(ROOT=ROOT,VOLUMES=('runtime','opensearch','metrics','ldap'),docker=docker,
                                save_env=manage.save_env,write_new=manage.write_new,guard=guard)
        def process(argv,**kwargs):
            if argv[1:3]==['image','inspect']:return SimpleNamespace(returncode=1,stdout='')
            if argv[1]=='run':
                mount=argv[argv.index('--mount')+1];name=mount.split('src=',1)[1].split(',',1)[0]
                with tarfile.open(fileobj=kwargs['stdin'],mode='r:') as archive:
                    extracted[name]={row.name:archive.extractfile(row).read() for row in archive if row.isfile()}
                return SimpleNamespace(returncode=0)
            self.fail('Unexpected process command '+repr(argv))
        return manager,process,created,extracted,events

    def test_restore_changes_only_ownership_and_preserves_application_state(self):
        target=self.base/'new';manager,process,created,extracted,events=self.manager()
        with patch.object(recovery.subprocess,'run',side_effect=process):
            result=recovery.restore_backup(target,self.backup,manager)
        values=manage.load(target)
        self.assertNotEqual(values['RIE_INSTANCE_ID'],self.values['RIE_INSTANCE_ID'])
        self.assertNotEqual(values['RIE_PROJECT'],self.values['RIE_PROJECT'])
        self.assertEqual(values['RIE_INSTANCE_DIR'],str(target));self.assertEqual((target/'docker-id').read_text(),'new-engine\n')
        self.assertFalse(result['services_started']);self.assertEqual(len(created),4)
        for suffix,files in self.volume_data.items():self.assertEqual(extracted[values['RIE_PROJECT']+'-'+suffix],files)
        self.assertEqual(recovery.verify_backup(self.backup)['source']['instance_id'],self.values['RIE_INSTANCE_ID'])
        self.assertEqual((target/'.env').stat().st_mode&0o777,0o600)

    def test_corrupt_archive_is_refused_before_docker_or_target_mutation(self):
        with (self.backup/'runtime.tar').open('ab') as stream:stream.write(b'corrupt')
        target=self.base/'target';manager,_,_,_,_=self.manager()
        with patch.object(manager,'docker') as docker,self.assertRaisesRegex(ValueError,'integrity'):
            recovery.restore_backup(target,self.backup,manager)
        docker.assert_not_called();self.assertFalse(target.exists())

    def test_unsafe_tar_members_are_refused_even_if_the_manifest_hash_matches(self):
        for kind in ('traversal','symlink','hardlink','fifo'):
            with self.subTest(kind=kind):
                path=self.backup/'runtime.tar'
                with tarfile.open(path,'w') as archive:
                    row=tarfile.TarInfo('../outside' if kind=='traversal' else 'untrusted')
                    if kind=='symlink':row.type=tarfile.SYMTYPE;row.linkname='/etc/passwd'
                    elif kind=='hardlink':row.type=tarfile.LNKTYPE;row.linkname='../outside'
                    elif kind=='fifo':row.type=tarfile.FIFOTYPE
                    archive.addfile(row)
                self.refresh_manifest()
                manager,_,_,_,_=self.manager();target=self.base/('target-'+kind)
                with patch.object(manager,'docker') as docker,self.assertRaises(ValueError):
                    recovery.restore_backup(target,self.backup,manager)
                docker.assert_not_called();self.assertFalse(target.exists())

    def test_existing_destination_and_symlink_input_are_refused(self):
        manager,_,_,_,_=self.manager();target=self.base/'existing';target.mkdir();(target/'keep').write_text('keep')
        with patch.object(manager,'docker') as docker,self.assertRaises(ValueError):
            recovery.restore_backup(target,self.backup,manager)
        docker.assert_not_called();self.assertEqual((target/'keep').read_text(),'keep')
        (self.backup/'instance/config/link').symlink_to('/etc/passwd')
        with self.assertRaises(ValueError):recovery.verify_backup(self.backup)

    def test_image_conflict_is_refused_before_image_load_or_target_creation(self):
        manager,_,_,_,_=self.manager();target=self.base/'new'
        with patch.object(recovery.subprocess,'run',return_value=SimpleNamespace(returncode=0,stdout='sha256:'+'f'*64)),\
             self.assertRaisesRegex(ValueError,'conflicts'):
            recovery.restore_backup(target,self.backup,manager)
        self.assertFalse(target.exists())


class PortablePDLReadinessTests(unittest.TestCase):
    def service(self, *, active=True, failure=False):
        from rie_agent.service import RIEAgentService
        value=object.__new__(RIEAgentService)
        value.settings=SimpleNamespace(allowed_index_patterns=('rie-pfs-fixture',),required_index_patterns=())
        value.store=SimpleNamespace(inventory=lambda:{'indices':{'rie-pfs-fixture':{'schema_hash':'current'}},'created_at':'cached'},
                                    catalog=lambda:[{'active':active,'index':'rie-pfs-fixture','schema_hash':'current'}])
        def resolve():
            if failure:raise RuntimeError('PRIVATE_SOURCE_CREDENTIAL')
            return ['rie-pfs-fixture']
        value.inventory_service=SimpleNamespace(resolve_indices=resolve)
        return value

    def test_cached_inventory_does_not_hide_a_source_outage(self):
        result,code=self.service(failure=True).readiness()
        self.assertEqual(code,503);self.assertEqual(result['status'],'sources_unavailable')
        self.assertNotIn('PRIVATE_SOURCE_CREDENTIAL',json.dumps(result))

    def test_reviewed_mapping_and_fresh_source_are_required(self):
        self.assertEqual(self.service(active=False).readiness()[1],503)
        result,code=self.service().readiness()
        self.assertEqual(code,200);self.assertEqual(result['source'],'verified_read_only')


class ColdBackupTests(unittest.TestCase):
    setUp = BackupRestoreTests.setUp
    write_tar = BackupRestoreTests.write_tar
    refresh_manifest = BackupRestoreTests.refresh_manifest
    def test_cold_backup_captures_exact_images_volumes_and_private_manifest(self):
        instance=self.backup/'instance'
        values={**self.values,'RIE_INSTANCE_DIR':str(instance)}
        output=self.base/'cold-backup'
        records=[{'Config':{'Image':row['reference']},'Image':row['id']} for row in self.images]
        image_by_reference={row['reference']:row for row in self.images}
        calls=[]
        def docker(*args,**options):
            calls.append(args)
            if args[0]=='ps':return SimpleNamespace(stdout='one two')
            if args[0]=='inspect':return SimpleNamespace(stdout=json.dumps(records))
            if args[:2]==('image','inspect'):
                return SimpleNamespace(stdout=json.dumps([{'Id':image_by_reference[ref]['id'],'Os':'linux','Architecture':'arm64'} for ref in args[2:]]))
            if args[0]=='info':return SimpleNamespace(stdout='linux/aarch64')
            if args[:2]==('volume','inspect'):return SimpleNamespace(stdout='[]')
            if args[:2]==('image','save'):
                Path(args[3]).write_bytes((self.backup/'images.tar').read_bytes());return SimpleNamespace(stdout='')
            self.fail('Unexpected backup command '+repr(args))
        manager=SimpleNamespace(ROOT=ROOT,VOLUMES=('runtime','opensearch','metrics','ldap'),docker=docker,
                                compose=lambda *a,**k:SimpleNamespace(stdout=''),write_new=manage.write_new)
        def process(argv,**kwargs):
            source=argv[argv.index('--mount')+1].split('src=',1)[1].split(',',1)[0]
            suffix=next(name for name in self.volume_data if source==values['RIE_PROJECT']+'-'+name)
            kwargs['stdout'].write((self.backup/(suffix+'.tar')).read_bytes())
            return SimpleNamespace(returncode=0)
        with patch.object(recovery.subprocess,'run',side_effect=process):
            result=recovery.create_backup(instance,values,output,manager)
        self.assertEqual(result['images_included'],2);self.assertEqual(result['data_archives'],4)
        manifest=recovery.verify_backup(output)
        self.assertEqual(manifest['images'],self.images)
        for path in [output,*output.rglob('*')]:
            self.assertEqual(path.stat().st_mode&0o777,0o700 if path.is_dir() else 0o600)
        self.assertEqual((output/'instance/config/access.json').read_bytes(),(instance/'config/access.json').read_bytes())

    def test_running_source_is_refused_without_creating_partial_backup(self):
        target=self.base/'should-not-exist'
        manager=SimpleNamespace(ROOT=ROOT,compose=lambda *a,**k:SimpleNamespace(stdout='running-container'),docker=lambda *a:None)
        with self.assertRaisesRegex(ValueError,'Stop this instance'):
            recovery.create_backup(self.backup/'instance',self.values,target,manager)
        self.assertFalse(target.exists())
        self.assertFalse(list(self.base.glob('should-not-exist.partial-*')))


class LifecycleInputTests(unittest.TestCase):
    def test_lifecycle_subprocess_has_no_access_to_parent_script_stdin(self):
        with patch.object(manage.subprocess,'run',return_value=SimpleNamespace(returncode=0)) as process:
            manage.run(['docker','compose','ps'])
        self.assertIs(process.call_args.kwargs['stdin'],subprocess.DEVNULL)

    def test_only_mapping_uploads_explicitly_inherit_stdin(self):
        with patch.object(manage,'compose',return_value=None) as compose:
            manage.tool(Path('/private/instance'),{},'python','/delivery/runtime_cli.py','check')
            self.assertIn('--interactive=false',compose.call_args.args)
            self.assertIs(compose.call_args.kwargs['stdin'],subprocess.DEVNULL)
            manage.tool(Path('/private/instance'),{},'python','/delivery/runtime_cli.py','pdl','load-mappings',interactive_input=True)
            self.assertIn('--interactive=true',compose.call_args.args)
            self.assertIsNone(compose.call_args.kwargs['stdin'])

    def test_ssh_style_bash_script_reaches_following_steps_even_if_docker_reads_stdin(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve()
            fake=root/'fake-docker.py'
            fake.write_text('import sys\nprint(len(sys.stdin.read()))\n')
            launcher=root/'check.py'
            launcher.write_text('import importlib.util,sys\ns=importlib.util.spec_from_file_location("manager",'+repr(str(ROOT/'deploy/ubuntu/manage.py'))+')\nm=importlib.util.module_from_spec(s);s.loader.exec_module(m)\nm.run([sys.executable,'+repr(str(fake))+'])\n')
            import shlex
            script=shlex.quote(sys.executable)+' -B '+shlex.quote(str(launcher))+'\n'+('# filler line\n'*10000)+"printf 'FOLLOWING_COMMAND_REACHED\\n'\n"
            result=subprocess.run(['bash','-s'],input=script,text=True,capture_output=True,timeout=10)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertEqual(result.stdout.splitlines(),['0','FOLLOWING_COMMAND_REACHED'])


class SelectedImageTests(unittest.TestCase):
    def test_repeated_up_recreates_mutable_built_images_but_preserves_source_volumes(self):
        with tempfile.TemporaryDirectory() as directory:
            instance=Path(directory).resolve()/'private'
            instance.mkdir(mode=0o700)
            values={'RIE_MODE':'demo','RIE_ENABLE_DEMO_UI':'true'}
            with patch.object(manage,'load',return_value=values),patch.object(manage,'guard'), \
                 patch.object(manage,'preflight_up'),patch.object(manage,'compose') as compose, \
                 patch('sys.argv',['manage.py','up',str(instance)]):
                manage.main()
            calls=[row.args[2:] for row in compose.call_args_list]
            built=[row for row in calls if 'up' in row and any(name in row for name in ('ldap','pdl','incidents','portal'))]
            self.assertEqual(len(built),3)
            self.assertTrue(all('--force-recreate' in row for row in built))
            dependencies=next(row for row in calls if 'up' in row and 'opensearch' in row)
            self.assertNotIn('--force-recreate',dependencies)
            self.assertFalse(any('down' in row or 'rm' in row for row in calls))


if __name__=='__main__':unittest.main()
