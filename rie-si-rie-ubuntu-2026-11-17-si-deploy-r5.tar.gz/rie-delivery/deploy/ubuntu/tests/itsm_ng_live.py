"""Optional qualification against an explicitly seeded, loopback ITSM-NG 1.6.17.

Not a unit-test prerequisite and never a source writer. The separate fixture
setup owns its database. Tokens are read privately, never emitted in receipts.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/path) for path in ('core/access-control/src','core/albert-client/src','use-cases/incidents/observability-demo')]
from dinum_access import PolicyStore
from dinum_access.security import CURRENT, Principal
from obs_poc.clients import Sources, SourceError
from obs_poc.config import Settings
from obs_poc.itsm_history import read_history, private_json
from obs_poc.precedents import select, propose


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url',required=True)
    parser.add_argument('--credentials',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--expect-revoked',action='store_true',help='Expect the deliberately disabled synthetic user 2002 to be refused')
    args=parser.parse_args()
    parsed=urlsplit(args.url)
    if parsed.scheme!='http' or parsed.hostname not in {'127.0.0.1','localhost'} or parsed.path not in {'','/'}:
        parser.error('Only an explicitly local synthetic ITSM qualification is supported')
    os.umask(0o077)
    if args.output.exists():parser.error('Preserve prior evidence; choose a new output')
    secrets=private_json(args.credentials.resolve())
    if secrets.get('target_version')!='1.6.17':parser.error('Native fixture version must be 1.6.17')
    checks=[]
    def checked(name,passed,**detail):
        checks.append({'name':name,'passed':bool(passed),**detail})
        if not passed:raise ValueError(name)
    with tempfile.TemporaryDirectory(prefix='rie-itsm-native-') as directory:
        folder=Path(directory).resolve()
        def write(name,data):
            path=folder/name;path.write_text(json.dumps(data));path.chmod(0o600);return path
        credentials=write('credentials.json',{'app_token':secrets['app_token'],'users':{}})
        config=write('config.json',{'version':1,'target_version':'1.6.17','provider':'itsm-ng',
            'api_url':args.url.rstrip('/')+'/apirest.php','public_url':'https://itsm-qualification.invalid',
            'credentials_file':str(credentials),'timezone':'Europe/Paris'})
        policy={'version':1,'revision':1,'default':'blocked','indices':{},'resources':{'incidents.tickets':'internal'}}
        write('policy.json',policy)
        store=PolicyStore(folder)
        gate=type('Gate',(),{'store':store,'config':{}})()
        context={'start':'2026-09-28T10:00:00+02:00','end':'2026-09-28T12:00:00+02:00','equipment_ids':['OBS-RTR-01']}
        reports={}
        old_mode=os.environ.get('PDL_MODE');os.environ['PDL_MODE']='demo'
        try:
            for user in ('2001','2002'):
                principal=Principal('ldap:'+hashlib.sha256(('native-fixture-'+user).encode()).hexdigest(),user+'@fixture.invalid','internal',True)
                write('credentials.json',{'app_token':secrets['app_token'],'users':{principal.subject:secrets['users'][user]}})
                marker=CURRENT.set((gate,principal));sources=Sources(Settings(itsm_history_config=config,ca_file=''))
                try:
                    history=read_history(sources,context,['congestion','saturation','latence'])
                    if args.expect_revoked and user=='2002':
                        checked('native_revoked_user_refused',False)
                except SourceError as exc:
                    if args.expect_revoked and user=='2002':
                        checked('native_revoked_user_refused',exc.code=='native_access_denied')
                        continue
                    raise
                finally:sources.close();CURRENT.reset(marker)
                reports[user]=history
                checked('native_individual_'+user,history['provider']=='itsm-ng' and not history['synthetic'],tickets=len(history['tickets']))
            high=reports['2001']
            if not args.expect_revoked:
                low=reports['2002']
                checked('native_entity_restriction',101 in [t['id'] for t in high['tickets']] and 101 not in [t['id'] for t in low['tickets']])
                checked('native_private_followup', 'NATIVE_PRIVATE_CANARY' in json.dumps(high) and 'NATIVE_PRIVATE_CANARY' not in json.dumps(low))
            current={'context':context,'confidence':{'level':'élevée'},'errors':[]}
            precedents=select(high,current,['congestion','saturation','latence'])
            for index,row in enumerate(precedents):row['source_id']='S'+str(index)
            proposal=propose(precedents,current)
            checked('native_solutions_used',proposal['state']=='proposed' and proposal['confidence']=='élevée')
        except (SourceError,ValueError,KeyError,TypeError) as error:
            checks.append({'name':'native_execution','passed':False,'code':error.code if isinstance(error,SourceError) else type(error).__name__})
        finally:
            if old_mode is None:os.environ.pop('PDL_MODE',None)
            else:os.environ['PDL_MODE']=old_mode
    result={'at_utc':datetime.now(timezone.utc).isoformat(),'target_version':'1.6.17','native_server':True,
            'real_si_rie':False,'checks':checks,'passed':bool(checks) and all(row['passed'] for row in checks),
            'tokens_emitted':False,'writes_to_tickets':False}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
