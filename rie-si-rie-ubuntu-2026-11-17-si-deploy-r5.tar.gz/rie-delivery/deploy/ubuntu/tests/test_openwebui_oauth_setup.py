"""Client provisioning preserves other tools; refresh survives contention/outages."""
import asyncio
from contextlib import redirect_stdout
from copy import deepcopy
from datetime import datetime, timedelta
import importlib.util
import json
import io
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[3]


def load(name):
    spec=importlib.util.spec_from_file_location('client_'+name,ROOT/'deploy/openwebui'/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


class SetupTests(unittest.TestCase):
    def setUp(self):
        self.setup=load('configure')
        folder=tempfile.TemporaryDirectory();self.addCleanup(folder.cleanup)
        self.backup=Path(folder.name).resolve()/'before.json'
        self.calls=[]
        self.old=[{'info':{'id':'calendar'},'key':'unrelated-private-value'},
                  {'info':{'id':'dinum-pdl-agent'},'auth_type':'bearer','key':'old-personal-credential'}]
        owner=self
        class API:
            base='http://127.0.0.1:8080'
            def call(self,path,body=None):
                owner.calls.append((path,deepcopy(body)))
                if body is None:
                    if path.endswith('/tool_servers'):return {'TOOL_SERVER_CONNECTIONS':deepcopy(owner.old)}
                    if path.endswith('/namespace/webui'):return {'webui.url':'http://localhost:8080'}
                    if path=='/api/models':return {'data':[{'id':'gpt-oss-120b'}]}
                    if path.startswith('/api/v1/functions/id/'):return {'id':path.rsplit('/',1)[-1],'is_active':True,'content':'previous filter'}
                    if path.startswith('/api/v1/models/model?'):return {'id':'previous model','params':{'system':'previous system'}}
                if '/oauth/clients/register' in path:return {'oauth_client_info':'native-encrypted-client-metadata'}
                if '/functions/' in path:return {'is_active':True}
                return {}
        self.api=API();self.urls={'pdl':'https://pdl.example.org/mcp','incidents':'https://inc.example.org/gptoss/assistant/mcp'}

    def test_setup_requires_no_user_token_and_preserves_unrelated_integrations(self):
        result=self.setup.configure(self.api,self.urls,self.backup)
        saved=next(body for path,body in self.calls if path.endswith('/tool_servers') and body is not None)
        rows=saved['TOOL_SERVER_CONNECTIONS']
        self.assertEqual(rows[0],self.old[0])
        self.assertEqual(len(rows),3)
        self.assertTrue(all(r['auth_type']=='oauth_2.1' and r['key']=='' for r in rows[1:]))
        # [] makes both presets and tools private in native Open WebUI. A
        # regular signed-in user must discover them before authorizing LDAP.
        expected=[{'principal_type':'user','principal_id':'*','permission':'read'}]
        self.assertTrue(all(r['config']['access_grants']==expected for r in rows[1:]))
        profiles=[body for path,body in self.calls if path.startswith('/api/v1/models/') and body is not None]
        self.assertEqual(len(profiles),2)
        self.assertTrue(all(profile['access_grants']==expected for profile in profiles))
        self.assertTrue(all(not any(grant['permission']=='write' or grant['principal_type']!='user'
                          for grant in profile['access_grants']) for profile in profiles))
        self.assertNotIn('old-personal-credential',json.dumps(saved))
        self.assertTrue(result['user_authorization_pending'])
        self.assertFalse(result['personal_mcp_token_required'])
        self.assertEqual(self.backup.stat().st_mode & 0o777,0o600)
        before=json.loads(self.backup.read_text())
        self.assertEqual(before['TOOL_SERVER_CONNECTIONS'],self.old)
        self.assertEqual(len(before['functions']),2);self.assertEqual(len(before['models']),2)

    def test_an_unavailable_model_prevents_every_configuration_write(self):
        with self.assertRaises(ValueError):self.setup.configure(self.api,self.urls,self.backup,model='missing')
        self.assertFalse(any(body is not None for _,body in self.calls))

    def test_existing_rollback_file_is_not_overwritten(self):
        self.backup.write_text('preserve this receipt')
        with self.assertRaises(FileExistsError):self.setup.configure(self.api,self.urls,self.backup)
        self.assertEqual(self.backup.read_text(),'preserve this receipt')
        self.assertFalse(any(body is not None for _,body in self.calls))

    def test_client_urls_reject_credentials_and_unprotected_remote_http(self):
        for url in ('http://remote.example.org','https://user:pass@example.org','https://example.org/?token=x','https://replace.invalid'):
            with self.subTest(url=url),self.assertRaises(ValueError):self.setup.checked_url(url)

    def test_oauth_credentials_are_redacted_even_outside_structured_fields(self):
        sys.path.insert(0,str(ROOT/'deploy/ubuntu'))
        from test_reporting import sanitize_text
        for prefix in ('dinum_oa1_','dinum_or1_'):
            token=prefix+'x'*43
            self.assertNotIn(token,sanitize_text('diagnostic '+token))

    def test_native_401_for_absent_private_asset_requires_a_fresh_admin_check(self):
        original=self.api.call
        def call(path,body=None):
            if path=='/api/v1/auths/':return {'role':'admin'}
            if body is None and path.startswith(('/api/v1/functions/id/','/api/v1/models/model?')):
                raise self.setup.ClientError(401)
            return original(path,body)
        with patch.object(self.api,'call',side_effect=call):
            self.assertTrue(self.setup.configure(self.api,self.urls,self.backup)['configured'])

    def test_expired_admin_session_never_turns_into_asset_creation(self):
        original=self.api.call
        def call(path,body=None):
            if path=='/api/v1/auths/':raise self.setup.ClientError(401)
            if body is None and path.startswith('/api/v1/functions/id/'):
                raise self.setup.ClientError(401)
            return original(path,body)
        with patch.object(self.api,'call',side_effect=call),self.assertRaises(self.setup.ClientError):
            self.setup.configure(self.api,self.urls,self.backup)
        self.assertFalse(any(body is not None for _,body in self.calls))

    def test_repeated_setup_keeps_registrations_used_by_existing_user_sessions(self):
        self.old=[{'url':self.urls[kind],'auth_type':'oauth_2.1','info':{'id':identifier,'oauth_client_info':'existing-'+kind}}
                  for kind,identifier,*_ in self.setup.PROFILES]
        original=self.api.call
        def call(path,body=None):
            if path.endswith('/namespace/webui'):return {'webui.url':self.api.base}
            return original(path,body)
        with patch.object(self.api,'call',side_effect=call):self.setup.configure(self.api,self.urls,self.backup)
        self.assertFalse(any('/oauth/clients/register' in path for path,_ in self.calls))
        rows=next(body['TOOL_SERVER_CONNECTIONS'] for path,body in self.calls if path.endswith('/tool_servers') and body)
        self.assertEqual([row['info']['oauth_client_info'] for row in rows],['existing-pdl','existing-incidents'])


class OperatorSetupTests(unittest.TestCase):
    def setUp(self):
        spec=importlib.util.spec_from_file_location('oauth_host_manage',ROOT/'deploy/ubuntu/manage.py')
        self.manage=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.manage)
        folder=tempfile.TemporaryDirectory();self.addCleanup(folder.cleanup)
        self.root=Path(folder.name).resolve();self.instance=self.root/'instance'
        with redirect_stdout(io.StringIO()):self.manage.bootstrap(self.instance,'external')
        self.document={'version':1,'issuer':'https://pdl.example.org',
            'resources':{'pdl':'https://pdl.example.org/mcp','incidents':'https://inc.example.org/gptoss/assistant/mcp'},
            'redirect_uris':['http://127.0.0.1:8080/oauth/clients/mcp:dinum-pdl-agent/callback'],
            'access_seconds':600,'refresh_seconds':604800,'login_seconds':28800}

    def command(self,document):
        source=self.root/'oauth.json';source.write_text(json.dumps(document));source.chmod(0o600)
        with patch.object(sys,'argv',['manage.py','configure-client-auth',str(self.instance),'--input',str(source)]),redirect_stdout(io.StringIO()):
            self.manage.main()

    def test_reviewed_client_auth_file_import_requires_no_docker_and_preserves_policy(self):
        before=(self.instance/'access/policy.json').read_bytes()
        with patch.object(self.manage,'docker',side_effect=AssertionError('No service operation')):
            self.command(self.document)
        target=self.instance/'config/oauth.json'
        self.assertEqual(json.loads(target.read_text()),self.document)
        self.assertEqual(target.stat().st_mode & 0o777,0o600)
        self.assertEqual(self.manage.load(self.instance)['DINUM_OAUTH_CONFIG'],'/data/config/oauth.json')
        self.assertEqual((self.instance/'access/policy.json').read_bytes(),before)

    def test_invalid_import_preserves_configuration_and_does_not_enable_authentication(self):
        before=(self.instance/'.env').read_bytes()
        with self.assertRaises(ValueError):self.command({**self.document,'issuer':'http://unsafe.example.org'})
        self.assertEqual((self.instance/'.env').read_bytes(),before)
        self.assertFalse((self.instance/'config/oauth.json').exists())


class RefreshTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.adapter=load('oauth_refresh')
        self.row=SimpleNamespace(id='private-session',provider='mcp:dinum-pdl-agent',
                                 token={'access_token':'expired','refresh_token':'current'},expires_at=0)
        self.deleted=0;self.updates=0
        owner=self
        class Sessions:
            @staticmethod
            async def get_session_by_provider_and_user_id(provider,user):return owner.row
            @staticmethod
            async def update_session_by_id(identifier,token):
                owner.updates+=1;owner.row.token=token;owner.row.expires_at=int((datetime.now()+timedelta(hours=1)).timestamp());return owner.row
            @staticmethod
            async def delete_session_by_id(identifier):owner.deleted+=1;owner.row=None
        module=ModuleType('open_webui.models.oauth_sessions');module.OAuthSessions=Sessions
        self.modules=patch.dict(sys.modules,{'open_webui.models.oauth_sessions':module});self.modules.start();self.addCleanup(self.modules.stop)
        class Manager:
            async def get_oauth_token(self,user_id,client_id,force_refresh=False):
                return {'original':True,'user_id':user_id,'client_id':client_id}
        self.adapter.install(Manager);self.manager=Manager()

    async def test_parallel_reads_refresh_once_and_reload_the_new_session(self):
        calls=[]
        async def refresh(*args):
            calls.append('refresh');await asyncio.sleep(.01)
            return {'access_token':'fresh','refresh_token':'rotated'},False
        with patch.object(self.adapter,'refreshed',side_effect=refresh):
            results=await asyncio.gather(*(self.manager.get_oauth_token('alice','mcp:dinum-pdl-agent') for _ in range(5)))
        self.assertEqual(len(calls),1)
        self.assertTrue(all(row['access_token']=='fresh' for row in results))
        self.assertEqual(self.deleted,0)

    async def test_provider_outage_preserves_signin_and_never_returns_expired_access(self):
        with patch.object(self.adapter,'refreshed',return_value=(None,False)):
            self.assertIsNone(await self.manager.get_oauth_token('alice','mcp:dinum-pdl-agent'))
        self.assertEqual(self.deleted,0);self.assertIsNotNone(self.row)
        with patch.object(self.adapter,'refreshed',return_value=({'access_token':'fresh','refresh_token':'next'},False)):
            result=await self.manager.get_oauth_token('alice','mcp:dinum-pdl-agent')
        self.assertEqual(result['access_token'],'fresh')

    async def test_permanent_rejection_removes_only_the_current_session(self):
        with patch.object(self.adapter,'refreshed',return_value=(None,True)):
            self.assertIsNone(await self.manager.get_oauth_token('alice','mcp:dinum-pdl-agent'))
        self.assertEqual(self.deleted,1)

    async def test_other_providers_use_the_unmodified_openwebui_method(self):
        with patch.object(self.adapter,'refreshed',side_effect=AssertionError('Unrelated provider')):
            self.assertEqual(await self.manager.get_oauth_token('alice','mcp:calendar'),
                             {'original':True,'user_id':'alice','client_id':'mcp:calendar'})
            self.assertEqual(await self.manager.get_oauth_token(client_id='mcp:calendar',user_id='eric'),
                             {'original':True,'user_id':'eric','client_id':'mcp:calendar'})

    async def test_different_users_never_receive_the_other_users_cached_token(self):
        async def lookup(provider,user):
            return SimpleNamespace(token={'access_token':user},expires_at=int((datetime.now()+timedelta(hours=1)).timestamp()))
        module=sys.modules['open_webui.models.oauth_sessions']
        with patch.object(module.OAuthSessions,'get_session_by_provider_and_user_id',side_effect=lookup):
            values=await asyncio.gather(*(self.manager.get_oauth_token(user,'mcp:dinum-pdl-agent') for user in ('alice','eric')))
        self.assertEqual([row['access_token'] for row in values],['alice','eric'])


if __name__=='__main__':unittest.main()
