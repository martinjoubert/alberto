"""Real-provider Open WebUI campaign; host qualification only, never runtime.

Every question is submitted through the browser. API reads collect only the
newly owned chat. No model, prompt, source, policy or token is changed. The fixed
matrix is repeated three times; failed questions are never silently retried.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[3]
MODELS={'pdl':'recette-20261109-pdl','incidents':'recette-20261109-incidents'}
LABELS={'pdl':'Recette Ubuntu — PDL','incidents':'Recette Ubuntu — Incidents'}
PDL_START='2026-10-12T08:00:00Z';PDL_END='2026-10-12T09:00:00Z'
INC_START='2026-09-28T08:00:00Z';INC_END='2026-09-28T10:00:00Z'
EXPECTED_IDS={'pfs-a-1','pfs-a-2','bb-a-1','pfaing-reference-only','tacacs-ipv4-only','tacacs-ipv6-only'}


def now():return datetime.now(timezone.utc).isoformat()


def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def clean(value):
    """Keep source facts and usage counts; remove all authentication/continuation strings."""
    if isinstance(value,dict):
        return {k:('[MASQUÉ]' if isinstance(v,str) and (k.lower() in
            {'token','continuation_token','authorization','api_key','cookie','key'} or k.lower().endswith('_token'))
            else clean(v)) for k,v in value.items()}
    if isinstance(value,list):return [clean(v) for v in value]
    if isinstance(value,str):
        value=re.sub(r'\b(?:[0-9a-f]{16}|[0-9a-f]{32})\.[0-9a-f]{32}\b','[CONTINUATION MASQUÉE]',value)
        value=re.sub(r'\bdinum_ut\d+_[A-Za-z0-9_-]+','[JETON MASQUÉ]',value)
        value=re.sub(r'\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+','[SESSION MASQUÉE]',value)
        return value
    return value


def write(path,value):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(clean(value),ensure_ascii=False,indent=2)+'\n')
    temporary.chmod(0o600);temporary.replace(path)


def same_time(a,b):
    try:return datetime.fromisoformat(a.replace('Z','+00:00'))==datetime.fromisoformat(b.replace('Z','+00:00'))
    except (ValueError,TypeError,AttributeError):return False


def checks_for(spec,result,saved,request):
    """Compare native facts to declared fixture oracles, not to another model answer."""
    result=result or {};expected=spec['expect'];kind=expected['kind'];checks=[]
    def check(name,condition,actual=None,wanted=None):
        checks.append({'name':name,'passed':bool(condition),'actual':actual,'expected':wanted})
    check('client_finished',saved.get('done') and not saved.get('error'))
    check('selected_model_sent',request.get('model')==MODELS[spec['uc']],request.get('model'),MODELS[spec['uc']])
    calls=[r for r in saved.get('output',[]) if r.get('type')=='function_call']
    refusal=bool(result) and result.get('assistant_contract') in ('server-dialogue-v1','incident-dialogue-v1') and result.get('status') in ('denied','error','clarification','needs_clarification','cancelled','rate_limited') and not any(result.get(k) for k in ('evidence','sources','metrics','events','logs','documents','results','indices','dsl'))
    check('one_verified_native_tool_result',len(calls)==1 and (calls[0].get('status')=='completed' or calls[0].get('status')=='failed' and refusal))
    check('native_result_present',bool(result))
    if not result:return checks
    status=result.get('status');evidence=result.get('evidence') or {}
    answer=result.get('answer') or result.get('clarification') or saved.get('content','')
    if spec['uc']=='incidents':
        check('authoritative_server_report_displayed',bool(result.get('answer')) and saved.get('content','').strip()==result['answer'].strip())
    if kind=='clarification':
        clarification_status='clarification' if spec['uc']=='incidents' else 'needs_clarification'
        check('period_clarification_without_evidence',status==clarification_status and not any(result.get(k) for k in ('evidence','metrics','events','sources')),status,clarification_status)
    elif kind=='rights':
        access=result.get('access_control',{});indices=set(access.get('allowed_indices',[]))
        pdl_indices={'rie-pfs-fixture','rie-bb-fixture','rie-pfaing-fixture','rie-tacacs-fixture'}
        check('four_pdl_fixture_indices_with_current_shared_policy',pdl_indices<=indices and indices<=pdl_indices|{'obs-network-docs','pdl-zabbix-observability-demo'},sorted(indices),'four PDL fixtures; the two declared Incidents indices may also be listed')
    elif kind.startswith('pdl_'):
        check('business_success',status=='success',status,'success')
        period=evidence.get('time_range') or (result.get('plan') or {}).get('time_range') or {}
        check('correct_pdl_period',same_time(period.get('gte'),expected.get('start',PDL_START)) and same_time(period.get('lt',period.get('lte')),expected.get('end',PDL_END)),period,{'gte':expected.get('start',PDL_START),'lt':expected.get('end',PDL_END)})
        if kind=='pdl_equipment':
            ids=set(EXPECTED_IDS)
            if expected['families']=='tacacs':ids={'tacacs-ipv4-only','tacacs-ipv6-only'}
            if expected['families']=='without_tacacs':ids-={'tacacs-ipv4-only','tacacs-ipv6-only'}
            actual={r.get('document_id') for r in evidence.get('rows',[])}
            check('exact_expected_documents',actual==ids,sorted(actual),sorted(ids))
            check('exact_total',evidence.get('total')==len(ids),evidence.get('total'),len(ids))
            check('equipment_context_preserved',evidence.get('equipment')=='edge-a',evidence.get('equipment'),'edge-a')
            scopes=[(r.get('source',{}).get('network') or {}).get('scope') for r in evidence.get('rows',[])]
            check('no_scope_contamination',bool(scopes) and set(scopes)=={'demo-alpha'},scopes,'demo-alpha')
        else:
            check('exact_total',evidence.get('total')==expected['total'],evidence.get('total'),expected['total'])
            if kind=='pdl_pfaing':
                rows=evidence.get('rows',[])
                ids={r.get('id',r.get('document_id',r.get('_id'))) for r in rows}
                check('two_client_ip_documents_not_limited_to_equipment',ids=={'pfaing-reference-only','pfaing-unrelated'},sorted(str(x) for x in ids),['pfaing-reference-only','pfaing-unrelated'])
            scope=expected.get('scope','demo-alpha')
            check('requested_scope_retained',scope in json.dumps(result.get('plan',{}),ensure_ascii=False),scope,scope)
        planner=result.get('planner') or {}
        check('real_planner_model_returned',planner.get('kind')=='AlbertPlanner' and bool(planner.get('returned_model')),planner.get('returned_model'),'nonempty actual Albert model')
    elif kind.startswith('incident_'):
        ctx=result.get('context') or {};wanted=set(expected['equipment'])
        check('correct_incident_equipment',set(ctx.get('equipment_ids',[]))==wanted,ctx.get('equipment_ids'),sorted(wanted))
        check('correct_incident_period',same_time(ctx.get('start'),INC_START) and same_time(ctx.get('end'),INC_END),{'start':ctx.get('start'),'end':ctx.get('end')},{'start':INC_START,'end':INC_END})
        metrics=result.get('metrics') or []
        if kind=='incident_missing':
            rows=[m for m in metrics if m.get('metric')==expected['metric'] and m.get('equipment') in wanted]
            check('missing_points_explicit',len(rows)==1 and rows[0].get('count')==0 and rows[0].get('expected')==120,rows,'0/120')
            check('missing_mean_is_unknown_not_zero',len(rows)==1 and rows[0].get('mean') is None,[m.get('mean') for m in rows],None)
            check('missing_data_not_a_complete_success',status in ('partial','ok'),status,'partial or explicitly limited ok')
        else:
            check('successful_incident_result',status=='ok',status,'ok')
            check('five_metrics_per_equipment',len(metrics)==5*len(wanted),len(metrics),5*len(wanted))
            logs=result.get('logs') or {}
            check('exact_log_count',isinstance(logs,dict) and logs.get('total')==120*len(wanted),logs.get('total') if isinstance(logs,dict) else None,120*len(wanted))
        if kind=='incident_resolution':
            events=[e for e in result.get('events',[]) if e.get('equipment') in wanted]
            equipment=expected['equipment'][0]
            finish='2026-09-28T11:30:00+02:00' if equipment=='OBS-RTR-01' else '2026-09-28T11:00:00+02:00'
            closed='2026-09-28T12:15:00+02:00' if equipment=='OBS-RTR-01' else '2026-09-28T11:20:00+02:00'
            check('technical_resolution_and_ticket_close_remain_distinct',len(events)==1 and same_time(events[0].get('end'),finish) and same_time((events[0].get('ticket') or {}).get('closed_at'),closed),[{k:e.get(k) for k in ('equipment','end','ticket')} for e in events],{'resolution':finish,'closed_at':closed})
            check('noon_answer_explicit',bool(re.search(r'(?:Oui|Non)\s*\*?\*?\s*:',answer)) and ('12h' in answer or 'midi' in answer or '12:00' in answer))
        if expected.get('generation'):
            usage=result.get('usage') or []
            check('real_generated_and_reviewed_diagnostic',result.get('synthesis_mode')=='generated' and bool(result.get('analysis')) and (result.get('review') or {}).get('valid') is True)
            check('actual_draft_and_review_models_with_tokens',{'draft','review'}<={r.get('stage') for r in usage} and all(r.get('actual_model') and r.get('total_tokens',0)>0 for r in usage),[{k:r.get(k) for k in ('stage','actual_model','total_tokens')} for r in usage],'draft+review with actual models and usage')
        if expected.get('precedents'):
            check('native_itsm_historical_precedents',result.get('ticket_history',{}).get('provider')=='itsm-ng' and bool(result.get('precedents')))
            check('conditional_solution_and_separate_confidence',result.get('proposed_solution',{}).get('state')=='proposed' and bool(result.get('proposed_solution',{}).get('confidence')))
        known={s.get('source_id') for s in result.get('sources',[])}
        citations=set(re.findall(r'\[(S\d+)\]',answer))
        check('displayed_citations_known',bool(known) and citations<=known,sorted(citations-known),[])
    elif kind=='blocked_equipment':
        check('excluded_equipment_has_no_published_evidence',status not in ('ok','success') and not any(result.get(k) for k in ('evidence','metrics','events','logs','documents','sources')),status,'explicit refusal/clarification without data')
    elif kind=='wrong_uc':
        check('wrong_domain_request_has_no_business_evidence',not any(result.get(k) for k in ('evidence','metrics','events','logs','documents','sources')))
        check('wrong_domain_explicitly_explained',bool(re.search(r'(?:hors|autre (?:modèle|outil)|ne (?:peux|peut)|ne permet(?:tent)? pas|uniquement|non (?:pris|prise) en charge)',answer,re.I)),answer[:600],'explicit scope limitation')
    return checks


def run(args):
    from playwright.sync_api import sync_playwright,expect
    sys.path.insert(0,str(ROOT/'use-cases/incidents/observability-demo'))
    from browser_ui import enter_question
    qa=load_module(ROOT/'deploy/ubuntu/qualification_openwebui.py','stability_client')
    reporting=load_module(ROOT/'deploy/ubuntu/test_reporting.py','stability_reporting')
    matrix=json.loads(args.matrix.read_text())
    assert matrix['repetitions']==3 and len(matrix['suites'])==3 and all(len(s['turns'])==10 for s in matrix['suites'])
    if args.output.exists():raise ValueError('Use a new campaign output directory')
    args.output.mkdir(parents=True,mode=0o700);os.chmod(args.output,0o700)
    session=json.loads(args.session.read_text());api=qa.API(args.url);api.token=session['token']
    report={'started_at_utc':now(),'matrix_sha256':hashlib.sha256(args.matrix.read_bytes()).hexdigest(),
            'provider':'real Albert API','synthetic_data':True,'repetitions':3,'planned_browser_posts':96,
            'completed_browser_posts':0,'cases':[],'status':'running','business_code_changed':False,
            'automatic_business_retries':0,'mixed_mode':'explicit preset switch in the same Open WebUI chat'}
    write(args.output/'matrix.json',matrix)
    campaign=reporting.Campaign(args.output/'allure-results','Open WebUI — stabilité réelle',
                                '96 messages navigateur planifiés ; données fictives, fournisseur réel.')
    last_incident=None
    def save():write(args.output/'progress.json',report)
    save()
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path=str(args.browser),
            args=['--disable-background-networking','--disable-sync','--no-first-run'])
        for repetition in range(1,4):
            suites=[*matrix['suites'],*[{'id':'wrong_'+row['id'],'title':'Mauvais preset — '+row['id'],'turns':[row]}
                                      for row in matrix['wrong_preset_probes']]]
            for suite in suites:
                case={'repetition':repetition,'suite':suite['id'],'started_at_utc':now(),'turns':[],'passed':False,'chat_id':None}
                report['cases'].append(case);save()
                context=browser.new_context(viewport={'width':1440,'height':1100},locale='fr-FR')
                context.add_init_script('localStorage.setItem("token",'+json.dumps(api.token)+');')
                page=context.new_page();page.goto(args.url+'/?models='+MODELS[suite['turns'][0]['uc']],wait_until='networkidle',timeout=60000)
                for number,spec in enumerate(suite['turns'],1):
                    if spec['uc']=='incidents' and last_incident is not None:
                        while time.monotonic()-last_incident<61:
                            save();time.sleep(max(0,min(5,61-(time.monotonic()-last_incident))))
                    entry={'id':spec['id'],'number':number,'uc':spec['uc'],'question':spec['question'],
                           'expected':spec['expect'],'started_at_utc':now(),'state':'preparing','checks':[],'passed':False}
                    case['turns'].append(entry);save()
                    began=time.monotonic();saved={};result=None;request={}
                    try:
                        wanted=LABELS[spec['uc']]
                        if page.locator('#model-selector-model-button').inner_text().strip()!=wanted:
                            page.locator('#model-selector-model-button').click()
                            search=page.get_by_placeholder('Rechercher un modèle')
                            expect(search).to_be_visible(timeout=10000);search.fill(wanted)
                            page.get_by_text(wanted,exact=True).last.click()
                            expect(page.locator('#model-selector-model-button')).to_have_text(wanted,timeout=15000)
                        send=enter_question(page,spec['question'],expected_model_label=wanted)
                        entry['state']='sending';save()
                        with page.expect_request(lambda r:r.method=='POST' and urlsplit(r.url).path=='/api/chat/completions',timeout=20000) as sent:
                            send.click()
                        request=sent.value.post_data_json
                        entry.update(state='submitted',request_id=request['id']);save()
                        page.wait_for_url('**/c/*',timeout=30000)
                        cid=urlsplit(page.url).path.split('/c/',1)[1]
                        if case['chat_id'] is not None and cid!=case['chat_id']:raise ValueError('Conversation changed unexpectedly')
                        case['chat_id']=cid;save()
                        stable_since=None
                        while time.monotonic()-began<420:
                            saved=api.call('/api/v1/chats/'+cid)['chat']['history']['messages'].get(request['id'],{})
                            result=qa.native_result(saved.get('output',[]))
                            if saved.get('error'):break
                            done=saved.get('done')
                            consistent=(spec['uc']!='incidents' or not result or saved.get('content','').strip()==str(result.get('answer','')).strip())
                            if done and consistent:
                                if stable_since is None:stable_since=time.monotonic()
                                if time.monotonic()-stable_since>=1:break
                            else:stable_since=None
                            time.sleep(1)
                        entry['checks']=checks_for(spec,result,saved,request)
                        entry.update(state='finished',business_status=(result or {}).get('status'),
                                     passed=bool(entry['checks']) and all(r['passed'] for r in entry['checks']),
                                     client_error=saved.get('error'),native_result=result,
                                     rendered_answer=saved.get('content',''),
                                     model_sent=request.get('model'),
                                     tool_calls=[{k:r.get(k) for k in ('name','status')} for r in saved.get('output',[]) if r.get('type')=='function_call'])
                        # Capture only our owned synthetic answer, never the human chat sidebar.
                        page.add_style_tag(content='#sidebar {visibility:hidden !important;}')
                        page.screenshot(path=str(args.output/f'r{repetition}-{suite["id"]}-{number:02d}.png'),full_page=False)
                    except Exception as exc:
                        entry.update(state='error',error_type=type(exc).__name__,error_detail=str(exc)[:2500])
                        entry['checks'].append({'name':'browser_turn_completed','passed':False})
                    finally:
                        if spec['uc']=='incidents':last_incident=time.monotonic()
                        entry.update(finished_at_utc=now(),seconds=round(time.monotonic()-began,3))
                        report['completed_browser_posts']+=int(entry.get('request_id') is not None)
                        save()
                        details='\n'.join(json.dumps(row,ensure_ascii=False) for row in entry['checks'] if not row['passed'])
                        reporting.write_result(args.output/'allure-results',f'Répétition {repetition} — {suite["title"]}',
                            f'{number:02d} — {spec["id"]}', 'passed' if entry['passed'] else 'failed',
                            message=(result or {}).get('clarification') or details[:3000],
                            diagnostics={'attendu-obtenu':details,'réponse visible':entry.get('rendered_answer','')},
                            description='Question envoyée par navigateur dans un fil conservé. '+spec['question'])
                        campaign.checkpoint(f'Répétition {repetition}, {suite["id"]}, tour {number} terminé')
                        print(json.dumps({'repetition':repetition,'suite':suite['id'],'turn':number,
                            'status':entry.get('business_status'),'passed':entry['passed'],'seconds':entry['seconds'],
                            'completed':report['completed_browser_posts'],'failed_checks':[r['name'] for r in entry['checks'] if not r['passed']]}),flush=True)
                case.update(finished_at_utc=now(),passed=all(t['passed'] for t in case['turns']));save();context.close()
        browser.close()
    report.update(status='completed',finished_at_utc=now(),passed=all(c['passed'] for c in report['cases']))
    save();campaign.finish();api.http.close()
    print(json.dumps({'completed':True,'messages':report['completed_browser_posts'],'passed':report['passed']}),flush=True)
    return 0


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url',default='http://127.0.0.1:8080')
    parser.add_argument('--session',type=Path,required=True)
    parser.add_argument('--matrix',type=Path,default=ROOT/'deploy/ubuntu/examples/openwebui-stability.json')
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--browser',type=Path,default=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'))
    args=parser.parse_args();os.umask(0o077)
    return run(args)


if __name__=='__main__':raise SystemExit(main())
