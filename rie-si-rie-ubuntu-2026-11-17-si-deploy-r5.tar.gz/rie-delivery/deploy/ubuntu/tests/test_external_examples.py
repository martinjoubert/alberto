"""Public external templates stay closed and can be adapted to runtime contracts."""
from contextlib import ExitStack
import importlib.util
import json
import os
from pathlib import Path
import shutil
import socket
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / part) for part in
               ('core/access-control/src', 'core/albert-client/src', 'use-cases/pdl/agentic-pdl')]
spec = importlib.util.spec_from_file_location('external_example_manage', ROOT / 'deploy/ubuntu/manage.py')
manage = importlib.util.module_from_spec(spec)
spec.loader.exec_module(manage)

from rie_agent.config import load_settings
from rie_agent.operator_mappings import load_bytes, validate_document

EXAMPLES = ROOT / 'deploy/ubuntu/examples'
TARGETS = {'pdl.json': 'config/pdl.yaml', 'access.json': 'config/access.json',
           'policy.json': 'access/policy.json', 'incidents-corpus.json': 'config/incidents-corpus.json',
           'metric-mapping.json': 'config/metric-mapping.json', 'itsm-tickets.json': 'config/itsm-tickets.json'}


def no_network(*_args, **_kwargs):
    raise AssertionError('External example checks must not contact a source')


class ExternalExampleTests(unittest.TestCase):
    def setUp(self):
        self.context = ExitStack()
        self.addCleanup(self.context.close)
        for owner, name in ((socket.socket, 'connect'), (socket.socket, 'connect_ex'),
                            (socket, 'create_connection'), (socket, 'getaddrinfo')):
            self.context.enter_context(patch.object(owner, name, no_network))
        self.folder = Path(self.context.enter_context(tempfile.TemporaryDirectory())).resolve()
        self.instance = self.folder / 'instance'
        manage.bootstrap(self.instance, 'external')
        self.values = manage.load(self.instance)
        self.values.update(OPENSEARCH_URL='https://search.site.test',
                           VICTORIAMETRICS_URL='https://metrics.site.test',
                           INCIDENTS_LOGS_INDEX='site-incidents-logs', INCIDENTS_DOCS_INDEX='site-incidents-docs')
        for source, target in TARGETS.items():
            value = json.loads((EXAMPLES / source).read_text())
            value.pop('requires_operator_configuration')
            if source == 'pdl.json':
                value['discovery']['allowed_index_patterns'] = ['site-pdl-logs']
            elif source == 'access.json':
                value['ldap'].update(host='ldap.site.test', app_dn='cn=reader,dc=site,dc=test',
                                     search_base='ou=people,dc=site,dc=test',
                                     group_dns={'internal': 'cn=internal,dc=site,dc=test',
                                                'external': 'cn=external,dc=site,dc=test'})
            elif source == 'policy.json':
                value['indices'] = {name: 'internal' for name in
                                    ('site-pdl-logs', 'site-incidents-logs', 'site-incidents-docs')}
                value['resources'] = {'incidents.metrics': 'internal', 'incidents.tickets': 'internal'}
            elif source == 'incidents-corpus.json':
                value.update(status='ready',anchor_date='2026-09-28',
                             start='2026-09-28T10:00:00+02:00',end='2026-09-28T12:00:00+02:00')
                value['hosts'] = [{'equipment': 'SITE-R1', 'aliases': [], 'scope': 'SITE',
                                   'allowed': True, 'hostid': 'r1', 'interface': 'uplink'}]
                value['data_flow']['ingestion'] = 'Fictitious configuration-only test'
            elif source == 'metric-mapping.json':
                value['provenance'] = 'Fictitious configuration-only test'
                value['metrics'] = {key: {'name': 'site_' + key, 'scale': 1}
                                    for key in ('cpu', 'latency', 'loss', 'in', 'out')}
            elif source == 'itsm-tickets.json':
                value.update(complete=True, provenance='Fictitious configuration-only test')
            (self.instance / target).write_text(json.dumps(value))
        (self.instance / 'config/ldap-ca.crt').write_text('Fixture CA path; no TLS connection is attempted')
        (self.instance / 'secrets/reader.password').write_text('non-secret-fixture-credential')

    def test_administrator_groups_require_distinct_bounded_list(self):
        path = self.instance / 'config/access.json'
        value = json.loads(path.read_text())
        for groups in ('cn=admins', None, [''], ['x']*33, [value['ldap']['group_dns']['internal']]):
            value['ldap']['administrator_group_dns'] = groups
            path.write_text(json.dumps(value))
            with self.subTest(groups=groups), self.assertRaisesRegex(ValueError, 'Administrator LDAP groups'):
                manage.validate_instance(self.instance, self.values)
        value['ldap']['administrator_group_dns'] = ['cn=access-admins,dc=site,dc=test']
        path.write_text(json.dumps(value))
        manage.validate_instance(self.instance, self.values)

    def test_optional_object_rules_are_exact_and_fail_closed(self):
        path = self.instance / 'access/policy.json'
        value = json.loads(path.read_text())
        value['resources'].update({'pdl.zabbix.host.10001': 'internal',
                                   'pdl.grafana.dashboard.site-network': 'internal'})
        path.write_text(json.dumps(value))
        manage.validate_instance(self.instance, self.values)
        for resource in ('pdl.zabbix.host.*', 'pdl.grafana.dashboard.*', 'pdl.zabbix.item.1'):
            path.write_text(json.dumps({**value, 'resources': {resource: 'internal'}}))
            with self.subTest(resource=resource), self.assertRaisesRegex(ValueError, 'Access policy'):
                manage.validate_instance(self.instance, self.values)

    def test_every_unedited_public_template_is_refused_before_startup(self):
        manage.validate_instance(self.instance, self.values)
        for source, target in TARGETS.items():
            with self.subTest(template=source):
                path = self.instance / target
                accepted = path.read_bytes()
                shutil.copyfile(EXAMPLES / source, path)
                try:
                    with self.assertRaises(ValueError):
                        manage.validate_instance(self.instance, self.values)
                finally:
                    path.write_bytes(accepted)

    def test_adapted_template_parses_runtime_settings_and_mapping_inventory_contract(self):
        manage.validate_instance(self.instance, self.values)
        environment = {'OPENSEARCH_URL': self.values['OPENSEARCH_URL'], 'OPENSEARCH_USER': 'reader',
                       'ALBERT_API_BASE_URL': 'https://ai.site.test/v1', 'ALBERT_MODEL': 'fixture', 'CA_BUNDLE': ''}
        with patch.dict(os.environ, environment):
            settings = load_settings(self.instance / 'config/pdl.yaml')
        self.assertEqual(settings.allowed_index_patterns, ('site-pdl-logs',))
        self.assertTrue(settings.opensearch.tls.verify)
        raw = (EXAMPLES / 'mappings.yaml').read_bytes().replace(b'replace-pdl-index', b'site-pdl-logs')
        document, _digest = load_bytes(raw)
        fields = {name: {'type': kind, 'types': [kind], 'searchable': True}
                  for name, kind in (('@timestamp', 'date'), ('network.scope', 'keyword'), ('event.action', 'keyword'))}
        inventory = {'allowed_patterns': ['site-pdl-logs'],
                     'indices': {'site-pdl-logs': {'schema_hash': 'a' * 64, 'fields': fields}}}
        proposals = validate_document(document, inventory)
        self.assertEqual([row['index'] for row in proposals], ['site-pdl-logs'])
        self.assertNotIn('active', proposals[0])
        inventory['indices']['site-pdl-logs']['fields']['@timestamp']['type'] = 'keyword'
        with self.assertRaises(ValueError):
            validate_document(document, inventory)

    def test_incidents_requires_its_complete_control_window_before_startup(self):
        path=self.instance/'config/incidents-corpus.json'
        corpus=json.loads(path.read_text())
        for field in ('anchor_date','start','end','timezone','interval_seconds'):
            with self.subTest(field=field):
                incomplete=dict(corpus);incomplete.pop(field)
                path.write_text(json.dumps(incomplete))
                with self.assertRaises(ValueError):manage.validate_instance(self.instance,self.values)
        path.write_text(json.dumps(corpus))
        manage.validate_instance(self.instance,self.values)

    def test_adapted_incidents_template_serves_status_and_readiness(self):
        from starlette.testclient import TestClient
        sys.path.insert(0,str(ROOT/'use-cases/incidents/observability-demo'))
        from obs_poc.config import Settings
        from obs_poc.clients import Sources
        from obs_poc.server import create_app
        settings=Settings(manifest_path=self.instance/'config/incidents-corpus.json',
            metric_mapping=self.instance/'config/metric-mapping.json',
            itsm_snapshot=self.instance/'config/itsm-tickets.json',
            metrics_provider='victoriametrics',events_provider='itsm-ng-simulator',
            logs_index='site-incidents-logs',docs_index='site-incidents-docs',grafana='',
            mcp_token='external-contract-test-token')
        with patch.object(Sources,'measurements',return_value=[{'clock':1790582400,'value':1}]), \
                patch.object(Sources,'os',return_value={'hits':{'hits':[]}}), TestClient(create_app(settings)) as client:
            status=client.get('/status')
            self.assertEqual(status.status_code,200)
            self.assertEqual(status.json()['hosts'][0]['equipment'],'SITE-R1')
            readiness=client.get('/readiness',headers={'Authorization':'Bearer external-contract-test-token'})
            self.assertEqual(readiness.status_code,200,readiness.text)
            self.assertTrue(readiness.json()['ready'])


if __name__ == '__main__':
    unittest.main()
