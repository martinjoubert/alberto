"""The actual exported source archive must retain a complete portable manual."""
import importlib.util
from pathlib import Path
import tarfile
import tempfile
import unittest
import zipfile

ROOT=Path(__file__).resolve().parents[3]
def load(name):
 spec=importlib.util.spec_from_file_location('delivery_documents_'+name,ROOT/'deploy/ubuntu'/(name+'.py'))
 result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result


class DeliveryDocumentationTests(unittest.TestCase):
 def test_extracted_real_delivery_exports_every_figure_without_repository_or_network(self):
  bundle=load('bundle');wiki=load('wiki_export')
  with tempfile.TemporaryDirectory() as directory:
   directory=Path(directory);output=directory/'source.tar.gz'
   bundle.archive(ROOT,output)
   with tarfile.open(output) as archive:archive.extractall(directory/'extracted',filter='data')
   source=directory/'extracted/rie-delivery/docs/si-rie'
   self.assertEqual(len(list((source/'diagrams').glob('*.drawio'))),12)
   self.assertEqual(len(list((source/'assets/diagrams').glob('*.svg'))),12)
   self.assertEqual(len(list((source/'assets/diagrams').glob('*.png'))),12)
   captures=sorted((source/'assets/screenshots-2026-11-06').glob('*.png'))
   self.assertEqual(len(captures),8)
   mapping_captures=sorted((source/'assets/screenshots-2026-11-16').glob('*.png'))
   self.assertEqual(len(mapping_captures),2)
   self.assertEqual([p.name for p in source.glob('*.md')],['README.md'])
   self.assertIn('## 12.',(source/'README.md').read_text())
   self.assertTrue((source/'reference/README.md').is_file())
   gallery=(source/'reference/09-demonstrations.md').read_text()
   for image in captures:
    relative=image.relative_to(source).as_posix()
    self.assertIn('](../'+relative+')',gallery)
    self.assertEqual(wiki.public_file(source,relative).read_bytes(),(ROOT/'docs/si-rie'/relative).read_bytes())
   wiki.export_bundle(source,directory/'wiki.zip')
   with zipfile.ZipFile(directory/'wiki.zip') as archive:
    self.assertIn('portable/assets/diagrams/01-deployment.svg',archive.namelist())
    self.assertIn('portable/diagrams/01-deployment.drawio',archive.namelist())
    for image in captures:
     relative=image.relative_to(source).as_posix()
     self.assertEqual(archive.read('portable/'+relative),image.read_bytes())
     self.assertEqual(archive.read('wikijs/'+relative),image.read_bytes())
     self.assertIn(('(/dinum-rie/'+relative+')').encode(),archive.read('wikijs/reference/09-demonstrations.md'))
    for image in mapping_captures:
     relative=image.relative_to(source).as_posix()
     self.assertEqual(archive.read('portable/'+relative),image.read_bytes())
     self.assertIn(('(/dinum-rie/'+relative+')').encode(),archive.read('wikijs/reference/04-pdl.md'))
