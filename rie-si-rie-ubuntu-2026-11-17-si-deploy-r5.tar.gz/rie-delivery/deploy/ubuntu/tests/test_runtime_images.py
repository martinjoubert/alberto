"""Business builds and startup are independent of optional delivery tooling."""
from contextlib import redirect_stdout
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location('ubuntu_split_images', ROOT/'deploy/ubuntu/manage.py')
manage = importlib.util.module_from_spec(spec); spec.loader.exec_module(manage)


def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


class ContextTests(unittest.TestCase):
    def test_exported_runtime_imports_without_the_checkout_or_network(self):
        with tempfile.TemporaryDirectory() as temporary:
            context = Path(temporary).resolve()/'exported-runtime'
            manage.context(context)
            code = r'''
import importlib,json,socket,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
sys.path[:0]=[str(root),str(root/'delivery'),str(root/'incidents')]
def blocked(*args,**kwargs):raise AssertionError('Runtime import attempted network access')
socket.socket.connect=blocked;socket.socket.connect_ex=blocked
socket.create_connection=blocked;socket.getaddrinfo=blocked
for name in ('rie_agent.mcp_app','obs_poc.server','runtime_cli','tokens','demo','seed_incidents','initialize'):
    loaded=importlib.import_module(name)
    assert Path(loaded.__file__).resolve().is_relative_to(root),(name,loaded.__file__)
# Exercise every selected business module, including imports deferred by entrypoints.
for folder,prefix in ((root/'rie_agent','rie_agent'),(root/'dinum_access','dinum_access'),
                      (root/'dinum_albert','dinum_albert'),(root/'incidents/obs_poc','obs_poc')):
    for path in folder.glob('*.py'):
        loaded=importlib.import_module(prefix+('.'+path.stem if path.stem!='__init__' else ''))
        assert Path(loaded.__file__).resolve().is_relative_to(root)
print('Detached runtime imports passed without network or checkout')
'''
            environment = {key:value for key,value in os.environ.items()
                           if key != 'PYTHONPATH' and not key.startswith(('ALBERT_', 'OPENAI_', 'PDL_', 'OBS_', 'DINUM_', 'RIE_'))}
            result = subprocess.run([sys.executable, '-I', '-B', '-c', code, str(context)],
                                    cwd=context.parent, env=environment, text=True, capture_output=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('Detached runtime imports passed', result.stdout)

    def test_optional_changes_do_not_change_runtime_or_copy_host_tools(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary).resolve(); root = folder/'sources'; here = root/'deploy/ubuntu'
            with patch.object(manage, 'ROOT', root), patch.object(manage, 'HERE', here):
                for source, _ in manage.runtime_copies():
                    write(source, '# allowed runtime\n')
                write(here/'requirements-portal.lock', '# ui dependencies\n')
                write(here/'wiki_export.py', '# public exporter\n')
                write(here/'qualification_reports.py', '# bounded report reader\n')
                write(here/'deployment_setup.py', '# offline preparation\n')
                for name in ('pdl.json','access.json','oauth.json'):
                    write(here/'examples'/name, '{}\n')
                for name in manage.PORTAL_TOOLS:
                    write(here/'portal'/name, '# optional portal\n')
                for name in manage.QUALIFICATION_TOOLS:
                    write(here/name, '# optional qualification\n')
                for name in ('manage.py', 'vm.py', 'qualification_openwebui.py', 'backup_restore.py', 'arbitrary_future_helper.py'):
                    write(here/name, 'HOST_ONLY_MARKER')
                write(root/'docs/si-rie/README.md', '# First public guide\n')
                runtime1 = manage.context(folder/'runtime')
                portal1 = manage.context(folder/'portal', 'portal')
                qualification1 = manage.context(folder/'qualification', 'qualification')
                write(root/'docs/si-rie/README.md', '# Corrected public guide\n')
                self.assertEqual(manage.context(folder/'runtime'), runtime1)
                self.assertNotEqual(manage.context(folder/'portal', 'portal'), portal1)
                self.assertEqual(manage.context(folder/'qualification', 'qualification'), qualification1)
            runtime_names = {p.relative_to(folder/'runtime').as_posix() for p in (folder/'runtime').rglob('*') if p.is_file()}
            self.assertFalse(any(name.startswith(('documentation/', 'portal/', 'qualification/')) for name in runtime_names))
            self.assertNotIn('rie_agent/admin_app.py', runtime_names)
            for target in ('runtime', 'portal', 'qualification'):
                data = b''.join(p.read_bytes() for p in (folder/target).rglob('*') if p.is_file())
                self.assertNotIn(b'HOST_ONLY_MARKER', data)
            self.assertTrue((folder/'qualification/qualification/runtime_entry.py').is_file())
            self.assertFalse((folder/'runtime/delivery/runtime_entry.py').exists())

    def test_runtime_lock_excludes_ui_and_observability_exporters(self):
        text = (ROOT/'deploy/ubuntu/requirements-runtime.lock').read_text()
        for forbidden in ('nicegui==', 'python-socketio==', 'python-engineio==', 'opentelemetry-sdk==', 'opentelemetry-exporter-'):
            self.assertNotIn(forbidden, text)
        portal = (ROOT/'deploy/ubuntu/requirements-portal.lock').read_text()
        self.assertIn('nicegui==', portal)
        self.assertNotIn('opentelemetry-sdk==', portal)


class PreflightTests(unittest.TestCase):
    def prepared(self, folder):
        instance = folder/'instance'
        with redirect_stdout(io.StringIO()):
            manage.bootstrap(instance, 'external')
        values = manage.load(instance)
        values.update(RIE_MODE='demo', RIE_IMAGE='dinum/runtime:present', RIE_LDAP_IMAGE='dinum/ldap:present',
                      OPENSEARCH_URL='http://opensearch:9200', VICTORIAMETRICS_URL='http://victoriametrics:8428')
        for name in ('slapd.conf', 'seed.ldif', 'server.crt', 'server.key', 'ca.crt'):
            write(instance/'config/ldap'/name, 'synthetic test input\n')
        return instance, values

    def invoke_up(self, instance, values, **mocks):
        with patch.object(sys, 'argv', ['manage.py', 'up', str(instance)]),patch.object(manage, 'load', return_value=values), \
             patch.object(manage, 'guard', mocks['guard']),patch.object(manage, 'docker', mocks['docker']), \
             patch.object(manage, 'compose', mocks['compose']):
            manage.main()

    def test_invalid_config_never_contacts_docker_or_stops_services(self):
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as temporary:
            instance, values = self.prepared(Path(temporary).resolve())
            for corrupt in ('bad_port', 'missing_secret', 'bad_policy'):
                with self.subTest(corrupt=corrupt):
                    edited = dict(values); secret = instance/'secrets/albert_key'
                    if corrupt == 'bad_port': edited['PDL_PORT'] = '999999'
                    elif corrupt == 'missing_secret': secret.unlink()
                    else: (instance/'access/policy.json').write_text('{bad json')
                    docker, guard, compose = Mock(), Mock(), Mock()
                    with self.assertRaises((ValueError, OSError)):
                        self.invoke_up(instance, edited, docker=docker, guard=guard, compose=compose)
                    docker.assert_not_called(); guard.assert_not_called(); compose.assert_not_called()
                    if not secret.exists(): secret.write_text('demo-only\n')

    def test_missing_portal_image_prevents_stop_and_receipt_write(self):
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as temporary:
            instance, values = self.prepared(Path(temporary).resolve())
            values.update(RIE_ENABLE_DEMO_UI='true', RIE_PORTAL_IMAGE='dinum/portal:missing')
            def inspect(*args, **kwargs):
                if args[2] == 'dinum/portal:missing': raise subprocess.CalledProcessError(1, args)
                return SimpleNamespace(stdout='[]')
            docker = Mock(side_effect=inspect); guard, compose = Mock(), Mock()
            with self.assertRaisesRegex(ValueError, 'portal image'):
                self.invoke_up(instance, values, docker=docker, guard=guard, compose=compose)
            guard.assert_not_called(); compose.assert_not_called()
            self.assertFalse((instance/'docker-id').exists())

    def test_old_monolithic_image_is_a_compatible_fallback(self):
        with tempfile.TemporaryDirectory() as temporary:
            instance, values = self.prepared(Path(temporary).resolve())
            values.pop('RIE_PORTAL_IMAGE'); values.pop('RIE_QUALIFICATION_IMAGE')
            values['RIE_ENABLE_DEMO_UI'] = 'true'
            self.assertEqual(manage.required_images(values)['portal'], values['RIE_IMAGE'])
            values.update(RIE_SIMULATED_ALBERT='true', ALBERT_URL='http://127.0.0.1:8123/v1')
            self.assertEqual(manage.required_images(values)['qualification'], values['RIE_IMAGE'])
            with patch.object(manage, 'docker') as docker:
                manage.preflight_up(instance, values)
            self.assertTrue(docker.called)

    def test_source_resources_are_validated_without_opening_legacy_policies(self):
        with tempfile.TemporaryDirectory() as temporary:
            instance, values = self.prepared(Path(temporary).resolve())
            policy = json.loads((instance/'access/policy.json').read_text())
            policy.pop('resources'); (instance/'access/policy.json').write_text(json.dumps(policy))
            manage.validate_instance(instance, values)
            for resource, visibility in [('incidents.arbitrary', 'internal'), ('incidents.metrics', 'everyone')]:
                policy['resources'] = {resource: visibility}; (instance/'access/policy.json').write_text(json.dumps(policy))
                with self.assertRaisesRegex(ValueError, 'known resources'):
                    manage.validate_instance(instance, values)


class InputTests(unittest.TestCase):
    def test_mapping_file_is_sent_by_python_without_shell_redirection(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary).resolve(); mapping = folder/'mapping.yaml'; mapping.write_text('version: 1\nindices: []\n')
            argv = ['manage.py', 'pdl', str(folder/'instance'), '--input', str(mapping), '--', 'validate-mappings']
            with patch.object(sys, 'argv', argv),patch.object(manage, 'load', return_value={'RIE_MODE':'external'}), \
                 patch.object(manage, 'guard'),patch.object(manage, 'tool') as tool:
                manage.main()
            self.assertEqual(tool.call_args.kwargs['input_text'], mapping.read_text())
            self.assertTrue(tool.call_args.kwargs['interactive_input'])

    def test_helper_credentials_do_not_require_docker(self):
        from unittest.mock import Mock
        helper = SimpleNamespace(run=Mock())
        with patch.object(sys, 'argv', ['manage.py', 'demo-credentials', '/private/tmp/instance']), \
             patch.object(manage, 'load', return_value={'RIE_MODE':'demo'}),patch.object(manage, 'module', return_value=helper), \
             patch.object(manage, 'guard') as guard:
            manage.main()
        guard.assert_not_called(); helper.run.assert_called_once()


if __name__ == '__main__': unittest.main()
