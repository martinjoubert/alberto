"""The live fixture mutator is scope-bound; denial expectations are strict."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('acl_lifecycle_tests',ROOT/'deploy/ubuntu/qualification_acl_lifecycle.py')
acl=importlib.util.module_from_spec(spec);spec.loader.exec_module(acl)


class ACLQualificationTests(unittest.TestCase):
    def configuration(self):
        return {'ldap':{'host':'ldap','port':1636,'search_base':'ou=people,'+acl.DIRECTORY_BASE,
                        'group_dns':acl.GROUP_DNS,'administrator_group_dns':[acl.ADMIN_GROUP_DN],'use_tls':True,'validate_cert':True}}

    def test_only_exact_verified_synthetic_ldap_can_be_mutated(self):
        source=self.configuration()
        self.assertEqual(acl.fixture_configuration(source,'demo'),source['ldap'])
        for key,value in (('host','real-ldap.internal'),('port',636),('search_base','ou=real,dc=organization'),
                          ('validate_cert',False),('group_dns',{'internal':'another-group'}),
                          ('administrator_group_dns',[]),('administrator_group_dns',[acl.GROUP_DNS['internal']])):
            candidate=deepcopy(source);candidate['ldap'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):acl.fixture_configuration(candidate,'demo')
        with self.assertRaises(ValueError):acl.fixture_configuration(source,'external')

    def test_administrator_membership_is_refreshed_for_the_same_two_credentials(self):
        from dinum_access.security import Principal
        class Gate:
            administrator=False
            calls=[]
            def authenticate(self,headers):
                self.calls.append(headers['authorization'])
                return Principal('stable-object','probe@example.test','internal',self.administrator)
        gate=Gate()
        for administrator in (False,True,False):
            gate.administrator=administrator
            observed=acl.administration_observation(gate,'PRIVATE_TOKEN','PRIVATE_SESSION')
            self.assertTrue(acl.administration_expected(observed,administrator))
            self.assertFalse(acl.administration_expected(observed,not administrator))
            self.assertNotIn('PRIVATE_',json.dumps(observed))
        self.assertEqual(gate.calls,['Bearer PRIVATE_TOKEN','Bearer PRIVATE_SESSION']*3)
        self.assertFalse(acl.administration_expected({},False))
        self.assertFalse(acl.administration_expected({'individual_token':{'category':'external','administrator':True},
                                                     'short_session':{'category':'internal','administrator':True}},True))

    def probe(self,**updates):
        return {'http_status':200,'category':'internal','business_status':'ok','has_evidence':False,
                'metric_count':5,'analysis_present':False,'generation_usage_present':False,'albert_calls':0,'error_code':None,**updates}

    def test_refusal_requires_403_and_no_evidence(self):
        for kind in ('unclassified','replaced','expired'):
            row=self.probe(http_status=403,error_code='expired_or_revoked_user_token')
            self.assertTrue(acl.expected(row,kind))
            self.assertFalse(acl.expected({**row,'has_evidence':True},kind))
            self.assertFalse(acl.expected({**row,'http_status':200},kind))
        self.assertFalse(acl.expected(self.probe(http_status=403,error_code='directory_unavailable'),'expired'))

    def test_external_incident_response_never_contains_evidence(self):
        row=self.probe(category='external',business_status='denied',metric_count=0)
        self.assertTrue(acl.expected(row,'external',incident=True))
        self.assertFalse(acl.expected({**row,'has_evidence':True},'external',incident=True))
        self.assertFalse(acl.expected({**row,'analysis_present':True},'external',incident=True))
        self.assertFalse(acl.expected(self.probe(albert_calls=1),'internal'))

    def test_disposable_internal_identity_without_itsm_never_borrows_a_native_account(self):
        row=self.probe(business_status='partial',source_errors=[{'source':'itsm-ng','code':'individual_credential_missing'}])
        self.assertTrue(acl.expected(row,'internal',incident=True))
        for errors in ([],[{'source':'opensearch','code':'unavailable'}],
                       [{'source':'itsm-ng','code':'native_access_denied'}]):
            self.assertFalse(acl.expected({**row,'source_errors':errors},'internal',incident=True))
        self.assertFalse(acl.expected({**row,'metric_count':0},'internal',incident=True))
        self.assertFalse(acl.expected({**row,'generation_usage_present':True},'internal',incident=True))

    def test_http_probe_sends_individual_token_but_never_returns_it(self):
        calls=[]
        class Client:
            def post(self,url,**options):
                calls.append((url,options))
                return SimpleNamespace(status_code=403,json=lambda:{'error':'expired_or_revoked_user_token'})
        result=acl.probe(Client(),'PRIVATE_BEARER',forged_header=True)
        self.assertEqual(calls[0][1]['headers']['Authorization'],'Bearer PRIVATE_BEARER')
        self.assertNotIn('PRIVATE_BEARER',json.dumps(result))
        self.assertEqual(result['error_code'],'expired_or_revoked_user_token')


if __name__=='__main__':unittest.main()
