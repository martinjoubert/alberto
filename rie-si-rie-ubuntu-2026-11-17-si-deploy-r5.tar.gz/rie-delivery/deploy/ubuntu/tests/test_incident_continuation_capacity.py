"""Bound both Incident continuation stores without deleting another live state."""
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[3]
for relative in ('core/access-control/src','core/albert-client/src','use-cases/incidents/observability-demo'):
    sys.path.insert(0,str(ROOT/relative))
from obs_poc.assistant import Continuations,PARAMETERS
from dinum_albert.dialogue import DialogueError


def state():
    return {'question':'Demande fictive','replies':[], 'parameters':{name:'' for name in PARAMETERS},
            'pending':False,'reference_pending':False}


class IncidentContinuationCapacityTests(unittest.TestCase):
    def test_legacy_default_and_explicit_ubuntu_capacity_are_bounded(self):
        with patch.dict(os.environ,{},clear=True):
            self.assertEqual(Continuations('key','test').max_states,2048)
        with patch.dict(os.environ,{'DINUM_DIALOGUE_MAX_STATES':'8192'}):
            self.assertEqual(Continuations('key','test').max_states,8192)
            self.assertEqual(Continuations('key','test',max_states=7).max_states,7)
        for value in (0,32769,-1,True,1.5,'','infinite'):
            with self.subTest(value=value),self.assertRaises(DialogueError):
                Continuations('key','test',max_states=value)

    def test_memory_capacity_preserves_live_token_then_reclaims_expired_state(self):
        clock=[100]
        store=Continuations('key','test',ttl=10,clock=lambda:clock[0],max_states=1)
        token=store.issue(state())
        with self.assertRaisesRegex(ValueError,'capacity'):store.issue(state())
        self.assertEqual(store.read(token),state())
        clock[0]=111
        replacement=store.issue(state())
        self.assertNotEqual(token,replacement)
        self.assertEqual(len(store.states),1)

    def test_deleted_file_during_cleanup_is_harmless_but_permission_error_is_not(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Continuations('key','test',directory=directory,max_states=3)
            stale=Path(directory)/'expired.json';stale.write_text('{"expires":0}');os.utime(stale,(0,0))
            original_stat=Path.stat
            def removed_before_stat(path,*args,**kwargs):
                if path==stale:path.unlink(missing_ok=True)
                return original_stat(path,*args,**kwargs)
            with patch.object(Path,'stat',removed_before_stat):token=store.issue(state())
            self.assertEqual(store.read(token),state())
            live=next(Path(directory).glob('*.json'))
            def no_permission(path,*args,**kwargs):
                if path==live:raise PermissionError('private path must not be ignored')
                return original_stat(path,*args,**kwargs)
            with patch.object(Path,'stat',no_permission),self.assertRaises(PermissionError):store.issue(state())

    def test_old_mtime_never_purges_a_live_state_to_make_room(self):
        with tempfile.TemporaryDirectory() as directory:
            store=Continuations('key','test',directory=directory,max_states=1)
            token=store.issue(state())
            live=next(Path(directory).glob('*.json'));before=live.read_bytes();os.utime(live,(0,0))
            with self.assertRaisesRegex(ValueError,'capacity'):store.issue(state())
            self.assertEqual(live.read_bytes(),before)
            self.assertEqual(store.read(token),state())

    def test_directory_limit_is_shared_between_instances_and_concurrent_workers(self):
        with tempfile.TemporaryDirectory() as directory:
            stores=[Continuations('key','test',directory=directory,max_states=7) for _ in range(2)]
            def issue(number):
                try:return stores[number%2].issue(state())
                except ValueError as error:
                    self.assertIn('capacity',str(error));return None
            with ThreadPoolExecutor(max_workers=12) as executor:tokens=list(executor.map(issue,range(50)))
            successful=[token for token in tokens if token]
            self.assertEqual(len(successful),7)
            self.assertEqual(len(list(Path(directory).glob('*.json'))),7)
            for token in successful:self.assertEqual(stores[0].read(token),state())


if __name__=='__main__':unittest.main()
