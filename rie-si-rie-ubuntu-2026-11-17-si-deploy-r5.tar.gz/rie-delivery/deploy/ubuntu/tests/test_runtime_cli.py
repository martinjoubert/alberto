"""Keep operator failures reviewable without bypassing LDAP or publishing secrets."""
from contextlib import contextmanager, redirect_stderr, redirect_stdout
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

import httpx

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'core/access-control/src'))
from dinum_access import AccessDenied, AccessGate

spec = importlib.util.spec_from_file_location('ubuntu_runtime_cli', ROOT / 'deploy/ubuntu/runtime_cli.py')
cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cli)


class Directory:
    def lookup(self, value, **options):
        result = value + '@example.org', 'external' if value == 'external' else 'internal', 'stable-' + value
        return (*result, value not in {'external', 'reader'}) if options.get('authorization') else result


class RuntimeCLITests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.stdout = io.StringIO()
        self.stderr = io.StringIO()

    def tearDown(self):
        self.temporary.cleanup()

    def invoke(self, argv):
        with redirect_stdout(self.stdout), redirect_stderr(self.stderr):
            return cli.main(argv)

    def test_policy_change_is_revision_checked_and_external_maintenance_is_denied(self):
        policy = self.root / 'policy.json'
        policy.write_text(json.dumps({'version': 1, 'revision': 1, 'default': 'blocked', 'indices': {}}))
        gate = AccessGate({'state_directory': str(self.root)}, Directory())
        with patch.object(cli, 'configured_gate', return_value=gate):
            self.assertEqual(self.invoke(['policy', '--username', 'operator', 'set', 'test-logs', 'internal', '--revision', '1']), 0)
            self.assertEqual(json.loads(policy.read_text())['revision'], 2)
            self.assertEqual(self.invoke(['policy', '--username', 'operator', 'set', 'test-logs', 'authenticated', '--revision', '1']), 2)
            self.assertEqual(self.invoke(['policy', '--username', 'external', 'set', 'test-logs', 'authenticated', '--revision', '2']), 2)
            self.assertEqual(self.invoke(['policy', '--username', 'reader', 'set', 'test-logs', 'authenticated', '--revision', '2']), 2)
        self.assertEqual(json.loads(policy.read_text())['indices'], {'test-logs': 'internal'})

    def test_seed_outside_demo_exits_before_writes(self):
        with patch.dict(os.environ, {'PDL_MODE': 'external'}), patch.object(cli, 'load_module') as load:
            self.assertEqual(self.invoke(['seed']), 2)
        load.assert_not_called()
        self.assertEqual(json.loads(self.stderr.getvalue())['command'], 'seed')

    def test_only_access_administrators_can_list_or_revoke_individual_client_sessions(self):
        from dinum_access.oauth_store import OAuthStore, secret
        self.root=self.root.resolve()
        (self.root/'policy.json').write_text(json.dumps({'version':1,'revision':1,'default':'blocked','indices':{}}))
        gate=AccessGate({'state_directory':str(self.root)},Directory())
        store=OAuthStore(self.root/'oauth');identifier=secret()
        import time
        grant={'id':identifier,'username':'alice','ldap_subject':'stable-alice','client_id':'local-client',
               'resource':'https://pdl.example.org/mcp','created':int(time.time()),'expires':int(time.time())+600,'revoked':False}
        store.save('grant',identifier,grant,grant['expires'])
        with patch.object(cli,'configured_gate',return_value=gate):
            for username in ('reader','external'):
                self.assertEqual(self.invoke(['list-client-sessions','--username',username]),2)
                self.assertEqual(self.invoke(['revoke-client-session','--username',username,'--id',identifier]),2)
            self.assertFalse(store.read('grant',identifier)['revoked'])
            self.assertEqual(self.invoke(['list-client-sessions','--username','operator']),0)
            self.assertEqual(self.invoke(['revoke-client-session','--username','operator','--id',identifier]),0)
        self.assertTrue(store.read('grant',identifier)['revoked'])
        self.assertNotIn('ldap_subject',self.stdout.getvalue())

    def fake_runtime(self, *, failing_source=False):
        fixture = self.root / 'fixture.json'
        fixture.write_text(json.dumps({'proposal': {}}))
        package = ModuleType('rie_agent')
        package.__path__ = []
        def acceptance_run(*args):
            if failing_source:
                raise RuntimeError('PRIVATE_SOURCE_ERROR_SHOULD_NOT_BE_REPORTED')
            return {'qualification_passed': True, 'results': [{}] * 6}
        modules = {
            'rie_agent': package,
            'rie_agent.acceptance': SimpleNamespace(ExplicitPlanner=lambda value: value, FIXTURE_PATH=fixture, run=acceptance_run),
            'rie_agent.config': SimpleNamespace(load_settings=lambda: None),
            'rie_agent.service': SimpleNamespace(RIEAgentService=lambda *a, **k: None),
        }
        return patch.dict(sys.modules, modules)

    @contextmanager
    def acting(self, username, **kwargs):
        yield None, None

    def test_source_runtime_error_leaves_a_private_failure_report_and_exit_two(self):
        real_client = httpx.Client
        def response(request):
            return httpx.Response(403, json={'error': 'identity_required'})
        with self.fake_runtime(failing_source=True), patch.dict(os.environ, {
                'PDL_MODE': 'demo', 'OPENSEARCH_URL': 'http://opensearch:9200'}), \
                patch.object(cli, 'DATA', self.root), patch.object(cli, 'acting', self.acting), \
                patch.object(cli, 'individual_token', side_effect=AccessDenied('directory_unavailable_or_denied')), \
                patch.object(cli.httpx, 'Client', side_effect=lambda **kw: real_client(transport=httpx.MockTransport(response), **kw)):
            self.assertEqual(self.invoke(['acceptance']), 2)
        report = self.root / 'acceptance.json'
        self.assertEqual(report.stat().st_mode & 0o777, 0o600)
        result = json.loads(report.read_text())
        self.assertFalse(result['passed'])
        failures = {row['name']: row for row in result['checks'] if not row['passed']}
        self.assertEqual(failures['pdl_internal_sources']['error'], 'RuntimeError')
        self.assertEqual(failures['pdl_external_sources']['error'], 'RuntimeError')
        self.assertNotIn('PRIVATE_SOURCE_ERROR', report.read_text() + self.stdout.getvalue() + self.stderr.getvalue())
        self.assertIn('pdl_internal_sources', json.loads(self.stdout.getvalue())['failed'])

    def test_partial_incident_with_no_logs_is_a_failed_check_not_a_crashed_recipe(self):
        real_client = httpx.Client
        store = SimpleNamespace(revoke=lambda identifier: None)
        @contextmanager
        def token(username):
            yield ('external-token' if username == 'eric.durand.ext' else 'internal-token'), store, 'test-id'
        def response(request):
            authorization = request.headers.get('authorization', '')
            if not authorization:
                return httpx.Response(403, json={'error': 'identity_required'})
            if request.url.path == '/diagnose':
                if authorization.endswith('external-token'):
                    return httpx.Response(200, json={'status': 'denied', 'access_control': {'category': 'external'}})
                return httpx.Response(200, json={'status': 'partial', 'errors': [{'source': 'opensearch'}],
                                                'metrics': [], 'logs': [], 'events': [], 'documents': []})
            payload = json.loads(request.content)
            if payload['method'] == 'initialize':
                result = {'serverInfo': {'name': 'test'}, 'protocolVersion': '2025-11-25'}
            elif payload['method'] == 'tools/list':
                result = {'tools': [{'name': 'investigate_pdl'}]}
            else:
                external = authorization.endswith('external-token')
                result = {'structuredContent': {'access_control': {'category': 'external' if external else 'internal',
                        'allowed_indices': ['rie-pfs-fixture']}, 'execution': {'albert_calls': 0}}}
            return httpx.Response(200, json={'jsonrpc': '2.0', 'id': 1, 'result': result})
        with self.fake_runtime(), patch.dict(os.environ, {
                'PDL_MODE': 'demo', 'OPENSEARCH_URL': 'http://opensearch:9200'}), \
                patch.object(cli, 'DATA', self.root), patch.object(cli, 'acting', self.acting), \
                patch.object(cli, 'individual_token', token), \
                patch.object(cli.httpx, 'Client', side_effect=lambda **kw: real_client(transport=httpx.MockTransport(response), **kw)):
            self.assertEqual(self.invoke(['acceptance']), 2)
        report = json.loads((self.root / 'acceptance.json').read_text())
        failed = {row['name']: row for row in report['checks'] if not row['passed']}
        self.assertEqual(failed['incidents_internal_live_evidence']['business_status'], 'partial')
        self.assertEqual(failed['incidents_internal_live_evidence']['metric_count'], 0)
        self.assertNotIn('internal_transport', failed)
        self.assertEqual(self.stderr.getvalue(), '')


if __name__ == '__main__':
    unittest.main()
