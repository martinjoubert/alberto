"""Portable reporting keeps real outcomes, integrity and private inputs separate."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

MODULE = Path(__file__).resolve().parents[1]/'build_report.py'
spec = importlib.util.spec_from_file_location('build_report', MODULE)
report = importlib.util.module_from_spec(spec)
spec.loader.exec_module(report)


class ReportingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.base = Path(self.temporary.name).resolve()
        self.results = self.base/'results';self.results.mkdir()

    def tearDown(self):
        self.temporary.cleanup()

    def result(self, identifier, status='passed', **extra):
        row = {'uuid': identifier, 'name': identifier, 'fullName': 'tests.'+identifier,
               'status': status, 'stage': 'finished', **extra}
        (self.results/(identifier+'-result.json')).write_text(json.dumps(row))

    def test_missing_results_never_become_a_successful_or_only_skipped_report(self):
        with self.assertRaisesRegex(ValueError, 'Missing'):
            report.stage_results(self.results, self.base/'selected', ['Albert'])

    def test_failures_and_platform_skips_remain_distinct_from_non_qualification(self):
        self.result('success');self.result('failure', 'failed');self.result('platform', 'skipped')
        self.result('unqualified', 'skipped', labels=[{'name': 'qualification', 'value': 'not_qualified'}])
        selected = self.base/'selected'
        counts = report.stage_results(self.results, selected, ['Endurance'])
        self.assertEqual(counts, {'passed':1, 'failed':1, 'broken':0, 'skipped':1, 'unknown':0, 'not_qualified':2})
        self.assertEqual(len(list(selected.glob('*-result.json'))), 5)
        notice = next(json.loads(p.read_text()) for p in selected.glob('*-result.json')
                      if json.loads(p.read_text())['name'].startswith('Non qualifié'))
        self.assertNotIn('start', notice)
        self.assertNotIn('stop', notice)

    def test_incomplete_or_successful_non_qualified_results_are_refused(self):
        for row in ({'stage':'running'}, {'labels':[{'name':'qualification', 'value':'not_qualified'}]}):
            with self.subTest(row=row):
                self.result('unfinished', **row)
                with self.assertRaises(ValueError):
                    report.stage_results(self.results, self.base/('selected-'+str(len(row))+row.get('stage','label')))

    def test_only_declared_safe_attachments_are_read(self):
        for name in ('../secret.txt', 'trace.html', 'result-result.json'):
            with self.subTest(name=name):
                self.result('unsafe', attachments=[{'source':name, 'type':'text/plain'}])
                with self.assertRaises(ValueError):
                    report.stage_results(self.results, self.base/('out-'+hashlib.sha256(name.encode()).hexdigest()[:5]))
        self.result('unsafe', attachments=[{'source':'x-attachment.txt', 'type':'text/plain'}])
        outside = self.base/'secret.txt';outside.write_text('private')
        (self.results/'x-attachment.txt').symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            report.stage_results(self.results, self.base/'links')

    def test_known_credential_patterns_are_refused_before_rendering(self):
        self.result('leak', statusDetails={'message':'Bearer '+'a'*64})
        with self.assertRaisesRegex(ValueError, 'Credential'):
            report.stage_results(self.results, self.base/'selected')

    def test_generated_report_must_not_depend_on_cdn_or_analytics(self):
        for content in ('<script src="https://cdn.example/script.js"></script>',
                        '<link href="relative.css">', 'googletagmanager.com'):
            with self.subTest(content=content), self.assertRaises(ValueError):
                report.validate_html(('<html><script>window.reportDataReady=true;</script>'+content+'</html>').encode())

    def test_bundle_has_exactly_two_integrity_checked_files_and_no_raw_results(self):
        self.result('failed', 'failed')
        tools = self.base/'tools';(tools/'node_modules/allure').mkdir(parents=True)
        (tools/'package.json').write_text(json.dumps({'devDependencies':{'allure':'3.33.0'}}))
        (tools/'node_modules/allure/package.json').write_text(json.dumps({'version':'3.33.0'}))
        (tools/'allurerc.json').write_text(json.dumps({'plugins':{'allure2':{'options':{'singleFile':True}}}}))
        html = b'<html><script>window.reportDataReady=true;</script></html>'
        def renderer(command, **kwargs):
            self.assertEqual(kwargs['env']['ALLURE_NO_ANALYTICS'], 'true')
            self.assertNotIn('ALBERT_API_KEY', kwargs['env'])
            config=json.loads(Path(command[command.index('--config')+1]).read_text())
            self.assertEqual(config['plugins']['allure2']['options']['reportName'],'Campagne échouée')
            out = Path(command[command.index('--output')+1]);out.mkdir()
            (out/'index.html').write_bytes(html)
            (out/'summary.json').write_text(json.dumps({'stats':{'total':1,'failed':1}}))
        with patch.object(report, 'TOOLS', tools), patch.object(report.subprocess, 'run', side_effect=renderer):
            result = report.build(self.results, self.base/'export', 'test-failure', 'Campagne échouée',
                                  'CI', commit='a'*40, node='/node')
        with zipfile.ZipFile(result['archive']) as archive:
            self.assertEqual(set(archive.namelist()), {'index.html', 'report.json'})
            metadata = json.loads(archive.read('report.json'))
            self.assertEqual(metadata['counts']['failed'], 1)
            self.assertEqual(metadata['html'], {'bytes':len(html),'sha256':hashlib.sha256(html).hexdigest()})
            self.assertEqual(archive.read('index.html'), html)
        archive = Path(result['archive'])
        self.assertEqual(hashlib.sha256(archive.read_bytes()).hexdigest(), result['sha256'])

    def test_tools_lock_is_exact_and_every_download_has_integrity(self):
        package = json.loads((report.TOOLS/'package.json').read_text())
        lock = json.loads((report.TOOLS/'package-lock.json').read_text())
        self.assertEqual(package['devDependencies'], {'allure':'3.33.0'})
        self.assertEqual(lock['packages']['']['devDependencies'], package['devDependencies'])
        for name, item in lock['packages'].items():
            if name:
                self.assertTrue(item['integrity'].startswith('sha512-'))
                self.assertTrue(item['resolved'].startswith('https://registry.npmjs.org/'))

    def test_ci_renders_and_retains_reports_even_when_business_tests_fail(self):
        import yaml
        root = MODULE.parents[2]
        workflow = yaml.safe_load((root/'.github/workflows/ubuntu-delivery.yml').read_text())
        steps = workflow['jobs']['offline-source-checks']['steps']
        render = next(row for row in steps if 'build_report.py' in row.get('run', ''))
        evidence = next(row for row in steps if row.get('with', {}).get('name', '').startswith('rie-qualification-'))
        tests = next(row for row in steps if row.get('id') == 'business-tests')
        self.assertTrue(render['if'].startswith('always()'))
        self.assertEqual(evidence['if'], 'always()')
        self.assertFalse(tests.get('continue-on-error', False))
        pipeline = yaml.safe_load((root/'.gitlab-ci.yml').read_text())
        self.assertEqual(pipeline['report:ubuntu']['when'], 'always')
        self.assertEqual(pipeline['report:ubuntu']['artifacts']['when'], 'always')
        self.assertEqual(len(pipeline['validate:ubuntu']['artifacts']['reports']['junit']), 3)
        self.assertIn({'job':'validate:ubuntu','artifacts':False}, pipeline['.build_rootless']['needs'])
        self.assertIn({'job':'report:ubuntu','artifacts':False}, pipeline['.build_rootless']['needs'])


if __name__ == '__main__':
    unittest.main()
