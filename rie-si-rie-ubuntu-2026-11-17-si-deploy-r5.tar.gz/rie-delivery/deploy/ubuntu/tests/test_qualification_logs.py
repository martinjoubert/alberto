"""Exercise stream loss, limits and interruption with real local child processes."""
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location('tested_qualification_logs', ROOT/'deploy/ubuntu/qualification_logs.py')
logs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(logs)


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.fake = self.root/'fake_docker.py'
        self.fake.write_text('''import sys,time
if sys.argv[1]=='inspect':
 print('true');raise SystemExit(0)
print('FIRST_LINE',flush=True)
print('STREAM_STDERR',file=sys.stderr,flush=True)
print('X'*4096,flush=True)
time.sleep(60)
''')

    def capture(self, name='run', **kwargs):
        cap = logs.Capture(self.root/name, ['canary'], docker=(sys.executable, '-u', str(self.fake)), **kwargs)
        self.addCleanup(self.cleanup_capture, cap)
        return cap

    @staticmethod
    def cleanup_capture(cap):
        if any(not stream.closed for stream in cap.files.values()):
            cap.stop(completed=False)

    def test_live_stream_is_private_durable_and_incomplete_until_stopped(self):
        cap = self.capture().start()
        deadline = time.monotonic()+5
        while b'FIRST_LINE' not in (cap.output/'canary.log').read_bytes() and time.monotonic()<deadline:
            time.sleep(.01)
        pending = json.loads((cap.output/'report.json').read_text())
        self.assertFalse(pending['passed']);self.assertEqual(pending['status'], 'incomplete')
        report = cap.stop(completed=True)
        self.assertTrue(report['passed'])
        raw = (cap.output/'canary.log').read_text()
        self.assertIn('FIRST_LINE', raw);self.assertIn('STREAM_STDERR', raw)
        self.assertEqual((cap.output/'canary.log').stat().st_mode & 0o777, 0o600)
        self.assertEqual(cap.output.stat().st_mode & 0o777, 0o700)
        self.assertEqual(report['logs']['canary']['bytes'], len(raw.encode()))
        self.assertNotIn('FIRST_LINE', json.dumps(report))

    def test_premature_stream_death_never_becomes_a_success(self):
        cap = self.capture().start()
        cap.processes['canary'].terminate();cap.processes['canary'].wait(timeout=5)
        report = cap.stop(completed=True)
        self.assertFalse(report['passed'])
        self.assertIn('stream_ended_before_stop', [r['code'] for r in report['errors']])
        self.assertTrue((cap.output/'canary.log').is_file())

    def test_zero_exit_before_workload_is_rejected(self):
        self.fake.write_text("import sys\nif sys.argv[1]=='inspect':print('true')\n")
        cap = self.capture()
        try:
            cap.start()
        except RuntimeError:
            pass
        else:
            cap.processes['canary'].wait(timeout=5)
            cap.stop(completed=True)
        self.assertFalse(json.loads((cap.output/'report.json').read_text())['passed'])
        self.assertTrue(all(stream.closed for stream in cap.files.values()))

    def test_byte_budget_failure_is_recorded_without_deleting_evidence(self):
        cap = self.capture(max_bytes=128)
        try:
            cap.start()
        except RuntimeError:
            pass
        else:
            cap.processes['canary'].wait(timeout=5)
            cap.stop(completed=True)
        report = json.loads((cap.output/'report.json').read_text())
        self.assertFalse(report['passed'])
        self.assertIn('log_byte_limit_exceeded', [r['code'] for r in report['errors']])
        self.assertGreater((cap.output/'canary.log').stat().st_size, 128)

    def test_operator_interruption_keeps_an_incomplete_receipt(self):
        cap = self.capture().start();report = cap.stop(completed=False)
        self.assertFalse(report['passed']);self.assertEqual(report['status'], 'incomplete')

    def test_names_and_existing_or_linked_destinations_are_refused(self):
        for name in ('../escape', '--option', 'with space', '/tmp/file'):
            with self.subTest(name=name),self.assertRaises(ValueError):
                logs.Capture(self.root/'never', [name])
        with self.assertRaises(ValueError):logs.Capture(self.root/'never', ['a','a'])
        with self.assertRaises(ValueError):logs.Capture(self.root, ['a'])
        (self.root/'link').symlink_to(self.root)
        with self.assertRaises(ValueError):logs.Capture(self.root/'link/out', ['a'])


class WrapperTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.manager = SimpleNamespace(ROOT=ROOT, guard=Mock(),load=Mock(return_value={
            'RIE_MODE':'demo','RIE_LOAD_QUALIFICATION':'true','RIE_SIMULATED_ALBERT':'true','RIE_PROJECT':'rie-test'}))

    def test_external_or_unmarked_instance_is_refused_before_collection(self):
        for change in ({'RIE_MODE':'external'},{'RIE_LOAD_QUALIFICATION':'false'},{'RIE_SIMULATED_ALBERT':'false'}):
            values = dict(self.manager.load.return_value);values.update(change)
            with patch.object(self.manager,'load',return_value=values),self.assertRaises(ValueError):
                logs.run(self.root/'instance',self.root/'out',manager=self.manager,runner=Mock())
        self.manager.guard.assert_not_called();self.assertFalse((self.root/'out').exists())

    def test_failed_capture_prevents_a_green_workload_from_qualifying(self):
        def workload(instance,output,duration,period):
            output.mkdir();(output/'report.json').write_text('{"passed":true}');return 0
        capture = Mock();capture.report={};capture.thread=True
        capture.stop.return_value={'passed':False}
        with redirect_stdout(io.StringIO()),patch.object(logs.time,'sleep'):
            code=logs.run(self.root/'instance',self.root/'out',duration=60,
                          manager=self.manager,runner=workload,capture_type=Mock(return_value=capture))
        self.assertEqual(code,2)
        report=json.loads((self.root/'out/report.json').read_text())
        self.assertFalse(report['passed']);self.assertEqual(report['kind'],'smoke')
        self.assertTrue(report['checks']['workload_passed'])
        self.assertFalse(report['checks']['continuous_log_clients_completed'])

    def test_workload_exception_closes_streams_and_preserves_failure(self):
        capture=Mock();capture.report={};capture.thread=True;capture.stop.return_value={'passed':False}
        with redirect_stdout(io.StringIO()):
            code=logs.run(self.root/'instance',self.root/'out',duration=60,manager=self.manager,
                          runner=Mock(side_effect=RuntimeError('private details not exported')),
                          capture_type=Mock(return_value=capture))
        capture.stop.assert_called_once_with(completed=False)
        self.assertEqual(code,2)
        report=json.loads((self.root/'out/report.json').read_text())
        self.assertFalse(report['passed']);self.assertNotIn('private details',json.dumps(report))


if __name__ == '__main__':
    unittest.main()
