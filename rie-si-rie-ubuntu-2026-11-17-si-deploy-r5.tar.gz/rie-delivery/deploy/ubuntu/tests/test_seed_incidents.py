"""Offline source-boundary tests for the autonomous synthetic incident seed."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from urllib.parse import urlsplit

import httpx


ROOT = Path(__file__).resolve().parents[3]
SPEC = importlib.util.spec_from_file_location('ubuntu_incidents_seed', ROOT / 'deploy/ubuntu/seed_incidents.py')
seed_module = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(seed_module)
FIXTURES = ROOT / 'use-cases/incidents/observability-demo'


class Sources:
    """Small HTTP source double, keeping actual stored documents and metric data."""
    def __init__(self):
        self.indices = {}
        self.metrics = []
        self.writes = []
        self.calls = []
        self.drop_metrics = False
        self.fail_after_rows = None

    def handle(self, request):
        self.calls.append((request.method, str(request.url)))
        host, path = request.url.host, request.url.path
        if request.method in ('PUT', 'POST'):
            self.writes.append((request.method, str(request.url)))
        if host == 'opensearch':
            parts = path.strip('/').split('/')
            if request.method == 'GET' and len(parts) == 2 and parts[1] == '_mapping':
                if parts[0] not in self.indices:
                    return httpx.Response(404)
                return httpx.Response(200, json={parts[0]: {'mappings': self.indices[parts[0]]['mapping']}})
            if request.method == 'PUT' and len(parts) == 1:
                if parts[0] in self.indices:
                    return httpx.Response(400)
                self.indices[parts[0]] = {'mapping': json.loads(request.content)['mappings'], 'rows': {}}
                return httpx.Response(200, json={'acknowledged': True})
            if request.method == 'POST' and path == '/_bulk':
                lines = request.content.decode().splitlines()
                items = []
                for n in range(0, len(lines), 2):
                    operation = json.loads(lines[n])
                    assert list(operation) == ['create'], 'No overwriting operation is allowed'
                    meta = operation['create']
                    data = self.indices[meta['_index']]['rows']
                    row = json.loads(lines[n + 1])
                    if meta['_id'] in data:
                        items.append({'create': {'status': 409}})
                    elif self.fail_after_rows is not None and n // 2 >= self.fail_after_rows:
                        items.append({'create': {'status': 429}})
                    else:
                        data[meta['_id']] = row
                        items.append({'create': {'status': 201}})
                return httpx.Response(200, json={'errors': any(i['create']['status'] != 201 for i in items), 'items': items})
            if request.method == 'POST' and len(parts) == 2 and parts[1] == '_search':
                rows = self.indices[parts[0]]['rows']
                size = json.loads(request.content)['size']
                return httpx.Response(200, json={'timed_out': False, '_shards': {'failed': 0}, 'hits': {
                    'total': {'value': len(rows), 'relation': 'eq'},
                    'hits': [{'_id': key, '_source': row} for key, row in list(rows.items())[:size]]}})
        if host == 'victoriametrics':
            if request.method == 'GET' and path == '/api/v1/export':
                selector = request.url.params.get('match[]', '')
                rows = self.metrics
                if not selector.startswith('{'):
                    name = selector.split('{', 1)[0]
                    rows = [row for row in rows if row['metric']['__name__'] == name
                            and 'equipment=' + json.dumps(row['metric']['equipment']) in selector]
                return httpx.Response(200, text=''.join(json.dumps(row) + '\n' for row in rows))
            if request.method == 'POST' and path == '/api/v1/import':
                if not self.drop_metrics:
                    self.metrics.extend(json.loads(line) for line in request.content.decode().splitlines())
                return httpx.Response(204)
            if request.method == 'GET' and path == '/internal/force_flush':
                return httpx.Response(200)
        raise AssertionError('Unexpected endpoint: ' + str(request.url))


class SeedTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.output = Path(self.temp.name) / 'incidents/corpus.json'
        self.sources = Sources()
        self.client = httpx.Client(transport=httpx.MockTransport(self.sources.handle))
        self.addCleanup(self.client.close)

    def run_seed(self):
        return seed_module.seed('http://opensearch:9200', 'http://victoriametrics:8428', self.output,
                                FIXTURES, client=self.client)

    def test_empty_sources_become_complete_and_repeated_seed_preserves_every_row(self):
        report = self.run_seed()
        self.assertEqual((report['logs'], report['documents'], report['metrics_series'], report['metric_points']),
                         (960, 10, 20, 4200))
        self.assertFalse(report['albert_called'])
        self.assertFalse(report['existing_data_replaced'])
        original = self.output.read_bytes()
        self.assertEqual(self.output.stat().st_mode & 0o777, 0o600)
        rows = json.dumps(self.sources.indices, sort_keys=True)
        first_writes = len(self.sources.writes)
        self.run_seed()
        self.assertEqual(self.output.read_bytes(), original)
        self.assertEqual(json.dumps(self.sources.indices, sort_keys=True), rows)
        # Only verification POST searches occur on a second run.
        self.assertTrue(all(url.endswith('/_search') for _, url in self.sources.writes[first_writes:]))
        self.assertEqual({urlsplit(url).hostname for _, url in self.sources.calls}, {'opensearch', 'victoriametrics'})

    def test_fixture_keeps_hole_excluded_host_and_reference_window(self):
        manifest, indices, samples = seed_module.build_corpus(FIXTURES)
        self.assertEqual([h['equipment'] for h in manifest['hosts'] if h['allowed']],
                         ['OBS-RTR-01', 'OBS-RTR-02', 'OBS-RTR-03'])
        self.assertFalse(manifest['hosts'][-1]['allowed'])
        self.assertEqual(manifest['start'], '2026-09-28T10:00:00+02:00')
        self.assertEqual(manifest['baseline_end'], manifest['start'])
        for row in samples:
            expected = 120 if row['metric']['equipment'] == 'OBS-RTR-03' else 240
            self.assertEqual(len(row['timestamps']), expected)
            if expected == 120:
                hole_start = int((seed_module.BASE + seed_module.timedelta(hours=1)).timestamp() * 1000)
                hole_end = hole_start + 120 * 60000
                self.assertFalse(any(hole_start <= stamp < hole_end for stamp in row['timestamps']))
        excluded = [r for r in indices[seed_module.LOGS_INDEX] if r['equipment'] == 'OBS-RTR-04']
        self.assertEqual(len(excluded), 240)
        self.assertEqual(manifest['events_checked'], [])  # No invented Zabbix validation.

    def test_unowned_second_index_aborts_before_any_write_to_empty_first_index(self):
        self.sources.indices[seed_module.DOCS_INDEX] = {'mapping': {}, 'rows': {}}
        with self.assertRaises(seed_module.SeedError):
            self.run_seed()
        self.assertFalse(self.sources.writes)
        self.assertNotIn(seed_module.LOGS_INDEX, self.sources.indices)
        self.assertFalse(self.output.exists())

    def test_changed_document_is_not_overwritten(self):
        self.run_seed()
        self.sources.indices[seed_module.DOCS_INDEX]['rows']['INC-001']['text'] = 'Human modification'
        writes = len(self.sources.writes)
        with self.assertRaises(seed_module.SeedError):
            self.run_seed()
        self.assertEqual(self.sources.indices[seed_module.DOCS_INDEX]['rows']['INC-001']['text'], 'Human modification')
        self.assertTrue(all(url.endswith('/_search') for _, url in self.sources.writes[writes:]))

    def test_partial_bulk_failure_can_be_retried_without_replacing_records(self):
        self.sources.fail_after_rows = 12
        with self.assertRaises(seed_module.SeedError):
            self.run_seed()
        self.assertFalse(self.output.exists())
        self.assertEqual(len(self.sources.indices[seed_module.LOGS_INDEX]['rows']), 12)
        original = dict(self.sources.indices[seed_module.LOGS_INDEX]['rows'])
        self.sources.fail_after_rows = None
        self.run_seed()
        self.assertEqual(len(self.sources.indices[seed_module.LOGS_INDEX]['rows']), 960)
        for key, value in original.items():
            self.assertIs(self.sources.indices[seed_module.LOGS_INDEX]['rows'][key], value)

    def test_changed_metric_denies_before_creating_any_index(self):
        _, _, samples = seed_module.build_corpus(FIXTURES)
        self.sources.metrics = [samples[0]]
        self.sources.metrics[0]['values'][0] = 99.
        with self.assertRaises(seed_module.SeedError):
            self.run_seed()
        self.assertFalse(self.sources.writes)
        self.assertFalse(self.output.exists())

    def test_retention_dropping_old_points_cannot_publish_a_ready_manifest(self):
        self.sources.drop_metrics = True
        with self.assertRaises(seed_module.SeedError):
            self.run_seed()
        self.assertFalse(self.output.exists())

    def test_existing_manifest_conflict_fails_before_network(self):
        self.output.parent.mkdir(parents=True)
        self.output.write_text('{"synthetic":false}')
        with self.assertRaises(seed_module.SeedError):
            self.run_seed()
        self.assertFalse(self.sources.calls)

    def test_only_dedicated_compose_hosts_and_loopback_are_accepted(self):
        for url in ('https://opensearch:9200', 'http://real-si-rie:9200', 'http://opensearch:9200/index',
                    'http://user:password@opensearch:9200', 'http://opensearch:9200?x=1', 'http://127.0.0.1:80'):
            with self.subTest(url=url), self.assertRaises(seed_module.SeedError):
                seed_module.endpoint(url, 'opensearch', 9200)
        self.assertEqual(seed_module.endpoint('http://127.0.0.1:19200', 'opensearch', 9200), 'http://127.0.0.1:19200')

    def test_partial_metric_ingestion_only_adds_missing_points(self):
        _, _, samples = seed_module.build_corpus(FIXTURES)
        first = samples[0]
        self.sources.metrics = [{'metric': first['metric'], 'values': first['values'][:10],
                                 'timestamps': first['timestamps'][:10]}]
        self.run_seed()
        points = seed_module.metric_points(self.sources.metrics)
        self.assertEqual(len(points), 4200)
        self.assertEqual(sum(len(r['values']) for r in self.sources.metrics), 4200)

    def test_actual_incident_readers_accept_manifest_labels_and_keep_exclusion(self):
        for path in (FIXTURES, ROOT / 'core/access-control/src', ROOT / 'core/albert-client/src'):
            sys.path.insert(0, str(path))
        from obs_poc.config import Settings
        from obs_poc.clients import Sources as RuntimeSources
        from obs_poc.domain import context, QueryError
        self.run_seed()
        settings = Settings(manifest_path=self.output, metrics_provider='victoriametrics',
                            events_provider='itsm-ng-simulator', victoria='http://victoriametrics:8428',
                            metric_mapping=FIXTURES / 'fixtures/metric-mapping.json',
                            itsm_snapshot=FIXTURES / 'fixtures/itsm-tickets.json')
        manifest = settings.manifest()
        source = RuntimeSources(settings)
        source.http.close()
        source.http = self.client
        source.metric_transport = httpx.MockTransport(self.sources.handle)
        _, hosts = context(manifest, equipment='R1', start=manifest['start'], end=manifest['end'])
        samples = source.measurements(hosts[0], 'loss', manifest['start'], manifest['end'])
        self.assertEqual(len(samples), 120)
        self.assertTrue(any(row['value'] == 3 for row in samples))
        _, hole_hosts = context(manifest, equipment='R3', start=manifest['start'], end=manifest['end'])
        self.assertEqual(source.measurements(hole_hosts[0], 'loss', manifest['start'], manifest['end']), [])
        events = source.events(manifest['hosts'], manifest['start'], manifest['end'])
        self.assertEqual({row['eventid'] for row in events}, {'ITSM-001', 'ITSM-002', 'ITSM-003'})
        self.assertNotIn('ITSM-004', {row['eventid'] for row in events})
        with self.assertRaises(QueryError):
            context(manifest, equipment='R4', start=manifest['start'], end=manifest['end'])


if __name__ == '__main__':
    unittest.main()
