"""Qualification helpers cannot mistake assistant prose for real tool evidence."""
import importlib.util
import json
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch

MODULE = Path(__file__).resolve().parents[1] / 'qualification_openwebui.py'
spec = importlib.util.spec_from_file_location('qualification_openwebui_helpers', MODULE)
recipe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(recipe)


class ClientQualificationHelpers(unittest.TestCase):
    def test_oauth_browser_rejects_admin_and_pending_accounts_before_source_authorization(self):
        spec=importlib.util.spec_from_file_location('oauth_reader_checks',MODULE.parent/'tests/browser_oauth.py')
        browser=importlib.util.module_from_spec(spec);spec.loader.exec_module(browser)
        from types import SimpleNamespace
        from unittest.mock import Mock
        for role in ('admin','pending'):
            api=SimpleNamespace(token='',call=Mock(return_value={'id':'client-user','role':role,'token':'local-session'}))
            with self.subTest(role=role),self.assertRaises(ValueError):
                browser.login_reader(api,{'email':'fixture@example.org','password':'test-only'})
            self.assertEqual(api.token,'')
            self.assertEqual(api.call.call_count,1)

    def test_oauth_browser_uses_an_ordinary_account_for_user_visibility_checks(self):
        spec=importlib.util.spec_from_file_location('oauth_reader_checks_user',MODULE.parent/'tests/browser_oauth.py')
        browser=importlib.util.module_from_spec(spec);spec.loader.exec_module(browser)
        from types import SimpleNamespace
        from unittest.mock import Mock
        api=SimpleNamespace(token='',call=Mock(return_value={'id':'client-user','role':'user','token':'local-session'}))
        self.assertEqual(browser.login_reader(api,{'email':'fixture@example.org','password':'test-only'}),{'id':'client-user','role':'user'})
        self.assertEqual(api.token,'local-session')

    def test_incident_spacing_starts_after_a_long_previous_response(self):
        # The previous turn started at0, reserved admission later, and finished
        # at52. At61 the original start-based wait would already allow a turn.
        clock = [61.0]
        sleeps = []
        def sleep(seconds):
            sleeps.append(seconds)
            clock[0] += seconds
        recipe.wait_incident_interval(52.0, clock=lambda: clock[0], sleeper=sleep)
        self.assertEqual(clock[0], 113.0)
        self.assertEqual(sum(sleeps), 52.0)
        self.assertTrue(all(0 < seconds <= 5 for seconds in sleeps))

    def test_first_or_already_spaced_incident_does_not_wait(self):
        with patch.object(recipe.time, 'sleep') as sleep:
            recipe.wait_incident_interval(None, clock=lambda: 0, sleeper=sleep)
            recipe.wait_incident_interval(52.0, clock=lambda: 113.0, sleeper=sleep)
        sleep.assert_not_called()

    def test_native_output_must_be_linked_to_exactly_one_completed_expected_tool(self):
        result = {'route': 'opensearch', 'status': 'success', 'evidence': {'total': 2}}
        output = [{'type': 'function_call', 'status': 'completed', 'name': 'dinum-pdl-agent_investigate_pdl', 'call_id': 'actual'},
                  {'type': 'function_call_output', 'call_id': 'actual', 'output': [{'type': 'text', 'text': json.dumps(result)}]}]
        self.assertEqual(recipe.native_result(output), result)
        self.assertIsNone(recipe.native_result([{'type': 'message', 'content': json.dumps(result)}]))
        wrong = [*output[:1], {**output[1], 'call_id': 'another'}]
        self.assertIsNone(recipe.native_result(wrong))
        self.assertIsNone(recipe.native_result([*output, output[0]]))

    def test_individual_connection_has_no_forwarded_identity_or_unscoped_tool(self):
        for kind, tool in (('pdl', 'investigate_pdl'), ('incidents', 'diagnose_observability')):
            connection = recipe.connection(kind, 'individual-credential')
            self.assertEqual(connection['auth_type'], 'bearer')
            self.assertEqual(connection['key'], 'individual-credential')
            self.assertEqual(connection['headers'], {})
            self.assertEqual(connection['config']['function_name_filter_list'], tool)
            self.assertTrue(connection['url'].startswith('http://host.docker.internal:'))

    def test_private_files_are_new_0600_and_never_overwrite_existing_material(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'nested/private.env'
            recipe.private_write(path, 'private-test-value')
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
            with self.assertRaises(FileExistsError):
                recipe.private_write(path, 'replacement')
            self.assertEqual(path.read_text(), 'private-test-value')

    def test_lifecycle_refuses_a_foreign_same_named_container(self):
        with patch.object(recipe, 'docker', side_effect=['container-id', json.dumps([{'Config': {'Labels': {'owner': 'someone-else'}}}])]):
            with self.assertRaises(ValueError):
                recipe.owned(object(), 'rie-client-qualification-alice')

    def test_client_prose_and_unknown_citations_cannot_validate_a_report(self):
        result = {'application': 'observability', 'status': 'ok', 'answer': 'Fait observé [S99]',
                  'sources': [{'source_id': 'S1'}]}
        message = {'content': 'Autre texte généré par le client', 'output': [
            {'type': 'function_call', 'status': 'completed', 'name': 'obs-gptoss_diagnose_observability', 'call_id': 'real'},
            {'type': 'function_call_output', 'call_id': 'real', 'output': [{'text': json.dumps(result)}]}]}
        report = {'browser_posts': 1, 'turn_limit': 12, 'cases': [
            {'case': 'incident_r1', 'turns': [{'result': result, 'message': message}]}]}
        checks = {row['name']: row['passed'] for row in recipe.evaluate_report(report)}
        self.assertTrue(checks['one_completed_native_tool_per_turn'])
        self.assertFalse(checks['incident_citations_reference_real_tool_sources'])
        self.assertFalse(checks['incident_r1_visible_server_report_preserved'])

    def test_turn_budget_is_an_acceptance_condition(self):
        checks = {row['name']: row['passed'] for row in recipe.evaluate_report({
            'browser_posts': 13, 'turn_limit': 12, 'cases': []})}
        self.assertFalse(checks['browser_post_budget'])

    def test_incident_follow_up_uses_native_receipts_and_compares_instants(self):
        def turn(result):
            return {'message':{'output':[
                {'type':'function_call','status':'completed','name':'site_diagnose_observability','call_id':'actual'},
                {'type':'function_call_output','call_id':'actual','output':[{'text':json.dumps(result)}]}]}}
        base={'application':'observability','status':'ok','analysis':{'situation':'Hypothèse'},
            'review':{'valid':True},'context':{'equipment_ids':['OBS-RTR-01']},
            'request_id':'first','read_at':'2026-11-09T10:00:00+00:00'}
        final={**base,'request_id':'second','read_at':'2026-11-09T10:02:00+00:00',
            'analysis':None,'synthesis_mode':'source_facts','usage':[],'dialogue':{'albert_calls':0},
            'answer':'**Oui : l’événement était déjà résolu à 12h00.**\n**Non : le ticket n’était pas encore clôturé à 12h00.**',
            'events':[{'end':'2026-09-28T09:30:00+00:00','ticket':{'closed_at':'2026-09-28T12:15:00+02:00'}}]}
        self.assertTrue(all(c['passed'] for c in recipe.incident_follow_up_checks([turn(base),turn(final)])))
        for changed in ({'context':{'equipment_ids':['OBS-RTR-02']}},{'request_id':'first','read_at':base['read_at']},
                        {'events':[]},{'status':'partial'},{'synthesis_mode':'generated'},{'usage':[{'model':'unexpected'}]},
                        {'dialogue':{'albert_calls':1}}):
            self.assertFalse(all(c['passed'] for c in recipe.incident_follow_up_checks([turn(base),turn({**final,**changed})])))
        self.assertFalse(any(c['passed'] for c in recipe.incident_follow_up_checks([
            {'message':{'content':json.dumps(final)}},{'message':{'content':json.dumps(final)}}])))

    def test_pdl_clarification_requires_the_server_question_in_both_client_renderings(self):
        question = 'Sur quelle période souhaitez-vous consulter le PDL ?'
        result = {'status': 'needs_clarification', 'route': None, 'clarification': question,
                  'assistant_contract': 'server-dialogue-v1', 'evidence': None}
        tool_output = [
            {'type': 'function_call', 'status': 'completed', 'name': 'dinum-pdl-agent_investigate_pdl', 'call_id': 'real'},
            {'type': 'function_call_output', 'call_id': 'real', 'output': [{'text': json.dumps(result)}]}]
        native_message = {'type': 'message', 'role': 'assistant', 'status': 'completed',
                          'content': [{'type': 'output_text', 'text': question}]}
        cases = [
            ({'content': '', 'output': tool_output}, False),
            ({'content': question, 'output': tool_output}, False),
            ({'content': question, 'output': [*tool_output, {**native_message, 'content': [
                {'type': 'output_text', 'text': 'Fonction lancée.'}]}]}, False),
            ({'content': question, 'output': [*tool_output, {**native_message, 'status': 'in_progress'}]}, False),
            ({'content': question, 'output': [*tool_output, native_message]}, True),
        ]
        for message, expected in cases:
            with self.subTest(message=message):
                report = {'cases': [{'case': 'pfs_clarification', 'turns': [
                    {'business_status': 'needs_clarification', 'result': result, 'message': message}]}]}
                checks = {row['name']: row['passed'] for row in recipe.evaluate_report(report)}
                self.assertEqual(checks['pdl_clarification_visible_server_question_preserved'], expected)

    def test_incident_generation_needs_actual_draft_review_and_usage(self):
        result={'status':'ok','synthesis_mode':'generated','analysis':{'situation':'Observation'},
            'review':{'valid':True},'usage':[{'stage':stage,'actual_model':'gpt-oss-120b','total_tokens':10}
                for stage in ('draft','review')], 'ticket_history':{'provider':'itsm-ng'},
            'proposed_solution':{'state':'proposed'}}
        self.assertTrue(all(c['passed'] for c in recipe.generation_checks(result,'incidents',require_itsm=True)))
        for change in ({'synthesis_mode':'disabled'},{'synthesis_mode':'source_facts'},{'status':'partial'},
                       {'analysis':None},{'review':{'valid':False}},{'usage':[]},
                       {'usage':[{'stage':'draft','model':'configured-only'}]},
                       {'ticket_history':{'provider':'fixture'}},{'proposed_solution':{'state':'review_unavailable'}}):
            with self.subTest(change=change):
                self.assertFalse(all(c['passed'] for c in recipe.generation_checks({**result,**change},'incidents',require_itsm=True)))

    def test_pdl_generation_needs_real_planner_and_dialogue_receipts(self):
        result={'status':'success','evidence':{'total':2},
            'planner':{'kind':'AlbertPlanner','returned_model':'gpt-oss-120b'},
            'dialogue':{'albert_calls':1,'actual_model':'gpt-oss-120b'}}
        self.assertTrue(all(c['passed'] for c in recipe.generation_checks(result,'pdl')))
        for change in ({'planner':{'kind':'FakePlanner','returned_model':'mock'}},
                       {'planner':{'kind':'AlbertPlanner','configured_model':'gpt-oss-120b'}},
                       {'dialogue':{'albert_calls':0,'actual_model':'gpt-oss-120b'}},{'evidence':None}):
            with self.subTest(change=change):
                self.assertFalse(all(c['passed'] for c in recipe.generation_checks({**result,**change},'pdl')))

    def test_provider_env_parser_keeps_values_private_and_does_not_execute_shell(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / '.env'
            path.write_text('# comment\nURL="https://provider.invalid/v1"\nVALUE=literal$(not-executed)\n')
            result = recipe.env_file(path)
            self.assertEqual(result['URL'], 'https://provider.invalid/v1')
            self.assertEqual(result['VALUE'], 'literal$(not-executed)')


if __name__ == '__main__':
    unittest.main()
