"""Individual portal sessions preserve the backend's authorization boundary."""
from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import httpx

ROOT = Path(__file__).resolve().parents[3]
for relative in ('deploy/ubuntu', 'core/access-control/src'):
    sys.path.insert(0, str(ROOT / relative))
from dinum_access import AccessDenied, AccessGate
from portal.backend import Session, PortalError, PDL_INDICES


class Directory:
    def __init__(self):
        self.kinds = {'alice': 'internal', 'bruno': 'internal', 'eric': 'external', 'unknown': None}
        self.subjects = {'alice': 'alice-object-original', 'bruno': 'bruno-object-original', 'eric': 'eric-object-original'}
        self.available = True

    def lookup(self, value, *, username=False, password=None, identity=False, authorization=False):
        name = value if username else value.split('@', 1)[0]
        if not self.available:
            raise AccessDenied('directory_unavailable_or_denied')
        kind = self.kinds.get(name)
        if kind is None or password is not None and password != 'fictional-password':
            raise AccessDenied('unclassified_identity')
        result = (name + '@rie.invalid', kind)
        result = (*result, self.subjects[name]) if identity else result
        return (*result, name == 'alice' and kind == 'internal') if authorization else result


class PortalBackendTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.state = self.root / 'access'
        self.state.mkdir()
        self.key = self.root / 'session.key'
        self.key.write_text('synthetic-session-material-of-at-least-32-characters')
        self.policy = {'version': 1, 'revision': 1, 'default': 'blocked',
                       'indices': {**{name: 'authenticated' for name in PDL_INDICES},
                                   'pdl-zabbix-observability-demo': 'internal', 'obs-network-docs': 'internal'},
                       'resources': {'incidents.metrics': 'internal', 'incidents.tickets': 'internal'}}
        (self.state / 'policy.json').write_text(json.dumps(self.policy))
        self.directory = Directory()
        self.config = {'version': 1, 'ldap': {}, 'state_directory': str(self.state),
                       'session_key_file': str(self.key), 'allow_webui_assertions': False}
        self.gate = lambda: AccessGate(self.config, self.directory)
        self.transport_calls = []
        self.responses = lambda request: httpx.Response(200, json={'status': 'ok'})

    def tearDown(self):
        self.temporary.cleanup()

    def session(self, name='alice'):
        def response(request):
            self.transport_calls.append(request)
            return self.responses(request)
        session = Session(gate_factory=self.gate,
                          client_factory=lambda **kwargs: httpx.Client(transport=httpx.MockTransport(response), **kwargs))
        session.login(name, 'fictional-password')
        return session

    def test_internal_reader_keeps_source_access_without_administration(self):
        session = self.session('bruno')
        identity = session.identity()
        self.assertEqual(identity['category'], 'internal')
        self.assertFalse(identity['administrator'])
        self.assertIn('obs-network-docs', session.own_access()['allowed_indices'])
        with self.assertRaisesRegex(AccessDenied, 'administrator_required'):
            session.policy()
        with self.assertRaisesRegex(AccessDenied, 'administrator_required'):
            session.change_policy('rie-pfs-fixture', 'blocked', 1)
        self.assertEqual(self.transport_calls, [])

    def test_two_clients_keep_distinct_identity_and_do_not_expose_session_in_repr(self):
        internal, external = self.session(), self.session('eric')
        self.assertNotEqual(internal.token, external.token)
        self.assertEqual(internal.own_access()['category'], 'internal')
        self.assertEqual(external.own_access()['category'], 'external')
        self.assertIn('obs-network-docs', internal.own_access()['allowed_indices'])
        self.assertNotIn('obs-network-docs', external.own_access()['allowed_indices'])
        self.assertNotIn(internal.token, repr(internal))
        internal.logout()
        self.assertEqual(external.identity()['email'], 'eric@rie.invalid')
        with self.assertRaises(AccessDenied):
            internal.own_access()

    def test_failed_or_unclassified_login_never_creates_a_session(self):
        session = Session(gate_factory=self.gate)
        with self.assertRaises(AccessDenied):
            session.login('unknown', 'fictional-password')
        self.assertEqual(session.token, '')
        with self.assertRaises(AccessDenied):
            session.login('alice', 'bad-password')
        self.assertEqual(session.token, '')

    def test_expired_session_is_removed_before_a_read(self):
        session = self.session()
        with patch('dinum_access.security.time.time', return_value=time.time() + 1000):
            with self.assertRaises(AccessDenied):
                session.own_access()
        self.assertEqual(session.token, '')
        self.assertEqual(self.transport_calls, [])

    def test_group_change_and_ldap_outage_are_rechecked_for_each_action(self):
        session = self.session()
        self.assertEqual(session.policy()['revision'], 1)
        self.directory.kinds['alice'] = 'external'
        with self.assertRaises(AccessDenied):
            session.policy()
        self.assertEqual(session.own_access()['category'], 'external')
        self.directory.available = False
        with self.assertRaises(AccessDenied):
            session.diagnose()
        self.assertEqual(self.transport_calls, [])
        self.assertEqual(session.token, '')

    def test_source_policy_change_preserves_indices_and_is_visible_to_each_session(self):
        internal, external = self.session(), self.session('eric')
        before = internal.policy()
        changed = internal.change_policy('incidents.metrics', 'authenticated', before['revision'], resource=True)
        self.assertEqual(changed['indices'], before['indices'])
        self.assertEqual(changed['resources']['incidents.tickets'], 'internal')
        self.assertIn('incidents.metrics', external.own_access()['allowed_resources'])
        self.assertNotIn('incidents.tickets', external.own_access()['allowed_resources'])
        with self.assertRaises(AccessDenied):
            internal.change_policy('incidents.tickets', 'authenticated', before['revision'], resource=True)
        removed = internal.change_policy('incidents.metrics', 'blocked', changed['revision'], resource=True)
        self.assertNotIn('incidents.metrics', external.own_access()['allowed_resources'])
        self.assertGreater(removed['revision'], changed['revision'])

    def test_source_administration_rechecks_role_and_does_not_accept_an_index_as_resource(self):
        internal, external = self.session(), self.session('eric')
        before = internal.policy()
        with self.assertRaises(AccessDenied):
            external.change_policy('incidents.metrics', 'authenticated', before['revision'], resource=True)
        with self.assertRaises(AccessDenied):
            internal.change_policy('obs-network-docs', 'authenticated', before['revision'], resource=True)
        self.directory.kinds['alice'] = 'external'
        with self.assertRaises(AccessDenied):
            internal.change_policy('incidents.metrics', 'authenticated', before['revision'], resource=True)
        self.assertEqual(json.loads((self.state/'policy.json').read_text()), before)

    def test_recreated_directory_object_invalidates_only_its_old_session(self):
        session, other = self.session(), self.session('eric')
        previous = session.token
        self.directory.subjects['alice'] = 'alice-object-recreated'
        with self.assertRaisesRegex(AccessDenied, 'directory_identity_changed'):
            session.diagnose()
        self.assertEqual(session.token, '')
        self.assertEqual(self.transport_calls, [])
        self.assertEqual(other.identity()['email'], 'eric@rie.invalid')
        session.login('alice', 'fictional-password')
        self.assertNotEqual(session.token, previous)
        self.assertTrue(session.identity()['administrator'])

    def test_policy_edits_require_internal_group_and_current_revision(self):
        session = self.session()
        changed = session.change_policy('rie-tacacs-fixture', 'internal', 1)
        self.assertEqual(changed['revision'], 2)
        with self.assertRaises(AccessDenied) as conflict:
            session.change_policy('rie-tacacs-fixture', 'authenticated', 1)
        self.assertEqual(conflict.exception.code, 'policy_conflict_reload')
        external = self.session('eric')
        with self.assertRaises(AccessDenied):
            external.change_policy('rie-tacacs-fixture', 'authenticated', 2)
        self.assertEqual(session.policy()['indices']['rie-tacacs-fixture'], 'internal')

    def test_local_catalogue_contains_only_currently_authorized_active_indices(self):
        catalog = self.root / 'pdl/catalog'
        catalog.mkdir(parents=True)
        (catalog / 'approved.json').write_text(json.dumps([
            {'active': True, 'index': 'rie-pfs-fixture', 'concepts': {'equipment': {'field': 'observer.name'}}},
            {'active': True, 'index': 'obs-network-docs', 'concepts': {'private': {}}},
            {'active': False, 'index': 'rie-bb-fixture', 'concepts': {'historical': {}}},
        ]))
        with patch.dict(os.environ, {'PDL_DATA_DIR': str(self.root / 'pdl')}):
            result = self.session('eric').catalogue()
        self.assertEqual([row['index'] for row in result], ['rie-pfs-fixture'])
        self.assertEqual(result[0]['concepts']['equipment']['field'], 'observer.name')

    def test_dated_recipe_is_not_published_after_one_required_index_is_revoked(self):
        receipt = self.root / 'acceptance.json'
        receipt.write_text(json.dumps({'at_utc': '2026-11-06T10:00:00Z', 'generation': 'not_tested',
                                      'pdl': {'results': [{'synthetic': True}]}}))
        session = self.session('eric')
        with patch.dict(os.environ, {'RIE_ACCEPTANCE_FILE': str(receipt)}):
            result = session.pdl_receipt()
            self.assertFalse(result['fresh_investigation'])
            self.assertEqual(result['captured_at_utc'], '2026-11-06T10:00:00Z')
            self.session().change_policy('rie-tacacs-fixture', 'internal', 1)
            with self.assertRaises(AccessDenied):
                session.pdl_receipt()

    def test_transport_forwards_only_the_individual_session_and_disables_synthesis(self):
        session = self.session('eric')
        with patch.dict(os.environ, {'MCP_TOKEN': 'shared-service-credential-must-not-be-used'}):
            result = session.diagnose()
        request = self.transport_calls[0]
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(request.headers['authorization'], 'Bearer ' + session.token)
        self.assertNotIn('x-openwebui-user-jwt', request.headers)
        self.assertNotIn('shared-service', request.headers['authorization'])
        self.assertFalse(json.loads(request.content)['synthesize'])

    def test_response_from_a_logged_out_session_is_discarded(self):
        session = self.session()
        def response(request):
            session.logout()
            return httpx.Response(200, json={'status': 'ok', 'evidence': 'must-not-be-published'})
        self.responses = response
        with self.assertRaises(PortalError) as refused:
            session.diagnose()
        self.assertEqual(refused.exception.code, 'session_changed')

    def test_http_errors_and_untrusted_error_bodies_do_not_reach_the_browser(self):
        session = self.session()
        for status in (403, 500):
            self.responses = lambda request, status=status: httpx.Response(status, json={'message': 'private-source-or-credential'})
            with self.subTest(status=status), self.assertRaises(PortalError) as error:
                session.diagnose()
            self.assertNotIn('private-source', str(error.exception))

    def test_mcp_followup_is_scoped_to_the_current_client_and_reset_on_login(self):
        self.responses = lambda request: httpx.Response(200, json={'jsonrpc': '2.0', 'id': 1, 'result': {
            'structuredContent': {'status': 'needs_clarification', 'continuation_token': 'server-owned-next'}}})
        internal, external = self.session(), self.session('eric')
        internal.pdl('Question initiale')
        internal.pdl('Précision', resume=True)
        external.pdl('Autre question', resume=True)
        internal.logout()
        internal.login('alice', 'fictional-password')
        internal.pdl('Nouvelle question', resume=True)
        tokens = [json.loads(request.content)['params']['arguments']['continuation_token'] for request in self.transport_calls]
        self.assertEqual(tokens, ['', 'server-owned-next', '', ''])

    def test_logout_during_slow_ldap_login_cannot_reactivate_the_session(self):
        session = Session(gate_factory=self.gate)
        gate = self.gate()
        original = gate.login
        def interrupted_login(username, password):
            token = original(username, password)
            session.logout()
            return token
        gate.login = interrupted_login
        session.gate_factory = lambda: gate
        with self.assertRaises(PortalError) as cancelled:
            session.login('alice', 'fictional-password')
        self.assertEqual(cancelled.exception.code, 'session_changed')
        self.assertEqual(session.token, '')

    def test_malformed_mcp_envelopes_produce_a_controlled_failure(self):
        session = self.session()
        malformed = [{'result': None}, {'result': []},
                     {'result': {'content': None}}, {'result': {'content': ['bad-row']}}]
        for payload in malformed:
            self.responses = lambda request, payload=payload: httpx.Response(200, json=payload)
            with self.subTest(payload=payload), self.assertRaises(PortalError) as failure:
                session.pdl('Quels sont mes droits ?')
            self.assertEqual(failure.exception.code, 'backend_response_invalid')

    def test_malformed_local_catalogue_and_recipe_fail_without_attribute_errors(self):
        session = self.session()
        catalog = self.root / 'pdl/catalog'
        catalog.mkdir(parents=True)
        (catalog / 'approved.json').write_text('["not-a-catalogue-entry"]')
        receipt = self.root / 'acceptance.json'
        receipt.write_text('[]')
        with patch.dict(os.environ, {'PDL_DATA_DIR': str(self.root / 'pdl'), 'RIE_ACCEPTANCE_FILE': str(receipt)}):
            for operation in (session.catalogue, session.pdl_receipt):
                with self.subTest(operation=operation.__name__), self.assertRaises(PortalError) as failure:
                    operation()
                self.assertEqual(failure.exception.code, 'local_state_unavailable')

    def test_invalid_question_makes_no_backend_call(self):
        with self.assertRaises(PortalError):
            self.session().pdl('')
        self.assertEqual(self.transport_calls, [])


if __name__ == '__main__':
    unittest.main()
