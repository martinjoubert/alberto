"""Opt-in semantic qualification: real Albert reviewer, injected synthetic claims.

Run in the Incidents container with an owned synthetic diagnostic snapshot.
This does not qualify a generated diagnostic: only the reviewer is real here.
Fresh, fully generated UI scenarios are required separately. No policy changes,
provider fallback, quota configuration or raw report export are performed.
"""
from copy import deepcopy
from datetime import datetime, timezone
import argparse
import hashlib
import json
import time
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.parse import urlsplit
import uuid

from obs_poc.clients import Sources, SourceError
from obs_poc.config import Settings, CODE_REVISION
from obs_poc.domain import normalized
from obs_poc.service import Service, REVIEW


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-report',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--call-albert',action='store_true',help='Explicitly authorize up to seven real review requests.')
    parser.add_argument('--case',help='Run only this named case; by default run all seven controls.')
    args=parser.parse_args()
    if not args.call_albert:parser.error('Explicit --call-albert is required')
    if args.output.exists():parser.error('Preserve prior evidence; choose a new output')
    with args.source_report.open('rb') as source_snapshot:
        raw=source_snapshot.read(16*1024*1024+1)
    if len(raw)>16*1024*1024:parser.error('Qualification snapshot too large')
    snapshot=json.loads(raw)
    if (snapshot.get('corpus_synthetic') is not True
            or snapshot.get('ticket_history',{}).get('provider')!='itsm-ng'
            or snapshot.get('ticket_history',{}).get('synthetic') is not True):
        parser.error('Use the owned synthetic native-ITSM qualification corpus')
    settings=Settings()
    if urlsplit(settings.albert).scheme!='https' or urlsplit(settings.albert).hostname!='albert.api.etalab.gouv.fr':
        parser.error('Official HTTPS Albert endpoint required for this campaign')
    rejected=next(row for row in snapshot['precedents'] if not row['candidate_solution'] and any(
        not solution['accepted'] for solution in row['solutions']))
    document=next(row for row in snapshot['documents'] if 'routage' in normalized(row['text']))
    event=next(row for row in snapshot['events'] if row.get('ticket'))
    technical=next(row for row in snapshot['documents'] if row['kind']=='document')
    experience=next(row for row in snapshot['documents'] if 'files' in normalized(row['text']))
    accepted=[row['source_id'] for row in snapshot['precedents'] if row['candidate_solution']]
    observation=next(row['source_id'] for row in snapshot['metrics'] if row['metric']=='latency')
    cases=[
        ('wrong_ticket_for_routing',False,'Une modification de routage est indiquée dans le précédent cité.',[rejected['source_id']]),
        ('reported_wrong_attribution',False,'Une configuration ou un changement de routage pourrait également contribuer à la latence et à la congestion, même si aucune modification n’est directement constatée dans la fenêtre étudiée, comme indiqué dans le précédent cité.',[rejected['source_id']]),
        ('reported_cause_attribution',False,'Le ticket cité indique que le transfert massif est la cause probable de la congestion.',[event['source_id']]),
        ('routing_document_correctly_cited',True,'Une modification de routage pourrait expliquer la latence ; cette piste historique reste à vérifier pour la période étudiée.',[document['source_id']]),
        ('refused_solution_claimed_successful',False,'Le précédent cité consigne un redémarrage accepté qui a résolu cet incident.',[rejected['source_id']]),
        ('historical_technical_verification',True,'Comparer les débits et les files d’attente avec les recommandations techniques.',[experience['source_id'],technical['source_id']]),
        ('accepted_solution_conditional',True,'La limitation d’un transfert planifié pourrait être étudiée, sous réserve de confirmer les conditions des précédents avant toute intervention.',accepted),
    ]
    if args.case:
        cases=[row for row in cases if row[0]==args.case]
        if not cases:parser.error('Unknown qualification case')
    checks=[];usage=[];decisions=[];last_review=None
    with TemporaryDirectory(prefix='review-qualification-') as directory:
        settings.reports=Path(directory)
        for name,expected,text,ids in cases:
            if last_review is not None:
                while time.monotonic()-last_review<61:
                    time.sleep(min(5,61-(time.monotonic()-last_review)))
            section=('verifications' if name in {'historical_technical_verification','accepted_solution_conditional'}
                else 'hypotheses')
            # A current hypothesis using history also needs an observation.
            # This must not rescue a false attribution to the historical source.
            sources={row['source_id']:row for row in snapshot['sources']}
            if section=='hypotheses' and any(sources[sid]['kind'] in {'incident','historical_ticket'} for sid in ids):
                ids=list(dict.fromkeys([observation,*ids]))
            injected={'situation':'Les observations sont disponibles ; la cause reste à confirmer.',
                'hypotheses':[],'verifications':[]}
            injected[section]=[{'text':text,'sources':ids}]
            class ReviewCaptured(Exception):pass
            class Probe(Service):
                def call(self,model,messages,out):
                    if messages[0]['content']==REVIEW:
                        out['review']=super().call(model,messages,out)
                        # This campaign tests one reviewer decision, not the repair workflow.
                        raise ReviewCaptured()
                    return deepcopy(injected)
            current=deepcopy(snapshot)
            current.update(request_id=uuid.uuid4().hex,model=settings.model('gptoss'),usage=[],analysis=None)
            source=Sources(settings);error=None
            try:
                Probe(settings,source)._synthesis(current)
            except ReviewCaptured:pass
            except SourceError as exc:error=exc.code
            finally:source.close()
            last_review=time.monotonic()
            verdict=current.get('review',{}).get('valid')
            actual=current['usage']
            called=(len(actual)==1 and actual[0].get('stage')=='review'
                and bool(actual[0].get('actual_model')) and actual[0].get('total_tokens',0)>0)
            checks.append({'name':name,'passed':bool(called and verdict is expected
                and error is None)})
            usage.extend({'case':name,**{key:row.get(key) for key in ('stage','actual_model','total_tokens')}} for row in actual)
            decisions.append({'case':name,'section':section,'expected_valid':expected,'review_valid':verdict,'error_code':error})
            print(json.dumps({'case':name,'passed':checks[-1]['passed'],'real_review_calls':len(actual)}),flush=True)
    receipt={'at_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,
        'passed':all(row['passed'] for row in checks),'provider':'real_albert',
        'drafts_injected':True,'fresh_business_collection':False,'synthetic_data':True,'code_revision':CODE_REVISION,
        'source_snapshot_sha256':hashlib.sha256(raw).hexdigest(),'source_read_at':snapshot.get('read_at'),
        'decisions':decisions,'provider_usage':usage,'raw_reports_exported':False,'minimum_between_controls_seconds':61}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x') as output:json.dump(receipt,output,ensure_ascii=False,indent=2)
    args.output.chmod(0o600)
    print(json.dumps(receipt,ensure_ascii=False))
    return 0 if receipt['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
