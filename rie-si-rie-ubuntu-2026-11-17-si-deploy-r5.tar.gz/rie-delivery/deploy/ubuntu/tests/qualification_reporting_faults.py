"""Exercise reporting with intentional failures, never business/SI validation.

This explicitly invoked qualification tool is outside test_*.py discovery.
Its children must fail; its own success means those failures were retained.
No backend, provider, LDAP, browser or VM is started by the default campaign.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import logging
import os
from pathlib import Path
import socket
import subprocess
import sys
from threading import Event
import time
import unittest

ROOT = Path(__file__).resolve().parents[3]
REPORTER = ROOT/'deploy/ubuntu/test_reporting.py'
PASSWORD = 'do-not-publish-fixture-value'
ENV_KEY = 'do-not-publish-env-key'
TOKEN = 'dinum_ut1_' + 'a'*32 + '_' + 'b'*43
BEARER = 'c'*64


def reporter():
    spec = importlib.util.spec_from_file_location('fault_reporting', REPORTER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def no_network(*_args, **_kwargs):
    raise AssertionError('Network is forbidden in the reporting fault campaign')


def emit_diagnostics():
    print('FAULT_STDOUT_MARKER password='+PASSWORD)
    print('ALBERT_API_KEY='+ENV_KEY+' OPENSEARCH_PASSWORD='+PASSWORD)
    print('FAULT_STDERR_MARKER Authorization: Bearer '+BEARER, file=sys.stderr)
    logging.getLogger('qualification.intentional-faults').warning('FAULT_LOG_MARKER api_key=%s', TOKEN)


def unittest_faults(reporting, output):
    class CommonFaults(unittest.TestCase):
        def test_positive_control(self):
            self.assertEqual(2+2, 4)

        def test_assertion_expected_actual(self):
            emit_diagnostics()
            self.assertEqual({'status':'unavailable'}, {'status':'ready'},
                             'SIMULATED_EXPECTED_READY_ACTUAL_UNAVAILABLE')

        def test_runtime_exception(self):
            emit_diagnostics()
            raise RuntimeError('SIMULATED_OPENSEARCH_UNAVAILABLE')

        def test_provider_timeout(self):
            logging.getLogger('qualification.intentional-faults').warning('FAULT_TIMEOUT_MARKER provider=fictive delay_ms=50 timeout_ms=2')
            with ThreadPoolExecutor(max_workers=1) as executor:
                pending = executor.submit(Event().wait, .05)
                try:
                    pending.result(timeout=.002)
                except FutureTimeout as error:
                    raise TimeoutError('SIMULATED_PROVIDER_TIMEOUT deadline_ms=2') from error

        def test_subtest_failure_followed_by_skip(self):
            for step in ('failed', 'skipped', 'passed'):
                with self.subTest(step=step):
                    if step == 'failed':
                        self.fail('SIMULATED_SUBTEST_FAILURE_MUST_SURVIVE')
                    elif step == 'skipped':
                        self.skipTest('later skip must not hide failure')
                    else:
                        self.assertTrue(True)

        @unittest.skip('SIMULATED_PLATFORM_NOT_AVAILABLE')
        def test_skipped(self):
            self.fail('unreachable')

        @unittest.expectedFailure
        def test_expected_failure(self):
            self.fail('SIMULATED_KNOWN_FAILURE')

        @unittest.expectedFailure
        def test_unexpected_success(self):
            self.assertTrue(True)

        def test_bounded_logs(self):
            print('FAULT_TRUNCATION_MARKER '+('x'*90_000))
            self.fail('SIMULATED_VERBOSE_FAILURE')

    class SetupFailure(unittest.TestCase):
        def setUp(self):
            print('FAULT_SETUP_MARKER')
            raise RuntimeError('SIMULATED_SETUP_UNAVAILABLE')

        def test_never_reached(self):
            self.fail('unreachable')

    class TeardownFailure(unittest.TestCase):
        def tearDown(self):
            print('FAULT_TEARDOWN_MARKER')
            raise RuntimeError('SIMULATED_TEARDOWN_FAILURE')

        def test_call_succeeds_but_teardown_fails(self):
            self.assertTrue(True)

    class ClassSetupFailure(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            print('FAULT_CLASS_SETUP_MARKER')
            raise RuntimeError('SIMULATED_CLASS_SETUP_UNAVAILABLE')

        def test_never_reached(self):
            self.fail('unreachable')

    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(cls)
                               for cls in (CommonFaults, SetupFailure, TeardownFailure, ClassSetupFailure))
    result = unittest.TextTestRunner(stream=io.StringIO(), resultclass=reporting.ReportingResult).run(suite)
    valid = reporting.write_unittest(result, 'Épreuves unittest', output/'unittest.xml', output.parent/'allure-results')
    return 0 if valid else 1


PYTEST_CASES = '''import logging,sys,pytest
PASSWORD='do-not-publish-fixture-value'
ENV_KEY='do-not-publish-env-key'
BEARER='c'*64
TOKEN='dinum_ut1_'+'a'*32+'_'+'b'*43
def test_pytest_assertion():
    print('PYTEST_STDOUT_MARKER password='+PASSWORD)
    print('ALBERT_API_KEY='+ENV_KEY+' OPENSEARCH_PASSWORD='+PASSWORD)
    print('PYTEST_STDERR_MARKER Authorization: Bearer '+BEARER,file=sys.stderr)
    logging.getLogger('qualification.intentional-faults').warning('PYTEST_LOG_MARKER api_key=%s',TOKEN)
    assert {'status':'unavailable'} == {'status':'ready'}, 'SIMULATED_PYTEST_EXPECTED_READY'
@pytest.fixture
def unavailable():
    print('PYTEST_SETUP_MARKER')
    raise RuntimeError('SIMULATED_PYTEST_SETUP_FAILURE')
def test_pytest_setup(unavailable):pass
@pytest.fixture
def teardown_failure():
    yield
    print('PYTEST_TEARDOWN_MARKER')
    raise RuntimeError('SIMULATED_PYTEST_TEARDOWN_FAILURE')
def test_pytest_teardown(teardown_failure):assert True
def test_pytest_exception():raise ValueError('SIMULATED_PYTEST_EXCEPTION')
@pytest.mark.skip(reason='SIMULATED_PYTEST_SKIP')
def test_pytest_skip():pass
'''


def child(mode, output):
    output.mkdir(parents=True, exist_ok=True, mode=0o700)
    reporting = reporter()
    for name in ('connect', 'connect_ex'):
        setattr(socket.socket, name, no_network)
    socket.create_connection = socket.getaddrinfo = no_network
    if mode == 'unittest':
        return unittest_faults(reporting, output)
    if mode == 'terminated':
        campaign = reporting.Campaign(output.parent/'allure-results', 'Processus interrompu',
                                      description='Épreuve négative : interruption volontaire par SIGTERM')
        campaign.checkpoint('Before SIGTERM: waiting after a successful positive control')
        reporting.write_result(output.parent/'allure-results', 'Processus interrompu',
                               'test_before_interruption', 'passed', message='Positive control before SIGTERM')
        (output/'ready').write_text('ready')
        Event().wait(60)
        return 0
    import pytest
    code = {'pytest':PYTEST_CASES,
            'empty':'VALUE = 1\n',
            'collection':"raise ImportError('SIMULATED_COLLECTION_IMPORT_FAILURE')\n",
            'interrupted':"import pytest\ndef test_interrupted():pytest.exit('SIMULATED_CAMPAIGN_INTERRUPTED',returncode=2)\n"}[mode]
    fixture = output/'fault_cases.py'
    fixture.write_text(code)
    plugin = reporting.PytestResults(output.parent/'allure-results', 'Épreuves pytest '+mode)
    try:
        return int(pytest.main([str(fixture), '-q', '--confcutdir='+str(output), '-p', 'no:cacheprovider',
                               '--junitxml='+str(output/'pytest.xml')], plugins=[plugin]))
    finally:
        plugin.finish()


def run_campaign(output, python):
    if output.exists():
        raise ValueError('Use a new directory for each fault campaign')
    output.mkdir(parents=True, mode=0o700)
    adapter_sha256 = hashlib.sha256(REPORTER.read_bytes()).hexdigest()
    environment = {k:v for k,v in os.environ.items() if k != 'PYTHONPATH' and not k.startswith(
        ('ALBERT_', 'OPENAI_', 'DINUM_', 'PDL_', 'OBS_', 'OTEL_', 'MCP_', 'OPENSEARCH_', 'VICTORIAMETRICS_', 'ZABBIX_'))}
    environment.update(PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    records = []
    for mode in ('unittest', 'pytest', 'empty', 'collection', 'interrupted', 'terminated'):
        folder = output/mode
        command = [str(python), '-B', str(Path(__file__).resolve()), '--child', mode, '--output', str(folder)]
        started = time.time_ns()//1_000_000
        if mode == 'terminated':
            with (output/(mode+'.log')).open('wb') as log:
                process = subprocess.Popen(command, env=environment, stdout=log, stderr=subprocess.STDOUT)
                deadline = time.monotonic()+10
                while not (folder/'ready').exists() and process.poll() is None and time.monotonic()<deadline:
                    time.sleep(.01)
                if not (folder/'ready').exists():
                    process.kill();process.wait()
                    raise RuntimeError('The intentional interruption child never became ready')
                process.terminate()
                returncode = process.wait(timeout=5)
            durable = [json.loads(path.read_text()) for path in (output/'allure-results').glob('*-result.json')]
            if not any(row['status']=='broken' and {'name':'suite','value':'Processus interrompu'} in row['labels'] for row in durable):
                raise AssertionError('SIGTERM lost the durable unfinished campaign sentinel')
            reporter().write_result(output/'allure-results', 'Processus interrompu', 'suite_process_interrupted', 'broken',
                start=started, stop=time.time_ns()//1_000_000,
                message='SIMULATED_PROCESS_TERMINATED after positive control; remaining campaign not executed',
                diagnostics={'process':'SIGTERM injected after ready marker; child return code '+str(returncode)})
        else:
            result = subprocess.run(command, env=environment, capture_output=True, timeout=30)
            returncode = result.returncode
            (output/(mode+'.log')).write_bytes(result.stdout+result.stderr)
        expected = {'unittest':1,'pytest':1,'empty':5,'collection':2,'interrupted':2,'terminated':-15}[mode]
        if returncode != expected:
            raise AssertionError(f'{mode}: expected exit {expected}, got {returncode}')
        records.append({'mode':mode,'exit_code':returncode,'expected_exit_code':expected})
    rows = [json.loads(path.read_text()) for path in (output/'allure-results').glob('*-result.json')]
    by_name = {row['name'].rsplit('.',1)[-1]:row for row in rows}
    expected_states = {'test_assertion_expected_actual':'failed','test_runtime_exception':'broken',
        'test_provider_timeout':'broken','test_subtest_failure_followed_by_skip':'failed',
        'test_skipped':'skipped','test_expected_failure':'skipped','test_unexpected_success':'failed',
        'test_bounded_logs':'failed','test_never_reached':'broken','test_call_succeeds_but_teardown_fails':'broken',
        'suite_process_interrupted':'broken','test_before_interruption':'passed'}
    for name,status in expected_states.items():
        if name not in by_name or by_name[name]['status'] != status:
            raise AssertionError('Intentional failure was lost or misclassified: '+name)
    if not any(row['name'].startswith('setUpClass') and row['status']=='broken' for row in rows):
        raise AssertionError('The class setup failure was lost')
    for name,status in {'test_pytest_assertion':'failed','test_pytest_setup':'broken',
                        'test_pytest_teardown':'broken','test_pytest_exception':'broken',
                        'test_pytest_skip':'skipped'}.items():
        matching = [row for row in rows if row['name'].endswith('::'+name)]
        if len(matching)!=1 or matching[0]['status']!=status:
            raise AssertionError('Pytest phase failure was lost or misclassified: '+name)
    for suite in ('Épreuves pytest empty','Épreuves pytest collection','Épreuves pytest interrupted'):
        selected = [row for row in rows if {'name':'suite','value':suite} in row['labels']]
        if not selected or not any(row['status']=='broken' for row in selected):
            raise AssertionError('Incomplete pytest campaign became successful: '+suite)
    all_text = '\n'.join(p.read_text() for p in (output/'allure-results').iterdir() if p.suffix in {'.json','.txt','.log'})
    for secret in (PASSWORD, ENV_KEY, TOKEN, BEARER):
        if secret in all_text:
            raise AssertionError('A fictitious secret was not redacted')
    assertion = next(row for row in rows if row['name'].endswith('test_assertion_expected_actual'))
    diagnostic_text = '\n'.join((output/'allure-results'/a['source']).read_text() for a in assertion['attachments'] if a['type']=='text/plain')
    for marker in ('FAULT_STDOUT_MARKER','FAULT_STDERR_MARKER','FAULT_LOG_MARKER'):
        if marker not in diagnostic_text:
            raise AssertionError('An actionable diagnostic channel was lost: '+marker)
    pytest_assertion = next(row for row in rows if 'test_pytest_assertion' in row['name'])
    pytest_logs = '\n'.join((output/'allure-results'/a['source']).read_text() for a in pytest_assertion['attachments'] if a['type']=='text/plain')
    for marker in ('PYTEST_STDOUT_MARKER','PYTEST_STDERR_MARKER','PYTEST_LOG_MARKER'):
        if marker not in pytest_logs:
            raise AssertionError('A pytest diagnostic channel was lost: '+marker)
    for name,marker in [('test_never_reached','FAULT_SETUP_MARKER'),
                        ('test_call_succeeds_but_teardown_fails','FAULT_TEARDOWN_MARKER')]:
        selected = next(row for row in rows if row['name'].endswith(name))
        logs = '\n'.join((output/'allure-results'/a['source']).read_text() for a in selected['attachments'] if a['type']=='text/plain')
        if marker not in logs:
            raise AssertionError('Fixture diagnostic lost: '+marker)
    class_setup = next(row for row in rows if row['name'].startswith('setUpClass'))
    if not any('FAULT_CLASS_SETUP_MARKER' in (output/'allure-results'/a['source']).read_text()
               for a in class_setup['attachments'] if a['type']=='text/plain'):
        raise AssertionError('The class setup log was lost')
    attachments = [p for p in (output/'allure-results').iterdir() if '-attachment.' in p.name]
    if any(p.stat().st_size>64*1024 for p in attachments):
        raise AssertionError('A diagnostic attachment exceeded 64 KiB')
    if 'TRONQU' not in all_text.upper():
        raise AssertionError('The long-log truncation is not visible')
    counts = {status:sum(row['status']==status for row in rows) for status in ('passed','failed','broken','skipped','unknown')}
    if hashlib.sha256(REPORTER.read_bytes()).hexdigest() != adapter_sha256:
        raise AssertionError('The reporting adapter changed during the fault campaign')
    receipt = {'at_utc':datetime.now(timezone.utc).isoformat(),'kind':'reporting-intentional-fault-campaign',
        'harness_passed':True,'business_validation':False,'intentionally_injected_failures':True,
        'children':records,'counts':counts,'all_diagnostic_channels_retained':True,'fictitious_secrets_redacted':True,
        'text_attachments_bounded':True,'individual_tests':len(rows),'sources_or_provider_called':False,
        'reporting_adapter_sha256':adapter_sha256,
        'qualification_tool_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (output/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--python',type=Path,default=Path(sys.executable))
    parser.add_argument('--node',type=Path,help='Render the verified intentional-failure results with this qualification-only Node executable')
    parser.add_argument('--child',choices=('unittest','pytest','empty','collection','interrupted','terminated'),help=argparse.SUPPRESS)
    args = parser.parse_args()
    os.umask(0o077)
    output = args.output.expanduser().resolve()
    if args.child:
        return child(args.child,output)
    try:
        # Resolving a venv's Python symlink would silently lose that environment.
        receipt = run_campaign(output,args.python.expanduser().absolute())
        if args.node:
            subprocess.run([str(args.python.expanduser().absolute()), '-B', str(ROOT/'deploy/ubuntu/build_report.py'),
                '--results', str(output/'allure-results'), '--output', str(output/'report'),
                '--id', 'reporting-faults-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S').lower(),
                '--title', 'Épreuves négatives du reporting — échecs attendus',
                '--environment', 'Qualification locale sans SI ni fournisseur IA',
                '--node', str(args.node.expanduser().resolve())],check=True)
            receipt['rendered_report'] = str(output/'report/index.html')
            (output/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    except (ValueError,AssertionError,RuntimeError,subprocess.SubprocessError) as error:
        parser.exit(2,'Reporting fault campaign failed: '+str(error)+'\n')
    print(json.dumps(receipt,ensure_ascii=False))
    return 0


if __name__ == '__main__':raise SystemExit(main())
