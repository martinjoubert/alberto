"""The exported source tree includes the local Open WebUI recipe dependencies."""
from __future__ import annotations
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location('client_source_bundle', ROOT / 'deploy/ubuntu/bundle.py')
bundle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bundle)


class ClientSourceBundleTests(unittest.TestCase):
    def test_extracted_recipe_imports_and_finds_its_helpers_without_the_checkout(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            archive_path = folder / 'client-sources.tar.gz'
            bundle.archive(ROOT, archive_path)
            destination = folder / 'extracted'
            destination.mkdir()
            with tarfile.open(archive_path) as archive:
                archive.extractall(destination, filter='data')
            checkout = destination / 'rie-delivery'
            helper_paths = (
                'deploy/ubuntu/qualification_openwebui.py',
                'use-cases/incidents/observability-demo/browser_ui.py',
                'use-cases/incidents/observability-demo/openwebui/report_display.py',
                'use-cases/pdl/agentic-pdl/rie_agent/openwebui_dialogue.py',
            )
            for relative in helper_paths:
                self.assertTrue((checkout / relative).is_file(), relative)
            environment = dict(os.environ)
            environment.pop('PYTHONPATH', None)
            result = subprocess.run([sys.executable, '-B', str(checkout / helper_paths[0]), '--help'],
                                    cwd=checkout, env=environment, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn('--max-turns', result.stdout)
            code = '''
import importlib.util,sys
from pathlib import Path
root=Path.cwd()
path=root/'deploy/ubuntu/qualification_openwebui.py'
spec=importlib.util.spec_from_file_location('exported_client_recipe',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
assert module.ROOT==root
assert module.connection('pdl','individual')['auth_type']=='bearer'
assert (module.ROOT/'use-cases/incidents/observability-demo/browser_ui.py').is_file()
path=root/'use-cases/incidents/observability-demo/openwebui/report_display.py'
spec=importlib.util.spec_from_file_location('exported_client_display',path)
display=importlib.util.module_from_spec(spec);spec.loader.exec_module(display)
assert callable(display.Filter().outlet)
print('Exported client recipe and display helper import without the checkout')
'''
            result = subprocess.run([sys.executable, '-B', '-c', code], cwd=checkout,
                                    env=environment, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertFalse((checkout / '.git').exists())
            self.assertFalse((checkout / 'demos/albert-openwebui-poc/.env').exists())


if __name__ == '__main__':
    unittest.main()
