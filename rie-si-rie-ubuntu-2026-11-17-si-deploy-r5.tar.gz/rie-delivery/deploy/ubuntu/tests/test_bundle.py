"""Check source delivery privacy, provenance, determinism and usable paths."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location('ubuntu_delivery_bundle_tests', Path(__file__).resolve().parents[1] / 'bundle.py')
bundle = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(bundle)


def write(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return path


class BundleTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / 'source'
        self.output = self.base / 'delivery.tar.gz'
        for name in (*bundle.EXPLICIT, *bundle.RESOURCES):
            write(self.root / name, '# public source: ' + name + '\n')
        for directory, suffixes, filenames in bundle.DIRECTORIES:
            folder = self.root / directory
            folder.mkdir(parents=True, exist_ok=True)
            if '.py' in suffixes:
                write(folder / '__init__.py', '# public package\n')
            if '.json' in suffixes:
                write(folder / 'fixture.json', '{"synthetic":true}\n')
        self.provenance = {'git_available': True, 'commit': '1' * 40, 'dirty': True}
        self.version_patch = patch.object(bundle, 'source_version', return_value=self.provenance)
        self.version_patch.start()
        self.addCleanup(self.version_patch.stop)

    def test_excluded_private_files_are_never_opened_or_added(self):
        private = [
            self.root / '.env',
            self.root / '.runtime/private.json',
            self.root / 'deploy/ubuntu/.env',
            self.root / 'deploy/ubuntu/secrets/token.py',
            self.root / 'use-cases/pdl/agentic-pdl/rie_agent/.env',
            self.root / 'use-cases/pdl/agentic-pdl/rie_agent/key.pem',
            self.root / 'use-cases/incidents/observability-demo/deploy/secrets/albert_key',
            self.root / 'core/access-control/src/dinum_access/.env',
            self.root / 'core/observability/src/dinum_observability/private.py',
            self.root / 'demos/pdl-demo/app.py',
        ]
        for path in private:
            write(path, 'PRIVATE_SENTINEL')
        original = Path.read_bytes

        def guarded(path):
            if path in private:
                raise AssertionError('A private file was opened: ' + str(path))
            return original(path)

        with patch.object(Path, 'read_bytes', guarded):
            members, manifest = bundle.collect(self.root)
        self.assertNotIn(b'PRIVATE_SENTINEL', b''.join(members.values()))
        self.assertFalse(manifest['observability_deployment_included'])
        self.assertEqual(manifest['qualification'], 'not_asserted_by_packaging')
        self.assertTrue(manifest['source']['dirty'])

    def test_original_paths_and_manifest_allow_an_archive_without_git(self):
        bundle.archive(self.root, self.output)
        with tarfile.open(self.output, 'r:gz') as archive:
            names = set(archive.getnames())
            expected = {
                'rie-delivery/README.md',
                'rie-delivery/DELIVERY-MANIFEST.json',
                'rie-delivery/deploy/ubuntu/manage.py',
                'rie-delivery/deploy/ubuntu/README.md',
                'rie-delivery/core/access-control/config.example.json',
                'rie-delivery/simulation-rie/ldap-demo/manage.py',
                'rie-delivery/use-cases/pdl/agentic-pdl/requirements-rie.lock.txt',
                'rie-delivery/use-cases/incidents/observability-demo/corpus-documents.json',
                'rie-delivery/deploy/ubuntu/requirements-runtime.lock',
                'rie-delivery/deploy/ubuntu/requirements-portal.lock',
            }
            self.assertTrue(expected.issubset(names))
            # Repository CI needs the complete development tree; an operator
            # archive must not carry a workflow whose dependencies are absent.
            self.assertFalse(any(name.startswith('rie-delivery/.github/') for name in names))
            self.assertTrue(all(member.isfile() and not member.issym() and not member.islnk() for member in archive.getmembers()))
            manifest = json.load(archive.extractfile('rie-delivery/DELIVERY-MANIFEST.json'))
            self.assertEqual(manifest['source'], self.provenance)
            for row in manifest['files']:
                content = archive.extractfile('rie-delivery/' + row['path']).read()
                self.assertEqual(row['bytes'], len(content))
                self.assertEqual(row['sha256'], hashlib.sha256(content).hexdigest())
        self.assertEqual(stat.S_IMODE(self.output.stat().st_mode), 0o600)
        checksum = self.output.with_name(self.output.name + '.sha256')
        self.assertEqual(stat.S_IMODE(checksum.stat().st_mode), 0o600)
        self.assertEqual(checksum.read_text(), hashlib.sha256(self.output.read_bytes()).hexdigest() + '  delivery.tar.gz\n')

    def test_packaging_is_reproducible_and_preserves_previous_output(self):
        first = bundle.archive(self.root, self.output)
        second_path = self.base / 'second.tar.gz'
        second = bundle.archive(self.root, second_path)
        self.assertEqual(first['sha256'], second['sha256'])
        self.assertEqual(self.output.read_bytes(), second_path.read_bytes())
        snapshot = self.output.read_bytes()
        with self.assertRaisesRegex(ValueError, 'new file'):
            bundle.archive(self.root, self.output)
        self.assertEqual(self.output.read_bytes(), snapshot)

    def test_selected_file_symlink_is_refused_before_packaging(self):
        selected = self.root / 'deploy/ubuntu/manage.py'
        selected.unlink()
        private = write(self.base / 'outside-secret', 'DO_NOT_OPEN')
        selected.symlink_to(private)
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            bundle.archive(self.root, self.output)
        self.assertFalse(self.output.exists())
        self.assertEqual(private.read_text(), 'DO_NOT_OPEN')

    def test_selected_directory_symlink_is_refused(self):
        selected = self.root / 'core/access-control/src/dinum_access'
        for member in selected.iterdir():
            member.unlink()
        selected.rmdir()
        outside = self.base / 'outside-package'
        outside.mkdir()
        write(outside / 'private.py', 'DO_NOT_OPEN')
        selected.symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            bundle.collect(self.root)

    def test_high_confidence_secret_in_a_public_source_blocks_without_echoing_it(self):
        credential = 'ghp_' + 'a' * 32
        write(self.root / 'deploy/ubuntu/manage.py', 'TOKEN = "' + credential + '"\n')
        with self.assertRaisesRegex(ValueError, 'provider_token') as caught:
            bundle.archive(self.root, self.output)
        self.assertNotIn(credential, str(caught.exception))
        self.assertFalse(self.output.exists())

    def test_missing_required_input_blocks_an_incomplete_archive(self):
        (self.root / 'deploy/ubuntu/README.md').unlink()
        with self.assertRaises(OSError):
            bundle.archive(self.root, self.output)
        self.assertFalse(self.output.exists())

    def test_destinations_are_restricted_and_never_replace_a_symlink(self):
        with self.assertRaisesRegex(ValueError, 'outside the checkout'):
            bundle.output_path(self.root, self.root / 'release.tar.gz')
        permitted = self.root / '.runtime/delivery/release.tar.gz'
        self.assertEqual(bundle.output_path(self.root, permitted), permitted.resolve())
        with self.assertRaisesRegex(ValueError, 'tar.gz'):
            bundle.output_path(self.root, self.base / 'release.zip')
        original = write(self.base / 'original.tar.gz', 'preserve')
        symlink = self.base / 'symlink.tar.gz'
        symlink.symlink_to(original)
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            bundle.output_path(self.root, symlink)
        self.assertEqual(original.read_text(), 'preserve')

    def test_real_archive_runs_preparation_and_build_context_without_git(self):
        actual_root = Path(__file__).resolve().parents[3]
        delivery = self.base / 'actual-sources.tar.gz'
        bundle.archive(actual_root, delivery)
        destination = self.base / 'extracted'
        destination.mkdir()
        with tarfile.open(delivery, 'r:gz') as archive:
            archive.extractall(destination, filter='data')
        checkout = destination / 'rie-delivery'
        private_instance = self.base / 'installed-instance'
        completed = subprocess.run([sys.executable, str(checkout / 'deploy/ubuntu/manage.py'),
                                    'prepare', str(private_instance), '--mode', 'external'],
                                   capture_output=True, text=True, check=False)
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertFalse((checkout / '.git').exists())
        self.assertTrue((private_instance / 'config/access.json').is_file())
        spec = importlib.util.spec_from_file_location('extracted_delivery_manage', checkout / 'deploy/ubuntu/manage.py')
        manage = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(manage)
        context = checkout / '.runtime/ci/context'
        manage.context(context)
        self.assertTrue((context / 'rie_agent/mcp_app.py').is_file())
        self.assertTrue((context / 'incidents/obs_poc/server.py').is_file())
        self.assertTrue((context / 'dinum_access/user_tokens.py').is_file())
        self.assertFalse((context / 'dinum_observability').exists())

    def test_unavailable_git_has_explicit_unknown_provenance(self):
        self.version_patch.stop()
        with patch.object(bundle.subprocess, 'run', side_effect=FileNotFoundError('git unavailable')):
            version = bundle.source_version(self.root)
        self.assertEqual(version, {'git_available': False, 'commit': None, 'dirty': None})


if __name__ == '__main__':
    unittest.main()
