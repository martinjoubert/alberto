"""Exercise private-instance isolation, build privacy, and non-destructive setup."""
from __future__ import annotations

import contextlib
import importlib.util
import io
import json
from pathlib import Path
import stat
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parents[1]


def load_module(filename, name):
    spec = importlib.util.spec_from_file_location(name, HERE / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


manage = load_module('manage.py', 'ubuntu_delivery_manage_tests')
initialize = load_module('initialize.py', 'ubuntu_delivery_initialize_tests')


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path


class PrivateInstanceTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.instance = self.base / 'private-instance'

    def prepare(self):
        with contextlib.redirect_stdout(io.StringIO()):
            manage.bootstrap(self.instance, 'external')
        return manage.load(self.instance)

    def test_external_bootstrap_is_private_and_fail_closed_without_docker(self):
        with patch.object(manage, 'docker', side_effect=AssertionError('Bootstrap must not contact Docker')):
            values = self.prepare()
        self.assertEqual(values['RIE_MODE'], 'external')
        self.assertEqual(values['ALBERT_MODEL'], 'gemma-4-31b-it')
        self.assertEqual(values['OBS_MODEL_GPTOSS'], 'gemma-4-31b-it')
        self.assertEqual(values['OBS_DIALOGUE_MODEL'], 'gpt-oss-120b')
        self.assertEqual(values['OBS_REVIEW_MODEL'], 'gpt-oss-120b')
        self.assertEqual(values['DINUM_DIALOGUE_MAX_STATES'], '8192')
        self.assertEqual(values['RIE_INSTANCE_DIR'], str(self.instance))
        self.assertRegex(values['RIE_PROJECT'], r'^rie-[a-f0-9]{12}$')
        access = json.loads((self.instance / 'config/access.json').read_text())
        self.assertIs(access['allow_webui_assertions'], False)
        self.assertNotIn('webui_key_file', access)
        self.assertEqual(access['recovery_subjects'], {})
        self.assertEqual(access['ldap']['attribute_for_subject'], 'entryUUID')
        self.assertEqual(access['ldap']['administrator_group_dns'], [])
        self.assertEqual(json.loads((self.instance / 'access/policy.json').read_text())['indices'], {})
        pdl = json.loads((self.instance / 'config/pdl.yaml').read_text())
        self.assertEqual(pdl['server']['admin_host'], '127.0.0.1')
        self.assertEqual(pdl['discovery']['allowed_index_patterns'], [])
        self.assertEqual((self.instance / 'secrets/albert_key').read_text().strip(), 'demo-not-a-credential')
        signing = (self.instance / 'secrets/session-signing.key').read_text().strip()
        self.assertGreaterEqual(len(signing), 32)
        self.assertNotIn(signing, (self.instance / '.env').read_text())
        for path in [self.instance, *self.instance.rglob('*')]:
            with self.subTest(path=path.relative_to(self.instance)):
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o700 if path.is_dir() else 0o600)

    def test_preparation_refuses_checkout_destination_before_creating_it(self):
        forbidden = manage.ROOT / '.runtime' / 'should-not-be-an-instance-test'
        with self.assertRaises(ValueError):
            manage.bootstrap(forbidden, 'external')
        self.assertFalse(forbidden.exists())

    def test_reinitialization_preserves_existing_identity_secrets_and_policy(self):
        self.prepare()
        snapshots = {p.relative_to(self.instance): p.read_bytes() for p in self.instance.rglob('*') if p.is_file()}
        with self.assertRaises(ValueError):
            manage.bootstrap(self.instance, 'external')
        self.assertEqual(snapshots, {p.relative_to(self.instance): p.read_bytes() for p in self.instance.rglob('*') if p.is_file()})

    def test_copying_instance_configuration_to_another_path_is_refused(self):
        self.prepare()
        other = self.base / 'other-instance'
        other.mkdir()
        (other / '.env').write_bytes((self.instance / '.env').read_bytes())
        with self.assertRaisesRegex(ValueError, 'mismatch'):
            manage.load(other)

    def test_env_rejects_shell_interpolation_without_replacing_existing_file(self):
        values = self.prepare()
        original = (self.instance / '.env').read_bytes()
        for value in ('$(hostname)', '${HOME}', 'https://host\nRIE_MODE=demo'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                manage.save_env(self.instance, {**values, 'ALBERT_URL': value})
            self.assertEqual((self.instance / '.env').read_bytes(), original)


class BuildContextTests(unittest.TestCase):
    def test_only_public_two_use_case_runtime_inputs_enter_the_context(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / 'checkout'
            deploy = root / 'deploy/ubuntu'
            files = {
                'deploy/ubuntu/Dockerfile': 'FROM python:3.12\n',
                'deploy/ubuntu/initialize.py': '# initializer\n',
                'deploy/ubuntu/runtime_cli.py': '# operator\n',
                'deploy/ubuntu/seed_incidents.py': '# incident fixture\n',
                'use-cases/pdl/agentic-pdl/requirements-rie.lock.txt': '# locked\n',
                'use-cases/pdl/agentic-pdl/rie_agent/__init__.py': '',
                'use-cases/pdl/agentic-pdl/rie_agent/mcp_app.py': '# PDL runtime\n',
                'use-cases/pdl/agentic-pdl/rie_agent/templates.yaml': 'version: 1\n',
                'use-cases/pdl/agentic-pdl/rie_agent/fixtures/portable.json': '{"synthetic":true}',
                'core/access-control/src/dinum_access/security.py': '# ACL\n',
                'core/access-control/src/dinum_access/user_tokens.py': '# individual identity\n',
                'core/access-control/tokens.py': '# CLI\n',
                'core/albert-client/src/dinum_albert/client.py': '# Albert transport\n',
                'use-cases/incidents/observability-demo/obs_poc/server.py': '# Incidents runtime\n',
                'use-cases/incidents/observability-demo/fixtures/itsm-tickets.json': '{"synthetic":true}',
                'use-cases/incidents/observability-demo/corpus-documents.json': '[]',
                'deploy/ubuntu/seed_pdl.py': '# PDL fixture\n',
            }
            for name, text in files.items():
                write(root / name, text)
            excluded = {
                'use-cases/pdl/agentic-pdl/.env': 'SECRET_ENV',
                'use-cases/pdl/agentic-pdl/rie_agent/.env': 'SECRET_PACKAGE_ENV',
                'use-cases/pdl/agentic-pdl/rie_agent/private.key': 'SECRET_KEY',
                'use-cases/incidents/observability-demo/deploy/secrets/albert_key': 'SECRET_ALBERT',
                'use-cases/incidents/observability-demo/reports/private.json': 'SECRET_REPORT',
                '.runtime/private.json': 'SECRET_RUNTIME',
                'core/observability/src/dinum_observability/__init__.py': '# out of scope\n',
                'demos/pdl-demo/app.py': '# no central frontend\n',
            }
            for name, text in excluded.items():
                write(root / name, text)
            output = Path(temporary) / 'context'
            with patch.object(manage, 'ROOT', root), patch.object(manage, 'HERE', deploy):
                for source, _ in manage.runtime_copies():
                    if not source.exists():
                        write(source, '# public runtime input\n')
                digest = manage.context(output)
            self.assertRegex(digest, r'^[a-f0-9]{20}$')
            members = {p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}
            self.assertTrue({'rie_agent/mcp_app.py', 'incidents/obs_poc/server.py',
                             'dinum_access/user_tokens.py', 'delivery/runtime_cli.py',
                             'delivery/seed_incidents.py', 'manifest.json'}.issubset(members))
            self.assertFalse(any('dinum_observability' in name or '/demos/' in name for name in members))
            content = b''.join(p.read_bytes() for p in output.rglob('*') if p.is_file())
            for name, marker in excluded.items():
                with self.subTest(excluded=name):
                    self.assertNotIn(marker.encode(), content)
            manifest = json.loads((output / 'manifest.json').read_text())
            self.assertEqual({row['path'] for row in manifest}, members - {'manifest.json'})
            self.assertTrue(all(len(row['sha256']) == 64 for row in manifest))


class InitializeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.source, self.target = self.base / 'input', self.base / 'runtime'
        write(self.source / 'config/pdl.yaml', 'new runtime configuration')
        write(self.source / 'secrets/albert_key', 'private-credential')
        write(self.source / 'access/policy.json', '{"revision":1}')

    def test_repeated_initialization_updates_inputs_and_preserves_live_policy_and_data(self):
        with patch.object(initialize.os, 'chown') as chown:
            initialize.initialize(self.source, self.target)
            write(self.target / 'access/policy.json', '{"revision":9,"operator_change":true}')
            write(self.target / 'access/user-tokens/person.json', '{"digest":"preserved"}')
            write(self.target / 'pdl/approved-catalog.json', '{"approved":true}')
            write(self.target / 'incidents/report.json', '{"evidence":"preserved"}')
            write(self.source / 'config/pdl.yaml', 'updated runtime configuration')
            initialize.initialize(self.source, self.target)
        self.assertEqual((self.target / 'config/pdl.yaml').read_text(), 'updated runtime configuration')
        self.assertEqual(json.loads((self.target / 'access/policy.json').read_text())['revision'], 9)
        self.assertEqual(json.loads((self.target / 'access/user-tokens/person.json').read_text())['digest'], 'preserved')
        self.assertTrue(json.loads((self.target / 'pdl/approved-catalog.json').read_text())['approved'])
        self.assertEqual(json.loads((self.target / 'incidents/report.json').read_text())['evidence'], 'preserved')
        self.assertTrue(chown.called)
        for call in chown.call_args_list:
            self.assertTrue(Path(call.args[0]).is_relative_to(self.target))
            self.assertEqual(call.args[1:], (10001, 10001))
        for path in [self.target, *self.target.rglob('*')]:
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o700 if path.is_dir() else 0o600)

    def test_symlink_state_cannot_modify_an_external_file_before_refusal(self):
        outside = write(self.base / 'outside.txt', 'leave this file untouched')
        outside.chmod(0o644)
        (self.target / 'config').mkdir(parents=True)
        (self.target / 'config/pdl.yaml').symlink_to(outside)
        with patch.object(initialize.os, 'chown') as chown, self.assertRaises(ValueError):
            initialize.initialize(self.source, self.target)
        self.assertEqual(outside.read_text(), 'leave this file untouched')
        self.assertEqual(stat.S_IMODE(outside.stat().st_mode), 0o644)
        chown.assert_not_called()

    def test_symlink_input_directory_is_refused_without_creating_runtime(self):
        moved = self.base / 'actual-config'
        (self.source / 'config').rename(moved)
        (self.source / 'config').symlink_to(moved, target_is_directory=True)
        with patch.object(initialize.os, 'chown') as chown, self.assertRaises(ValueError):
            initialize.initialize(self.source, self.target)
        self.assertFalse(self.target.exists())
        chown.assert_not_called()

    def test_symlink_initial_policy_is_refused_without_creating_runtime(self):
        policy = self.source / 'access/policy.json'
        policy.unlink()
        policy.symlink_to(write(self.base / 'outside-policy.json', '{"revision":77}'))
        with patch.object(initialize.os, 'chown') as chown, self.assertRaises(ValueError):
            initialize.initialize(self.source, self.target)
        self.assertFalse(self.target.exists())
        chown.assert_not_called()


class OwnershipGuardTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.instance = Path(self.temporary.name)
        self.values = {'RIE_PROJECT': 'rie-123456789abc', 'RIE_INSTANCE_ID': '1' * 32}

    def fake_docker(self, *, volumes=None, containers=None, identity='daemon-identity'):
        volumes = volumes or {}
        containers = containers or []

        def command(*args, **kwargs):
            if args[:1] == ('info',):
                return SimpleNamespace(stdout=identity + '\n')
            if args[:2] == ('volume', 'ls'):
                expression = args[3]
                matches = [name for name in volumes if expression == 'name=^' + name + '$']
                return SimpleNamespace(stdout='\n'.join(matches))
            if args[:2] == ('volume', 'inspect'):
                return SimpleNamespace(stdout=json.dumps(volumes[args[2]]))
            if args[:1] == ('ps',):
                return SimpleNamespace(stdout='\n'.join('container-' + str(n) for n, _ in enumerate(containers)))
            if args[:1] == ('inspect',):
                return SimpleNamespace(stdout=json.dumps(containers))
            self.fail('Guard attempted an unexpected/mutating Docker operation: ' + repr(args))

        return command

    def test_foreign_volume_is_refused_before_binding_instance_to_engine(self):
        volume = self.values['RIE_PROJECT'] + '-runtime'
        with patch.object(manage, 'docker', side_effect=self.fake_docker(volumes={volume: {'rie.instance': 'another-instance'}})):
            with self.assertRaisesRegex(ValueError, 'Foreign volume'):
                manage.guard(self.instance, self.values)
        self.assertFalse((self.instance / 'docker-id').exists())

    def test_every_service_requires_the_exact_instance_label(self):
        for service in manage.SERVICES:
            with self.subTest(service=service):
                container = {'Config': {'Labels': {'com.docker.compose.service': service, 'rie.instance': 'another-instance'}}}
                with patch.object(manage, 'docker', side_effect=self.fake_docker(containers=[container])):
                    with self.assertRaisesRegex(ValueError, 'Foreign container'):
                        manage.guard(self.instance, self.values)
                self.assertFalse((self.instance / 'docker-id').exists())

    def test_owned_services_and_volumes_are_accepted_and_engine_identity_is_persisted(self):
        containers = [{'Config': {'Labels': {'com.docker.compose.service': name, 'rie.instance': self.values['RIE_INSTANCE_ID']}}}
                      for name in manage.SERVICES]
        volumes = {self.values['RIE_PROJECT'] + '-' + name: {'rie.instance': self.values['RIE_INSTANCE_ID']}
                   for name in manage.VOLUMES}
        with patch.object(manage, 'docker', side_effect=self.fake_docker(volumes=volumes, containers=containers)):
            manage.guard(self.instance, self.values)
        self.assertEqual((self.instance / 'docker-id').read_text(), 'daemon-identity\n')
        self.assertEqual(stat.S_IMODE((self.instance / 'docker-id').stat().st_mode), 0o600)

    def test_same_instance_on_another_docker_engine_is_refused(self):
        write(self.instance / 'docker-id', 'original-engine\n')
        with patch.object(manage, 'docker', side_effect=self.fake_docker(identity='replacement-engine')) as docker:
            with self.assertRaisesRegex(ValueError, 'engine changed'):
                manage.guard(self.instance, self.values)
        self.assertEqual(docker.call_count, 1)
        self.assertEqual((self.instance / 'docker-id').read_text(), 'original-engine\n')

    def test_unknown_service_is_refused_even_with_a_valid_instance_label(self):
        container = {'Config': {'Labels': {'com.docker.compose.service': 'unrelated-database', 'rie.instance': self.values['RIE_INSTANCE_ID']}}}
        with patch.object(manage, 'docker', side_effect=self.fake_docker(containers=[container])):
            with self.assertRaisesRegex(ValueError, 'Unknown service'):
                manage.guard(self.instance, self.values)


if __name__ == '__main__':
    unittest.main()
