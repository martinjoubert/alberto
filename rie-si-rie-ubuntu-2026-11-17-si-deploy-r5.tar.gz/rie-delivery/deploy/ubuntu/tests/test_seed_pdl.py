"""Verify synthetic PDL seeding and mapping approval boundaries without services."""
from copy import deepcopy
from contextlib import redirect_stdout
from dataclasses import replace
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


class FixtureSelectionTests(unittest.TestCase):
    def test_demo_fixture_selection_is_explicit_and_synthetic_only(self):
        try:
            import rie_agent
        except ImportError:
            self.skipTest('Fixture selection check uses the locked CI runtime imports.')
        spec = importlib.util.spec_from_file_location('ubuntu_demo_selector', ROOT / 'seed_pdl.py')
        demo = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(demo)
        portable = demo.load_fixture('portable')
        self.assertEqual(set(portable['indices']), {'rie-pfs-fixture', 'rie-bb-fixture', 'rie-pfaing-fixture', 'rie-tacacs-fixture'})
        self.assertFalse(any(concept.get('identity_extractor') for item in portable['indices'].values()
                             for concept in item['concepts'].values()))
        reference = demo.load_fixture('equipment-reference')
        self.assertFalse(reference['target_architecture'])
        self.assertEqual(set(reference['indices']), {'rie-bb-legacy-fixture', 'rie-tacacs-legacy-fixture'})
        with self.assertRaisesRegex(ValueError, 'supported synthetic'):
            demo.load_fixture('../../private-config')
        for invalid in ({'synthetic': False, 'indices': {'rie-x-fixture': {}}},
                        {'synthetic': True, 'indices': {'outside-production-index': {}}}):
            with patch.object(demo.json, 'loads', return_value=invalid):
                with self.assertRaises(ValueError):
                    demo.load_fixture('equipment-reference')


class DemoMappingTests(unittest.TestCase):
    """Activate shipped synthetic mappings without approving arbitrary proposals."""

    def setUp(self):
        """Use the real catalog with isolated fixture inventory and no network calls."""
        try:
            from rie_agent.config import SourceConfig
            from rie_agent.store import Store
            from tests_rie.test_equipment import inventory_for
            from tests_rie.test_runtime import settings
        except ImportError:
            self.skipTest('Demo mapping checks use the locked CI runtime imports.')
        spec = importlib.util.spec_from_file_location('ubuntu_demo_mappings', ROOT / 'seed_pdl.py')
        self.demo = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.demo)
        self.temp = tempfile.TemporaryDirectory(prefix='dinum-demo-mappings-')
        self.addCleanup(self.temp.cleanup)
        self.settings = replace(settings(Path(self.temp.name)),
                                opensearch=SourceConfig(True, 'http://opensearch:9200'))
        self.fixture = self.demo.load_fixture('portable')
        self.inventory = inventory_for(self.fixture)
        self.inventory['allowed_patterns'] = ['rie-*-fixture']
        for index, definition in self.fixture['indices'].items():
            self.inventory['indices'][index]['physical_mapping'] = {
                'properties': deepcopy(definition['properties'])}
        self.store = Store(self.settings.data_dir)
        self.store.save_inventory(self.inventory)

    def prepare(self, **kwargs):
        """Exercise demo activation while keeping provider clients out of this test."""
        with patch.dict(os.environ, {'PDL_MODE': 'demo'}), redirect_stdout(io.StringIO()):
            return self.demo.prepare_mappings(self.settings, self.fixture, self.inventory, self.store, **kwargs)

    def review(self, index, mapping=None, kind='fixture_mapping'):
        """Stage an exact bundled proposal or an explicitly different operator proposal."""
        return self.store.create_review({'kind': kind, 'index': index,
                                        'schema_hash': self.inventory['indices'][index]['schema_hash'],
                                        'proposed_mapping': deepcopy(mapping or self.fixture['indices'][index]['concepts']),
                                        'dsl_trials': []})

    def test_default_installs_four_active_bundled_mappings_and_records_audit(self):
        self.prepare()
        catalog = self.store.catalog()
        self.assertEqual({entry['index'] for entry in catalog}, set(self.fixture['indices']))
        self.assertTrue(all(entry['active'] for entry in catalog))
        self.assertEqual({entry['approved_by'] for entry in catalog}, {'bundled-demo-fixture'})
        for entry in catalog:
            self.assertEqual(entry['concepts'], self.fixture['indices'][entry['index']]['concepts'])
        self.assertEqual({review['status'] for review in self.store.reviews()}, {'approved'})
        events = [json.loads(line) for line in (self.store.root / 'audit/events.jsonl').read_text().splitlines()]
        self.assertEqual(sum(event['event'] == 'mapping.approved' for event in events), 4)

    def test_default_activation_qualifies_all_six_runtime_acceptance_scenarios(self):
        from rie_agent.acceptance import ExplicitPlanner, run
        from rie_agent.service import RIEAgentService
        from tests_rie.fixture_search import FixtureSearch
        from tests_rie.test_runtime import FakeInventory
        self.prepare()
        service = RIEAgentService(self.settings, planner=ExplicitPlanner({}),
                                 inventory=FakeInventory(self.inventory),
                                 search=FixtureSearch(self.fixture, self.settings))
        report = run(service, self.fixture)
        self.assertTrue(report['qualification_passed'], report)
        self.assertEqual(len(report['results']), 6)
        self.assertTrue(all(case['passed'] and case['result']['status'] == 'success'
                            for case in report['results']))

    def test_repeated_activation_preserves_versions_reviews_and_audit(self):
        self.prepare()
        before = deepcopy(self.store.catalog()), deepcopy(self.store.reviews())
        audit = (self.store.root / 'audit/events.jsonl').read_text()
        self.prepare()
        self.assertEqual((self.store.catalog(), self.store.reviews()), before)
        self.assertEqual((self.store.root / 'audit/events.jsonl').read_text(), audit)

    def test_manual_mode_leaves_four_pending_reviews_without_catalog_activation(self):
        self.prepare(manual_mappings=True)
        self.assertEqual(self.store.catalog(), [])
        self.assertEqual(len(self.store.reviews()), 4)
        self.assertTrue(all(review['status'] == 'pending' for review in self.store.reviews()))
        before = deepcopy(self.store.reviews())
        self.prepare(manual_mappings=True)
        self.assertEqual(self.store.reviews(), before)

    def test_changed_pending_mapping_is_not_approved_as_a_bundled_default(self):
        index = 'rie-pfs-fixture'
        changed = deepcopy(self.fixture['indices'][index]['concepts'])
        changed['management_ip']['identity_namespace'] = 'operator-custom-ip'
        pending = self.review(index, changed)
        self.prepare()
        self.assertEqual(self.store.review(pending['id'])['status'], 'pending')
        active = next(entry for entry in self.store.catalog() if entry['index'] == index)
        self.assertEqual(active['concepts'], self.fixture['indices'][index]['concepts'])
        self.assertNotEqual(active['approved_from_review'], pending['id'])

    def test_exact_bundled_pending_review_is_reused_and_approved(self):
        pending = self.review('rie-bb-fixture')
        self.prepare()
        active = next(entry for entry in self.store.catalog() if entry['index'] == pending['index'])
        self.assertEqual(active['approved_from_review'], pending['id'])
        self.assertEqual(len(self.store.reviews()), 4)

    def test_schema_mismatch_is_rejected_before_any_mapping_or_review_write(self):
        index = list(self.fixture['indices'])[-1]
        self.inventory['indices'][index]['physical_mapping']['properties']['extra'] = {'type': 'keyword'}
        self.store.save_inventory(self.inventory)
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(self.store.catalog(), [])
        self.assertEqual(self.store.reviews(), [])
        self.assertFalse((self.store.root / 'audit/events.jsonl').exists())

    def test_invalid_last_concept_is_rejected_before_any_partial_activation(self):
        index = list(self.fixture['indices'])[-1]
        self.inventory['indices'][index]['fields']['log.tacacs.dest']['searchable'] = False
        self.store.save_inventory(self.inventory)
        with self.assertRaises(ValueError):
            self.prepare()
        self.assertEqual(self.store.catalog(), [])
        self.assertEqual(self.store.reviews(), [])
        self.assertFalse((self.store.root / 'audit/events.jsonl').exists())

    def test_existing_active_operator_mapping_is_preserved(self):
        index = 'rie-bb-fixture'
        changed = deepcopy(self.fixture['indices'][index]['concepts'])
        changed['management_ip']['identity_namespace'] = 'operator-custom-ip'
        pending = self.review(index, changed, kind='manual_mapping')
        approved = self.store.approve(pending['id'], pending['schema_hash'], author='local-operator')
        self.prepare()
        active = next(entry for entry in self.store.catalog() if entry['index'] == index and entry['active'])
        self.assertEqual(active, approved)
        self.assertEqual(len(self.store.catalog()), 4)

    def test_external_context_is_refused_before_loading_demo_fixture(self):
        with patch.object(self.demo, 'load_settings', return_value=self.settings), \
                patch.object(self.demo, 'load_fixture') as fixture_loader, \
                patch.dict(os.environ, {'PDL_MODE': 'external'}):
            with self.assertRaises(RuntimeError):
                self.demo.demo_context()
        fixture_loader.assert_not_called()


if __name__ == '__main__':
    unittest.main()
