"""Private operator imports and pre-start checks for the optional ITSM history."""
from contextlib import redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('itsm_host_manage',ROOT/'deploy/ubuntu/manage.py')
manage=importlib.util.module_from_spec(spec);spec.loader.exec_module(manage)


class Imports(unittest.TestCase):
    def setUp(self):
        folder=tempfile.TemporaryDirectory();self.addCleanup(folder.cleanup)
        self.root=Path(folder.name).resolve();self.instance=self.root/'instance'
        with redirect_stdout(io.StringIO()):manage.bootstrap(self.instance,'external')

    def command(self,name,document):
        path=self.root/'input.json';path.write_text(json.dumps(document));path.chmod(0o600)
        output=io.StringIO()
        with patch.object(sys,'argv',['manage.py',name,str(self.instance),'--username','bruno','--input',str(path)]),redirect_stdout(output):
            manage.main()
        return output.getvalue()

    def test_operator_imports_only_individual_secret_without_echo(self):
        binding={'itsm_user_id':23,'user_token':'fixture-individual-token-not-real'}
        subject='ldap:'+'a'*64
        with patch.object(manage,'tool',return_value=SimpleNamespace(stdout=json.dumps({'subject':subject}))) as tool:
            output=self.command('itsm-user',binding)
        store=self.instance/'secrets/itsm-users.json'
        self.assertEqual(json.loads(store.read_text())['users'][subject],binding)
        self.assertEqual(store.stat().st_mode & 0o777,0o600)
        self.assertNotIn(binding['user_token'],output)
        self.assertEqual(tool.call_args.args[-1],'bruno')

    def test_no_generic_or_unbound_credential_is_accepted(self):
        for document in ({'user_token':'fixture-only-token-000000'},
                         {'itsm_user_id':1,'user_token':'short'},
                         {'itsm_user_id':True,'user_token':'fixture-only-token-000000'},
                         {'itsm_user_id':1,'user_token':'fixture-only-token-000000','shared':True}):
            with self.subTest(document=document),patch.object(manage,'tool') as tool:
                with self.assertRaises(ValueError):self.command('itsm-user',document)
                tool.assert_not_called()
        self.assertFalse((self.instance/'secrets/itsm-users.json').exists())

    def test_fixture_configuration_cannot_enable_synthetic_history_in_external(self):
        before=(self.instance/'.env').read_bytes()
        with self.assertRaises(ValueError):
            self.command('configure-itsm-history',{'version':1,'target_version':'1.6.17','provider':'fixture'})
        self.assertEqual(before,(self.instance/'.env').read_bytes())
        self.assertFalse((self.instance/'config/itsm-history.json').exists())

    def test_unknown_version_and_placeholder_endpoints_leave_config_unchanged(self):
        template=json.loads((ROOT/'deploy/ubuntu/examples/itsm-history.json').read_text())
        for change in ({'target_version':'latest'},{'api_url':'http://itsm.test/apirest.php'},{}):
            before=(self.instance/'.env').read_bytes()
            with self.assertRaises(ValueError):self.command('configure-itsm-history',{**template,**change})
            self.assertEqual(before,(self.instance/'.env').read_bytes())

    def test_native_configuration_does_not_contact_any_source(self):
        template=json.loads((ROOT/'deploy/ubuntu/examples/itsm-history.json').read_text())
        template.update(api_url='https://itsm.site.test/apirest.php',public_url='https://itsm.site.test')
        with patch.object(manage,'docker') as docker,patch.object(manage,'tool') as tool:
            self.command('configure-itsm-history',template)
        docker.assert_not_called();tool.assert_not_called()
        self.assertEqual(manage.load(self.instance)['OBS_ITSM_HISTORY_CONFIG'],'/data/config/itsm-history.json')
