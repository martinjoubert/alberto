"""Fault oracle and campaign isolation; all Docker/network actions are injected."""
from contextlib import redirect_stdout
from copy import deepcopy
import importlib.util
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock,patch

ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('resilience_tests',ROOT/'deploy/ubuntu/qualification_resilience.py')
resilience=importlib.util.module_from_spec(spec);spec.loader.exec_module(resilience)


def baseline():
    return {'pdl_internal':{'http_status':200,'response':{'result':{'structuredContent':{
                'access_control':{'category':'internal'},'execution':{'albert_calls':0}}}}},
            'incidents_internal':{'http_status':200,'response':{'status':'ok','errors':[],
                'metrics':[{'value':number} for number in range(5)],'logs':{'total':120},'documents':[{'id':'sample'}],
                'usage':[],'analysis':None}},
            'incidents_external':{'http_status':200,'response':{'status':'denied','access_control':{'category':'external'}}}}


def fault(service):
    result=deepcopy(baseline())
    if service=='pdl':result['pdl_internal']={'http_status':0,'response':{}}
    elif service=='incidents':
        for name in ('incidents_internal','incidents_external'):result[name]={'http_status':0,'response':{}}
    elif service=='ldap':
        for name in result:result[name]={'http_status':403,'response':{'error':'directory_unavailable_or_denied'}}
    else:
        row=result['incidents_internal']['response'];row['status']='partial';row['errors']=[{'source':service}]
        if service=='opensearch':row.update(logs=[],documents=[])
        else:row['metrics']=[]
    return result


class FaultOracleTests(unittest.TestCase):
    def test_all_five_expected_faults_are_distinct_and_pass_the_oracle(self):
        self.assertTrue(resilience.healthy(baseline()))
        for service in resilience.SERVICES:
            with self.subTest(service=service):
                checks=resilience.evaluate_fault(service,fault(service))
                self.assertTrue(all(checks.values()),checks)
                self.assertFalse(resilience.healthy(fault(service)))

    def test_reused_evidence_or_external_leak_never_pass(self):
        row=fault('opensearch');row['incidents_internal']['response']['logs']={'rows':['stale']}
        self.assertFalse(resilience.evaluate_fault('opensearch',row)['old_logs_and_documents_are_not_reused'])
        row=fault('victoriametrics');row['incidents_internal']['response']['metrics']=[{'value':'stale'}]
        self.assertFalse(resilience.evaluate_fault('victoriametrics',row)['old_measurements_are_not_reused'])
        row=fault('ldap');row['incidents_external']['response']['sources']=[{'private':'leak'}]
        self.assertFalse(resilience.evaluate_fault('ldap',row)['external_has_no_incident_evidence'])

    def test_baseline_with_generation_or_external_evidence_is_not_healthy(self):
        row=baseline();row['pdl_internal']['response']['result']['structuredContent']['execution']['albert_calls']=1
        self.assertFalse(resilience.healthy(row))
        row=baseline();row['incidents_external']['response']['metrics']=[{'private':'leak'}]
        self.assertFalse(resilience.healthy(row))


class CampaignTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.instance=self.root/'instance';self.instance.mkdir()
        self.values={'RIE_MODE':'demo','RIE_PROJECT':'rie-test','PDL_PORT':'19910','INCIDENTS_PORT':'19950'}
        self.manager=SimpleNamespace(ROOT=ROOT,load=Mock(return_value=self.values),guard=Mock(),compose=Mock())

    def test_campaign_stops_only_one_owned_service_then_recovers_and_revokes(self):
        output=self.root/'evidence';credentials={'internal':'DO_NOT_PUBLISH_INTERNAL_SECRET','external':'DO_NOT_PUBLISH_EXTERNAL_SECRET'}
        metadata={'internal':{'id':'a'*32},'external':{'id':'b'*32}}
        with patch.object(resilience,'issue_credentials',return_value=(credentials,metadata,{})),\
             patch.object(resilience,'probes',side_effect=[baseline(),fault('ldap'),baseline()]),\
             patch.object(resilience,'runtime_check',side_effect=[0,2,0]),\
             patch.object(resilience,'revoke_credentials') as revoke,redirect_stdout(io.StringIO()):
            code=resilience.run(self.instance,output,services=('ldap',),manager=self.manager)
        self.assertEqual(code,0)
        commands=[call.args[2:] for call in self.manager.compose.call_args_list]
        self.assertEqual(commands,[('--profile','demo','stop','--timeout','45','ldap'),('--profile','demo','start','ldap')])
        revoke.assert_called_once();self.assertFalse((self.instance/'.resilience.lock').exists())
        self.assertFalse((output/'.credentials').exists())
        report=json.loads((output/'report.json').read_text());self.assertTrue(report['passed'])
        self.assertEqual(report['cases'][0]['check_exit_during_fault'],2)
        text=''.join(path.read_text() for path in output.iterdir() if path.is_file())
        self.assertNotIn('DO_NOT_PUBLISH',text)

    def test_unhealthy_baseline_never_triggers_fault_injection(self):
        output=self.root/'evidence'
        with patch.object(resilience,'issue_credentials',return_value=({}, {'user':{'id':'a'*32}}, {})),\
             patch.object(resilience,'probes',return_value=fault('ldap')),\
             patch.object(resilience,'revoke_credentials') as revoke,redirect_stdout(io.StringIO()):
            code=resilience.run(self.instance,output,manager=self.manager)
        self.assertEqual(code,2);self.manager.compose.assert_not_called();revoke.assert_called_once()
        self.assertFalse(json.loads((output/'report.json').read_text())['passed'])

    def test_campaign_refuses_the_endurance_instance_before_mutation(self):
        self.values['RIE_LOAD_QUALIFICATION']='true'
        output=self.root/'never-created'
        with self.assertRaisesRegex(ValueError,'non-load'):
            resilience.run(self.instance,output,manager=self.manager)
        self.manager.compose.assert_not_called();self.assertFalse(output.exists())


if __name__=='__main__':unittest.main()
