from pathlib import Path
import sys
import unittest

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from load_seed import compare_documents


class ReadOnlyCorpusTests(unittest.TestCase):
    def compare(self, hits):
        calls = []
        def handler(request):
            calls.append((request.method, request.url.path))
            if request.method == 'DELETE':
                return httpx.Response(200, json={'succeeded': True})
            return httpx.Response(200, json={'_scroll_id': 'fixture-cursor', '_shards': {'failed': 0},
                                            'hits': {'hits': hits if len(calls) == 1 else []}})
        with httpx.Client(base_url='http://fixture.invalid', transport=httpx.MockTransport(handler)) as client:
            return compare_documents(client, 'fixture-index', {'a': {'value': 1}}), calls

    def test_full_source_is_compared_and_only_search_cursor_is_deleted(self):
        result, calls = self.compare([{'_id': 'a', '_source': {'value': 1}}])
        self.assertEqual(result['documents'], 1)
        self.assertTrue(result['all_sources_compared'])
        self.assertEqual(calls, [('POST', '/fixture-index/_search'), ('POST', '/_search/scroll'),
                                 ('DELETE', '/_search/scroll')])

    def test_equal_count_does_not_hide_source_corruption(self):
        with self.assertRaises(ValueError):
            self.compare([{'_id': 'a', '_source': {'value': 2}}])

    def test_missing_extra_and_duplicate_records_are_refused(self):
        for hits in ([], [{'_id': 'b', '_source': {'value': 1}}],
                     [{'_id': 'a', '_source': {'value': 1}}] * 2):
            with self.subTest(hits=hits), self.assertRaises(ValueError):
                self.compare(hits)
