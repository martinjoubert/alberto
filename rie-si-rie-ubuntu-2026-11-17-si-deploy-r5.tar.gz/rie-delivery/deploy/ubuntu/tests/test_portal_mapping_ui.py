"""Exercise guided controls, explicit confirmation and expired mapping sessions."""
import importlib
import importlib.util
import asyncio
import os
from unittest.mock import patch
import unittest

from deploy.ubuntu.tests.test_portal_mappings import MappingFixture


@unittest.skipUnless(importlib.util.find_spec('nicegui'), 'NiceGUI test dependency required')
class MappingUiTests(MappingFixture, unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        storage = patch.dict(os.environ, {'NICEGUI_STORAGE_PATH': str(self.root / 'ui-storage')})
        storage.start(); self.addCleanup(storage.stop)
        self.portal = importlib.import_module('portal.app')
        from nicegui import helpers
        pytest_mode = patch.object(helpers, 'is_pytest', return_value=True)
        pytest_mode.start(); self.addCleanup(pytest_mode.stop)
        self.session.mapping_administration = lambda: self.admin
        self.factory = patch.object(self.portal, 'Session', return_value=self.session)
        self.factory.start(); self.addCleanup(self.factory.stop)

    async def login(self, user, name='alice'):
        user.find('Identifiant LDAP').type(name)
        user.find('Mot de passe').type('fictional-password')
        user.find('Se connecter').click()
        await user.should_see('Connexion établie.', retries=30)

    async def test_reader_never_sees_mapping_controls(self):
        self.session.logout()
        from nicegui.testing.user_simulation import user_simulation
        async with user_simulation(root=self.portal.mapping_administration) as user:
            await user.open('/')
            await self.login(user, 'bruno')
            await user.should_see('Administration réservée', retries=30)
            await user.should_not_see('Actualiser les sources')
            self.assertEqual(self.refreshes, 0)

    async def test_existing_review_needs_a_confirmation_then_approves_one_index(self):
        identifier = self.stage()
        self.session.logout()
        from nicegui.testing.user_simulation import user_simulation
        async with user_simulation(root=self.portal.mapping_administration) as user:
            await user.open('/')
            await self.login(user)
            await user.should_see('1 revue(s) en attente.', retries=30)
            next(iter(user.find('Revue à examiner').elements)).value = identifier
            user.find('Examiner cette revue').click()
            await user.should_see('pfs-prod · pending', retries=30)
            user.find('Justification de l’approbation').type('Source owner confirmed the fields')
            user.find('Approuver ce mapping').click()
            await user.should_see('Confirmez la vérification du sens métier', retries=30)
            self.assertEqual(self.store.catalog(), [])
            # A denied action removes its stale review; inspect it explicitly again.
            user.find('Examiner cette revue').click()
            await user.should_see('pfs-prod · pending', retries=30)
            user.find('Je confirme le sens des champs').click()
            user.find('Justification de l’approbation').type('Source owner confirmed the fields')
            user.find('Approuver ce mapping').click()
            await user.should_see('Mapping approuvé pour pfs-prod', retries=30)
            await user.should_see('0 revue(s) en attente.', retries=30)
            self.assertEqual(len(self.store.catalog()), 1)

    async def test_guided_proposal_validates_and_stages_without_activation(self):
        self.stage()
        self.session.logout()
        from nicegui.testing.user_simulation import user_simulation
        async with user_simulation(root=self.portal.mapping_administration) as user:
            await user.open('/')
            await self.login(user)
            await user.should_see('1 revue(s) en attente.', retries=30)
            user.find('Vérifier la proposition').click()
            await user.should_see('Proposition valide techniquement', retries=30)
            user.find('Motif de la proposition').type('New reviewed proposal from guided form')
            user.find('Enregistrer une proposition').click()
            await user.should_see('Proposition enregistrée en attente', retries=30)
            self.assertEqual(self.store.catalog(), [])

    async def test_new_index_and_fields_can_be_configured_without_yaml(self):
        self.session.logout()
        from nicegui.testing.user_simulation import user_simulation
        from nicegui import ui
        async with user_simulation(root=self.portal.mapping_administration) as user:
            await user.open('/')
            await self.login(user)
            await user.should_see('Choisissez un index découvert', retries=30)
            next(iter(user.find('Ajouter un index découvert').elements)).value = 'pfs-prod'
            user.find('Ajouter cet index').click()
            await user.should_see('Index sélectionné : pfs-prod', retries=30)
            next(element for element in user.find(ui.select).elements
                 if element.props.get('data-mapping-field') == 'timestamp').value = '@timestamp'
            next(iter(user.find('Ajouter un concept métier').elements)).value = 'action'
            user.find('Ajouter ce concept').click()
            await user.should_see('Action réseau · champ à choisir', retries=30)
            next(element for element in user.find(ui.select).elements
                 if element.props.get('data-mapping-field') == 'action').value = 'event.action'
            user.find('Vérifier la proposition').click()
            await user.should_see('Proposition valide techniquement', retries=30)
            user.find('Motif de la proposition').type('Created entirely with guided controls')
            user.find('Enregistrer une proposition').click()
            await user.should_see('1 revue(s) en attente.', retries=30)
            mapping = self.store.reviews()[0]['proposed_mapping']
            self.assertEqual(mapping['timestamp']['field'], '@timestamp')
            self.assertEqual(mapping['action']['field'], 'event.action')
            self.assertEqual(self.store.catalog(), [])

    async def test_lost_admin_membership_removes_fields_and_review_controls(self):
        self.stage()
        self.session.logout()
        from nicegui.testing.user_simulation import user_simulation
        async with user_simulation(root=self.portal.mapping_administration) as user:
            await user.open('/')
            await self.login(user)
            await user.should_see('1 revue(s) en attente.', retries=30)
            self.directory.administrator = False
            user.find('Actualiser les sources').click()
            await user.should_see('Administration réservée', retries=30)
            await user.should_not_see('Enregistrer une proposition')
            await user.should_not_see('pfs-prod')
            self.assertEqual(self.store.catalog(), [])

    async def test_invalid_typed_values_block_validation_and_export(self):
        fields = self.inventory['indices']['pfs-prod']['fields']
        fields['event.count'] = {'type': 'long', 'types': ['long'], 'searchable': True, 'aggregatable': True}
        self.document['indices']['pfs']['concepts']['severity'] = {'field': 'event.count', 'type': 'long'}
        self.store.save_inventory(self.inventory)
        self.stage()
        self.session.logout()
        from nicegui.testing.user_simulation import user_simulation
        from nicegui import ui
        async with user_simulation(root=self.portal.mapping_administration) as user:
            await user.open('/')
            await self.login(user)
            await user.should_see('1 revue(s) en attente.', retries=30)
            target = next(element for element in user.find(ui.textarea).elements
                          if element.props.get('data-mapping-values') == 'severity')
            target.value = 'not-a-number'
            user.find('Vérifier la proposition').click()
            await user.should_see('Corrigez les valeurs métier incompatibles', retries=30)
            with patch.object(self.admin, 'export') as export:
                user.find('Exporter le YAML').click()
                await asyncio.sleep(.1)
                export.assert_not_called()
                await user.should_see('Corrigez les valeurs métier incompatibles', retries=30)
            self.assertEqual(self.store.catalog(), [])


if __name__ == '__main__':
    unittest.main()
