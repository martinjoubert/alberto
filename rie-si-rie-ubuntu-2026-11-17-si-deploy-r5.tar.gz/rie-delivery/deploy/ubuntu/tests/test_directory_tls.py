"""Verify the actual LDAP TLS socket against DNS/IP names and untrusted peers."""
from contextlib import contextmanager
import datetime
import ipaddress
from pathlib import Path
import socket
import ssl
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'core/access-control/src'))
from dinum_access.security import _verified_directory_tls


class DirectoryTlsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.folder.cleanup)
        cls.root = Path(cls.folder.name)
        now = datetime.datetime.now(datetime.timezone.utc)
        ca_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'LDAP TLS test CA')])
        ca = (x509.CertificateBuilder().subject_name(ca_name).issuer_name(ca_name)
              .public_key(ca_key.public_key()).serial_number(x509.random_serial_number())
              .not_valid_before(now - datetime.timedelta(days=2))
              .not_valid_after(now + datetime.timedelta(days=2))
              .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
              .sign(ca_key, hashes.SHA256()))
        cls.ca_file = cls.root / 'ca.pem'
        cls.ca_file.write_bytes(ca.public_bytes(serialization.Encoding.PEM))
        cls.key_file = cls.root / 'server.key'
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.key_file.write_bytes(key.private_bytes(serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        cls.key_file.chmod(0o600)
        cls.certificates = {}
        for name, names, expired in (
            ('ip', [x509.IPAddress(ipaddress.ip_address('127.0.0.1'))], False),
            ('dns', [x509.DNSName('ldap.example.test')], False),
            ('ipv6', [x509.IPAddress(ipaddress.ip_address('::1'))], False),
            ('expired', [x509.IPAddress(ipaddress.ip_address('127.0.0.1'))], True),
        ):
            cert = (x509.CertificateBuilder()
                .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'test-server')]))
                .issuer_name(ca_name).public_key(key.public_key())
                .serial_number(x509.random_serial_number())
                .not_valid_before(now - datetime.timedelta(days=2))
                .not_valid_after(now - datetime.timedelta(days=1) if expired
                                 else now + datetime.timedelta(days=1))
                .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
                .add_extension(x509.SubjectAlternativeName(names), critical=False)
                .sign(ca_key, hashes.SHA256()))
            path = cls.root / (name + '.pem')
            path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
            cls.certificates[name] = path

    @contextmanager
    def peer(self, certificate='ip'):
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(self.certificates[certificate], self.key_file)
        errors = []
        # Exercise real TLS over local IPC, with no DNS, listener or network access.
        server_socket, client_socket = socket.socketpair()
        self.addCleanup(server_socket.close)
        self.addCleanup(client_socket.close)
        server_socket.settimeout(5)
        client_socket.settimeout(5)

        def serve():
            try:
                with context.wrap_socket(server_socket, server_side=True) as secure:
                    secure.recv(1)
            except ssl.SSLError:
                # Rejected clients intentionally abort their handshake.
                pass
            except Exception as error:
                errors.append(error)

        thread = threading.Thread(target=serve, daemon=True)
        thread.start()
        try:
            yield client_socket
        finally:
            thread.join(6)
            server_socket.close()
            client_socket.close()
            self.assertFalse(thread.is_alive(), 'TLS peer did not finish')
            self.assertEqual(errors, [])

    def connect(self, certificate, hostname, ca_file=None):
        tls = _verified_directory_tls(str(ca_file or self.ca_file))
        self.assertEqual(tls.validate, ssl.CERT_REQUIRED)
        with self.peer(certificate) as raw:
            connection = SimpleNamespace(socket=raw, server=SimpleNamespace(host=hostname))
            tls.wrap_socket(connection, do_handshake=True)
            with connection.socket as secure:
                self.assertTrue(secure.context.check_hostname)
                self.assertEqual(secure.context.verify_mode, ssl.CERT_REQUIRED)
                secure.sendall(b'x')

    def test_verified_ipv4_san_is_accepted(self):
        self.connect('ip', '127.0.0.1')

    def test_verified_dns_san_is_accepted(self):
        self.connect('dns', 'ldap.example.test')

    def test_verified_ipv6_san_is_accepted(self):
        # The address used for the test socket is independent of its checked identity.
        self.connect('ipv6', '::1')

    def test_wrong_ipv4_san_is_rejected(self):
        with self.assertRaises(ssl.SSLCertVerificationError):
            self.connect('ip', '127.0.0.2')

    def test_wrong_dns_san_is_rejected(self):
        with self.assertRaises(ssl.SSLCertVerificationError):
            self.connect('dns', 'other.example.test')

    def test_dns_name_does_not_authorize_an_ip_address(self):
        with self.assertRaises(ssl.SSLCertVerificationError):
            self.connect('dns', '127.0.0.1')

    def test_ip_address_does_not_authorize_a_dns_name(self):
        with self.assertRaises(ssl.SSLCertVerificationError):
            self.connect('ip', 'ldap.example.test')

    def test_expired_certificate_is_rejected(self):
        with self.assertRaises(ssl.SSLCertVerificationError):
            self.connect('expired', '127.0.0.1')

    def test_untrusted_ca_is_rejected(self):
        # A leaf is a valid PEM certificate, but cannot trust its issuer.
        with self.assertRaises(ssl.SSLCertVerificationError):
            self.connect('ip', '127.0.0.1', self.certificates['dns'])


if __name__ == '__main__':
    unittest.main()
