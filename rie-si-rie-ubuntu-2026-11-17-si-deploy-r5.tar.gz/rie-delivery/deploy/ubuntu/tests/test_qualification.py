"""Qualification doubles are bounded, labelled and cannot become a live provider."""
import importlib.util
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'use-cases/pdl/agentic-pdl'),str(ROOT/'core/access-control/src'),str(ROOT/'core/albert-client/src')]
def module(name):
 spec=importlib.util.spec_from_file_location('delivery_'+name,ROOT/'deploy/ubuntu'/(name+'.py'))
 result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
provider=module('simulated_provider');qualification=module('qualification');load=module('load_seed');vm=module('vm')


class QualificationTests(unittest.TestCase):
 def test_storage_sampling_records_a_file_expiring_during_the_scan(self):
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory);stable=root/'report.json';stable.write_bytes(b'kept')
   expired=root/'state.json';expired.write_bytes(b'cache')
   def entries(*_args):
    yield stable
    expired.unlink()
    yield expired
   output=io.StringIO()
   with patch.object(Path,'rglob',entries),redirect_stdout(output):
    exec(qualification.STORAGE_SAMPLE_CODE,{})
   self.assertEqual(json.loads(output.getvalue()),{'files':1,'bytes':4,'vanished_during_scan':1})
   self.assertEqual(stable.read_bytes(),b'kept')
 def test_storage_sampling_does_not_hide_a_permission_failure(self):
  with patch.object(Path,'rglob',return_value=iter([Path('/data/denied')])),patch.object(Path,'lstat',side_effect=PermissionError('denied')):
   with self.assertRaises(PermissionError):exec(qualification.STORAGE_SAMPLE_CODE,{})
 def test_storage_sampling_does_not_follow_links_outside_the_volume(self):
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory);target=root/'outside';target.write_bytes(b'not counted')
   link=root/'link';link.symlink_to(target)
   output=io.StringIO()
   with patch.object(Path,'rglob',return_value=iter([link])),redirect_stdout(output):
    exec(qualification.STORAGE_SAMPLE_CODE,{})
   self.assertEqual(json.loads(output.getvalue()),{'files':0,'bytes':0,'vanished_during_scan':0})
 def test_known_fixture_plan_is_copied_and_the_normal_runtime_keeps_validation(self):
  question=next(iter(provider.fixture_questions()))
  request={'model':provider.MODEL,'messages':[{'role':'user','content':json.dumps({'question':question})}]}
  result=provider.answer(request);result['index']='forged'
  self.assertNotEqual(provider.answer(request).get('index'),'forged')
 def test_unknown_model_and_question_fail_instead_of_faking_general_intelligence(self):
  for model,question in [('real-model','unknown'),(provider.MODEL,'unknown')]:
   with self.assertRaises(ValueError):provider.answer({'model':model,'messages':[{'content':json.dumps({'question':question})}]})
 def test_dialogue_double_classifies_only_explicit_fixture_questions(self):
  q=next(iter(provider.fixture_questions()))
  result=provider.answer({'model':provider.MODEL,'messages':[{'content':json.dumps({'current_message':q})}]})
  self.assertEqual(result,{'action':'new','confidence':1.0,'clarification':'','source_change':'unchanged'})
 def test_percentiles_and_expected_refusals_remain_separate_from_errors(self):
  rows=[{'latency_ms':v,'passed':v!=100,'expected_denial':v==2,'business_status':'denied' if v==2 else 'ok'} for v in (1,2,3,100)]
  result=qualification.summary(rows)
  self.assertEqual(result['requests'],4);self.assertEqual(result['unexpected_errors'],1)
  self.assertEqual(result['expected_denials'],1);self.assertEqual(result['p95_ms'],100)
  self.assertIsNone(qualification.percentile([],.99))
 def test_load_accounts_do_not_expose_passwords_and_preserve_original_users(self):
  manage=module('manage')
  with tempfile.TemporaryDirectory() as directory:
   instance=Path(directory)/'instance';manage.bootstrap(instance,'demo')
   original=(instance/'config/ldap/seed.ldif').read_text()
   records=load.prepare_accounts(instance)
   self.assertEqual(len(records),10);self.assertEqual(len({r['username'] for r in records}),10)
   self.assertEqual(sum(r['category']=='external' for r in records),2)
   self.assertNotIn('password',json.dumps(records));self.assertIn('uid=alice.martin,',(instance/'config/ldap/seed.ldif').read_text())
   self.assertGreater((instance/'config/ldap/seed.ldif').stat().st_size,len(original))
   self.assertEqual(load.prepare_accounts(instance),records)
   self.assertEqual(json.loads((instance/'config/load-accounts.json').read_text()),records)
 def test_load_account_preparation_refuses_an_existing_docker_instance(self):
  with tempfile.TemporaryDirectory() as directory:
   p=Path(directory);(p/'.env').write_text('RIE_MODE=demo\n');(p/'docker-id').touch()
   with self.assertRaises(ValueError):load.prepare_accounts(p)
 def test_vm_has_no_mounts_agent_forwarding_or_extra_exposed_ports(self):
  content=vm.config('rie-u24-manual','24.04',0)
  self.assertIn('mounts: []',content);self.assertIn('forwardAgent: false',content)
  self.assertIn('ignore: true',content);self.assertIn('digest: sha256:',content)
  with self.assertRaises(ValueError):vm.config('unrelated-project','24.04',0)


if __name__=='__main__':unittest.main()
