"""Exercise the three Ubuntu demos against a running portal, with real LDAP users.

Credentials come from a private accounts JSON and are never written to reports.
The only temporary policy change is restored in a finally block. No Albert call
is made: PDL uses self-access information and Incidents disables synthesis.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import sys
import time
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', required=True)
    parser.add_argument('--pdl-port', type=int, default=19910, help='Published PDL port displayed by this instance')
    parser.add_argument('--incidents-port', type=int, default=19950, help='Published Incidents port displayed by this instance')
    credentials = parser.add_mutually_exclusive_group(required=True)
    credentials.add_argument('--accounts-file', type=Path)
    credentials.add_argument('--accounts-stdin', action='store_true', help='Read private fixture users from stdin without a host credential file.')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--channel', help='Optional installed Chromium channel, for example msedge.')
    parser.add_argument('--browser-executable', type=Path)
    parser.add_argument('--source-docs', type=Path)
    parser.add_argument('--allure-results', type=Path, help='Optional Allure result directory for this browser recipe')
    parser.add_argument('--simulated-backends', action='store_true',
                        help='Label a UI-only recipe using backend doubles; never a VM qualification.')
    parser.add_argument('--require-itsm-history', action='store_true',
                        help='Also require the explicit synthetic historical-ticket demo and its ACL round trip')
    parser.add_argument('--itsm-history-provider',choices=['fixture','itsm-ng'],default='fixture')
    args = parser.parse_args()
    if not all(1 <= port <= 65535 for port in (args.pdl_port, args.incidents_port)):
        parser.error('Published backend ports must be between 1 and 65535')
    if not args.url.startswith(('http://127.0.0.1:', 'http://localhost:', 'https://')):
        parser.error('Use loopback HTTP or an authenticated HTTPS test endpoint')
    os.umask(0o077)
    args.output.mkdir(parents=True, exist_ok=True, mode=0o700)
    accounts = json.load(sys.stdin) if args.accounts_stdin else json.loads(args.accounts_file.read_text())
    users = {row['uid']: row['password'] for row in accounts['users']}
    internal, reader, external, unknown = 'alice.martin', 'bruno.lecteur', 'eric.durand.ext', 'camille.inconnue'
    if not {internal, external, unknown}.issubset(users):
        parser.error('The synthetic directory accounts are required')
    from playwright.sync_api import sync_playwright, expect
    checks, errors = [], []
    base = args.url.rstrip('/')
    reporting = None
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    import test_reporting as reporting_tools
    from browser_diagnostics import BrowserDiagnostics
    diagnostics = BrowserDiagnostics(args.output, secrets=users.values())
    campaign = reporting_tools.Campaign(args.allure_results, 'browser-portal') if args.allure_results else None
    if args.allure_results:
        reporting = reporting_tools
    step_start, step_clock = time.time_ns()//1_000_000, time.monotonic()

    def record(name, status, captures=(), message='', trace=''):
        nonlocal step_start, step_clock
        stop = step_start + round((time.monotonic()-step_clock)*1000)
        if reporting:
            reporting.write_result(args.allure_results, 'browser-portal', name, status,
                start=step_start, stop=stop, message=message, trace=trace,
                diagnostics=diagnostics.channels() if status != 'passed' else {}, secrets=users.values(),
                attachments=[args.output/name for name in captures],
                steps=[{'name': name, 'status': status, 'stage': 'finished', 'start': step_start, 'stop': stop}],
                labels=[{'name': 'framework', 'value': 'playwright-python'},
                        {'name': 'backends', 'value': 'simulated' if args.simulated_backends else 'deployed-ubuntu'}])
        step_start, step_clock = time.time_ns()//1_000_000, time.monotonic()

    def checked(name, captures=()):
        checks.append({'name': name, 'passed': True})
        record(name, 'passed', captures)
        if campaign:
            campaign.checkpoint('Dernier contrôle terminé : '+name)
        print(json.dumps({'check': name, 'passed': True}), flush=True)

    def login(page, name):
        page.locator('input[data-portal-username], [data-portal-username] input').fill(name)
        page.locator('input[data-portal-password], [data-portal-password] input').fill(users[name])
        page.locator('[data-portal-login]').click()
        expect(page.locator('[data-portal-login-status]')).to_contain_text('Connexion établie', timeout=30000)
        expect(page.locator('[data-portal-identity]')).to_be_visible(timeout=30000)
        assert page.locator('input[data-portal-password], [data-portal-password] input').input_value() == '', 'Password must be cleared'

    def read_result(page):
        expect(page.locator('[data-portal-pending]')).to_have_count(0, timeout=180000)
        expect(page.locator('[data-portal-result]')).to_be_visible(timeout=180000)
        return json.loads(page.locator('[data-portal-result] pre code').inner_text())

    def perform(page, marker):
        previous = page.locator('[data-portal-result]')
        previous_id = previous.get_attribute('id') if previous.count() else None
        button=page.locator('[' + marker + ']')
        if marker=='data-incidents-read' and not button.is_visible():
            page.get_by_role('button', name='Expand "Contrôle technique des sources, sans génération IA"', exact=True).click()
        button.click()
        if previous_id:
            expect(page.locator('#' + previous_id)).to_have_count(0, timeout=180000)
        return read_result(page)

    def select_visibility(page, value):
        labels = {'blocked': 'Interdit à tous', 'internal': 'Réservé aux internes',
                  'authenticated': 'Ouvert aux utilisateurs authentifiés'}
        page.locator('[data-admin-visibility]').click()
        page.get_by_role('option', name=labels[value], exact=True).click()

    with sync_playwright() as playwright:
        options = {'headless': True}
        if args.channel:
            options['channel'] = args.channel
        if args.browser_executable:
            options['executable_path'] = str(args.browser_executable)
        browser = internal_context = external_context = page = other = None
        try:
            browser = playwright.chromium.launch(**options)
            internal_context = browser.new_context(viewport={'width': 1440, 'height': 1000})
            external_context = browser.new_context(viewport={'width': 1440, 'height': 1000})
            page = internal_context.new_page()
            other = external_context.new_page()
            diagnostics.watch(page)
            diagnostics.watch(other)
            page.on('pageerror', lambda error: errors.append(type(error).__name__))
            other.on('pageerror', lambda error: errors.append(type(error).__name__))
            for route, title in [('/', 'UC PDL, Incidents et ACL'),
                                  ('/demo-pdl-5min', 'PDL — quatre familles'),
                                  ('/demo-incidents-5min', 'Incidents — mesures'),
                                  ('/demo-acces', 'ACL — identité'),
                                  ('/admin-acces', 'Administrer les règles'),
                                  ('/documentation', 'Documentation SI-RIE')]:
                page.goto(base + route, wait_until='networkidle')
                expect(page.locator('[data-portal-title]')).to_contain_text(title)
                expected_diagrams = 12 if route == '/documentation' else (1 if route in {
                    '/', '/demo-pdl-5min', '/demo-incidents-5min', '/demo-acces'} else 0)
                expect(page.locator('[data-portal-diagram]')).to_have_count(expected_diagrams, timeout=20000)
                for image in page.locator('[data-portal-diagram] img').all():
                    image.scroll_into_view_if_needed()
                    expect(image).to_be_visible()
                    page.wait_for_function('image => image.complete && image.naturalWidth > 0', arg=image.element_handle())
                assert not page.locator('a[href*="127.0.0.1:3000"]').count(), 'No absent Grafana destination'
                assert not page.locator('a[href*="127.0.0.1:9950"]').count(), 'No historical MCP destination'
                checked('page_' + (route.strip('/') or 'home'))
                if route == '/' and page.locator('[data-portal-fullscreen]').count():
                    page.locator('[data-portal-fullscreen]').first.click()
                    expect(page.get_by_role('button', name='Fermer le diagramme', exact=True)).to_be_visible()
                    page.get_by_role('button', name='Fermer le diagramme', exact=True).click()
                    checked('diagram_fullscreen_and_return')
            page.goto(base + '/demo-pdl-5min', wait_until='networkidle')
            expect(page.locator('[data-pdl-corpus]')).to_contain_text('12 octobre 2026')
            expect(page.locator('[data-pdl-mcp-url]')).to_contain_text(str(args.pdl_port)+'/mcp')
            login(page, internal)
            catalog = perform(page, 'data-pdl-catalogue')['catalogue']
            assert {row['index'] for row in catalog} == {'rie-pfs-fixture', 'rie-bb-fixture', 'rie-pfaing-fixture', 'rie-tacacs-fixture'}, 'Current portable catalogue required'
            page.screenshot(path=str(args.output / 'pdl-catalog.png'), full_page=True)
            pdl_access = perform(page, 'data-pdl-own-access')
            assert pdl_access['access_control']['category'] == 'internal', 'Own MCP identity must be internal'
            receipt = perform(page, 'data-pdl-receipt')
            assert receipt['source'] == 'latest_acceptance_of_this_ubuntu_instance', 'Recipe must come from this instance'
            assert receipt['fresh_investigation'] is False and receipt['captured_at_utc'], 'Historical recipe must be dated'
            page.locator('[data-portal-logout]').click()
            expect(page.locator('[data-portal-result]')).to_have_count(0)
            expect(page.locator('[data-portal-identity]')).to_have_count(0)
            checked('pdl_current_catalogue_mcp_identity_and_dated_receipt', ('pdl-catalog.png',))

            page.goto(base + '/demo-incidents-5min', wait_until='networkidle')
            expect(page.locator('[data-incidents-mcp-url]')).to_contain_text(str(args.incidents_port)+'/gptoss/assistant/mcp')
            login(page, internal)
            diagnostic = perform(page, 'data-incidents-read')
            assert diagnostic['status'] == 'ok' and not diagnostic['errors'], 'Internal fresh diagnostic must succeed'
            assert len(diagnostic['metrics']) == 5 and diagnostic['logs']['total'] == 120, 'Read real VM evidence'
            assert diagnostic['analysis'] is None, 'No Albert synthesis in this browser recipe'
            page.screenshot(path=str(args.output / 'incidents-internal.png'), full_page=True)
            checked('incidents_fresh_internal_evidence_without_generation', ('incidents-internal.png',))
            if args.require_itsm_history:
                assert diagnostic.get('ticket_history',{}).get('provider')==args.itsm_history_provider
                assert diagnostic['ticket_history']['synthetic'] is True
                assert len(diagnostic.get('precedents',[]))==3
                assert diagnostic['proposed_solution']['state']=='proposed'
                assert diagnostic['proposed_solution']['confidence']=='élevée'
                assert 'Redémarrer' not in diagnostic['proposed_solution']['solution']
                assert 'HISTORICAL_FORBIDDEN_CANARY' not in json.dumps(diagnostic)
                report=page.locator('[data-incidents-report]')
                expect(report).to_contain_text('Confiance dans la solution')
                expect(report).to_contain_text('Confiance dans le diagnostic')
                expect(report).to_contain_text('à valider par un opérateur')
                checked('itsm_precedents_and_separate_explained_confidence')

            other.goto(base + '/demo-incidents-5min', wait_until='networkidle')
            expect(other.locator('[data-portal-identity]')).to_have_count(0)
            login(other, external)
            denial = perform(other, 'data-incidents-read')
            assert denial['status'] == 'denied', 'External source access must be denied'
            assert not any(denial.get(key) for key in ('metrics', 'events', 'logs', 'documents', 'sources', 'evidence')), 'Denied data must not leak'
            expect(page.locator('[data-portal-identity]')).not_to_contain_text('eric.durand')
            other.screenshot(path=str(args.output / 'incidents-external-denied.png'), full_page=True)
            checked('external_refusal_and_distinct_browser_sessions', ('incidents-external-denied.png',))

            other.goto(base + '/admin-acces', wait_until='networkidle')
            login(other, external)
            expect(other.locator('[data-admin-denied]')).to_be_visible()
            expect(other.locator('[data-admin-save]')).to_have_count(0)
            checked('external_cannot_administrate')

            if reader in users:
                other.goto(base + '/demo-pdl-5min', wait_until='networkidle')
                login(other, reader)
                reader_catalog = perform(other, 'data-pdl-catalogue')['catalogue']
                assert {row['index'] for row in reader_catalog} == {row['index'] for row in catalog}, 'Internal reader keeps the current PDL catalogue'
                reader_access = perform(other, 'data-pdl-own-access')
                assert reader_access['access_control']['category'] == 'internal', 'Distinct account must remain internal'
                other.goto(base + '/demo-incidents-5min', wait_until='networkidle')
                login(other, reader)
                reader_diagnostic = perform(other, 'data-incidents-read')
                assert reader_diagnostic['status'] == 'ok' and not reader_diagnostic['errors']
                assert len(reader_diagnostic['metrics']) == 5 and reader_diagnostic['logs']['total'] == 120
                assert reader_diagnostic['analysis'] is None, 'Reader test must not generate AI content'
                other.goto(base + '/admin-acces', wait_until='networkidle')
                login(other, reader)
                expect(other.locator('[data-admin-denied]')).to_be_visible()
                expect(other.locator('[data-admin-save]')).to_have_count(0)
                other.goto(base + '/qualification', wait_until='networkidle')
                login(other, reader)
                expect(other.locator('[data-qualification-denied]')).to_be_visible()
                expect(other.locator('[data-qualification-report]')).to_have_count(0)
                checked('internal_reader_retains_business_reads_without_administration_or_reports')
            else:
                record('internal_reader_not_provided_by_historical_fixture', 'skipped',
                       message='Ancienne fixture sans Bruno : séparation de rôle non qualifiée par ce parcours.')

            page.goto(base + '/admin-acces', wait_until='networkidle')
            login(page, internal)
            expect(page.locator('[data-admin-revision]')).to_contain_text('Révision active', timeout=30000)
            row = page.locator('[data-admin-policy] tr').filter(has_text='rie-pfs-fixture')
            original = row.locator('td').nth(1).inner_text().strip()
            assert original in {'authenticated', 'internal', 'blocked'}, 'Exact current policy must be read'
            changed = False
            try:
                page.locator('input[data-admin-index], [data-admin-index] input').fill('rie-pfs-fixture')
                select_visibility(page, 'internal')
                perform(page, 'data-admin-save')
                changed = True
                other.goto(base + '/demo-acces', wait_until='networkidle')
                login(other, external)
                current = perform(other, 'data-acl-own-access')
                assert current['category'] == 'external' and 'rie-pfs-fixture' not in current['allowed_indices'], 'Policy change must apply to fresh reads'
                other.screenshot(path=str(args.output / 'acl-current-external-rights.png'), full_page=True)
                page.screenshot(path=str(args.output / 'acl-administration.png'), full_page=True)
                checked('policy_change_effective_without_client_identity_upgrade', ('acl-current-external-rights.png', 'acl-administration.png'))
            finally:
                if changed:
                    select_visibility(page, original)
                    restored = perform(page, 'data-admin-save')
                    assert restored['policy']['indices']['rie-pfs-fixture'] == original, 'The original policy must be restored'

            source_row = page.locator('[data-admin-resources] tr').filter(has_text='Mesures VictoriaMetrics')
            source_original = source_row.locator('td').nth(1).inner_text().strip()
            assert source_original in {'authenticated', 'internal', 'blocked'}
            page.locator('[data-admin-target]').get_by_role('button', name='Source Incidents', exact=True).click()
            expect(page.locator('[data-admin-resource]')).to_be_visible()
            source_changed = False
            try:
                select_visibility(page, 'blocked')
                changed_source = perform(page, 'data-admin-save')
                source_changed = True
                assert changed_source['policy']['resources']['incidents.metrics'] == 'blocked'
                other.goto(base + '/demo-incidents-5min', wait_until='networkidle')
                login(other, internal)
                denied_source = perform(other, 'data-incidents-read')
                assert denied_source['status'] == 'denied'
                assert not any(denied_source.get(key) for key in ('metrics', 'events', 'logs', 'documents', 'sources', 'evidence'))
                page.screenshot(path=str(args.output / 'acl-source-administration.png'), full_page=True)
                checked('source_policy_refusal_applies_to_current_internal_session', ('acl-source-administration.png',))
            finally:
                if source_changed:
                    select_visibility(page, source_original)
                    restored_source = perform(page, 'data-admin-save')
                    assert restored_source['policy']['resources']['incidents.metrics'] == source_original
            reopened = perform(other, 'data-incidents-read')
            assert reopened['status'] == 'ok' and reopened.get('metrics'), 'Source access must recover on the next read'
            checked('source_policy_recovery_without_session_replacement')
            if args.require_itsm_history:
                row=page.locator('[data-admin-resources] tr').filter(has_text='Tickets et suivi ITSM')
                original_ticket=row.locator('td').nth(1).inner_text().strip()
                page.locator('[data-admin-resource]').click()
                page.get_by_role('option',name='Tickets et suivi ITSM',exact=True).click()
                ticket_changed=False
                try:
                    select_visibility(page,'blocked')
                    perform(page,'data-admin-save');ticket_changed=True
                    denied=perform(other,'data-incidents-read')
                    assert denied['status']=='denied'
                    assert 'proposed_solution' not in denied and 'precedents' not in denied
                    expect(other.locator('[data-incidents-report]')).not_to_contain_text('Solution proposée')
                    checked('itsm_blocked_discards_prior_solution_in_same_session')
                    select_visibility(page,'authenticated');perform(page,'data-admin-save')
                    allowed=perform(other,'data-incidents-read')
                    assert allowed['proposed_solution']['state']=='proposed'
                    external_page=external_context.new_page()
                    try:
                        external_page.goto(base+'/demo-incidents-5min',wait_until='networkidle')
                        login(external_page,external)
                        external_result=perform(external_page,'data-incidents-read')
                        assert external_result['status']=='denied'
                        assert 'proposed_solution' not in external_result
                        assert not external_result.get('sources')
                    finally:external_page.close()
                    checked('itsm_authenticated_rule_does_not_open_other_sources')
                finally:
                    if ticket_changed:
                        select_visibility(page,original_ticket)
                        restored=perform(page,'data-admin-save')
                        assert restored['policy']['resources']['incidents.tickets']==original_ticket
                recovered=perform(other,'data-incidents-read')
                assert recovered['proposed_solution']['state']=='proposed'
                checked('itsm_ticket_policy_restored_and_solution_fresh')

            other.goto(base + '/demo-acces', wait_until='networkidle')
            other.locator('input[data-portal-username], [data-portal-username] input').fill(unknown)
            other.locator('input[data-portal-password], [data-portal-password] input').fill(users[unknown])
            other.locator('[data-portal-login]').click()
            expect(other.locator('[data-portal-login-status]')).to_contain_text('Connexion refusée', timeout=30000)
            expect(other.locator('[data-portal-identity]')).to_have_count(0)
            checked('unclassified_account_refused')

            page.goto(base + '/documentation', wait_until='networkidle')
            response = internal_context.request.get(base + '/download/wiki.zip', timeout=60000)
            assert response.status == 200, 'The complete public ZIP must be downloadable'
            with zipfile.ZipFile(io.BytesIO(response.body())) as archive:
                assert any(name.endswith('.md') for name in archive.namelist()), 'Markdown pages required'
                assert any(name.endswith('.drawio') for name in archive.namelist()), 'Editable diagrams required'
                assert any(name.endswith('.svg') for name in archive.namelist()), 'Rendered diagrams required'
            for relative in ('diagrams/01-deployment.drawio', 'assets/diagrams/01-deployment.svg'):
                download = internal_context.request.get(base + '/download/file/' + relative)
                assert download.status == 200 and download.body(), 'Each public diagram must download'
                if args.source_docs:
                    assert hashlib.sha256(download.body()).digest() == hashlib.sha256((args.source_docs / relative).read_bytes()).digest(), 'The portal must serve canonical documentation'
            assert internal_context.request.get(base + '/download/file/../../secrets/albert_key').status != 200, 'No path traversal'
            checked('public_documentation_exports_and_allowlist')

            page.goto(base + '/documentation/02-configuration', wait_until='networkidle')
            section_link = page.locator('a[href*="/documentation/01-installation#raccorder-le-poste-utilisateur"]')
            expect(section_link).to_have_count(1)
            section_link.click()
            expect(page.locator('[data-portal-document]')).to_contain_text('Raccorder le poste utilisateur')
            page.wait_for_function('''() => {
                let id; try { id = decodeURIComponent(location.hash.slice(1)); } catch { return false; }
                const target = id && document.getElementById(id);
                if (!target) return false;
                const bounds = target.parentElement.getBoundingClientRect();
                return bounds.top >= 40 && bounds.top < innerHeight;
            }''')
            checked('canonical_section_link_scrolls_to_visible_heading')
            assert not errors, 'No browser JavaScript exception expected'
        except (Exception, KeyboardInterrupt) as error:
            detail = diagnostics.failure(error)
            if campaign:
                campaign.checkpoint('Échec avant clôture : '+detail['message'])
            checks.append({'name': 'browser_scenario', 'passed': False, **detail})
            captures = diagnostics.captures(((page,'failure-internal.png'),(other,'failure-external.png')))
            record('browser_scenario', 'failed' if isinstance(error, AssertionError) else 'broken',
                   captures, detail['message'], detail['trace'])
        finally:
            for number, target in enumerate((internal_context, external_context, browser)):
                if target is None:
                    continue
                try:
                    target.close()
                except Exception as error:
                    diagnostics.add('fermeture impossible', type(error).__name__+' '+str(error))
                    name = 'browser_cleanup_'+str(number)
                    checks.append({'name':name,'passed':False,'error_type':type(error).__name__})
                    record(name,'broken',message=diagnostics.clean(str(error)))
    report = {'at_utc': datetime.now(timezone.utc).isoformat(), 'url': base,
              'synthetic_accounts': True, 'albert_called': False,
              'backends': 'simulated_for_ui_recipe' if args.simulated_backends else 'deployed_ubuntu_services',
              'checks': checks,
              'browser_errors': errors, 'passed': bool(checks) and all(row['passed'] for row in checks)}
    (args.output / 'browser-results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    diagnostics.save()
    if campaign:
        campaign.finish()
    print(json.dumps({'passed': report['passed'], 'checks': len(checks), 'report': str(args.output / 'browser-results.json')}))
    return 0 if report['passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
