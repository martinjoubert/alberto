"""Qualify the real NiceGUI/Allure viewer with distinct synthetic LDAP users.

This host-only Playwright recipe reads imported reports; it never launches a
test campaign, changes policy, calls Albert or starts services. Account secrets
and temporary viewing grants are not written to its receipt.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys
import time
from urllib.parse import urljoin, urlsplit
import zipfile


COUNT_LABELS = (('passed', 'réussis'), ('failed', 'échecs'), ('broken', 'erreurs'),
                ('skipped', 'sautés'), ('unknown', 'incomplets'),
                ('not_qualified', 'non qualifiés'))


def outcome(counts):
    if counts['failed'] or counts['broken']:
        return 'Échec'
    if counts['unknown']:
        return 'Incomplet'
    if counts['not_qualified'] or not counts['passed']:
        return 'Périmètres non qualifiés'
    return 'Réussi avec tests sautés' if counts['skipped'] else 'Réussi sur le périmètre exécuté'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', required=True)
    parser.add_argument('--accounts-file', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--report-id', required=True)
    parser.add_argument('--browser-executable', type=Path)
    parser.add_argument('--expected-case', help='Optional real test name to find in the Allure Suites view')
    parser.add_argument('--allure-results', type=Path, help='Optional Allure results for this browser recipe')
    args = parser.parse_args()
    endpoint = urlsplit(args.url)
    if (endpoint.scheme not in {'http', 'https'} or not endpoint.hostname
            or endpoint.username or endpoint.password or endpoint.query or endpoint.fragment
            or (endpoint.scheme == 'http' and endpoint.hostname not in {'127.0.0.1', 'localhost'})):
        parser.error('Use a loopback HTTP or authenticated HTTPS portal URL without credentials')
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,63}', args.report_id):
        parser.error('Use the immutable imported report ID')
    os.umask(0o077)
    args.output.mkdir(parents=True, exist_ok=True, mode=0o700)
    if (args.output/'browser-results.json').exists():
        parser.error('Use a new output directory for each recipe')
    accounts = json.loads(args.accounts_file.read_text())
    users = {row['uid']: row['password'] for row in accounts['users']}
    admin, external = 'alice.martin', 'eric.durand.ext'
    if not {admin, external}.issubset(users):
        parser.error('The synthetic internal administrator and external accounts are required')

    from playwright.sync_api import sync_playwright, expect

    base = args.url.rstrip('/')
    origin = urlsplit(base)
    checks, errors, external_requests = [], [], []
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    import test_reporting as reporting
    from browser_diagnostics import BrowserDiagnostics
    diagnostics = BrowserDiagnostics(args.output, secrets=users.values())
    reporting_campaign = reporting.Campaign(args.allure_results, 'browser-qualification') if args.allure_results else None
    step_start, step_clock = time.time_ns()//1_000_000, time.monotonic()
    report_open = False
    exported = {}

    def record(name, status, *, message='', trace='', captures=()):
        nonlocal step_start, step_clock
        stop = step_start+round((time.monotonic()-step_clock)*1000)
        if args.allure_results:
            reporting.write_result(args.allure_results, 'browser-qualification', name, status,
                start=step_start, stop=stop, message=message, trace=trace, secrets=users.values(),
                attachments=[args.output/path for path in captures],
                diagnostics=diagnostics.channels() if status != 'passed' else {},
                labels=[{'name':'framework','value':'playwright-python'}])
        step_start, step_clock = time.time_ns()//1_000_000, time.monotonic()

    def checked(name):
        checks.append({'name': name, 'passed': True})
        record(name, 'passed')
        if reporting_campaign:
            reporting_campaign.checkpoint('Dernier contrôle terminé : '+name)
        print(json.dumps({'check': name, 'passed': True}), flush=True)

    def login(page, username):
        page.locator('input[data-portal-username], [data-portal-username] input').fill(username)
        page.locator('input[data-portal-password], [data-portal-password] input').fill(users[username])
        page.locator('[data-portal-login]').click()
        expect(page.locator('[data-portal-login-status]')).to_contain_text('Connexion établie', timeout=30000)
        expect(page.locator('[data-portal-identity]')).to_be_visible(timeout=30000)
        assert page.locator('input[data-portal-password], [data-portal-password] input').input_value() == ''

    def local_only(route):
        destination = urlsplit(route.request.url)
        if (destination.scheme in {'blob', 'data'}
                or (destination.scheme, destination.hostname, destination.port)
                == (origin.scheme, origin.hostname, origin.port)):
            route.continue_()
        else:
            # Block before sending; record only the origin, never a query/grant.
            if report_open:
                external_requests.append(destination.scheme+'://'+(destination.netloc or 'unknown'))
            route.abort()

    with sync_playwright() as playwright:
        options = {'headless': True}
        if args.browser_executable:
            options['executable_path'] = str(args.browser_executable)
        browser = context = other_context = page = other = None
        try:
            browser = playwright.chromium.launch(**options)
            context = browser.new_context(viewport={'width': 1440, 'height': 1080})
            other_context = browser.new_context(viewport={'width': 1440, 'height': 1080})
            context.route('**/*', local_only)
            other_context.route('**/*', local_only)
            page, other = context.new_page(), other_context.new_page()
            diagnostics.watch(page)
            diagnostics.watch(other)
            page.on('pageerror', lambda error: errors.append(type(error).__name__))
            other.on('pageerror', lambda error: errors.append(type(error).__name__))
            view_path = '/qualification/view/'+args.report_id
            export_path = '/qualification/export/'+args.report_id
            for path in (view_path, export_path):
                assert context.request.get(base+path).status == 403
                assert context.request.get(base+path+'?access=forged-qualification-grant').status == 403
            checked('anonymous_and_forged_report_requests_refused')

            page.goto(base+'/qualification', wait_until='networkidle')
            expect(page.locator('[data-portal-title]')).to_contain_text('Qualification')
            expect(page.locator('iframe')).to_have_count(0)
            expect(page.locator('[data-qualification-campaign]')).to_have_count(0)
            checked('anonymous_catalogue_contains_no_report_or_frame')

            other.goto(base+'/qualification', wait_until='networkidle')
            login(other, external)
            expect(other.locator('[data-qualification-denied]')).to_be_visible()
            expect(other.locator('[data-qualification-campaign]')).to_have_count(0)
            expect(other.locator('iframe')).to_have_count(0)
            checked('external_ldap_session_denied_without_report')

            login(page, admin)
            campaign = page.locator('[data-qualification-campaign][data-report-id="'+args.report_id+'"]')
            expect(campaign).to_have_count(1, timeout=30000)
            expect(campaign.locator('[data-qualification-counts]')).to_be_visible()
            expect(campaign.locator('[data-qualification-outcome]')).to_be_visible()
            expect(campaign.locator('iframe')).to_have_count(0)
            page.screenshot(path=str(args.output/'qualification-catalogue.png'), full_page=True)
            checked('administrator_sees_campaign_counts_without_eager_frame')

            html_url = urljoin(base, campaign.locator('[data-qualification-html]').get_attribute('href'))
            export_url = urljoin(base, campaign.locator('[data-qualification-export]').get_attribute('href'))
            archive_response = context.request.get(export_url)
            html_response = context.request.get(html_url)
            assert archive_response.status == 200 and html_response.status == 200
            archive_bytes, html = archive_response.body(), html_response.body()
            with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
                assert archive.testzip() is None
                assert archive.namelist() == ['report.json', 'index.html']
                raw_metadata = archive.read('report.json')
                metadata = json.loads(raw_metadata)
                assert archive.read('index.html') == html
            assert metadata['schema_version'] == 1 and metadata['kind'] == 'rie-qualification-report'
            assert metadata['id'] == args.report_id
            assert metadata['renderer']['name'] == 'Allure'
            assert len(html) == metadata['html']['bytes']
            assert hashlib.sha256(html).hexdigest() == metadata['html']['sha256']
            expect(campaign).to_contain_text(metadata['title'])
            expect(campaign).to_contain_text(metadata['environment'])
            expect(campaign).to_contain_text(metadata['created_at'])
            expect(campaign).to_contain_text(metadata['source']['commit'] or 'non identifiée')
            counts = metadata['counts']
            expected_counts = ' · '.join(f'{counts[key]} {title}' for key, title in COUNT_LABELS)
            expect(campaign.locator('[data-qualification-counts]')).to_have_text(expected_counts)
            expect(campaign.locator('[data-qualification-outcome]')).to_have_text(outcome(counts))
            (args.output/'qualification-export.zip').write_bytes(archive_bytes)
            exported = {'id': args.report_id, 'counts': counts, 'html_sha256': metadata['html']['sha256'],
                        'html_bytes': len(html), 'metadata_sha256': hashlib.sha256(raw_metadata).hexdigest(),
                        'zip_sha256': hashlib.sha256(archive_bytes).hexdigest()}
            checked('zip_html_and_visible_metadata_match_exactly')

            report_open = True
            campaign.locator('[data-qualification-open]').click()
            iframe = campaign.locator('[data-qualification-frame] iframe')
            expect(iframe).to_have_count(1)
            sandbox = iframe.get_attribute('sandbox') or ''
            assert 'allow-scripts' in sandbox and 'allow-same-origin' not in sandbox
            assert iframe.get_attribute('referrerpolicy') == 'no-referrer'
            viewer_url = urljoin(base, iframe.get_attribute('src'))
            viewer_response = context.request.get(viewer_url)
            assert viewer_response.status == 200
            csp = viewer_response.headers.get('content-security-policy', '')
            assert 'sandbox' in csp and 'allow-same-origin' not in csp
            assert "default-src 'none'" in csp and "connect-src blob: data:" in csp
            frame = iframe.element_handle().content_frame()
            assert frame is not None
            frame.wait_for_function('() => document.body && document.body.innerText.trim().length >= 80', timeout=45000)
            expect(frame.locator('a[href="#suites"]').first).to_be_visible()
            assert iframe.evaluate('element => {try {void element.contentWindow.document; return false;} catch (error) {return error.name === "SecurityError";}}')
            preference_test = '''() => {
                for (const store of [localStorage, sessionStorage]) {
                    store.setItem('__rie_qualification_probe__', 'temporary');
                    if (store.getItem('__rie_qualification_probe__') !== 'temporary') return false;
                }
                return true;
            }'''
            assert frame.evaluate(preference_test)
            frame.goto(viewer_url, wait_until='domcontentloaded')
            frame.wait_for_function('() => document.body && document.body.innerText.trim().length >= 80', timeout=45000)
            assert frame.evaluate('() => localStorage.getItem("__rie_qualification_probe__") === null && sessionStorage.getItem("__rie_qualification_probe__") === null')
            page.screenshot(path=str(args.output/'qualification-allure.png'), full_page=True)
            checked('real_allure_renders_in_opaque_sandbox_with_memory_preferences')

            if args.expected_case:
                frame.locator('a[href="#suites"]').first.click()
                search = frame.locator('input[type="text"]').first
                expect(search).to_be_visible(timeout=20000)
                search.fill(args.expected_case)
                case = frame.get_by_text(args.expected_case, exact=False).first
                expect(case).to_be_visible(timeout=20000)
                checked('expected_real_test_case_found_in_allure_suites')

            assert not errors, 'No browser JavaScript error expected'
            assert not external_requests, 'No external report request expected'
            checked('no_javascript_errors_or_external_report_requests')

            page.locator('[data-portal-logout]').click()
            expect(page.locator('[data-portal-identity]')).to_have_count(0)
            expect(page.locator('[data-qualification-campaign]')).to_have_count(0)
            expect(page.locator('iframe')).to_have_count(0)
            for url in (viewer_url, html_url, export_url):
                assert context.request.get(url).status == 403
            checked('logout_revokes_previous_view_and_export_grants')
        except (Exception, KeyboardInterrupt) as error:
            detail = diagnostics.failure(error)
            checks.append({'name':'qualification_browser_scenario','passed':False,**detail})
            if reporting_campaign:
                reporting_campaign.checkpoint('Échec avant clôture : '+detail['message'])
            captures = diagnostics.captures(((page,'failure-qualification.png'),(other,'failure-external.png')))
            record('qualification_browser_scenario','failed' if isinstance(error,AssertionError) else 'broken',
                   message=detail['message'],trace=detail['trace'],captures=captures)
        finally:
            for number,target in enumerate((context,other_context,browser)):
                if target is None:
                    continue
                try:
                    target.close()
                except Exception as error:
                    diagnostics.add('fermeture impossible', type(error).__name__+' '+str(error))
                    name='qualification_cleanup_'+str(number)
                    checks.append({'name':name,'passed':False,'error_type':type(error).__name__})
                    record(name,'broken',message=diagnostics.clean(str(error)))

    receipt = {'at_utc': datetime.now(timezone.utc).isoformat(), 'report_id': args.report_id,
               'synthetic_accounts': True, 'albert_called': False,
               'checks': checks, 'browser_errors': errors,
               'external_report_requests': external_requests, 'exported_report': exported,
               'expected_case_checked': bool(args.expected_case),
               'passed': bool(checks) and all(row['passed'] for row in checks) and not errors and not external_requests}
    (args.output/'browser-results.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
    diagnostics.save()
    if reporting_campaign:
        reporting_campaign.finish()
    print(json.dumps({'passed': receipt['passed'], 'checks': len(checks),
                      'report': str(args.output/'browser-results.json')}))
    return 0 if receipt['passed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
