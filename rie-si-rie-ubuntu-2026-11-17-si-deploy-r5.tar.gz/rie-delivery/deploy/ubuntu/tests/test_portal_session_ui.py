"""Exercise real NiceGUI controls with signed sessions and an isolated directory.

The verifier clock advances only inside these tests; no wall clock, server,
LDAP account or operational credential is changed.
"""
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
for relative in ('deploy/ubuntu', 'core/access-control/src'):
    sys.path.insert(0, str(ROOT/relative))
from dinum_access import AccessDenied, AccessGate
from dinum_access import security
from portal.backend import Session


class FixtureDirectory:
    administrator = True

    def lookup(self, value, *, username=False, password=None, identity=False, authorization=False):
        if value not in ('alice', 'alice@fixture.invalid') or password not in (None, 'fixture-password'):
            raise AccessDenied('invalid_credentials')
        row = ('alice@fixture.invalid', 'internal')
        if identity:
            row += ('fixture-stable-object',)
        return (*row, self.administrator) if authorization else row


@unittest.skipUnless(importlib.util.find_spec('nicegui'), 'NiceGUI test dependency required')
class PortalSessionUITests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.storage_environment = patch.dict(os.environ, {'NICEGUI_STORAGE_PATH':str(self.root/'ui-storage')})
        self.storage_environment.start()
        self.state = self.root/'access';self.state.mkdir(mode=0o700)
        self.key = self.root/'session.key';self.key.write_text('isolated-test-signing-material-of-at-least-32-characters')
        self.key.chmod(0o600)
        self.policy = {'version':1,'revision':1,'default':'blocked',
                       'indices':{'rie-ui-fixture':'authenticated'},'resources':{}}
        (self.state/'policy.json').write_text(json.dumps(self.policy))
        self.directory = FixtureDirectory()
        self.gate = AccessGate({'version':1,'ldap':{},'state_directory':str(self.state),
            'session_key_file':str(self.key),'allow_webui_assertions':False}, self.directory)
        self.portal = importlib.import_module('portal.app')
        from nicegui import helpers
        self.sessions = []
        self.expired = False
        original_verify = security.verify

        def verify(*args, **kwargs):
            if self.expired:
                kwargs['now'] = time.time()+601
            return original_verify(*args, **kwargs)

        def session():
            current = Session(gate_factory=lambda:self.gate)
            self.sessions.append(current)
            return current

        self.patches = [patch.object(self.portal, 'Session', side_effect=session),
                        patch.object(security, 'verify', side_effect=verify),
                        patch.object(helpers, 'is_pytest', return_value=True)]
        for item in self.patches:
            item.start()

    async def asyncTearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.storage_environment.stop()
        self.temporary.cleanup()

    async def login(self, user):
        for element in user.find('Identifiant LDAP').elements:
            element.value = ''
        user.find('Identifiant LDAP').type('alice')
        user.find('Mot de passe').type('fixture-password')
        user.find('Se connecter').click()
        await user.should_see('Connexion établie.', retries=30)

    async def test_expired_admin_save_clears_stale_controls_and_can_reconnect(self):
        from nicegui.testing.user_simulation import user_simulation
        async with user_simulation(root=self.portal.acl_administration) as user:
            await user.open('/')
            await self.login(user)
            await user.should_see('Révision active : 1', retries=30)
            user.find('Nom exact de l’index').type('rie-ui-fixture')
            self.expired = True
            user.find('Enregistrer la règle').click()
            await user.should_see('Session inactive.', retries=30)
            await user.should_not_see('Enregistrer la règle')
            await user.should_not_see('Révision active : 1')
            await user.should_not_see('alice@fixture.invalid')
            await user.should_not_see('Connexion établie.')
            self.assertEqual(json.loads((self.state/'policy.json').read_text()), self.policy)
            self.assertEqual(self.sessions[0].token, '')
            self.assertTrue(user.notify.contains('Session inactive.'))
            self.expired = False
            await self.login(user)
            await user.should_see('Révision active : 1', retries=30)
            user.find('Nom exact de l’index').type('rie-ui-fixture')
            user.find('Enregistrer la règle').click()
            await user.should_see('Révision active : 2', retries=30)

    async def test_expired_business_read_removes_earlier_result_and_identity(self):
        from nicegui.testing.user_simulation import user_simulation
        async with user_simulation(root=self.portal.acl_demo) as user:
            await user.open('/')
            await self.login(user)
            user.find('Afficher mes droits actuels').click()
            await user.should_see('lecture effectuée', retries=30)
            self.expired = True
            user.find('Afficher mes droits actuels').click()
            await user.should_see('Session inactive.', retries=30)
            await user.should_not_see('lecture effectuée')
            await user.should_not_see('Afficher mes droits actuels')
            await user.should_not_see('alice@fixture.invalid')

    async def test_policy_conflict_keeps_valid_session_and_notifies_operator(self):
        from nicegui.testing.user_simulation import user_simulation
        async with user_simulation(root=self.portal.acl_administration) as user:
            await user.open('/')
            await self.login(user)
            await user.should_see('Révision active : 1', retries=30)
            user.find('Nom exact de l’index').type('rie-ui-fixture')
            changed = {**self.policy, 'revision':2}
            (self.state/'policy.json').write_text(json.dumps(changed))
            user.find('Enregistrer la règle').click()
            await user.should_see('La politique a changé.', retries=30)
            self.assertTrue(user.notify.contains('La politique a changé.'))
            self.assertTrue(self.sessions[0].token)
            await user.should_see('Enregistrer la règle')
            self.assertEqual(json.loads((self.state/'policy.json').read_text()), changed)

    async def test_lost_admin_membership_removes_editor_without_logging_reader_out(self):
        from nicegui.testing.user_simulation import user_simulation
        async with user_simulation(root=self.portal.acl_administration) as user:
            await user.open('/')
            await self.login(user)
            await user.should_see('Révision active : 1', retries=30)
            self.directory.administrator = False
            user.find('Actualiser les règles').click()
            await user.should_see('Administration réservée', retries=30)
            await user.should_not_see('Enregistrer la règle')
            self.assertTrue(self.sessions[0].token)
            self.assertEqual(self.sessions[0].own_access()['category'], 'internal')
