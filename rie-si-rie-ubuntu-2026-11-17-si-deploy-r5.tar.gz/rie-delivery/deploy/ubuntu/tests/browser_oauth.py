"""Qualify native Open WebUI OAuth and optional real Albert turns in a browser.

Host-only qualification against prepared clients and fictitious SI identities.
Private accounts arrive on stdin, never argv. This creates authorizations and
owned chats, but does not change sources, ACL, client settings or user passwords.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT/'deploy/ubuntu'))
from test_reporting import Campaign, private_directory, sanitize_text, write_result
from qualification_openwebui import native_result, generation_checks


def clean(value):
    if isinstance(value, dict):
        return {key: ('[MASQUÉ]' if isinstance(item, str) and
                     (key.endswith('_token') or key in {'token','password','authorization','cookie'})
                     else clean(item)) for key,item in value.items()}
    if isinstance(value, list): return [clean(item) for item in value]
    return sanitize_text(value) if isinstance(value,str) else value


def login_reader(api, account):
    """A local administrator cannot qualify ordinary-user model/tool sharing."""
    session=api.call('/api/v1/auths/signin',{'email':account['email'],'password':account['password']})
    if session.get('role')!='user':
        raise ValueError('Qualify the browser with an ordinary Open WebUI user account')
    api.token=session['token']
    return {'id':session['id'],'role':session['role']}


def authorize(page, base, identifier, account):
    """Exercise the native state/PKCE callback and the actual HTML form."""
    page.goto(base+'/oauth/clients/mcp:'+identifier+'/authorize',wait_until='domcontentloaded',timeout=60000)
    page.get_by_role('heading',name='Connecter Open WebUI aux sources').wait_for(timeout=15000)
    needs_password=page.locator('input[name=password]').count()>0
    if needs_password:
        page.get_by_label('Identifiant LDAP',exact=True).fill(account['username'])
        page.get_by_label('Mot de passe LDAP',exact=True).fill(account['password'])
    elif account['username'] not in page.locator('body').inner_text():
        raise ValueError('The displayed LDAP identity must match this browser user')
    page.get_by_role('button',name='Autoriser la connexion').click()
    page.wait_for_url(base+'/**',wait_until='domcontentloaded',timeout=30000)
    if urlsplit(page.url).netloc != urlsplit(base).netloc or urlsplit(page.url).query:
        raise ValueError('The native callback did not return cleanly to the owned client')
    return {'first_ldap_form':needs_password,'explicit_confirmation':True,'returned_to_own_client':True}


def run(args,clients):
    from playwright.sync_api import sync_playwright
    sys.path.insert(0,str(ROOT/'deploy/openwebui'))
    from configure import API, checked_url
    sys.path.insert(0,str(ROOT/'use-cases/incidents/observability-demo'))
    from browser_ui import enter_question
    destination=private_directory(args.output)
    report={'at_utc':datetime.now(timezone.utc).isoformat(),'personal_mcp_token_copied':False,
            'si_real_accessed':False,'real_albert_requested':args.with_albert,'clients':[],'checks':[],'turns':[]}
    campaign=Campaign(destination/'allure-results','Open WebUI — OAuth et LDAP',
                      'Autorisations navigateur et conversations réelles, clients et identités de laboratoire.')
    def record(name,passed,details,*,image=None):
        report['checks'].append({'name':name,'passed':bool(passed),'details':clean(details)})
        write_result(destination/'allure-results','Open WebUI — OAuth et LDAP',name,
                     'passed' if passed else 'failed',diagnostics={'Observation':json.dumps(clean(details),ensure_ascii=False,indent=2)},
                     attachments=[image] if image else [])
        (destination/'results.json').write_text(json.dumps(clean(report),ensure_ascii=False,indent=2)+'\n')
        (destination/'results.json').chmod(0o600)
        print(json.dumps({'name':name,'passed':bool(passed)}),flush=True)
    with sync_playwright() as driver:
        browser=driver.chromium.launch(headless=True,executable_path=str(args.browser))
        for row in clients:
            person=row['profile'];base=checked_url(row['url']);api=API(base)
            account=row['openwebui'];identity=login_reader(api,account)
            report['clients'].append({'profile':person,'role':identity['role']})
            context=browser.new_context(viewport={'width':1440,'height':1100},locale='fr-FR')
            login=context.request.post(base+'/api/v1/auths/signin',data=account)
            if not login.ok:raise ValueError('Owned client login failed')
            context.add_init_script('localStorage.setItem("token",'+json.dumps(api.token)+');')
            page=context.new_page()
            try:
                for kind,identifier in [('pdl','dinum-pdl-agent'),('incidents','obs-gptoss')]:
                    outcome=authorize(page,base,identifier,row['ldap'])
                    record(person+'_'+kind+'_native_authorization',outcome['first_ldap_form']==(kind=='pdl'),outcome)
                if not args.with_albert:continue
                cases=([('pdl','albert-pdl-rie',[
                    'Montre les logs de l’équipement edge-a PFS BB PFAING TACACS dans demo-alpha du 12 octobre 2026 de 08:00 à 09:00 UTC.',
                    'Uniquement TACACS pour ce même équipement, sur la même période.']),
                    ('incidents','albert-observabilite-gptoss',[
                    'Diagnostique OBS-RTR-01 le 28 septembre 2026 de 10:00 à 12:00, heure de Paris. Cite les sources, les précédents ITSM-NG et la solution probable avec ses conditions. Distingue résolution technique et clôture du ticket.'])]
                    if person=='alice' else [('incidents','albert-observabilite-gptoss',[
                    'Diagnostique OBS-RTR-01 le 28 septembre 2026 de 10:00 à 12:00, heure de Paris.'])])
                for kind,model,questions in cases:
                    page.goto(base+'/?models='+model,wait_until='networkidle',timeout=90000)
                    for number,question in enumerate(questions,1):
                        send=enter_question(page,question)
                        with page.expect_request(lambda request:request.method=='POST' and urlsplit(request.url).path=='/api/chat/completions',timeout=20000) as sent:
                            send.click()
                        request=sent.value.post_data_json
                        page.wait_for_url('**/c/*',timeout=30000)
                        chat_id=urlsplit(page.url).path.split('/c/',1)[1];started=time.monotonic();message={}
                        while time.monotonic()-started<300:
                            message=api.call('/api/v1/chats/'+chat_id)['chat']['history']['messages'].get(request['id'],{})
                            if message.get('done') or message.get('error'):break
                            page.wait_for_timeout(1000)
                        result=native_result(message.get('output',[])) or {}
                        checks=(generation_checks(result,kind,require_itsm=kind=='incidents') if person=='alice' else [
                            {'name':'external_denied_without_evidence','passed':result.get('status')=='denied'
                             and result.get('access_control',{}).get('category')=='external'
                             and not any(result.get(key) for key in ('evidence','sources','metrics','logs','events','documents'))}])
                        if kind=='pdl':checks.append({'name':'expected_corpus_total','passed':result.get('evidence',{}).get('total')==(6 if number==1 else 2)})
                        checks.append({'name':'one_native_tool_and_visible_server_answer','passed':bool(result)
                            and message.get('done') and not message.get('error')
                            and message.get('content','').strip()==result.get('answer','').strip()})
                        turn={'person':person,'kind':kind,'question':question,'chat_id':chat_id,
                              'seconds':round(time.monotonic()-started,2),'checks':checks,'result':result}
                        report['turns'].append(turn)
                        capture=destination/(person+'-'+kind+'-'+str(number)+'.png');page.screenshot(path=str(capture),full_page=True)
                        record(person+'_'+kind+'_turn_'+str(number),all(check['passed'] for check in checks),turn,image=capture)
            except Exception as error:
                record(person+'_browser_failure',False,{'error_type':type(error).__name__,'stage':'authorization_or_conversation'})
            finally:context.close()
        browser.close()
    report['passed']=len(report['checks'])==(8 if args.with_albert else 4) and all(check['passed'] for check in report['checks'])
    (destination/'results.json').write_text(json.dumps(clean(report),ensure_ascii=False,indent=2)+'\n')
    campaign.finish()
    return 0 if report['passed'] else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--accounts-stdin',action='store_true',required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--browser',type=Path,default=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'))
    parser.add_argument('--with-albert',action='store_true')
    args=parser.parse_args();os.umask(0o077)
    if args.output.exists():raise ValueError('Choose a new qualification output directory')
    data=sys.stdin.read(65537)
    if len(data)>65536:raise ValueError('Bounded private input required')
    clients=json.loads(data)['clients']
    if len(clients)!=2 or {row['profile'] for row in clients}!={'alice','eric'}:
        raise ValueError('The two declared laboratory identities are required')
    return run(args,clients)


if __name__=='__main__':raise SystemExit(main())
