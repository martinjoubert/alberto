#!/usr/bin/env python3
"""Package public delivery sources using an explicit allowlist, without services.

The archive is a source delivery, not a statement of Ubuntu or SI-RIE validation.
Only public inputs selected below are opened. Instance data and private files are
neither scanned nor copied. This also works in a source archive without Git.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
PREFIX = 'rie-delivery'
MANIFEST = 'DELIVERY-MANIFEST.json'
EXPLICIT = (
    'deploy/ubuntu/Dockerfile',
    'deploy/ubuntu/compose.yaml',
    'deploy/ubuntu/README.md',
    'deploy/ubuntu/VALIDATION.md',
    'deploy/ubuntu/manage.py',
    'deploy/ubuntu/rie-development.code-workspace',
    'deploy/ubuntu/initialize.py',
    'deploy/ubuntu/runtime_cli.py',
    'deploy/ubuntu/seed_incidents.py',
    'deploy/ubuntu/bundle.py',
    'deploy/ubuntu/install.sh',
    'deploy/ubuntu/requirements-runtime.lock',
    'deploy/ubuntu/requirements-portal.lock',
    'deploy/ubuntu/requirements-runtime.in',
    'deploy/ubuntu/requirements-portal.in',
    'deploy/ubuntu/requirements-browser.in',
    'deploy/ubuntu/requirements-browser.lock',
    'docs/si-rie/README.md',
    'core/access-control/config.example.json',
    'core/access-control/tokens.py',
    'core/albert-client/tests/test_dialogue_storage.py',
    'core/albert-client/tests/test_server_dialogue.py',
    'simulation-rie/ldap-demo/manage.py',
    'simulation-rie/ldap-demo/Dockerfile',
    'simulation-rie/ldap-demo/start.sh',
    'deploy/ubuntu/seed_pdl.py',
    'deploy/ubuntu/examples/pdl-demo-mappings.yaml',
    'use-cases/pdl/agentic-pdl/requirements-rie.lock.txt',
    'use-cases/pdl/agentic-pdl/docs-rie/wiki/mapping-operator.md',
    'use-cases/incidents/observability-demo/README.md',
    'use-cases/incidents/observability-demo/corpus-documents.json',
    'use-cases/incidents/observability-demo/browser_ui.py',
    'use-cases/incidents/observability-demo/openwebui/report_display.py',
    'docs/handover/dify-n8n.md',
)
# Directory members are shallow: no cache, instance, test evidence or private
# subdirectory can enter through recursive traversal.
DIRECTORIES = (
    ('use-cases/pdl/agentic-pdl/rie_agent', {'.py'}, set()),
    ('use-cases/pdl/agentic-pdl/rie_agent/fixtures', {'.json'}, set()),
    ('core/access-control/src/dinum_access', {'.py'}, set()),
    ('core/access-control/tests', {'.py'}, set()),
    ('core/albert-client/src/dinum_albert', {'.py'}, set()),
    ('use-cases/incidents/observability-demo/obs_poc', {'.py'}, set()),
    ('use-cases/incidents/observability-demo/fixtures', {'.json'}, set()),
    ('deploy/ubuntu', {'.py', '.yaml', '.yml'}, {'Dockerfile', 'README.md'}),
    ('deploy/ubuntu/tests', {'.py'}, set()),
    ('deploy/ubuntu/portal', {'.py'}, set()),
    ('deploy/openwebui', {'.py', '.md', '.yaml'}, {'Dockerfile', 'Dockerfile.dockerignore'}),
    ('deploy/ubuntu/examples', {'.md', '.json', '.yaml'}, set()),
    ('deploy/ubuntu/reporting', {'.json', '.mjs'}, set()),
    ('docs/si-rie', {'.md'}, set()),
    ('docs/si-rie/reference', {'.md'}, set()),
    ('docs/si-rie/assets', {'.svg', '.png'}, set()),
    ('docs/si-rie/assets/diagrams', {'.svg', '.png'}, set()),
    ('docs/si-rie/assets/screenshots-2026-11-06', {'.png'}, set()),
    ('docs/si-rie/assets/screenshots-2026-11-07', {'.png'}, set()),
    ('docs/si-rie/assets/screenshots-2026-11-09', {'.png'}, set()),
    ('docs/si-rie/assets/screenshots-2026-11-13', {'.png'}, set()),
    ('docs/si-rie/assets/screenshots-2026-11-16', {'.png'}, set()),
    ('docs/si-rie/diagrams', {'.drawio'}, set()),
    ('docs/si-rie/sources', {'.mmd', '.puml', '.md'}, set()),
)
RESOURCES = (
    'use-cases/pdl/agentic-pdl/rie_agent/templates.yaml',
    'use-cases/pdl/agentic-pdl/rie_agent/reference_profiles.yaml',
)
FORBIDDEN_PARTS = {'.git', '.runtime', '.venv', 'venv', '__pycache__', '.pytest_cache',
                   'secrets', 'data', 'backups', 'artifacts', '.private', '.data'}
FORBIDDEN_SUFFIXES = {'.pem', '.key', '.crt', '.db', '.sqlite', '.sqlite3', '.log', '.pyc'}
PATTERNS = {
    'private_key': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----'),
    'provider_token': re.compile(rb'\b(?:glpat-|ghp_|github_pat_|sk-proj-)[A-Za-z0-9_-]{16,}'),
    'jwt': re.compile(rb'\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{16,}'),
    'literal_bearer': re.compile(rb'Bearer [A-Za-z0-9_-]{40,}'),
}
README = '''# Livraison PDL, Incidents et ACL

**Déployeur SI-RIE : commencer par [le guide unique en douze étapes](docs/si-rie/README.md).**
Faire compléter [la fiche de raccordement](docs/si-rie/reference/26-si-connection-sheet.md) avant l'installation.
Les variantes scriptée/demo sont dans [le manuel de référence](deploy/ubuntu/README.md) ; ne pas les enchaîner au guide principal.
Pour le laboratoire, [la fiche sandbox](docs/si-rie/reference/22-external-sandbox.md) conserve ses paramètres fictifs.

Le dossier conserve les chemins du code source pour les commandes du guide.
Les images serveur approuvées proviennent de la registry GitLab indiquée par le SI.
Open WebUI reste installé sur chaque poste utilisateur. L'observabilité et les
autres démonstrateurs ne font pas partie de cette livraison.

DELIVERY-MANIFEST.json fournit la référence Git, l'état modifié ou non du checkout
et l'empreinte SHA-256 de chaque fichier. Comparer au reçu de livraison.
Le packaging n'atteste aucune qualification Ubuntu, Albert, LDAP ou SI-RIE.
'''.encode('utf-8')


def private_path(relative):
    path = Path(relative)
    return (any(part in FORBIDDEN_PARTS or part.endswith('.egg-info') for part in path.parts)
            or path.name == '.env' or path.name.startswith('.env.')
            or path.name.startswith('.') or path.name == 'config.local.json'
            or path.suffix.lower() in FORBIDDEN_SUFFIXES)


def regular(root, relative, *, directory=False):
    """Check every component before opening it; never follow selected symlinks."""
    path = root
    for part in Path(relative).parts:
        path = path / part
        if path.is_symlink():
            raise ValueError('Symlink delivery input refused: ' + str(relative))
    info = path.stat()
    if not (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)):
        raise ValueError('Non-regular delivery input refused: ' + str(relative))
    return path


def selected_names(root):
    """List exactly the runtime, operator documentation and offline test inputs."""
    root = Path(root).resolve()
    names = set(EXPLICIT) | set(RESOURCES)
    for relative, suffixes, filenames in DIRECTORIES:
        folder = regular(root, relative, directory=True)
        for path in folder.iterdir():
            name = path.relative_to(root).as_posix()
            if not private_path(name) and (path.suffix in suffixes or path.name in filenames):
                regular(root, name)
                names.add(name)
    for name in names:
        if private_path(name):
            raise ValueError('Private input cannot be delivered: ' + name)
        regular(root, name)
    return sorted(names)


def source_version(root):
    """Record Git identity without putting file names or contents in metadata."""
    try:
        commit = subprocess.run(['git', '-C', str(root), 'rev-parse', 'HEAD'], check=True,
                                capture_output=True, text=True, timeout=10).stdout.strip()
        status = subprocess.run(['git', '-C', str(root), 'status', '--porcelain', '--untracked-files=normal'],
                                check=True, capture_output=True, text=True, timeout=10).stdout
        if not re.fullmatch(r'[a-f0-9]{40,64}', commit):
            raise ValueError('Invalid Git commit identity')
        return {'git_available': True, 'commit': commit, 'dirty': bool(status.strip())}
    except (OSError, subprocess.SubprocessError, ValueError):
        return {'git_available': False, 'commit': None, 'dirty': None}


def collect(root):
    """Audit selected public sources and return immutable bytes for packaging."""
    root = Path(root).resolve()
    members = {'README.md': README}
    for name in selected_names(root):
        data = regular(root, name).read_bytes()
        for rule, pattern in PATTERNS.items():
            if pattern.search(data):
                raise ValueError('Public-input audit failed: ' + name + ' (' + rule + ')')
        members[name] = data
    manifest = {
        'schema_version': 1,
        'scope': ['pdl', 'incidents', 'access_control', 'operator_manual', 'offline_tests'],
        'observability_deployment_included': False,
        'source': source_version(root),
        'qualification': 'not_asserted_by_packaging',
        'files': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                  for name, data in sorted(members.items())],
    }
    members[MANIFEST] = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    return members, manifest


def output_path(root, output):
    """Keep generated files outside sources, allowing only .runtime/delivery inside."""
    root = Path(root).resolve()
    output = Path(output).expanduser()
    if output.is_symlink():
        raise ValueError('Symlink archive destination refused')
    output = output.resolve()
    if output.suffixes[-2:] != ['.tar', '.gz']:
        raise ValueError('Archive output must end in .tar.gz')
    runtime = root / '.runtime/delivery'
    if output.is_relative_to(root) and not output.is_relative_to(runtime):
        raise ValueError('Write outside the checkout or below .runtime/delivery')
    if output.exists():
        raise ValueError('Archive output must be a new file')
    return output


def archive(root, output):
    """Write a deterministic source tarball, plus a SHA-256 sidecar, both private."""
    output = output_path(root, output)
    checksum = output.with_name(output.name + '.sha256')
    if checksum.exists() or checksum.is_symlink():
        raise ValueError('Checksum output must be a new file')
    members, manifest = collect(root)
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
                    for name, data in sorted(members.items()):
                        header = tarfile.TarInfo(PREFIX + '/' + name)
                        header.size = len(data)
                        header.mode = 0o755 if name.endswith('.sh') else 0o644
                        header.mtime = 0
                        header.uid = header.gid = 0
                        header.uname = header.gname = ''
                        tar.addfile(header, io.BytesIO(data))
        digest = hashlib.sha256(output.read_bytes()).hexdigest()
        fd = os.open(checksum, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'w') as stream:
            stream.write(digest + '  ' + output.name + '\n')
    except BaseException:
        output.unlink(missing_ok=True)
        raise
    return {'archive': str(output), 'sha256': digest, 'files': len(manifest['files']),
            'source': manifest['source'], 'qualification': manifest['qualification']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--audit-only', action='store_true')
    args = parser.parse_args()
    if args.audit_only and args.output:
        parser.error('--audit-only does not write an archive')
    if not args.audit_only and not args.output:
        parser.error('--output is required unless --audit-only is used')
    try:
        if args.audit_only:
            _, manifest = collect(ROOT)
            result = {'status': 'passed', 'files': len(manifest['files']), 'source': manifest['source'],
                      'qualification': manifest['qualification']}
        else:
            result = archive(ROOT, args.output)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (OSError, ValueError) as error:
        print(json.dumps({'status': 'failed', 'error': str(error)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
