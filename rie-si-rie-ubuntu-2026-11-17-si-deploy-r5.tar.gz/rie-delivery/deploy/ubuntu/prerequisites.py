"""Explicit Ubuntu host preparation; never change packages during normal install."""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile


def release(path=Path('/etc/os-release')):
    rows={}
    for line in path.read_text().splitlines():
        if '=' in line:
            key,value=line.split('=',1);rows[key]=value.strip('"')
    if rows.get('ID')!='ubuntu' or rows.get('VERSION_ID') not in {'24.04','26.04'}:
        raise ValueError('Package installation supports only Ubuntu 24.04/26.04 LTS.')
    if rows.get('VERSION_CODENAME') not in {'noble','resolute'}:
        raise ValueError('Unexpected Ubuntu package codename.')
    return rows


def run(argv, **kwargs):
    subprocess.run(argv,check=True,**kwargs)


def opensearch_sysctl(privilege):
    """Persist the minimum only when needed, preserving larger administrator values."""
    current=int(subprocess.check_output(['sysctl','-n','vm.max_map_count'],text=True).strip())
    if current>=262144:return
    target=Path('/etc/sysctl.d/60-dinum-rie-opensearch.conf')
    expected='vm.max_map_count=262144\n'
    if target.exists() and target.read_text()!=expected:
        raise ValueError('Existing DINUM sysctl file differs; review it without overwriting.')
    if not target.exists():
        with tempfile.TemporaryDirectory(prefix='dinum-sysctl-') as directory:
            staged=Path(directory)/target.name;staged.write_text(expected)
            run(privilege+['install','-m','0644',str(staged),str(target)])
    run(privilege+['sysctl','-w','vm.max_map_count=262144'])


def install():
    profile=release()
    arch={'aarch64':'arm64','arm64':'arm64','x86_64':'amd64'}.get(platform.machine())
    if arch is None:raise ValueError('Only ARM64 and AMD64 hosts are supported.')
    privilege=[] if os.geteuid()==0 else ['sudo']
    run(privilege+['apt-get','update'])
    run(privilege+['apt-get','install','-y','ca-certificates','curl','git','python3','openssl'])
    docker=shutil.which('docker')
    if docker:
        for suffix in (['compose','version'],['buildx','version']):
            run([docker,*suffix],stdout=subprocess.DEVNULL)
        opensearch_sysctl(privilege)
        print('Existing Docker and plugins retained; no daemon configuration changed.')
        return
    run(privilege+['install','-m','0755','-d','/etc/apt/keyrings'])
    key=Path('/etc/apt/keyrings/docker.asc')
    if not key.exists():
        with tempfile.TemporaryDirectory(prefix='dinum-docker-key-') as directory:
            downloaded=Path(directory)/'docker.asc'
            run(['curl','--fail','--silent','--show-error','--location','https://download.docker.com/linux/ubuntu/gpg','--output',str(downloaded)])
            run(privilege+['install','-m','0644',str(downloaded),str(key)])
    source=Path('/etc/apt/sources.list.d/docker.sources')
    expected=('Types: deb\nURIs: https://download.docker.com/linux/ubuntu\nSuites: '+profile['VERSION_CODENAME']+
              '\nComponents: stable\nArchitectures: '+arch+'\nSigned-By: /etc/apt/keyrings/docker.asc\n')
    if source.exists() and source.read_text()!=expected:
        raise ValueError('Existing Docker repository configuration differs; review it without overwriting.')
    if not source.exists():
        with tempfile.TemporaryDirectory(prefix='dinum-docker-source-') as directory:
            staged=Path(directory)/'docker.sources';staged.write_text(expected)
            run(privilege+['install','-m','0644',str(staged),str(source)])
    run(privilege+['apt-get','update'])
    run(privilege+['apt-get','install','-y','docker-ce','docker-ce-cli','containerd.io','docker-buildx-plugin','docker-compose-plugin'])
    run(privilege+['systemctl','enable','--now','docker'])
    opensearch_sysctl(privilege)
    print('Ubuntu prerequisites prepared. No user/group or firewall configuration changed.')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--install',action='store_true',required=True)
    parser.parse_args()
    try:install()
    except (OSError,ValueError,subprocess.CalledProcessError) as error:
        print('Prerequisite preparation failed: '+(str(error) if not isinstance(error,subprocess.CalledProcessError) else 'a system command failed'),file=sys.stderr)
        raise SystemExit(2)
