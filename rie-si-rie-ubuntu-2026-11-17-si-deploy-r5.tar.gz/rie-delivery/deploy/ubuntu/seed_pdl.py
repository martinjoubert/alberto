"""Install synthetic fixtures and activate their bundled demonstration mappings.

Seeding is restricted to the demo OpenSearch service. Only the packaged fixture
mapping can be activated automatically; real PDL mappings remain human-reviewed.
This module never calls Albert.
"""
import argparse
import json
import os
from pathlib import Path
import time

import requests
import rie_agent
from rie_agent.config import load_settings
from rie_agent.inventory import OpenSearchInventory
from rie_agent.mappings import validate_mapping
from rie_agent.store import Store


FIXTURES = {'portable': 'pdl_portable.json', 'equipment-reference': 'equipment_reference.json'}


def load_fixture(name):
    """Load a named synthetic fixture restricted to rie-*-fixture indices."""
    if name not in FIXTURES:
        raise ValueError('Select a supported synthetic fixture.')
    fixture = json.loads((Path(rie_agent.__file__).parent / 'fixtures' / FIXTURES[name]).read_text())
    if fixture.get('synthetic') is not True:
        raise ValueError('Only explicitly synthetic fixtures are accepted.')
    if not fixture.get('indices') or any(not index.startswith('rie-') or not index.endswith('-fixture')
                                         for index in fixture['indices']):
        raise ValueError('Fixture index outside the dedicated scope.')
    return fixture


def demo_context(fixture_name='portable'):
    """Return settings and fixture after checking demo mode and its exact OpenSearch URL."""
    settings = load_settings()
    if os.environ.get('PDL_MODE') != 'demo' or settings.opensearch.url != 'http://opensearch:9200':
        raise RuntimeError('Synthetic seed is restricted to this project\'s demo OpenSearch.')
    return settings, load_fixture(fixture_name)


def prepare_mappings(settings, fixture, inventory, store, manual_mappings=False):
    """Validate all bundled schemas, then activate only their known fixture mappings.

    Preserve active operator mappings and unrelated pending reviews. A mismatch
    stops automatic activation before creating any review or catalog entry.
    Callers must first pass demo_context; this helper performs no network reads.
    """
    for index, spec in fixture['indices'].items():
        entry = inventory['indices'][index]
        validate_mapping(spec['concepts'], entry)
        if not manual_mappings and entry.get('physical_mapping', {}).get('properties') != spec['properties']:
            raise ValueError(f'{index}: schema differs from bundled fixture; use --manual-mappings to review it.')
    pending = store.reviews()
    for index, spec in fixture['indices'].items():
        entry = inventory['indices'][index]
        active = next((item for item in store.catalog() if item.get('active') and item['index'] == index
                       and item['schema_hash'] == entry['schema_hash']), None)
        if active:
            print(f'{index}: active catalog retained')
            continue
        review = next((item for item in pending if item['index'] == index and item['status'] == 'pending'
                       and item.get('kind') == 'fixture_mapping' and item['schema_hash'] == entry['schema_hash']
                       and item['proposed_mapping'] == spec['concepts']), None)
        if not review:
            review = store.create_review({'kind': 'fixture_mapping', 'index': index,
                                         'schema_hash': entry['schema_hash'],
                                         'proposed_mapping': spec['concepts'], 'dsl_trials': []})
        if manual_mappings:
            print(f'Review required: {settings.public_admin_url}/reviews/{review["id"]}')
        else:
            store.approve(review['id'], entry['schema_hash'], author='bundled-demo-fixture',
                          reason='Automatic activation of the packaged synthetic fixture mapping; no human review.')
            print(f'{index}: bundled demo mapping activated')
    print('Manual fixture review required.' if manual_mappings else 'Bundled demo mappings ready; no manual approval required.')


def seed(fixture_name='portable', manual_mappings=False):
    """Wait for OpenSearch, add missing documents and prepare bundled mappings.

    Preserve existing indices and documents with the same ID. By default activate
    the known demo mappings; manual_mappings retains the teaching review workflow.
    """
    settings, fixture = demo_context(fixture_name)
    session = requests.Session()
    session.trust_env = False
    for _ in range(90):
        try:
            response = session.get(settings.opensearch.url, timeout=2)
            if response.status_code == 200:
                break
        except requests.RequestException:
            pass
        time.sleep(2)
    else:
        raise RuntimeError('Demo OpenSearch is not ready after 180 seconds.')
    for index, spec in fixture['indices'].items():
        url = settings.opensearch.url + '/' + index
        exists = session.head(url, timeout=10)
        if exists.status_code == 404:
            response = session.put(url, json={'settings': {'number_of_shards': 1, 'number_of_replicas': 0},
                                             'mappings': {'properties': spec['properties']}}, timeout=15)
            response.raise_for_status()
        elif exists.status_code != 200:
            exists.raise_for_status()
        else:
            # load_fixture already validated the scope; preserve the existing mapping.
            print(f'{index}: existing index preserved')
        for doc in spec['documents']:
            response = session.put(url + '/_create/' + doc['id'], json=doc['source'], timeout=10)
            if response.status_code != 409:
                response.raise_for_status()
        session.post(url + '/_refresh', timeout=10).raise_for_status()
        print(f'{index}: {len(spec["documents"])} synthetic documents installed')
    store = Store(settings.data_dir)
    inventory = OpenSearchInventory(settings, store).refresh()
    prepare_mappings(settings, fixture, inventory, store, manual_mappings)


def approve(review_id, author, fixture_name='portable'):
    """Approve an explicit fixture review after comparison with current inventory.

    Each concept must target a searchable field with the same type. Store.approve checks
    the schema hash and records the decision attributed to author.
    """
    settings, fixture = demo_context(fixture_name)
    store = Store(settings.data_dir)
    review = store.review(review_id)
    if review['index'] not in fixture['indices']:
        raise ValueError('Review does not belong to the explicitly selected synthetic fixture.')
    inventory = OpenSearchInventory(settings, store).refresh()
    entry = inventory['indices'][review['index']]
    mapping = review['proposed_mapping']
    for name, spec in mapping.items():
        field = entry['fields'].get(spec.get('field'))
        if not field or field['type'] != spec.get('type') or not field['searchable']:
            raise ValueError(f'Invalid reviewed concept: {name}')
    result = store.approve(review_id, entry['schema_hash'], author=author,
                           reason='Explicit review of synthetic demonstration mapping')
    print(json.dumps({'catalog_id': result['id'], 'index': result['index'], 'status': 'approved'}))


def inspect(review_id=None):
    """Print a review or public inventory/catalog/review state without generation."""
    settings = load_settings()
    store = Store(settings.data_dir)
    value = store.review(review_id) if review_id else {
        'indices': list(store.inventory().get('indices', {})),
        'active_catalog': [item for item in store.catalog() if item.get('active')],
        'pending_reviews': [item for item in store.reviews() if item['status'] == 'pending']}
    print(json.dumps(value, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=['seed', 'inspect', 'approve'])
    parser.add_argument('--review-id')
    parser.add_argument('--author', default='local-demo-operator')
    parser.add_argument('--fixture', choices=sorted(FIXTURES), default='portable')
    parser.add_argument('--manual-mappings', action='store_true', help='leave bundled demo mappings pending for a teaching review')
    args = parser.parse_args()
    if args.operation == 'seed':
        seed(args.fixture, args.manual_mappings)
    elif args.operation == 'inspect':
        inspect(args.review_id)
    elif not args.review_id:
        parser.error('approve requires --review-id after an explicit review')
    else:
        approve(args.review_id, args.author, args.fixture)
