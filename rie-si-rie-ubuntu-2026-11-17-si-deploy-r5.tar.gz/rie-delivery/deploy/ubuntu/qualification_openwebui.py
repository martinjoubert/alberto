"""Qualify real Albert conversations through two isolated local Open WebUI clients.

This host-only recipe uses fresh, owned client volumes and individual backend
credentials. It never modifies an existing Open WebUI instance or prints secrets.
Browser conversation posts are bounded; raw receipts remain in the private state.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import time
from urllib.parse import urlsplit

import httpx

ROOT = Path(__file__).resolve().parents[2]
IMAGE = 'ghcr.io/open-webui/open-webui@sha256:98b795650b5323614d9b1cd7abd20cd1b62245b02fe81671f46f37acea8c6668'
OWNER = 'rie-local-client-real-20261106'
PREFIX = 'rie-client-qualification'
MODEL = 'gpt-oss-120b'
CLIENTS = {'alice': 13001, 'eric': 13002}
PDL_ID, INCIDENT_ID = 'albert-pdl-rie', 'albert-observabilite-gptoss'
SYSTEM = '''Pour chaque message utilisateur, appelle exactement une fois l’outil MCP sélectionné.
Transmets question comme copie intégrale du message courant. Utilise le dernier continuation_token de ce fil, vide pour une nouvelle conversation.
Le serveur interprète le dialogue et relit les droits et les preuves. Après l’appel, restitue sa réponse, ses preuves et ses limites sans les inventer.
Un refus reste un refus ; une clarification reste une question. N’expose aucun jeton dans la réponse. Ne relance pas automatiquement en cas de limitation.'''


def private_write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as out:
        out.write(value)


def env_file(path):
    values = {}
    for line in Path(path).read_text().splitlines():
        if '=' in line and not line.lstrip().startswith('#'):
            key, value = line.split('=', 1)
            values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def docker(args, *argv, capture=True):
    result = subprocess.run([args.docker, *argv], check=True, text=True,
                            stdout=subprocess.PIPE if capture else None,
                            stderr=subprocess.PIPE if capture else None)
    return result.stdout.strip() if capture else ''


def owned(args, name, *, volume=False):
    exists = docker(args, *(['volume', 'ls', '--filter', 'name=^'+name+'$', '--format', '{{.Name}}']
                           if volume else ['ps', '-aq', '--filter', 'name=^/'+name+'$']))
    if not exists:
        return False
    item = json.loads(docker(args, *(['volume', 'inspect', name] if volume else ['inspect', name])))[0]
    labels = (item.get('Labels') if volume else item['Config'].get('Labels')) or {}
    if labels.get('rie.qualification.owner') != OWNER:
        raise ValueError('Foreign client container/volume; refusing lifecycle operation')
    return True


def connection(kind, key):
    server = 'dinum-pdl-agent' if kind == 'pdl' else 'obs-gptoss'
    path = ':19910/mcp' if kind == 'pdl' else ':19950/gptoss/assistant/mcp'
    tool = 'investigate_pdl' if kind == 'pdl' else 'diagnose_observability'
    return {'url': 'http://host.docker.internal' + path, 'path': '', 'type': 'mcp',
            'auth_type': 'bearer', 'key': key, 'headers': {},
            'config': {'enable': True, 'access_grants': [], 'function_name_filter_list': tool},
            'info': {'id': server, 'name': 'Ubuntu ' + kind, 'description': 'Individual local client; server-side ACL.'}}


def configure_client(args, person):
    folder = args.state / person
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    credentials = folder / 'account.json'
    if credentials.exists():
        account = json.loads(credentials.read_text())
    else:
        account = {'name': 'Qualification ' + person, 'email': person + '@qualification.invalid',
                   'password': secrets.token_urlsafe(32)}
        private_write(credentials, json.dumps(account)+'\n')
    provider = env_file(args.provider_env)
    base = provider.get('ALBERT_API_BASE_URL') or provider.get('ALBERT_API_URL')
    key = provider.get('ALBERT_API_KEY')
    parsed = urlsplit(base or '')
    if parsed.scheme != 'https' or parsed.username or parsed.password or not key:
        raise ValueError('A private HTTPS Albert configuration is required')
    backend_key = (args.state / (person + '.token')).read_text().strip()
    if not re.fullmatch(r'dinum_ut1_[a-f0-9]{32}_[A-Za-z0-9_-]{43}', backend_key):
        raise ValueError('An individual server-issued backend token is required')
    connections = [connection(kind, backend_key) for kind in ('pdl', 'incidents')]
    settings = {'PORT': '8080', 'WEBUI_AUTH': 'true', 'ENABLE_SIGNUP': 'true',
                'WEBUI_SECRET_KEY': secrets.token_urlsafe(48), 'ENABLE_PERSISTENT_CONFIG': 'false',
                'ENABLE_FORWARD_USER_INFO_HEADERS': 'false', 'ENABLE_OLLAMA_API': 'false',
                'ENABLE_OPENAI_API': 'true', 'OPENAI_API_BASE_URL': base, 'OPENAI_API_BASE_URLS': base,
                'OPENAI_API_KEY': key, 'OPENAI_API_KEYS': key,
                'ENABLE_TOOL_SERVERS': 'true', 'TOOL_SERVER_CONNECTIONS': json.dumps(connections, separators=(',', ':')),
                'ENABLE_TITLE_GENERATION': 'false', 'ENABLE_TAGS_GENERATION': 'false',
                'ENABLE_FOLLOW_UP_GENERATION': 'false', 'ENABLE_MEMORY_BACKGROUND_REVIEW': 'false',
                'ENABLE_CONTEXT_COMPACTION': 'false', 'ENABLE_CUSTOM_MODEL_FALLBACK': 'false',
                'CHAT_RESPONSE_MAX_TOOL_CALL_ITERATIONS': '1', 'OFFLINE_MODE': 'true',
                'HF_HUB_OFFLINE': '1', 'ANONYMIZED_TELEMETRY': 'false', 'DO_NOT_TRACK': 'true',
                'ENABLE_VERSION_UPDATE_CHECK': 'false', 'CORS_ALLOW_ORIGIN': 'http://127.0.0.1:'+str(CLIENTS[person])}
    env_path = folder / 'client.env'
    if not env_path.exists():
        private_write(env_path, ''.join(k+'='+v+'\n' for k,v in settings.items()))
    name, volume = PREFIX+'-'+person, PREFIX+'-'+person+'-data'
    if not owned(args, volume, volume=True):
        docker(args, 'volume', 'create', '--label', 'rie.qualification.owner='+OWNER, volume)
    if not owned(args, name):
        docker(args, 'run', '-d', '--name', name, '--label', 'rie.qualification.owner='+OWNER,
               '--publish', '127.0.0.1:'+str(CLIENTS[person])+':8080', '--add-host', 'host.docker.internal:'+args.host_ip,
               '--env-file', str(env_path), '--mount', 'type=volume,source='+volume+',target=/app/backend/data',
               '--memory', '1200m', '--cpus', '1', '--pids-limit', '256',
               '--log-driver', 'json-file', '--log-opt', 'max-size=10m', '--log-opt', 'max-file=2', IMAGE)
    else:
        docker(args, 'start', name)
    return account, connections


class API:
    def __init__(self, url):
        self.url = url
        self.token = ''
        self.http = httpx.Client(base_url=url, trust_env=False, follow_redirects=False, timeout=240)

    def call(self, path, body=None):
        response = self.http.request('GET' if body is None else 'POST', path,
                                     headers={'Authorization':'Bearer '+self.token} if self.token else {},
                                     **({'json':body} if body is not None else {}))
        if response.status_code >= 300:
            raise ValueError('OpenWebUI HTTP '+str(response.status_code)+' '+path.split('?')[0])
        return response.json()

    def login(self, account):
        try:
            value = self.call('/api/v1/auths/signin', {'email':account['email'], 'password':account['password']})
        except ValueError:
            value = self.call('/api/v1/auths/signup', account)
        if value.get('role') != 'admin':
            raise ValueError('Each isolated client must have its own fresh local administrator')
        self.token = value['token']


def setup(args):
    args.state.mkdir(parents=True, exist_ok=True, mode=0o700)
    args.state.chmod(0o700)
    for person, port in CLIENTS.items():
        account, connections = configure_client(args, person)
        api = API('http://127.0.0.1:'+str(port))
        deadline = time.monotonic()+300
        while True:
            try:
                api.call('/api/config'); break
            except (httpx.HTTPError, ValueError):
                if time.monotonic()>deadline:raise ValueError('Local client startup timed out') from None
                time.sleep(2)
        api.login(account)
        for item in connections:
            result = api.call('/api/v1/configs/tool_servers/verify', item)
            expected = 'investigate_pdl' if item['info']['id']=='dinum-pdl-agent' else 'diagnose_observability'
            if {row['name'] for row in result.get('specs',[])} != {expected}:
                raise ValueError('Unexpected native MCP contract')
        api.call('/api/v1/configs/tool_servers', {'TOOL_SERVER_CONNECTIONS':connections})
        models = {row['id'] for row in api.call('/api/models')['data']}
        if MODEL not in models:raise ValueError('The requested Albert model is unavailable')
        filters = [('pdl_rie_dialogue', ROOT/'use-cases/pdl/agentic-pdl/rie_agent/openwebui_dialogue.py'),
                   ('incident_report_display', ROOT/'use-cases/incidents/observability-demo/openwebui/report_display.py')]
        for identifier,path in filters:
            payload={'id':identifier,'name':identifier,'content':path.read_text(), 'meta':{'description':'Stock client contract/display helper; no observability addon.'}}
            try:api.call('/api/v1/functions/id/'+identifier); endpoint='/api/v1/functions/id/'+identifier+'/update'
            except ValueError:endpoint='/api/v1/functions/create'
            saved=api.call(endpoint,payload)
            if not saved.get('is_active'):api.call('/api/v1/functions/id/'+identifier+'/toggle',{})
        for kind, mid, server, fid in [('pdl',PDL_ID,'dinum-pdl-agent','pdl_rie_dialogue'),
                                        ('incidents',INCIDENT_ID,'obs-gptoss','incident_report_display')]:
            payload={'id':mid,'base_model_id':MODEL,'name':'Ubuntu '+('PDL' if kind=='pdl' else 'Incidents'),
                     'params':{'system':SYSTEM,'function_calling':'native','temperature':0,'max_tokens':4096},
                     'meta':{'description':'Ubuntu qualified individual-client connection.', 'toolIds':['server:mcp:'+server],
                             'filterIds':[fid], 'capabilities':{'builtin_tools':False}},
                     'access_grants':[],'is_active':True}
            try:api.call('/api/v1/models/model?id='+mid);endpoint='/api/v1/models/model/update'
            except ValueError:endpoint='/api/v1/models/create'
            api.call(endpoint,payload)
        api.http.close()
        print(json.dumps({'client':person,'status':'configured','port':port,'model':MODEL,'identity_forwarding':False}),flush=True)


def unwrap(value, depth=0):
    if depth>8:return None
    if isinstance(value,str):
        try:return unwrap(json.loads(value),depth+1)
        except ValueError:return None
    if isinstance(value,dict):
        if 'status' in value and ('route' in value or value.get('application')=='observability'):
            return value
        for key in ('structuredContent','content','text','output'):
            if key in value:
                result=unwrap(value[key],depth+1)
                if result is not None:return result
    elif isinstance(value,list):
        for row in value:
            result=unwrap(row,depth+1)
            if result is not None:return result
    return None



def native_result(output):
    """Accept exactly one completed tool call and its linked native output."""
    if not isinstance(output, list):
        return None
    calls = [row.get('call_id') for row in output if isinstance(row, dict)
             and row.get('type') == 'function_call' and row.get('status') in ('completed','failed')
             and row.get('name', '').endswith(('_investigate_pdl', '_diagnose_observability'))]
    if len(calls) != 1:
        return None
    linked = [unwrap(row.get('output')) for row in output if isinstance(row, dict)
              and row.get('type') == 'function_call_output' and row.get('call_id') == calls[0]]
    if len(linked)!=1:return None
    value=linked[0]
    failed=any(row.get('type')=='function_call' and row.get('call_id')==calls[0] and row.get('status')=='failed' for row in output)
    if failed and not (isinstance(value,dict) and value.get('assistant_contract') in ('server-dialogue-v1','incident-dialogue-v1')
            and isinstance(value.get('answer'),str) and value.get('status') in ('denied','error','clarification','needs_clarification','cancelled','rate_limited')
            and not any(value.get(k) for k in ('evidence','sources','metrics','events','logs','documents','results','indices','dsl'))):return None
    return value



def incident_follow_up_checks(turns):
    """Qualify chronology and continuation from actual native tool receipts."""
    results=[native_result(t.get('message',{}).get('output',[])) or {} for t in turns]
    first,last=results if len(results)==2 else ({},{})
    events=last.get('events',[]);answer=last.get('answer','')
    def at(value,expected):
        try:return datetime.fromisoformat(value)==datetime.fromisoformat(expected)
        except (TypeError,ValueError):return False
    return [
        {'name':'incident_initial_generation_then_source_status','passed':len(results)==2
            and first.get('status')=='ok' and bool(first.get('analysis')) and first.get('review',{}).get('valid') is True
            and last.get('status')=='ok' and last.get('synthesis_mode')=='source_facts'
            and last.get('analysis') is None and last.get('usage')==[]
            and last.get('dialogue',{}).get('albert_calls')==0},
        {'name':'incident_follow_up_context_and_fresh_reads','passed':bool(last.get('context'))
            and last.get('context')==first.get('context') and bool(last.get('read_at'))
            and last.get('read_at')!=first.get('read_at') and bool(last.get('request_id'))
            and last.get('request_id')!=first.get('request_id')},
        {'name':'incident_noon_alarm_and_ticket_distinct','passed':bool(re.search(
            r'\*\*Oui : l’événement .*était déjà résolu.*à 12h00',answer)) and bool(re.search(
            r'\*\*Non : le ticket .*n’était pas encore clôturé à 12h00',answer))},
        {'name':'incident_resolution_and_closure_from_sources','passed':len(events)==1
            and at(events[0].get('end'),'2026-09-28T11:30:00+02:00')
            and at(events[0].get('ticket',{}).get('closed_at'),'2026-09-28T12:15:00+02:00')},
    ]


def generation_checks(result, kind, *, require_itsm=False):
    """Reject a no-generation receipt as proof of a real provider scenario.

    Caller must obtain this receipt from the controlled HTTP/native invocation;
    a configured model name or assistant prose alone proves no execution.
    """
    if kind not in ('pdl','incidents'):raise ValueError('Unknown generation use case')
    result=result or {};checks=[]
    def check(name, passed):checks.append({'name':kind+'_'+name,'passed':bool(passed)})
    if kind=='pdl':
        check('generation_success',result.get('status')=='success' and result.get('evidence'))
        planner=result.get('planner',{});dialogue=result.get('dialogue',{})
        check('albert_planner_returned_model',planner.get('kind')=='AlbertPlanner' and planner.get('returned_model'))
        check('albert_dialogue_returned_model',dialogue.get('albert_calls',0)>0 and dialogue.get('actual_model'))
    else:
        check('generation_success',result.get('status')=='ok' and result.get('synthesis_mode')=='generated'
              and result.get('analysis') and result.get('review',{}).get('valid') is True)
        usage=result.get('usage',[])
        for stage in ('draft','review'):
            calls=[row for row in usage if row.get('stage')==stage]
            check('albert_'+stage+'_returned_model_and_tokens',calls and all(
                row.get('actual_model') and isinstance(row.get('total_tokens'),int) and row['total_tokens']>0
                for row in calls))
        if require_itsm:
            check('native_itsm_history',result.get('ticket_history',{}).get('provider')=='itsm-ng')
            check('reviewed_proposal',result.get('proposed_solution',{}).get('state')=='proposed')
    return checks


def evaluate_report(report):
    """Derive acceptance checks from immutable native receipts, not model claims."""
    by_name = {case['case']: case for case in report.get('cases', [])}
    checks = [{'name': 'browser_post_budget', 'passed': report.get('browser_posts', 0) <= report.get('turn_limit', 0)}]
    turns = [turn for case in by_name.values() for turn in case.get('turns', [])]
    checks.append({'name': 'one_completed_native_tool_per_turn',
                   'passed': bool(turns) and all(native_result(turn.get('message', {}).get('output')) is not None for turn in turns)})
    clarification = by_name.get('pfs_clarification', {}).get('turns', [])
    checks.append({'name': 'clarification_has_no_published_evidence',
                   'passed': len(clarification) == 2 and clarification[0].get('business_status') == 'needs_clarification'
                   and not (clarification[0].get('result') or {}).get('evidence')})
    first_message = clarification[0].get('message', {}) if clarification else {}
    first_result = native_result(first_message.get('output', [])) or {}
    expected_question = first_result.get('clarification') or first_result.get('answer')
    rendered = [item for item in first_message.get('output', []) if item.get('type') == 'message']
    native_text = ''.join(part.get('text', '') for part in rendered[0].get('content', [])
                          if part.get('type') == 'output_text') if len(rendered) == 1 else None
    checks.append({'name': 'pdl_clarification_visible_server_question_preserved',
                   'passed': first_result.get('status') == 'needs_clarification'
                   and isinstance(expected_question, str) and bool(expected_question.strip())
                   and first_message.get('content') == expected_question and native_text == expected_question
                   and rendered[0].get('status') == 'completed'})
    internal = by_name.get('incident_r1', {}).get('turns', [])
    checks.extend(incident_follow_up_checks(internal))
    first_native=native_result(internal[0].get('message',{}).get('output',[])) if internal else None
    checks.extend(generation_checks(first_native,'incidents'))
    for name in ('pfs_count','equipment_cross_index','equipment_tacacs_follow_up','pfs_authorized'):
        for turn in by_name.get(name,{}).get('turns',[]):
            checks.extend({**row,'name':name+'_'+row['name']} for row in generation_checks(
                native_result(turn.get('message',{}).get('output',[])),'pdl'))
    result = internal[-1].get('result') or {} if internal else {}
    answer = result.get('answer', '')
    citations = set(re.findall(r'\[(S\d+)\]', answer)) if isinstance(answer, str) else set()
    known = {source.get('source_id') for source in result.get('sources', [])}
    checks.append({'name': 'incident_citations_reference_real_tool_sources',
                   'passed': bool(citations) and citations <= known})
    for name in ('incident_r1', 'incident_denied'):
        saved = by_name.get(name, {}).get('turns', [])
        final = saved[-1] if saved else {}
        result = final.get('result') or {}
        visible = final.get('message', {}).get('content')
        checks.append({'name': name + '_visible_server_report_preserved',
                       'passed': isinstance(visible, str) and isinstance(result.get('answer'), str)
                       and visible.strip() == result['answer'].strip()})
    external = by_name.get('incident_denied', {}).get('turns', [])
    result = external[-1].get('result') or {} if external else {}
    checks.append({'name': 'external_category_and_empty_incident_evidence',
                   'passed': result.get('status') == 'denied'
                   and result.get('access_control', {}).get('category') == 'external'
                   and not any(result.get(key) for key in ('metrics', 'events', 'logs', 'documents', 'sources', 'evidence'))})
    return checks


def wait_incident_interval(previous_finished, *, clock=time.monotonic, sleeper=time.sleep):
    """Allow the full admission interval after a completed, possibly long turn."""
    if previous_finished is None:
        return
    while True:
        remaining = 61 - (clock() - previous_finished)
        if remaining <= 0:
            return
        sleeper(min(5, remaining))


def run_browser(args):
    from playwright.sync_api import sync_playwright
    sys.path.insert(0,str(ROOT/'use-cases/incidents/observability-demo'))
    from browser_ui import enter_question
    report={'at_utc':datetime.now(timezone.utc).isoformat(),'provider':'real_albert','model':MODEL,
            'client_location':'isolated_OpenWebUI_on_Mac_Colima','browser_posts':0,'turn_limit':args.max_turns,
            'cases':[],'raw_receipts_private':True,'si_real_accessed':False}
    report_path=args.state/'real-conversation-results.json'
    def save():
        report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    cases=[('alice','pfs_count',PDL_ID,["Compte les refus PFS dans demo-alpha le 12 octobre 2026 de 08:00 à 09:00 UTC."], 'success'),
           ('alice','pfs_clarification',PDL_ID,["Compte les refus PFS dans demo-alpha.","Le 12 octobre 2026 de 08:00 à 09:00 UTC."], 'success'),
           ('alice','equipment_cross_index',PDL_ID,["Montre les logs de l’équipement edge-a PFS BB PFAING TACACS dans demo-alpha du 12 octobre 2026 de 08:00 à 09:00 UTC."], 'success'),
           ('alice','equipment_tacacs_follow_up',PDL_ID,["Montre les logs de l’équipement edge-a PFS BB PFAING TACACS dans demo-alpha du 12 octobre 2026 de 08:00 à 09:00 UTC.",
              "Uniquement TACACS pour ce même équipement, sur la même période."], 'success'),
           ('alice','incident_r1',INCIDENT_ID,["Diagnostique R1 le 28 septembre 2026 de 10:00 à 12:00, heure de Paris, sur le site de Rennes. Cite les sources et distingue résolution technique et clôture du ticket.",
               "À 12 h, heure de Paris, l’alerte était-elle résolue et le ticket déjà clôturé ?"], 'ok'),
           ('eric','incident_denied',INCIDENT_ID,["Diagnostique R1 le 28 septembre 2026 de 10:00 à 12:00, heure de Paris, sur le site de Rennes."], 'denied'),
           ('eric','pfs_authorized',PDL_ID,["Compte les refus PFS dans demo-alpha le 12 octobre 2026 de 08:00 à 09:00 UTC."], 'success')]
    with sync_playwright() as manager:
        browser=manager.chromium.launch(headless=True,executable_path=str(args.browser),args=['--disable-background-networking','--disable-sync','--no-first-run'])
        last_incident_finished = None
        for person,name,model,questions,expected in cases:
            if model == INCIDENT_ID:
                wait_incident_interval(last_incident_finished)
            api=API('http://127.0.0.1:'+str(CLIENTS[person]));api.login(json.loads((args.state/person/'account.json').read_text()))
            context=browser.new_context(viewport={'width':1440,'height':1000},locale='fr-FR')
            context.add_init_script('localStorage.setItem("token",'+json.dumps(api.token)+');')
            page=context.new_page()
            item={'case':name,'profile':person,'expected_status':expected,'turns':[],'passed':False}
            report['cases'].append(item);save()
            try:
                page.goto(api.url+'/?models='+model,wait_until='networkidle',timeout=60000)
                for question in questions:
                    if report['browser_posts']>=args.max_turns:raise ValueError('Conversation turn budget exhausted')
                    send=enter_question(page,question)
                    with page.expect_request(lambda request:request.method=='POST' and urlsplit(request.url).path=='/api/chat/completions',timeout=20000) as sent:
                        send.click()
                    request=sent.value.post_data_json
                    report['browser_posts']+=1;save()
                    page.wait_for_url('**/c/*',timeout=30000)
                    cid=urlsplit(page.url).path.split('/c/',1)[1]
                    began=time.monotonic();saved={};result=None
                    while time.monotonic()-began<300:
                        saved=api.call('/api/v1/chats/'+cid)['chat']['history']['messages'].get(request['id'],{})
                        result=native_result(saved.get('output',[]))
                        if saved.get('done') or saved.get('error'):break
                        page.wait_for_timeout(1000)
                    entry={'question':question,'seconds':round(time.monotonic()-began,2),'done':bool(saved.get('done')),
                           'error':bool(saved.get('error')),'business_status':(result or {}).get('status'),'result':result,
                           'message':saved,'chat_id':cid}
                    item['turns'].append(entry);save()
                    if model == INCIDENT_ID:
                        last_incident_finished=time.monotonic()
                    print(json.dumps({'case':name,'turn':len(item['turns']),'status':entry['business_status'],'done':entry['done'],'error':entry['error']}),flush=True)
                final=item['turns'][-1]
                result=final.get('result') or {}
                item['passed']=bool(final['done'] and not final['error'] and result.get('status')==expected)
                if name in ('pfs_count','pfs_authorized'):
                    item['exact_two_denials']=result.get('evidence',{}).get('total')==2
                    item['passed'] &= item['exact_two_denials']
                if name=='pfs_clarification':
                    item['clarification_then_success']=len(item['turns'])==2 and item['turns'][0]['business_status']=='needs_clarification'
                    item['passed'] &= item['clarification_then_success']
                if name=='equipment_cross_index':
                    item['exact_six_documents']=result.get('evidence',{}).get('total')==6
                    item['passed'] &= item['exact_six_documents']
                if name=='equipment_tacacs_follow_up':
                    evidence=result.get('evidence') or {}
                    item['first_turn_six_documents']=(len(item['turns'])==2 and
                        (item['turns'][0].get('result') or {}).get('evidence',{}).get('total')==6)
                    item['tacacs_only_after_follow_up']=(evidence.get('counts')=={'rie-tacacs-fixture':2}
                        and evidence.get('log_indices')==['rie-tacacs-fixture']
                        and sorted((row.get('index'),row.get('document_id')) for row in evidence.get('rows',[]))==[
                            ('rie-tacacs-fixture','tacacs-ipv4-only'),('rie-tacacs-fixture','tacacs-ipv6-only')])
                    item['equipment_scope_and_period_preserved']=(evidence.get('equipment')=='edge-a'
                        and evidence.get('time_range')=={'gte':'2026-10-12T08:00:00+00:00','lt':'2026-10-12T09:00:00+00:00'}
                        and all((row.get('source',{}).get('network') or {}).get('scope')=='demo-alpha'
                                for row in evidence.get('rows',[])))
                    item['passed'] &= (item['first_turn_six_documents'] and item['tacacs_only_after_follow_up']
                        and item['equipment_scope_and_period_preserved'])
                if name=='incident_r1':
                    item['five_metrics_120_logs']=len(result.get('metrics',[]))==5 and (result.get('logs') or {}).get('total')==120
                    item['initial_analysis_present']=isinstance((item['turns'][0].get('result') or {}).get('analysis'),dict)
                    item['passed'] &= item['five_metrics_120_logs'] and item['initial_analysis_present']
                    item['passed'] &= all(row['passed'] for row in incident_follow_up_checks(item['turns']))
                if name=='incident_denied':
                    item['no_forbidden_evidence']=not any(result.get(k) for k in ('metrics','events','logs','documents','sources','evidence'))
                    item['passed'] &= item['no_forbidden_evidence']
                page.screenshot(path=str(args.state/(name+'.png')),full_page=True)
            except Exception as error:
                item['error_type']=type(error).__name__;item['passed']=False
                try:page.screenshot(path=str(args.state/(name+'-error.png')),full_page=True)
                except Exception:pass
            finally:
                save();context.close();api.http.close()
                if model == INCIDENT_ID:
                    last_incident_finished = time.monotonic()
        browser.close()
    report['checks'] = evaluate_report(report)
    report['passed']=bool(report['cases']) and all(case['passed'] for case in report['cases']) and all(check['passed'] for check in report['checks'])
    save();print(json.dumps({'passed':report['passed'],'cases':len(report['cases']),'browser_posts':report['browser_posts'],'report':str(report_path)}))
    return 0 if report['passed'] else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=['setup','run','stop'])
    parser.add_argument('--state',type=Path,default=ROOT/'.runtime/ci/ubuntu-qualification/openwebui-real')
    parser.add_argument('--provider-env',type=Path,default=ROOT/'demos/albert-openwebui-poc/.env')
    parser.add_argument('--docker',default=os.getenv('RIE_DOCKER',str(ROOT.parent/'.tools/docker-cli/bin/docker')))
    parser.add_argument('--host-ip',default='192.168.5.2')
    parser.add_argument('--browser',type=Path,default=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'))
    parser.add_argument('--max-turns',type=int,default=12)
    args=parser.parse_args();args.state=args.state.resolve();os.umask(0o077)
    if not 1<=args.max_turns<=30:parser.error('Bound actual conversation posts to1–30')
    if args.operation=='setup':setup(args);return 0
    if args.operation=='run':return run_browser(args)
    for person in CLIENTS:
        name=PREFIX+'-'+person
        if owned(args,name):docker(args,'stop','--time','30',name)
    print(json.dumps({'clients':'stopped','volumes':'preserved','owner':OWNER}))
    return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except (ValueError,OSError,subprocess.CalledProcessError,httpx.HTTPError) as error:
        print(json.dumps({'status':'failed','error_type':type(error).__name__,'detail':'Inspect private qualification receipts; no credential emitted.'}),file=sys.stderr)
        raise SystemExit(2)
