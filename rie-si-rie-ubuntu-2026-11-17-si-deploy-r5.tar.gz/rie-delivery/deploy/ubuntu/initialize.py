"""Copy private host inputs to this instance's volume, preserving business state."""
import os
from pathlib import Path
import shutil


def initialize(source=Path('/input'), target=Path('/data'), ldap_target=Path('/ldap-data')):
    # Validate the complete tree before following paths or mutating any file.
    for root in (source, target, ldap_target):
        for path in [root, *root.rglob('*')]:
            if path.is_symlink():
                raise ValueError('Symlink inputs/state are forbidden')
    for name in ('config', 'secrets', 'access', 'pdl', 'incidents', 'access/user-tokens'):
        folder = target/name
        folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    for name in ('config', 'secrets'):
        for path in (source/name).rglob('*'):
            if path.is_symlink():
                raise ValueError('Symlink inputs are forbidden')
            dest = target/name/path.relative_to(source/name)
            if path.is_file():
                dest.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                shutil.copyfile(path, dest)
    policy = target/'access/policy.json'
    if not policy.exists():
        shutil.copyfile(source/'access/policy.json', policy)
    # Only this volume is traversed; no host ownership is changed.
    for path in [target, *target.rglob('*')]:
        if path.is_symlink():
            raise ValueError('Symlink state is forbidden')
        path.chmod(0o700 if path.is_dir() else 0o600)
        os.chown(path, 10001, 10001)
    if ldap_target.exists():
        for path in [ldap_target, *ldap_target.rglob('*')]:
            os.chown(path, 10001, 10001)


if __name__ == '__main__':
    initialize()
