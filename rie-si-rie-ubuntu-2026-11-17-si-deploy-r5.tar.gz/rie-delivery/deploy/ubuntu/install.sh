#!/usr/bin/env bash
# Repeat the documented installation. No secret is accepted as an argument.
set -euo pipefail
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
instance=''
mode=demo
mode_given=false
with_ui=false
install_prerequisites=false
dry_run=false
username=alice.martin
usage() {
  cat <<'EOF'
Usage: bash deploy/ubuntu/install.sh --instance ABSOLUTE_PRIVATE_PATH [options]
  --mode demo|external       Synthetic sources or operator-configured real sources
  --with-demo-ui             Start the optional local NiceGUI demonstration portal
  --install-prerequisites    Explicitly install Ubuntu packages and Docker if absent
  --username LDAP_LOGIN      Internal operator for readiness/acceptance (demo: alice.martin)
  --dry-run                 Print the exact phases; create/change nothing
The instance is outside the checkout. Existing secrets, mappings and policies are preserved.
Run as a Docker-authorized operator. If using sudo, keep --instance absolute.
EOF
}
while (($#)); do
  case "$1" in
    --instance|--mode|--username)
      (($# >= 2)) || { usage >&2; exit 2; }
      case "$1" in
        --instance) instance=$2;;
        --mode) mode=$2; mode_given=true;;
        --username) username=$2;;
      esac
      shift 2;;
    --with-demo-ui) with_ui=true; shift;;
    --install-prerequisites) install_prerequisites=true; shift;;
    --dry-run) dry_run=true; shift;;
    -h|--help) usage; exit 0;;
    *) printf 'Unknown option: %s\n' "$1" >&2; usage >&2; exit 2;;
  esac
done
[[ -n "$instance" && "$instance" = /* && "$mode" =~ ^(demo|external)$ ]] || { usage >&2; exit 2; }
[[ "$instance" != *[[:space:]]* && "$instance" != *'$'* && "$instance" != *'`'* ]] || {
  printf 'Choose a private absolute path without whitespace or shell interpolation.\n' >&2; exit 2;
}
python_bin=${RIE_PYTHON:-python3}
command -v "$python_bin" >/dev/null || { printf 'Python 3.10+ is required.\n' >&2; exit 2; }
if ! "$python_bin" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 2)'; then
  printf 'Python 3.10 or newer is required; set RIE_PYTHON to a supported interpreter.\n' >&2; exit 2
fi
command_line() { printf '  '; printf '%q ' "$@"; printf '\n'; }
phase() {
  command_line "$@"
  if ! "$dry_run"; then "$@"; fi
}
if [[ -f "$instance/.env" ]]; then
  existing_mode=$("$python_bin" - "$instance/.env" <<'PY'
from pathlib import Path
import sys
rows=dict(line.split('=',1) for line in Path(sys.argv[1]).read_text().splitlines() if line and not line.startswith('#'))
if rows.get('RIE_MODE') not in {'demo','external'}:raise SystemExit(2)
print(rows['RIE_MODE'])
PY
)
  if "$mode_given" && [[ "$existing_mode" != "$mode" ]]; then
    printf 'Existing instance mode differs; choose a new instance instead of resetting it.\n' >&2; exit 2
  fi
  mode=$existing_mode
fi
printf 'DINUM two-use-case installation: mode=%s instance=%s dry_run=%s\n' "$mode" "$instance" "$dry_run"
if "$install_prerequisites"; then
  phase "$python_bin" "$script_dir/prerequisites.py" --install
fi
if ! "$dry_run"; then
  command -v openssl >/dev/null || { printf 'openssl is required; use --install-prerequisites on Ubuntu.\n' >&2; exit 2; }
  docker_bin=${RIE_DOCKER:-docker}
  "$docker_bin" info >/dev/null || {
    printf 'Docker is unavailable or access is denied. Use an authorized operator or sudo with the same absolute --instance.\n' >&2; exit 2;
  }
  "$docker_bin" compose version >/dev/null
  "$docker_bin" buildx version >/dev/null
fi
if [[ ! -f "$instance/.env" ]]; then
  phase "$python_bin" "$script_dir/manage.py" prepare "$instance" --mode "$mode"
else
  printf 'Existing instance retained; resuming documented phases.\n'
fi
if "$with_ui"; then
  phase "$python_bin" "$script_dir/manage.py" configure-ui "$instance" --enable-demo-ui
fi
phase "$python_bin" "$script_dir/manage.py" validate "$instance"
phase "$python_bin" "$script_dir/manage.py" build "$instance"
phase "$python_bin" "$script_dir/manage.py" pull "$instance"
phase "$python_bin" "$script_dir/manage.py" up "$instance"
if [[ "$mode" = demo ]]; then
  phase "$python_bin" "$script_dir/manage.py" seed "$instance" --username "$username"
fi
phase "$python_bin" "$script_dir/manage.py" check "$instance" --username "$username"
if [[ "$mode" = demo ]]; then
  phase "$python_bin" "$script_dir/manage.py" acceptance "$instance" --username "$username"
fi
printf 'Installation phases complete. Provider generation and client Open WebUI require their separate recipe.\n'
