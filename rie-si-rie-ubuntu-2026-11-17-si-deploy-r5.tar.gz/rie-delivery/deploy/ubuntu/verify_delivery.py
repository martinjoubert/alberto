#!/usr/bin/env python3
"""Verify the complete public source delivery before building or creating an instance.

This checks integrity against the received manifest, not publisher authenticity.
Use a fresh extracted directory: added files are refused, including build outputs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import sys

MANIFEST = 'DELIVERY-MANIFEST.json'


def verify_delivery(root):
    root = Path(root).expanduser().absolute()
    if root.is_symlink() or not root.is_dir():
        raise ValueError('Choose the real directory of a freshly extracted delivery.')
    actual = {}
    for path in root.rglob('*'):
        mode = path.lstat().st_mode
        if stat.S_ISLNK(mode) or not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
            raise ValueError('Links and special files are forbidden in a delivery.')
        if stat.S_ISREG(mode):
            actual[path.relative_to(root).as_posix()] = path
    if MANIFEST not in actual:
        raise ValueError('Missing '+MANIFEST)
    manifest = json.loads(actual[MANIFEST].read_text())
    if manifest.get('schema_version') != 1 or not isinstance(manifest.get('files'), list):
        raise ValueError('Unsupported delivery manifest.')
    expected = {}
    for item in manifest['files']:
        name = item.get('path')
        if (not isinstance(name, str) or not name or '\\' in name or '\x00' in name
                or PurePosixPath(name).is_absolute()
                or any(part in {'', '.', '..'} for part in name.split('/'))
                or ':' in name or name == MANIFEST or name in expected):
            raise ValueError('Unsafe or duplicate delivery manifest path.')
        if (type(item.get('bytes')) is not int or item['bytes'] < 0
                or not isinstance(item.get('sha256'), str)
                or not re.fullmatch('[a-f0-9]{64}', item['sha256'])):
            raise ValueError('Invalid file size or SHA-256 in manifest.')
        expected[name] = item
    if not expected or set(actual) != set(expected) | {MANIFEST}:
        raise ValueError('Delivery contains missing or unlisted files; extract into a new directory.')
    for name, item in expected.items():
        path = actual[name]
        checksum = hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024*1024), b''):
                checksum.update(chunk)
        if path.stat().st_size != item['bytes'] or checksum.hexdigest() != item['sha256']:
            raise ValueError('Delivery integrity check failed: '+name)
    return {'passed': True, 'files': len(expected), 'source': manifest.get('source'),
            'manifest_sha256': hashlib.sha256(actual[MANIFEST].read_bytes()).hexdigest(),
            'authenticity': 'not_verified_by_checksum'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path, help='Fresh extracted rie-delivery directory')
    args = parser.parse_args()
    try:
        print(json.dumps(verify_delivery(args.directory), ensure_ascii=False))
    except (OSError, ValueError, TypeError, AttributeError) as error:
        print('ERROR: '+str(error), file=sys.stderr)
        raise SystemExit(2)


if __name__ == '__main__':
    main()
