"""Real-time qualification driver; no Docker socket is exposed to applications.

Run `endurance INSTANCE --output PRIVATE_DIR` on the Ubuntu host. It starts an
unprivileged HTTP workload container while the host separately samples Docker.
Short runs are explicitly labelled smoke tests and never count as endurance.
"""
from __future__ import annotations
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import time


# Executed inside the backend by the host sampler. Conversation expiry and
# atomic writes may remove an entry between enumeration and stat; count those
# races explicitly, while retaining errors such as denied filesystem access.
STORAGE_SAMPLE_CODE = r'''
from pathlib import Path
import json,stat
result={'files':0,'bytes':0,'vanished_during_scan':0}
for path in Path('/data').rglob('*'):
    try:info=path.lstat()
    except FileNotFoundError:
        result['vanished_during_scan']+=1
        continue
    if stat.S_ISREG(info.st_mode):
        result['files']+=1
        result['bytes']+=info.st_size
print(json.dumps(result))
'''


def now():return datetime.now(timezone.utc).isoformat()


def percentile(values,fraction):
    if not values:return None
    ordered=sorted(values)
    return round(ordered[max(0,math.ceil(len(ordered)*fraction)-1)],3)


def summary(rows):
    latencies=[row['latency_ms'] for row in rows]
    return {'requests':len(rows),'unexpected_errors':sum(not row['passed'] for row in rows),
            'expected_denials':sum(row['expected_denial'] for row in rows),
            'p50_ms':percentile(latencies,.5),'p95_ms':percentile(latencies,.95),'p99_ms':percentile(latencies,.99),
            'business_statuses':dict(Counter(row['business_status'] for row in rows))}


def next_client_start(previous,period,deadline,*,clock=time.monotonic,sleeper=time.sleep):
    """Wait for this identity's next start, including across stage boundaries.

    A stage still lasts until its deadline when its final request was less than
    one period ago. Sleeping never reserves another client's slot.
    """
    while True:
        current=clock()
        if current>=deadline:return None
        earliest=current if previous is None else previous+period
        if current>=earliest:return current
        sleeper(min(earliest,deadline)-current)


def cadence_summary(rows,period):
    """Measure native monotonic starts per identity across the whole run."""
    starts={}
    for row in rows:starts.setdefault(row['client'],[]).append(row['start_monotonic_seconds'])
    pairs=[(earlier,later) for values in starts.values()
           for earlier,later in zip(sorted(values),sorted(values)[1:])]
    return {'period_seconds':period,'identities':len(starts),'intervals_checked':len(pairs),
            'minimum_start_gap_seconds':round(min((later-earlier for earlier,later in pairs)),6) if pairs else None,
            'violations':sum(later<earlier+period for earlier,later in pairs),
            'measurement':'native monotonic request starts per identity, including stage transitions'}


def structured(response):
    value=response.json()
    if value.get('error') or value.get('result',{}).get('isError'):return {'status':'protocol_error'}
    result=value.get('result',{})
    if isinstance(result.get('structuredContent'),dict):return result['structuredContent']
    for item in result.get('content',[]):
        if item.get('type')=='text':
            try:return json.loads(item['text'])
            except ValueError:pass
    return {'status':'missing_structured_result'}


def workload(duration,output,period=5):
    import httpx
    from dinum_access import AccessGate
    from dinum_access.user_tokens import UserTokens
    from rie_agent.acceptance import FIXTURE_PATH,scenarios
    if os.getenv('PDL_MODE')!='demo' or os.getenv('RIE_LOAD_QUALIFICATION')!='true' or os.getenv('RIE_SIMULATED_ALBERT')!='true':
        raise ValueError('Use only the explicitly marked, separate simulated load instance')
    output=Path(output);output.mkdir(parents=True,exist_ok=False,mode=0o700)
    fixture=json.loads(FIXTURE_PATH.read_text())
    questions=[row['question'] for row in scenarios(fixture) if row['id'] in {'pfs_count','bb_aggregate','pfaing_search'}]
    # Independent oracle for the explicitly specified 100000-row load fixture.
    totals_by_case={'pfs_count':24999,'bb_aggregate':25000,'pfaing_search':25000}
    expected_totals={row['question']:totals_by_case[row['id']] for row in scenarios(fixture) if row['id'] in totals_by_case}
    gate=AccessGate.configured();store=UserTokens(gate.config['user_tokens_directory'])
    accounts=json.loads(Path('/data/config/load-accounts.json').read_text())
    if len(accounts)!=10 or len({row['username'] for row in accounts})!=10:raise ValueError('Ten distinct load identities required')
    total_started=time.monotonic();report={'started_at':now(),'real_time':True,'kind':'endurance' if duration>=7200 else 'smoke',
        'duration_requested_seconds':duration,'period_seconds':period,'model':'qualification-fixture','actual_albert_calls':0,
        'simulated_provider':True,'identity_count':10,'stages':[]}
    lock=threading.Lock();rows=[];max_inflight=0;inflight=0
    record_stream=(output/'requests.jsonl').open('x')
    body={'question':'Examiner les mesures et logs R1 pendant la période demandée.','variant':'gptoss','equipment':'OBS-RTR-01',
          'start':'2026-09-28T10:00:00+02:00','end':'2026-09-28T12:00:00+02:00','synthesize':False}
    credentials=[]
    try:
        with tempfile.TemporaryDirectory(prefix='rie-load-credentials-') as private:
            for account in accounts:
                path=Path(private)/(account['username']+'.token')
                record=store.issue(gate.directory,account['username'],path,days=1)
                credentials.append({**account,'token':path.read_text().strip(),'id':record['id']})
            schedule=[(1,int(duration*.25)),(5,int(duration*.375))]
            schedule.append((10,duration-sum(seconds for _,seconds in schedule)))
            # Exactly one worker per identity runs in a phase; phases join before
            # the next starts. Keep its last start outside the per-phase worker.
            last_starts=[None for _ in credentials]
            for stage_number,(users,seconds) in enumerate(schedule,1):
                stage_started=time.monotonic();deadline=stage_started+seconds;phase_rows=[]
                def worker(index):
                    nonlocal max_inflight,inflight
                    account=credentials[index]
                    headers={'Authorization':'Bearer '+account['token'],'Accept':'application/json, text/event-stream',
                             'MCP-Protocol-Version':'2025-11-25'}
                    iteration=0
                    with httpx.Client(timeout=180,trust_env=False,follow_redirects=False) as client:
                        while True:
                            began=next_client_start(last_starts[index],period,deadline)
                            if began is None:break
                            last_starts[index]=began;started_at=now()
                            operation='pdl' if (iteration+index)%2==0 else 'incidents'
                            expected_denial=operation=='incidents' and account['category']=='external'
                            status=0;result={};error=None
                            with lock:
                                inflight+=1;max_inflight=max(max_inflight,inflight)
                            try:
                                if operation=='pdl':
                                    response=client.post('http://pdl:9910/mcp',headers=headers,json={'jsonrpc':'2.0','id':iteration+1,
                                        'method':'tools/call','params':{'name':'investigate_pdl','arguments':{
                                        'question':questions[(iteration+index)%len(questions)],'continuation_token':''}}})
                                    status=response.status_code;result=structured(response) if status==200 else {}
                                else:
                                    response=client.post('http://incidents:9950/diagnose',headers=headers,json=body)
                                    status=response.status_code;result=response.json() if status==200 else {}
                                allowed={'denied'} if expected_denial else {'success'} if operation=='pdl' else {'ok'}
                                passed=status==200 and result.get('status') in allowed
                                if passed and operation=='pdl':
                                    evidence=result.get('evidence') or {}
                                    passed=evidence.get('total')==expected_totals[questions[(iteration+index)%len(questions)]]
                                if passed and operation=='incidents' and not expected_denial:
                                    passed=(len(result.get('metrics') or [])==5 and not result.get('errors')
                                            and (result.get('logs') or {}).get('total')==12480)
                                if expected_denial:
                                    passed=passed and all(not result.get(name) for name in ('sources','evidence','metrics','logs','events','documents','results'))
                            except (httpx.HTTPError,ValueError,KeyError,TypeError) as exc:
                                passed=False;error=type(exc).__name__
                            finally:
                                with lock:inflight-=1
                            row={'at_utc':now(),'stage':stage_number,'users':users,'client':index+1,'category':account['category'],
                                 'started_at_utc':started_at,'start_monotonic_seconds':began,
                                 'operation':operation,'http_status':status,'business_status':result.get('status','unavailable'),
                                 'latency_ms':round((time.monotonic()-began)*1000,3),'expected_denial':expected_denial,
                                 'passed':passed,'error_code':error}
                            with lock:
                                phase_rows.append(row);rows.append(row);record_stream.write(json.dumps(row)+'\n');record_stream.flush()
                            iteration+=1
                with ThreadPoolExecutor(max_workers=users) as pool:list(pool.map(worker,range(users)))
                stage={**summary(phase_rows),'users':users,'requested_seconds':seconds,
                       'elapsed_seconds':round(time.monotonic()-stage_started,3),
                       'operations':{op:summary([row for row in phase_rows if row['operation']==op]) for op in ('pdl','incidents')}}
                stage['throughput_requests_per_second']=round(stage['requests']/max(stage['elapsed_seconds'],.001),4)
                report['stages'].append(stage)
                print(json.dumps({'event':'stage_completed',**stage}),flush=True)
                (output/'progress.json').write_text(json.dumps(report,indent=2)+'\n')
    finally:
        for account in credentials:store.revoke(account['id'])
        record_stream.close()
    report.update(finished_at=now(),elapsed_seconds=round(time.monotonic()-total_started,3),max_client_inflight=max_inflight,
                  client_queue_model='closed_loop_one_request_per_client_no_unbounded_queue',summary=summary(rows),
                  cadence=cadence_summary(rows,period))
    report['passed']=(bool(rows) and not report['summary']['unexpected_errors'] and report['elapsed_seconds']>=duration
                      and report['cadence']['violations']==0)
    (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'event':'workload_completed','passed':report['passed'],'kind':report['kind'],**report['summary']}),flush=True)
    return 0 if report['passed'] else 2


def host_endurance(instance,output,duration,period):
    spec=importlib.util.spec_from_file_location('delivery_manage',Path(__file__).with_name('manage.py'))
    manager=importlib.util.module_from_spec(spec);spec.loader.exec_module(manager)
    instance=Path(instance).resolve();values=manager.load(instance);manager.guard(instance,values)
    if values.get('RIE_LOAD_QUALIFICATION')!='true' or values.get('RIE_SIMULATED_ALBERT')!='true':
        raise ValueError('Host target must be the separate, explicitly marked load instance')
    output=Path(output).resolve()
    if output.exists() or output.is_relative_to(manager.ROOT):raise ValueError('Choose a new private result directory outside source checkout')
    output.mkdir(parents=True,mode=0o700)
    names=[values['RIE_PROJECT']+'-'+service+'-1' for service in ('pdl','incidents','opensearch','victoriametrics','ldap')]
    baseline=json.loads(manager.docker('inspect',*names,capture=True).stdout)
    stop=threading.Event();samples=[]
    def sample():
        with (output/'resources.jsonl').open('x') as stream:
            while not stop.is_set():
                row={'at_utc':now(),'disk':dict(zip(('total','used','free'),shutil.disk_usage('/var/lib/docker')))}
                try:
                    result=manager.docker('stats','--no-stream','--format','{{json .}}',*names,capture=True)
                    row['containers']=[json.loads(line) for line in result.stdout.splitlines() if line]
                    state=json.loads(manager.docker('inspect',*names,capture=True).stdout)
                    row['state']=[{'name':item['Name'],'running':item['State']['Running'],'oom':item['State']['OOMKilled'],
                                   'restarts':item['RestartCount']} for item in state]
                    row['application_storage']=json.loads(manager.docker('exec',names[0],'python','-c',STORAGE_SAMPLE_CODE,capture=True).stdout)
                except (subprocess.CalledProcessError,ValueError,OSError) as exc:row['sampling_error']=type(exc).__name__
                samples.append(row);stream.write(json.dumps(row)+'\n');stream.flush()
                stop.wait(15)
    thread=threading.Thread(target=sample,name='host-resource-sampler',daemon=True);thread.start()
    remote='/data/qualification/soak-'+str(int(time.time()))
    status=2
    try:
        with (output/'workload.log').open('x') as stream:
            result=manager.compose(instance,values,'run','--rm','--no-deps','--pull','never','operator',
                'python','/delivery/qualification.py','workload','--duration',str(duration),'--period',str(period),'--output',remote,
                stdout=stream,stderr=subprocess.STDOUT)
            status=result.returncode
    except subprocess.CalledProcessError:status=2
    finally:
        stop.set();thread.join(timeout=30)
    manager.compose(instance,values,'cp','pdl:'+remote,str(output/'workload'))
    report=json.loads((output/'workload/report.json').read_text())
    previous={item['Name']:item['RestartCount'] for item in baseline}
    unexpected=[state for sample in samples for state in sample.get('state',[]) if state['oom'] or not state['running'] or state['restarts']!=previous[state['name']]]
    report['host_resources']={'samples':len(samples),'unexpected_container_states':len(unexpected),
        'sampling_errors':sum('sampling_error' in row for row in samples),'application_storage_first':samples[0].get('application_storage') if samples else None,
        'application_storage_last':samples[-1].get('application_storage') if samples else None}
    report['passed']=report['passed'] and status==0 and not unexpected and not report['host_resources']['sampling_errors']
    report['platform']='Ubuntu ARM64 guest; measured capacity is not an AMD64 or real SI-RIE sizing guarantee'
    (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'passed':report['passed'],'kind':report['kind'],'elapsed_seconds':report['elapsed_seconds'],
                      'requests':report['summary']['requests'],'output':str(output)}),flush=True)
    return 0 if report['passed'] else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=['endurance','workload'])
    parser.add_argument('instance',nargs='?')
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--duration',type=int,default=7200)
    parser.add_argument('--period',type=float,default=5)
    args=parser.parse_args();os.umask(0o077)
    if args.duration<3 or args.period<5:parser.error('Duration >=3s and request period >=5s required')
    if args.operation=='endurance':
        if not args.instance:parser.error('instance required')
        return host_endurance(args.instance,args.output,args.duration,args.period)
    return workload(args.duration,args.output,args.period)


if __name__=='__main__':raise SystemExit(main())
