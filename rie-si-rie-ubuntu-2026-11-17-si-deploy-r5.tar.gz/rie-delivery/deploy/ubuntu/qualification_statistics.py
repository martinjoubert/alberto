"""Summarize an actual endurance receipt without exposing questions or tokens.

Read-only host tool. Docker CPU percentages refer to one logical CPU (100%),
and memory is the Docker working-set statistic, not the guest's total RAM.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from datetime import datetime
import json
from pathlib import Path
import re

from qualification import percentile, summary


def timestamp(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()


def byte_count(value):
    match = re.fullmatch(r'([0-9]+(?:\.[0-9]+)?)\s*(B|kB|MB|GB|TB|KiB|MiB|GiB|TiB)', value)
    if not match:
        raise ValueError('Unrecognized Docker byte measurement')
    factors = {'B': 1, 'kB': 1000, 'MB': 1000**2, 'GB': 1000**3, 'TB': 1000**4,
               'KiB': 1024, 'MiB': 1024**2, 'GiB': 1024**3, 'TiB': 1024**4}
    return round(float(match[1]) * factors[match[2]])


def resource_summary(samples):
    services = defaultdict(list)
    for sample in samples:
        for item in sample.get('containers', []):
            service = item['Name'].rsplit('-', 2)[-2]
            services[service].append(item)
    return {
        service: {'samples': len(items),
                  'cpu_p95_percent_of_one_cpu': percentile([float(i['CPUPerc'].rstrip('%')) for i in items], .95),
                  'cpu_peak_percent_of_one_cpu': max(float(i['CPUPerc'].rstrip('%')) for i in items),
                  'working_set_peak_bytes': max(byte_count(i['MemUsage'].split('/')[0].strip()) for i in items)}
        for service, items in sorted(services.items())
    }


def analyze(root):
    root = Path(root)
    report = json.loads((root / 'report.json').read_text())
    rows = [json.loads(line) for line in (root / 'workload/requests.jsonl').read_text().splitlines() if line]
    samples = [json.loads(line) for line in (root / 'resources.jsonl').read_text().splitlines() if line]
    if not rows or not samples:
        raise ValueError('An actual request trace and resource samples are required')
    measured = summary(rows)
    if measured != report['summary']:
        raise ValueError('Request trace differs from the recorded report')
    stages = []
    for number, recorded in enumerate(report['stages'], 1):
        phase = [row for row in rows if row['stage'] == number]
        if not phase or summary(phase)['requests'] != recorded['requests']:
            raise ValueError('Incomplete stage trace')
        began = min(timestamp(row['at_utc']) - row['latency_ms'] / 1000 for row in phase)
        ended = began + recorded['elapsed_seconds']
        phase_samples = [row for row in samples if began <= timestamp(row['at_utc']) < ended]
        stages.append({**recorded, 'resources': resource_summary(phase_samples)})
    by_client = defaultdict(list)
    for row in rows:
        by_client[row['client']].append(timestamp(row['at_utc']) - row['latency_ms'] / 1000)
    gaps = [later-earlier for times in by_client.values()
            for earlier, later in zip(sorted(times), sorted(times)[1:])]
    sampling_times = sorted(timestamp(row['at_utc']) for row in samples)
    sampling_gaps = [later-earlier for earlier, later in zip(sampling_times, sampling_times[1:])]
    first, last = samples[0], samples[-1]
    return {
        'kind': report['kind'], 'passed': report['passed'],
        'started_at': report['started_at'], 'finished_at': report['finished_at'],
        'elapsed_seconds': report['elapsed_seconds'], 'summary': measured, 'stages': stages,
        'client_cadence': {'minimum_observed_start_gap_seconds': round(min(gaps), 6) if gaps else None,
                          'p95_start_gap_seconds': percentile(gaps, .95),
                          'maximum_start_gap_seconds': round(max(gaps), 6) if gaps else None,
                          'measurement': 'UTC completion timestamp minus monotonic request latency'},
        'sampling': {'samples': len(samples),
                     'maximum_gap_seconds': round(max(sampling_gaps), 3) if sampling_gaps else None,
                     'errors': sum('sampling_error' in row for row in samples)},
        'resources': resource_summary(samples),
        'guest_filesystem': {'used_first_bytes': first['disk']['used'], 'used_last_bytes': last['disk']['used'],
                             'free_minimum_bytes': min(row['disk']['free'] for row in samples),
                             'shared_guest_with_reference_instance': True},
        'application_storage': {'first': first.get('application_storage'), 'last': last.get('application_storage'),
                                'includes': 'all files in load runtime volume, including reports and audits'},
        'queue': {'model': report['client_queue_model'], 'maximum_client_inflight': report['max_client_inflight'],
                  'server_queue_depth': 'not instrumented; no observability stack installed'},
        'host_resources': report['host_resources'], 'platform': report['platform'],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('receipt', type=Path)
    args = parser.parse_args()
    print(json.dumps(analyze(args.receipt), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
