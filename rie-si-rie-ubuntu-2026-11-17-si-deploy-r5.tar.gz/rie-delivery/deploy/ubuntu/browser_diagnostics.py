"""Bounded browser diagnostics, without response bodies, cookies or headers."""
from __future__ import annotations

from collections import deque
import json
from pathlib import Path
import traceback
from urllib.parse import urlsplit, urlunsplit

from test_reporting import sanitize_text


class BrowserDiagnostics:
    def __init__(self, output, *, secrets=()):
        self.output = Path(output)
        self.secrets = tuple(value for value in secrets if value)
        self.events = deque(maxlen=100)

    def clean(self, value, limit=65536):
        return sanitize_text(value, secrets=self.secrets, limit=limit)

    @staticmethod
    def url(value):
        try:
            parts = urlsplit(value)
            host = parts.hostname or ''
            if parts.port:
                host += ':'+str(parts.port)
            return urlunsplit((parts.scheme, host, parts.path, '', ''))
        except ValueError:
            return '[URL invalide]'

    def add(self, kind, text):
        self.events.append(self.clean(kind+' · '+str(text), 4096))

    def watch(self, page):
        page.on('console', lambda event:self.add('console '+event.type, event.text))
        page.on('pageerror', lambda error:self.add('JavaScript', str(error)))
        page.on('requestfailed', lambda request:self.add('réseau',
            request.method+' '+self.url(request.url)+' '+str(request.failure)))
        page.on('response', lambda response:self.add('HTTP '+str(response.status), self.url(response.url))
                if response.status >= 400 else None)

    def channels(self):
        return {'navigateur': self.clean('\n'.join(self.events)) or 'Aucun événement console/réseau capturé.'}

    def failure(self, error):
        """Persist the original exception before attempting optional captures."""
        row = {'error_type': type(error).__name__, 'message': self.clean(str(error)),
               'trace': self.clean(''.join(traceback.format_exception(type(error), error, error.__traceback__)))}
        (self.output/'failure-details.json').write_text(json.dumps(row, ensure_ascii=False, indent=2)+'\n')
        self.add('échec primaire', row['message'])
        return row

    def captures(self, pages):
        captured = []
        for page, filename in pages:
            try:
                # A failed login may still have its password in the input.
                page.locator('input[type="password"]').evaluate_all("items => items.forEach(item => item.value = '')")
            except Exception:
                pass
            try:
                page.screenshot(path=str(self.output/filename), full_page=True)
                if (self.output/filename).is_file():
                    captured.append(filename)
                else:
                    self.add('capture indisponible', filename+' : aucun fichier produit')
            except Exception as error:
                self.add('capture indisponible', filename+' : '+type(error).__name__+' '+str(error))
        return captured

    def save(self):
        (self.output/'browser-diagnostics.txt').write_text(self.channels()['navigateur']+'\n')
