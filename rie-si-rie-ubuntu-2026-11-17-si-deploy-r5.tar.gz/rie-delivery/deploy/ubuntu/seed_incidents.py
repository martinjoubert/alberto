"""Initialize the dedicated fictional Incidents corpus, without Zabbix or Albert.

Only fixed private Compose endpoints and loopback addresses are accepted. Existing
indices must carry this seed's ownership/hash marker; existing documents and
metrics are compared before any write. A retry completes missing records, never
replaces a record or deletes data. This is administrative fixture ingestion, not
an agent permission to write to a source.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta
import hashlib
import json
import math
import os
from pathlib import Path
import tempfile
from urllib.parse import urlsplit

import httpx

LOGS_INDEX = 'pdl-zabbix-observability-demo'
DOCS_INDEX = 'obs-network-docs'
SEED_VERSION = 'dinum-incidents-ubuntu-fixture-v1'
BASE = datetime.fromisoformat('2026-09-28T09:00:00+02:00')
KEYS = ('cpu', 'latency', 'loss', 'in', 'out')


class SeedError(ValueError):
    """A conflicting or incomplete corpus must not be silently accepted."""


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def endpoint(value, service, port):
    parsed = urlsplit(value)
    if (parsed.scheme != 'http' or parsed.username or parsed.password
            or parsed.query or parsed.fragment or parsed.path not in ('', '/')
            or not ((parsed.hostname == service and parsed.port == port)
                    or (parsed.hostname in ('127.0.0.1', 'localhost')
                        and parsed.port is not None and 1024 <= parsed.port <= 65535))):
        raise SeedError('Fixture seed requires a dedicated local demonstration endpoint.')
    return value.rstrip('/')


def values(number, minute):
    result = {'cpu': 20., 'latency': 10., 'loss': 0., 'in': 25., 'out': 20.}
    if number == 1:
        if 50 <= minute < 150:
            result.update(cpu=65., **{'in': 95., 'out': 90.})
        if 75 <= minute < 150:
            result.update(latency=80., loss=3.)
    if number == 2 and 105 <= minute < 120:
        result.update(latency=120., loss=20., cpu=30.)
    return result


def fixture_dir():
    installed = Path('/app/incidents')
    return installed if installed.is_dir() else Path(__file__).resolve().parents[2] / 'use-cases/incidents/observability-demo'


def build_corpus(fixtures):
    """Use the same fixed time window and labels as the packaged ITSM snapshot."""
    fixtures = Path(fixtures)
    mapping = json.loads((fixtures / 'fixtures/metric-mapping.json').read_text())
    documents = json.loads((fixtures / 'corpus-documents.json').read_text())
    tickets = json.loads((fixtures / 'fixtures/itsm-tickets.json').read_text())
    if (set(mapping['metrics']) != set(KEYS)
            or mapping['fixed_labels'] != {'job': 'dinum-observability'}
            or mapping['bindings'] != {'equipment': 'equipment', 'interface': 'interface'}
            or any(mapping['metrics'][key].get('scale') != 1 for key in KEYS)):
        raise SeedError('The bundled fixture metric mapping has changed; review the seed first.')
    if (tickets.get('complete') is not True or tickets.get('simulator') != 'ITSM-NG'
            or {r['equipment'] for r in tickets['tickets']} != {f'OBS-RTR-{n:02d}' for n in range(1, 5)}
            or any(not r.get('synthetic') or not r['alert_started_at'].startswith('2026-09-28T')
                   for r in tickets['tickets'])):
        raise SeedError('The bundled ITSM snapshot does not match the fixed corpus.')
    if len(documents) != 10 or len({r['record_id'] for r in documents}) != 10:
        raise SeedError('Incomplete bundled documentary corpus.')
    hosts = [{'equipment': f'OBS-RTR-{n:02d}', 'number': n, 'aliases': [f'R{n}'],
              'scope': 'Site de Rennes' if n < 3 else 'Beta', 'allowed': n < 4,
              'hostid': f'synthetic-{n}', 'interface': 'uplink0'} for n in range(1, 5)]
    logs = []
    for minute in range(240):
        for host in hosts:
            n = host['number']
            code = ('congestion' if n == 1 and 75 <= minute < 150 else
                    ('link_down' if minute % 2 else 'link_up') if n == 2 and 105 <= minute < 120 else 'heartbeat')
            logs.append({'record_id': f'2026-09-28-{n}-{minute:03d}',
                         '@timestamp': (BASE + timedelta(minutes=minute)).isoformat(),
                         'equipment': host['equipment'], 'scope': host['scope'],
                         'interface': host['interface'], 'event_code': code,
                         'message': {'heartbeat': 'Observation normale', 'congestion': 'File uplink chargée et pertes',
                                     'link_down': 'Liaison indisponible', 'link_up': 'Liaison rétablie'}[code],
                         'observer': {'type': 'zabbix', 'name': 'ZABBIX-DEMO'},
                         'event': {'dataset': 'zabbix.network'},
                         'provenance': 'synthetic-fixture-no-intranet-exporter'})
    samples = []
    for host in hosts:
        minutes = [m for m in range(240) if not (host['number'] == 3 and 60 <= m < 180)]
        for key in KEYS:
            labels = {'__name__': mapping['metrics'][key]['name'], **mapping['fixed_labels'],
                      **{label: host[binding] for label, binding in mapping['bindings'].items()}}
            samples.append({'metric': labels,
                            'values': [values(host['number'], m)[key] for m in minutes],
                            'timestamps': [int((BASE + timedelta(minutes=m)).timestamp() * 1000) for m in minutes]})
    manifest = {'status': 'ready', 'synthetic': True, 'anchor_date': '2026-09-28', 'timezone': 'Europe/Paris',
                'start': (BASE + timedelta(hours=1)).isoformat(), 'end': (BASE + timedelta(hours=3)).isoformat(),
                'baseline_start': BASE.isoformat(), 'baseline_end': (BASE + timedelta(hours=1)).isoformat(),
                'collection_start': BASE.isoformat(), 'collection_end': (BASE + timedelta(hours=4)).isoformat(),
                'hosts': hosts, 'events_checked': [], 'logs': len(logs), 'documents': len(documents),
                'interval_seconds': 60, 'scope_aliases': {'Alpha': 'Site de Rennes', 'Rennes': 'Site de Rennes'},
                'data_flow': {'metrics': 'victoriametrics', 'logs': 'opensearch-pdl', 'logs_index': LOGS_INDEX,
                              'alerts_and_treatment': 'itsm-ng-simulator', 'distributed_traces': 'not_collected',
                              'ingestion': 'standalone deterministic synthetic fixtures; no intranet exporter connected'}}
    fingerprint = hashlib.sha256(canonical({'manifest': manifest, 'logs': logs, 'documents': documents,
                                          'samples': samples, 'tickets': tickets}).encode()).hexdigest()
    marker = {'version': SEED_VERSION, 'sha256': fingerprint}
    manifest['bootstrap'] = marker
    return manifest, {LOGS_INDEX: logs, DOCS_INDEX: documents}, samples


def read_index(client, base, index, expected, marker):
    """Validate ownership and every existing row; permit recovery of partial seeds."""
    response = client.get(base + '/' + index + '/_mapping')
    if response.status_code == 404:
        return False, expected
    response.raise_for_status()
    data = response.json()
    if set(data) != {index} or data[index]['mappings'].get('_meta', {}).get('dinum_seed') != marker:
        raise SeedError('Existing index is not owned by this exact fixture seed: ' + index)
    response = client.post(base + '/' + index + '/_search', json={
        'size': len(expected) + 1, 'track_total_hits': True, 'query': {'match_all': {}}})
    response.raise_for_status()
    body = response.json()
    hits = body['hits']
    if (body.get('timed_out') or body.get('_shards', {}).get('failed', 0)
            or hits['total'].get('relation') != 'eq' or hits['total']['value'] != len(hits['hits'])):
        raise SeedError('Incomplete fixture index verification: ' + index)
    wanted = {row['record_id']: row for row in expected}
    seen = set()
    for hit in hits['hits']:
        key = hit['_id']
        if key in seen or key not in wanted or hit['_source'] != wanted[key]:
            raise SeedError('Existing fixture document differs; no document was replaced: ' + index)
        seen.add(key)
    return True, [row for row in expected if row['record_id'] not in seen]


def metric_points(rows):
    points = {}
    for row in rows:
        identity = canonical(row['metric'])
        if len(row['values']) != len(row['timestamps']):
            raise SeedError('Invalid metric sample lengths.')
        for timestamp, value in zip(row['timestamps'], row['values']):
            if not math.isfinite(float(timestamp)) or not math.isfinite(float(value)):
                raise SeedError('Invalid metric sample.')
            key = identity, float(timestamp)
            if key in points and points[key] != float(value):
                raise SeedError('Conflicting metric sample.')
            points[key] = float(value)
    return points


def missing_metrics(client, base, expected):
    """Retain real missing intervals; never interpolate or overwrite a sample."""
    response = client.get(base + '/api/v1/export', params={
        'match[]': '{job="dinum-observability"}', 'start': BASE.isoformat(),
        'end': (BASE + timedelta(hours=4) - timedelta(milliseconds=1)).isoformat(), 'max_rows_per_line': 1000})
    response.raise_for_status()
    if len(response.content) > 2_000_000:
        raise SeedError('Metric verification response is too large.')
    actual = metric_points([json.loads(line) for line in response.text.splitlines() if line.strip()])
    wanted = metric_points(expected)
    if any(key not in wanted or wanted[key] != value for key, value in actual.items()):
        raise SeedError('Existing metrics differ; no metric was replaced.')
    missing = []
    for row in expected:
        identity = canonical(row['metric'])
        pairs = [(timestamp, value) for timestamp, value in zip(row['timestamps'], row['values'])
                 if (identity, float(timestamp)) not in actual]
        if pairs:
            missing.append({'metric': row['metric'], 'timestamps': [p[0] for p in pairs], 'values': [p[1] for p in pairs]})
    return missing


def mapping(marker):
    properties = {key: {'type': 'keyword'} for key in
                  ('record_id', 'equipment', 'scope', 'interface', 'event_code', 'kind')}
    properties.update({key: {'type': 'text'} for key in ('title', 'text', 'keywords', 'message')})
    properties.update({'@timestamp': {'type': 'date'}, 'date': {'type': 'date'}, 'allowed': {'type': 'boolean'}})
    return {'mappings': {'_meta': {'dinum_seed': marker}, 'properties': properties}}


def publish_manifest(output, manifest):
    """Publish a complete 0600 file atomically without replacing an existing file."""
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if output.exists():
        if json.loads(output.read_text()) != manifest:
            raise SeedError('Existing manifest changed during initialization.')
        return
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', dir=output.parent, prefix='.corpus-seed-', delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        try:
            os.link(temporary, output)
        except FileExistsError:
            if json.loads(output.read_text()) != manifest:
                raise SeedError('Existing manifest changed during initialization.') from None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def seed(opensearch, victoria, output, fixtures=None, *, client=None):
    """Preflight all sources, create missing fixture rows, verify, publish manifest."""
    os_base = endpoint(opensearch, 'opensearch', 9200)
    vm_base = endpoint(victoria, 'victoriametrics', 8428)
    output = Path(output)
    manifest, indices, samples = build_corpus(fixtures or fixture_dir())
    if output.exists() and json.loads(output.read_text()) != manifest:
        raise SeedError('Existing manifest differs; use a new dedicated demonstration instance.')
    owns_client = client is None
    client = client or httpx.Client(timeout=60, trust_env=False)
    try:
        plans = {index: read_index(client, os_base, index, rows, manifest['bootstrap'])
                 for index, rows in indices.items()}
        metrics = missing_metrics(client, vm_base, samples)
        for index, (exists, rows) in plans.items():
            if not exists:
                client.put(os_base + '/' + index, json=mapping(manifest['bootstrap'])).raise_for_status()
            if rows:
                payload = ''.join(canonical({'create': {'_index': index, '_id': row['record_id']}})
                                  + '\n' + canonical(row) + '\n' for row in rows)
                response = client.post(os_base + '/_bulk?refresh=true', content=payload.encode(),
                                       headers={'Content-Type': 'application/x-ndjson'})
                response.raise_for_status()
                result = response.json()
                if (result.get('errors') is not False or len(result.get('items', [])) != len(rows)
                        or any(row.get('create', {}).get('status') != 201 for row in result['items'])):
                    raise SeedError('Fixture index creation incomplete; no overwrite attempted.')
        if metrics:
            client.post(vm_base + '/api/v1/import', content=''.join(canonical(row) + '\n' for row in metrics).encode(),
                        headers={'Content-Type': 'application/json'}).raise_for_status()
            # Make imported raw samples visible to immediate verification.
            client.get(vm_base + '/internal/force_flush').raise_for_status()
        for index, rows in indices.items():
            exists, missing = read_index(client, os_base, index, rows, manifest['bootstrap'])
            if not exists or missing:
                raise SeedError('Fixture verification incomplete: ' + index)
        if missing_metrics(client, vm_base, samples):
            raise SeedError('Metric verification incomplete; check VictoriaMetrics retention.')
        publish_manifest(output, manifest)
        return {'status': 'ready', 'synthetic': True, 'anchor_date': manifest['anchor_date'],
                'logs': len(indices[LOGS_INDEX]), 'documents': len(indices[DOCS_INDEX]),
                'metrics_series': len(samples), 'metric_points': len(metric_points(samples)),
                'sha256': manifest['bootstrap']['sha256'], 'albert_called': False, 'existing_data_replaced': False}
    finally:
        if owns_client:
            client.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--opensearch', default='http://opensearch:9200')
    parser.add_argument('--victoria', default='http://victoriametrics:8428')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--fixtures-dir', type=Path, default=fixture_dir())
    args = parser.parse_args()
    try:
        result = seed(args.opensearch, args.victoria, args.output, args.fixtures_dir)
    except (SeedError, httpx.HTTPError, OSError, ValueError, KeyError, TypeError):
        parser.exit(2, 'Incidents fixture initialization failed. Check local service health, ownership, corpus and retention; no data is replaced.\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
