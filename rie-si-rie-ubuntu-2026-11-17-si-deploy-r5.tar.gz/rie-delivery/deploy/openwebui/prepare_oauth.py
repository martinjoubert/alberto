"""Apply a bounded, version-pinned OAuth refresh adapter to a build context."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

SOURCE_SHA256 = 'a744dff881f1e2eddad7dddf458ea80a6f9523697ee922c9906c73702b1bc88a'
HOOK = '\n\nfrom rie_poc_oauth_refresh import install as _install_poc_oauth_refresh\n_install_poc_oauth_refresh(OAuthClientManager)\n'


def prepare(source, output):
    data = Path(source).read_bytes()
    if hashlib.sha256(data).hexdigest() != SOURCE_SHA256:
        raise ValueError('Open WebUI OAuth source changed; qualify this version before applying the adapter')
    Path(output).write_bytes(data + HOOK.encode())


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args();prepare(args.source,args.output)
