"""Configure a local Open WebUI without any user MCP credential to copy.

Only local-client administration is authenticated here. Individual LDAP access
is granted later by the user through native OAuth in their own browser session.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import getpass
import json
import os
from pathlib import Path
import sys
from urllib.error import HTTPError
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, ProxyHandler

ROOT = Path(__file__).resolve().parents[2]
SYSTEM = '''Pour chaque message utilisateur, appelle exactement une fois l’outil MCP sélectionné.
Transmets question comme copie intégrale du message courant. Utilise le dernier continuation_token de ce fil, vide pour une nouvelle conversation.
Le serveur interprète le dialogue et relit les droits et les preuves. Après l’appel, restitue sa réponse, ses preuves et ses limites sans les inventer.
Un refus reste un refus ; une clarification reste une question. N’expose aucun jeton dans la réponse. Ne relance pas automatiquement en cas de limitation.'''
PROFILES = (
    ('pdl', 'dinum-pdl-agent', 'investigate_pdl', 'albert-pdl-rie', 'pdl_rie_dialogue',
     'use-cases/pdl/agentic-pdl/rie_agent/openwebui_dialogue.py'),
    ('incidents', 'obs-gptoss', 'diagnose_observability', 'albert-observabilite-gptoss', 'incident_report_display',
     'use-cases/incidents/observability-demo/openwebui/report_display.py'),
)
# This shares the client presets/tool definitions with signed-in WebUI users.
# It grants no source access: OAuth still authenticates each LDAP identity and
# the two backends apply the current ACL before reading any data.
CLIENT_READ_GRANT = {'principal_type': 'user', 'principal_id': '*', 'permission': 'read'}


class ClientError(ValueError):
    def __init__(self, code):
        super().__init__('Open WebUI HTTP ' + str(code)); self.status = code


def checked_url(value):
    parsed = urlsplit(value)
    if (parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.hostname.lower().endswith('.invalid')
            or parsed.username or parsed.password
            or parsed.query or parsed.fragment or parsed.scheme == 'http' and parsed.hostname not in {'127.0.0.1', 'localhost', '::1'}):
        raise ValueError('Use HTTPS, or local loopback HTTP, without credentials in URLs')
    return value.rstrip('/')


class API:
    def __init__(self, base):
        self.base = checked_url(base)
        self.opener = build_opener(ProxyHandler({}))
        self.token = ''

    def call(self, path, body=None):
        headers = {'Content-Type': 'application/json'}
        if self.token: headers['Authorization'] = 'Bearer ' + self.token
        request = Request(self.base + path, headers=headers,
                          data=json.dumps(body).encode() if body is not None else None)
        try:
            with self.opener.open(request, timeout=40) as response:
                data = response.read(8_000_001)
                if len(data) > 8_000_000: raise ValueError('Bounded client response required')
                return json.loads(data)
        except HTTPError as error:
            raise ClientError(error.code) from None

    def login(self, email, password):
        account = self.call('/api/v1/auths/signin', {'email': email, 'password': password})
        if account.get('role') != 'admin':
            raise ValueError('The local Open WebUI administrator is required for setup')
        self.token = account['token']


def configure(api, urls, backup, *, model='gpt-oss-120b'):
    """Preserve unrelated integrations and keep a private rollback snapshot."""
    if not re_model(model): raise ValueError('Choose a plain base model identifier')
    source = {row[4]: (ROOT / row[5]).read_text() for row in PROFILES}
    existing = api.call('/api/v1/configs/tool_servers')['TOOL_SERVER_CONNECTIONS'] or []
    old_webui = api.call('/api/v1/configs/namespace/webui')
    old_url = old_webui.get('webui.url', old_webui.get('url'))
    old_assets = {'functions': {}, 'models': {}}
    for _, _, _, mid, fid, _ in PROFILES:
        for group, identifier, route in [('functions', fid, '/api/v1/functions/id/' + fid),
                                         ('models', mid, '/api/v1/models/model?' + urlencode({'id': mid}))]:
            try: old_assets[group][identifier] = api.call(route)
            except ClientError as error:
                # 0.11.3 also uses 401 for an absent private function/model.
                # Recheck the authenticated administrator before treating it as absent.
                if error.status == 401 and api.call('/api/v1/auths/').get('role') != 'admin':
                    raise
                if error.status not in {401, 404}: raise
                old_assets[group][identifier] = None
    backup = Path(backup).expanduser().absolute()
    if backup.is_relative_to(ROOT) or any(path.is_symlink() for path in (backup, *backup.parents)):
        raise ValueError('Choose a private backup outside the source tree')
    backup.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    # Backup includes encrypted native client metadata, never a LDAP password.
    descriptor = os.open(backup, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, 'w') as stream:
        json.dump({'TOOL_SERVER_CONNECTIONS': existing, 'webui.url': old_url, **old_assets}, stream)
    models = {row['id'] for row in api.call('/api/models')['data']}
    if model not in models:
        raise ValueError('The requested base model is not available in this Open WebUI')
    # A common browser origin is required for callback/session ownership checks.
    api.call('/api/v1/configs/import', {'config': {'webui.url': api.base}})
    additions = []
    for kind, identifier, tool, mid, fid, _ in PROFILES:
        previous = next((row for row in existing if (row.get('info') or {}).get('id') == identifier), {})
        encrypted = (previous.get('info') or {}).get('oauth_client_info')
        # Re-running setup must not replace a registration still used by native
        # per-user refresh sessions. A changed origin/resource needs a new one.
        reusable = (previous.get('auth_type') == 'oauth_2.1' and previous.get('url') == urls[kind]
                    and old_url == api.base and isinstance(encrypted, str) and bool(encrypted))
        if not reusable:
            encrypted = api.call('/api/v1/configs/oauth/clients/register?type=mcp',
                                 {'client_id': identifier, 'url': checked_url(urls[kind])})['oauth_client_info']
        if not isinstance(encrypted, str) or not encrypted:
            raise ValueError('Native encrypted OAuth client registration failed')
        additions.append({'url': urls[kind], 'path': '', 'type': 'mcp', 'auth_type': 'oauth_2.1',
            'headers': {}, 'key': '', 'info': {'id': identifier, 'name': 'SI-RIE — ' + kind.upper(), 'oauth_client_info': encrypted},
            'config': {'enable': True, 'access_grants': [dict(CLIENT_READ_GRANT)], 'function_name_filter_list': tool}})
    targets = {row['info']['id'] for row in additions}
    retained = [row for row in existing if (row.get('info') or {}).get('id') not in targets]
    api.call('/api/v1/configs/tool_servers', {'TOOL_SERVER_CONNECTIONS': retained + additions})
    for kind, identifier, tool, mid, fid, _ in PROFILES:
        payload = {'id': fid, 'name': fid, 'content': source[fid],
                   'meta': {'description': 'Contrat du client portable SI-RIE ; identité OAuth gérée par Open WebUI.'}}
        route = '/api/v1/functions/id/' + fid + '/update' if old_assets['functions'][fid] else '/api/v1/functions/create'
        saved = api.call(route, payload)
        if not saved.get('is_active'): api.call('/api/v1/functions/id/' + fid + '/toggle', {})
        payload = {'id': mid, 'base_model_id': model, 'name': 'SI-RIE — ' + kind.upper(),
            'params': {'system': SYSTEM, 'function_calling': 'native', 'temperature': 0, 'max_tokens': 4096},
            'meta': {'description': 'Première utilisation : autorisez la connexion aux sources avec votre compte LDAP.',
                     'toolIds': ['server:mcp:' + identifier], 'filterIds': [fid], 'capabilities': {'builtin_tools': False}},
            'access_grants': [dict(CLIENT_READ_GRANT)], 'is_active': True}
        route = '/api/v1/models/model/update' if old_assets['models'][mid] else '/api/v1/models/create'
        api.call(route, payload)
    return {'configured': True, 'user_authorization_pending': True, 'webui_url': api.base,
            'connections': sorted(targets), 'personal_mcp_token_required': False,
            'albert_generation_tested': False, 'rollback_snapshot': str(backup)}


def re_model(value):
    import re
    return isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,127}', value)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--webui-url', default='http://127.0.0.1:8080')
    parser.add_argument('--pdl-url', required=True)
    parser.add_argument('--incidents-url', required=True)
    parser.add_argument('--admin-email')
    parser.add_argument('--credentials-file', type=Path, help='Private automation-only local Open WebUI credentials')
    parser.add_argument('--base-model', default='gpt-oss-120b')
    parser.add_argument('--backup', type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    urls = {'pdl': checked_url(args.pdl_url), 'incidents': checked_url(args.incidents_url)}
    checked_url(args.webui_url)
    if args.dry_run:
        print(json.dumps({'dry_run': True, 'webui_url': args.webui_url, 'resources': urls,
                          'personal_mcp_token_required': False})); return 0
    if args.credentials_file:
        if (any(path.is_symlink() for path in (args.credentials_file, *args.credentials_file.parents))
                or not args.credentials_file.is_file() or args.credentials_file.stat().st_size > 65536
                or args.credentials_file.stat().st_mode & 0o077):
            raise ValueError('Automation credentials require a private 0600 file')
        credentials = json.loads(args.credentials_file.read_text())
        email, password = credentials['email'], credentials['password']
    else:
        email = args.admin_email or input('Compte administrateur de cet Open WebUI local : ')
        password = getpass.getpass('Mot de passe Open WebUI local : ')
    api = API(args.webui_url); api.login(email,password)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = args.backup or Path.home()/'.local/share/dinum-rie-client'/('before-setup-'+stamp+'.json')
    result = configure(api, urls, backup, model=args.base_model)
    print(json.dumps(result)); return 0


if __name__ == '__main__':
    try: raise SystemExit(main())
    except (ValueError, OSError, KeyError) as error:
        print('Configuration refusée : vérifier le client local, les accès, les URL et le modèle. Aucun secret affiché.', file=sys.stderr)
        raise SystemExit(2)
