"""Serialize the two PoC clients' refreshes; keep grants on temporary failure.

Compatibility adapter for Open WebUI 0.11.3. Other integrations use the original
method. The native encrypted OAuth session store remains the credential owner.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
import logging
import weakref

import aiohttp

PROVIDERS = frozenset({'mcp:dinum-pdl-agent', 'mcp:obs-gptoss'})
LOCKS = weakref.WeakValueDictionary()
log = logging.getLogger(__name__)


async def refreshed(manager, session):
    from open_webui.env import AIOHTTP_CLIENT_SESSION_SSL
    from open_webui.utils.oauth import _normalize_token_expiry, should_send_oauth_resource
    token = session.token
    client = await manager.get_client(session.provider)
    info = await manager.get_client_info(session.provider)
    if not client or not info or not token.get('refresh_token'):
        return None, True
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30), trust_env=True) as http:
        # Metadata URLs are configured by the local administrator, not by chat.
        async with http.get(await manager.get_server_metadata_url(session.provider), ssl=AIOHTTP_CLIENT_SESSION_SSL) as response:
            if response.status != 200:
                return None, False
            metadata = await response.json()
        endpoint = metadata.get('token_endpoint')
        if not endpoint:
            return None, False
        payload = {'grant_type': 'refresh_token', 'refresh_token': token['refresh_token'],
                   'client_id': client.client_id}
        if client.client_secret:
            payload['client_secret'] = client.client_secret
        if should_send_oauth_resource(info):
            payload['resource'] = info.resource
        if token.get('scope'):
            payload['scope'] = token['scope']
        async with http.post(endpoint, data=payload, ssl=AIOHTTP_CLIENT_SESSION_SSL) as response:
            if response.status == 200:
                value = await response.json()
                if not isinstance(value.get('access_token'), str) or not value['access_token']:
                    return None, False
                value.setdefault('refresh_token', token['refresh_token'])
                value.setdefault('scope', token.get('scope'))
                _normalize_token_expiry(value)
                return value, False
            # A timeout, LDAP outage or provider restart must not delete sign-in.
            if response.status in (400, 401):
                try:
                    reason = (await response.json()).get('error')
                except (ValueError, aiohttp.ClientError):
                    reason = None
                return None, reason in {'invalid_grant', 'invalid_client', 'unauthorized_client'}
            return None, False


def install(manager_class):
    original = manager_class.get_oauth_token
    if getattr(original, '_dinum_refresh_adapter', False):
        return

    async def get_token(self, user_id, client_id, force_refresh=False):
        if client_id not in PROVIDERS:
            return await original(self, user_id=user_id, client_id=client_id, force_refresh=force_refresh)
        from open_webui.models.oauth_sessions import OAuthSessions
        key = (id(self), client_id, user_id)
        lock = LOCKS.get(key)
        if lock is None:
            lock = asyncio.Lock(); LOCKS[key] = lock
        async with lock:
            # Reload after waiting: another call may already have rotated it.
            session = await OAuthSessions.get_session_by_provider_and_user_id(client_id, user_id)
            if not session:
                return None
            if not force_refresh and session.expires_at and datetime.now() + timedelta(minutes=5) < datetime.fromtimestamp(session.expires_at):
                return session.token
            try:
                value, rejected = await refreshed(self, session)
            except (aiohttp.ClientError, TimeoutError, OSError, ValueError):
                value, rejected = None, False
            if value:
                saved = await OAuthSessions.update_session_by_id(session.id, value)
                return saved.token if saved else None
            if rejected:
                await OAuthSessions.delete_session_by_id(session.id)
            # Fail this call without reusing an expired access credential.
            log.warning('PoC OAuth refresh %s for %s', 'rejected' if rejected else 'temporarily unavailable', client_id)
            return None

    get_token._dinum_refresh_adapter = True
    manager_class.get_oauth_token = get_token
