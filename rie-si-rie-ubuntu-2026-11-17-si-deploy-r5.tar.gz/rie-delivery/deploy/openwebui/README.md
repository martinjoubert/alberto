# Client Open WebUI du PoC

Ce dossier prépare le **client installé sur chaque poste**, sans jeton MCP à
copier. Suivre [la procédure utilisateur et déployeur](../../docs/si-rie/reference/25-user-access.md).

`configure.py` utilise l'API administrateur du client local pour préserver les
autres connexions, sauvegarder les paramètres privés hors Git et installer les
deux connexions MCP OAuth, filtres et modèles. La connexion LDAP individuelle
a lieu ensuite dans le navigateur, sur le serveur d'autorisation du PoC.

Le `Dockerfile` dérive de l'image Open WebUI figée. `prepare_oauth.py` vérifie
l'empreinte du module amont avant d'activer `oauth_refresh.py` : renouvellement
sérialisé par utilisateur/connexion et conservation de l'autorisation après
une panne temporaire. Les sessions chiffrées restent gérées par Open WebUI.
Un seul worker est pris en charge. La licence et l'identité du client amont
ne sont pas modifiées. Ce dossier n'entre pas dans les images des moteurs.

`compose.override.yaml` s'ajoute au Compose **existant du poste** pour ne
changer que l'image du service `openwebui` et les options requises. Conserver
son volume et sa clé ; le remplacement ne doit pas initialiser un autre client.
`RIE_OPENWEBUI_IMAGE` permet de désigner l'image validée dans la registry du SI.

Les tests de protocole et d'intégration sont dans
`deploy/ubuntu/tests/test_oauth_client_access.py` et
`deploy/ubuntu/tests/test_openwebui_oauth_setup.py`, exécutés par le runner
Ubuntu de la CI. La recette du navigateur et d'Albert reste distincte.
