"""Exercise authority boundaries, policy changes and transport identity offline."""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

from dinum_access.security import (AccessDenied, AccessGate, AccessMiddleware, CURRENT,
                                   PolicyStore, Principal, require_indices, sign, verify, guard_result)
from dinum_access import is_access_question, access_information
from dinum_access import authorize_path


class DirectoryStub:
    kind = 'external'
    administrator = True
    def lookup(self, email, **kwargs):
        if self.kind == 'unknown':
            raise AccessDenied('unclassified_identity')
        result = (email, self.kind)
        return (*result, self.kind == 'internal' and self.administrator) if kwargs.get('authorization') else result


class AccessFixture:
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.path = Path(self.temp.name)
        self.key = b'a'*40
        (self.path/'key').write_bytes(self.key)
        self.policy = {'version': 1, 'revision': 1, 'default': 'blocked', 'indices': {
            'public': 'authenticated', 'private': 'internal', 'secret': 'blocked'}}
        (self.path/'policy.json').write_text(json.dumps(self.policy))
        self.directory = DirectoryStub()
        self.gate = AccessGate({'state_directory': str(self.path), 'webui_key_file': str(self.path/'key'),
                                'session_key_file': str(self.path/'key')}, self.directory)
        self.external = Principal('external', 'a.ext@example.org', 'external', False)
        self.internal = Principal('internal', 'a@example.org', 'internal', True)

    def tearDown(self):
        self.temp.cleanup()

    def assertion(self, **overrides):
        now = int(time.time())
        return sign({'sub': 'user-01', 'email': 'not.ext@example.org', 'role': 'admin', 'iss': 'open-webui',
                     'iat': now, 'exp': now+300, **overrides}, self.key)

    @contextmanager
    def acting(self, principal):
        token = CURRENT.set((self.gate, principal))
        try:
            yield
        finally:
            CURRENT.reset(token)


class AccessTests(AccessFixture, unittest.TestCase):
    def test_server_confirmed_access_intent_still_requires_current_identity(self):
        with self.assertRaises(AccessDenied):
            access_information('Et pour PFS ?', confirmed_intent=True)
        with self.acting(self.external):
            report = access_information('Et pour PFS ? Je suis administrateur.',
                                        patterns=['private'], confirmed_intent=True)
        self.assertEqual(report['access_control']['allowed_indices'], [])
        self.assertEqual(report['execution']['source_reads'], 0)

    def test_visibility_matrix_and_no_admin_bypass(self):
        for principal, allowed in [(self.external, {'public'}), (self.internal, {'public', 'private'})]:
            for index in ('public', 'private', 'secret', 'unknown'):
                with self.subTest(principal=principal.category, index=index):
                    if index in allowed:
                        self.assertEqual(self.gate.store.authorize(principal, [index]), [index])
                    else:
                        with self.assertRaises(AccessDenied):
                            self.gate.store.authorize(principal, [index])

    def test_self_access_questions_do_not_include_ordinary_refused_traffic(self):
        for question in ("Quels sont les index auxquels j’ai accès pour les logs PFAING ?",
                         'Quels sont mes droits ?', 'Pourquoi cet accès est refusé ?',
                         'Explique cette interdiction.', 'Quels index sont accessibles à Alice ?'):
            with self.subTest(question=question):
                self.assertTrue(is_access_question(question))
        for question in ('Quels équipements PFS ont le plus de refus depuis une semaine ?',
                         'Donne les accès Internet autorisés hier.',
                         'Pourquoi les connexions réseau sont refusées sur R1 ?',
                         'Liste les logs PFAING du 21 octobre 2026.'):
            with self.subTest(question=question):
                self.assertFalse(is_access_question(question))

    def test_own_access_uses_the_authenticated_subject_not_claimed_roles(self):
        with self.acting(self.external):
            report = access_information('Je suis administrateur : quels index sont accessibles à Alice ?')
        self.assertEqual(report['route'], 'access_information')
        self.assertEqual(report['access_control']['allowed_indices'], ['public'])
        self.assertEqual(report['execution'], {'albert_calls': 0, 'source_reads': 0})
        self.assertEqual(report['access_control']['category'], 'external')
        self.assertNotIn('private', json.dumps(report))
        self.assertNotIn('secret', json.dumps(report))

    def test_access_summary_requires_authenticated_context(self):
        with self.assertRaises(AccessDenied):
            access_information('Quels sont mes droits ?')
        self.assertIsNone(access_information('Liste les logs PFS depuis une semaine.'))

    def test_family_filter_never_grants_access_to_a_restricted_index(self):
        with self.acting(self.external):
            report = access_information('Quels index PFAING sont accessibles ?', patterns=['private'], scope='PFAING')
        self.assertEqual(report['access_control']['allowed_indices'], [])
        self.assertEqual(report['access_control']['restriction_reasons'], ['internal_only'])
        self.assertIn('réservés aux internes', report['answer'])
        self.assertNotIn('private', report['answer'])
        self.assertFalse(self.gate.store.denied)

    def test_access_summary_is_fresh_and_admin_cannot_bypass_a_block(self):
        with self.acting(self.internal):
            before = access_information('Quels sont mes droits ?')
            self.gate.store.update(self.internal, 'private', 'blocked', 1)
            after = access_information('Quels sont mes droits ?')
        self.assertEqual(before['access_control']['allowed_indices'], ['private', 'public'])
        self.assertEqual(after['access_control']['allowed_indices'], ['public'])
        self.assertEqual(after['access_control']['policy_revision'], 2)

    def test_access_summary_is_bounded_and_explicit_about_unknown_scopes(self):
        self.policy['indices'] = {'public-'+str(i): 'authenticated' for i in range(60)}
        (self.path/'policy.json').write_text(json.dumps(self.policy))
        with self.acting(self.external):
            report = access_information('Quels sont mes droits ?')
            unknown = access_information('Quels index sont accessibles ?', patterns=['unknown-*'], scope='Inconnu')
        self.assertEqual(len(report['access_control']['allowed_indices']), 50)
        self.assertEqual(report['access_control']['allowed_total'], 60)
        self.assertTrue(report['access_control']['truncated'])
        self.assertEqual(unknown['access_control']['restriction_reasons'], ['no_rule_for_scope'])

    def test_denial_drops_plans_and_traces_with_forbidden_names(self):
        with self.acting(self.external):
            self.gate.store.denied = True
            report = guard_result({'status': 'error', 'route': 'controlled_catalog',
                'plan': {'index': 'private'}, 'execution': {'planning_attempts': [{'index': 'secret'}]},
                'answer_core': {'unreviewed': 'secret'}})
        self.assertEqual(report['status'], 'denied')
        self.assertNotIn('private', json.dumps(report))
        self.assertNotIn('secret', json.dumps(report))
        self.assertIn('index accessibles', report['answer'])
        self.assertEqual(report['evidence'], [])

    def test_email_and_role_do_not_grant_admin(self):
        p = self.gate.authenticate({'x-openwebui-user-jwt': self.assertion()})
        self.assertEqual(p.category, 'external'); self.assertFalse(p.administrator)

    def test_admin_denial_links_to_the_exact_rule_without_changing_policy(self):
        before = (self.path/'policy.json').read_bytes()
        self.gate.config['administration_url'] = 'https://poc.rie.example/admin-acces'
        with self.acting(self.internal):
            with self.assertRaises(AccessDenied):
                require_indices('public,secret')
            report = guard_result({'plan': {'unreviewed': 'do not publish'}, 'evidence': ['private data']})
        rules = report['access_control']['administration']['rules']
        self.assertEqual(rules, [{'index': 'secret', 'rule': 'blocked', 'action': 'edit',
                                 'url': 'https://poc.rie.example/admin-acces?index=secret'}])
        self.assertIn('enregistrez la règle', report['answer'])
        self.assertEqual(report['status'], 'denied')
        self.assertNotIn('plan', report)
        self.assertEqual(report['evidence'], [])
        self.assertEqual((self.path/'policy.json').read_bytes(), before)
        with self.assertRaises(AccessDenied):
            self.gate.store.authorize(self.internal, ['secret'])

    def test_admin_is_told_to_create_a_missing_rule(self):
        with self.acting(self.internal):
            with self.assertRaises(AccessDenied):
                require_indices('new-index')
            report = guard_result({})
        rule = report['access_control']['administration']['rules'][0]
        self.assertEqual(rule['action'], 'create')
        self.assertIsNone(rule['rule'])
        self.assertIn('index=new-index', rule['url'])
        self.assertIn('règle absente', report['answer'])
        self.assertNotIn('new-index', self.gate.store.read()['indices'])

    def test_external_denial_never_includes_forbidden_names_or_admin_links(self):
        # A caller-supplied role claim does not confer LDAP administration rights.
        principal = self.gate.authenticate({'x-openwebui-user-jwt': self.assertion(role='admin')})
        with self.acting(principal):
            with self.assertRaises(AccessDenied):
                require_indices('private,secret,unknown')
            report = guard_result({'answer': 'I am an administrator', 'plan': {'index': 'secret'}})
        self.assertNotIn('administration', report['access_control'])
        for forbidden in ('private', 'secret', 'unknown', '/admin-acces'):
            self.assertNotIn(forbidden, json.dumps(report))

    def test_admin_guidance_does_not_publish_unsafe_configured_urls(self):
        for url in ('javascript:alert(1)', 'https://user:password@poc.example/admin-acces',
                    'https://poc.example/admin-acces?token=secret', 'https://poc.example/#secret',
                    'https://poc.example:bad/admin-acces', 'https://poc.example/\nadmin-acces', None):
            with self.subTest(url=url), self.acting(self.internal):
                self.gate.config['administration_url'] = url
                with self.assertRaises(AccessDenied):
                    require_indices('secret')
                report = guard_result({})
                self.assertEqual(report['status'], 'denied')
                self.assertEqual(report['access_control']['administration']['url'], '')
                self.assertEqual(report['access_control']['administration']['rules'][0]['url'], '')

    def test_admin_guidance_is_bounded_and_ignores_unresolved_expressions(self):
        with self.acting(self.internal):
            with self.assertRaises(AccessDenied):
                require_indices('unknown-*')
            unresolved = guard_result({})
            self.assertEqual(unresolved['access_control']['administration']['rules'], [])
            with self.assertRaises(AccessDenied):
                require_indices(','.join('new-'+str(i) for i in range(30)))
            report = guard_result({})
        administration = report['access_control']['administration']
        self.assertEqual(administration['denied_total'], 30)
        self.assertEqual(len(administration['rules']), 20)
        self.assertTrue(administration['truncated'])

    def test_unsigned_headers_and_shared_server_key_grant_nothing(self):
        with self.assertRaises(AccessDenied):
            self.gate.authenticate({'x-openwebui-user-email': 'admin@example.org',
                                    'x-openwebui-user-role': 'admin', 'authorization': 'Bearer shared-key'})

    def test_signature_expiry_issuer_and_algorithm(self):
        now = int(time.time())
        for overrides in ({'exp': now-1}, {'iss': 'evil'}, {'iat': now+100}, {'exp': now+10000}):
            with self.subTest(overrides=overrides), self.assertRaises(AccessDenied):
                self.gate.authenticate({'x-openwebui-user-jwt': self.assertion(**overrides)})
        token = self.assertion()
        with self.assertRaises(AccessDenied):
            verify(token, b'wrong'*10, 'open-webui')

    def test_group_revocation_and_ambiguity_are_not_cached(self):
        headers = {'x-openwebui-user-jwt': self.assertion()}
        self.directory.kind = 'internal'; self.assertTrue(self.gate.authenticate(headers).administrator)
        self.directory.kind = 'external'; self.assertFalse(self.gate.authenticate(headers).administrator)
        self.directory.kind = 'unknown'
        with self.assertRaises(AccessDenied):
            self.gate.authenticate(headers)

    def test_test_client_token_has_dedicated_issuer_and_audience(self):
        token = self.gate.login('reader', 'private-password')
        self.assertEqual(self.gate.authenticate({'authorization': 'Bearer '+token}).category, 'external')
        with self.assertRaises(AccessDenied):
            self.gate.authenticate({'authorization': 'Bearer '+self.assertion()})
        with self.assertRaises(AccessDenied):
            verify(token, self.key, 'dinum-access', audience='another-mcp')

    def test_external_cannot_edit_or_invent_a_role(self):
        with self.assertRaises(AccessDenied):
            self.gate.store.update(self.external, 'private', 'authenticated', 1)
        self.assertEqual(self.gate.store.read()['revision'], 1)

    def test_policy_change_is_immediate_and_stale_save_fails(self):
        self.gate.store.update(self.internal, 'public', 'blocked', 1)
        with self.assertRaises(AccessDenied):
            self.gate.store.authorize(self.external, ['public'])
        with self.assertRaises(AccessDenied):
            self.gate.store.update(self.internal, 'secret', 'authenticated', 1)
        self.assertEqual(self.gate.store.read()['indices']['secret'], 'blocked')

    def test_rule_addition_and_removal_restore_default_denial(self):
        store = self.gate.store
        store.update(self.internal, 'new-index', 'authenticated', 1)
        self.assertEqual(store.authorize(self.external, ['new-index']), ['new-index'])
        removed = store.remove(self.internal, 'new-index', 2)
        self.assertNotIn('new-index', removed['indices'])
        self.assertEqual(removed['revision'], 3)
        for principal in (self.internal, self.external):
            with self.assertRaises(AccessDenied):
                store.authorize(principal, ['new-index'])
        audit = [json.loads(line) for line in (self.path/'audit.jsonl').read_text().splitlines()]
        deletion = next(row for row in audit if row['operation'].startswith('remove_'))
        self.assertEqual(deletion['indices'], ['new-index'])
        self.assertEqual(deletion['revision'], 3)

    def test_external_cannot_remove_an_index_rule(self):
        with self.assertRaises(AccessDenied):
            self.gate.store.remove(self.external, 'private', 1)
        self.assertEqual(self.gate.store.read(), self.policy)

    def test_stale_removal_cannot_erase_a_newer_rule(self):
        store = self.gate.store
        store.update(self.internal, 'public', 'internal', 1)
        with self.assertRaisesRegex(AccessDenied, 'policy_conflict_reload'):
            store.remove(self.internal, 'public', 1)
        self.assertEqual(store.read()['indices']['public'], 'internal')
        self.assertEqual(store.read()['revision'], 2)

    def test_unknown_or_invalid_rule_removal_preserves_policy(self):
        for name in ('unknown', 'pub*', '../policy', '', None):
            with self.subTest(index=name), self.assertRaises(AccessDenied):
                self.gate.store.remove(self.internal, name, 1)
        self.assertEqual(self.gate.store.read(), self.policy)
        with self.assertRaises(AccessDenied):
            self.gate.store.update(self.internal, 'public', None, 1)

    def test_audit_failure_preserves_rule_on_removal(self):
        with patch.object(PolicyStore, 'audit', side_effect=OSError('full disk')):
            with self.assertRaises(OSError):
                self.gate.store.remove(self.internal, 'public', 1)
        self.assertEqual(self.gate.store.read(), self.policy)
        self.assertEqual(list(self.path.glob('policy-*.tmp')), [])

    def test_missing_or_corrupt_policy_fails_closed(self):
        (self.path/'policy.json').write_text('not json')
        with self.assertRaises(AccessDenied):
            self.gate.store.authorize(self.internal, ['public'])

    def test_mixed_wildcards_are_denied_without_partial_read(self):
        with self.acting(self.external):
            with self.assertRaises(AccessDenied):
                require_indices('*', lambda _: {'indices': [{'name': 'public'}, {'name': 'private'}]})

    def test_wildcards_are_frozen_and_unknown_new_index_denied(self):
        with self.acting(self.internal):
            self.assertEqual(require_indices('pub*', lambda _: {'indices': [{'name': 'public'}]}), 'public')
            with self.assertRaises(AccessDenied):
                require_indices('pub*', lambda _: {'indices': [{'name': 'public'}, {'name': 'public-new'}]})

    def test_alias_cannot_hide_forbidden_indices(self):
        with self.acting(self.internal), self.assertRaises(AccessDenied):
            require_indices('public', lambda _: {'indices': [], 'aliases': [{'name': 'public', 'indices': ['secret']}]})

    def test_enabled_deployment_requires_context_even_outside_http(self):
        with patch.dict(os.environ, {'DINUM_ACCESS_CONFIG': '/missing'}), self.assertRaises(AccessDenied):
            require_indices('public')

    def test_invalid_config_does_not_turn_protection_off(self):
        with patch.dict(os.environ, {'DINUM_ACCESS_CONFIG': '/missing'}), self.assertRaises(AccessDenied):
            AccessGate.configured()

    def test_audit_has_no_email_question_password_or_token(self):
        self.gate.store.authorize(self.external, ['public'])
        text = (self.path/'audit.jsonl').read_text()
        self.assertNotIn(self.external.email, text)
        self.assertEqual(json.loads(text)['operation'], 'read_indices')

    def test_missing_audit_prevents_a_new_grant(self):
        with patch.object(PolicyStore, 'audit', side_effect=OSError('full disk')):
            with self.assertRaises(OSError):
                self.gate.store.update(self.internal, 'secret', 'authenticated', 1)
        self.assertEqual(self.gate.store.read()['indices']['secret'], 'blocked')

    def test_source_failure_cannot_be_published_as_partial_success(self):
        with self.acting(self.external):
            with self.assertRaises(AccessDenied):
                require_indices('secret')
            report = guard_result({'status': 'limited', 'answer': 'Partial conclusion',
                                   'evidence': [{'data': 'prior allowed result'}], 'results': [1]})
        self.assertEqual(report['status'], 'denied')
        self.assertEqual(report['code'], 'access_denied')
        self.assertEqual(report['evidence'], [])

    def test_denied_source_never_receives_a_search(self):
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parents[3]/'use-cases/pdl/agentic-pdl'))
        from adapters.opensearch.adapter import OpenSearchAdapter
        from unittest.mock import Mock
        adapter = OpenSearchAdapter.__new__(OpenSearchAdapter)
        adapter.base_url = 'http://localhost:9200'; adapter.timeout = 1; adapter.read_targets = ()
        adapter.session = Mock()
        adapter.session.get.return_value.json.return_value = {'indices': [{'name': 'private'}]}
        adapter.session.get.return_value.iter_content.return_value = (b'{"indices":[{"name":"private"}]}',)
        with self.acting(self.external), self.assertRaises(AccessDenied) as caught:
            adapter._request('POST', '/private/_search', json={'size': 1})
        self.assertEqual(caught.exception.code, 'index_forbidden')
        adapter.session.request.assert_not_called()

    def test_resolution_reads_streamed_bounded_json_and_closes(self):
        from unittest.mock import Mock
        reply = Mock()
        reply.iter_content.return_value = (b'{"indices":[{"name":"public"}]}',)
        session = Mock()
        session.get.return_value = reply
        with self.acting(self.external):
            self.assertEqual(authorize_path('/public/_search', 'https://source.invalid/pdl', session), '/public/_search')
        self.assertEqual(session.get.call_args.args[0], 'https://source.invalid/pdl/_resolve/index/public')
        self.assertTrue(session.get.call_args.kwargs['stream'])
        self.assertFalse(session.get.call_args.kwargs['allow_redirects'])
        reply.json.assert_not_called()
        reply.close.assert_called_once()

    def test_oversized_resolution_is_closed_and_never_authorizes(self):
        from unittest.mock import Mock
        reply = Mock()
        consumed = []
        def chunks():
            for _ in range(100):
                consumed.append(True)
                yield b'x'*65536
        reply.iter_content.return_value = chunks()
        session = Mock()
        session.get.return_value = reply
        with self.acting(self.external), self.assertRaises(AccessDenied) as caught:
            authorize_path('/public/_search', 'https://source.invalid', session)
        self.assertEqual(caught.exception.code, 'index_resolution_failed')
        self.assertLessEqual(len(consumed), 31)
        reply.json.assert_not_called()
        reply.close.assert_called_once()

    def test_invalid_resolution_and_http_error_close_without_free_error_details(self):
        from unittest.mock import Mock
        for invalid_http in (False, True):
            reply = Mock()
            reply.iter_content.return_value = (b'CANARY_PRIVATE_INVALID_JSON',)
            if invalid_http:
                reply.raise_for_status.side_effect = RuntimeError('CANARY_PRIVATE_HTTP_ERROR')
            session = Mock()
            session.get.return_value = reply
            with self.acting(self.external), self.assertRaises(AccessDenied) as caught:
                authorize_path('/public/_mapping', 'https://source.invalid', session)
            self.assertNotIn('CANARY', str(caught.exception))
            self.assertEqual(caught.exception.code, 'index_resolution_failed')
            reply.close.assert_called_once()


class MiddlewareTests(AccessFixture, unittest.IsolatedAsyncioTestCase):
    async def test_discovery_does_not_authorize_a_tool_call_or_batch(self):
        forwarded = []
        async def app(scope, receive, send):
            forwarded.append(json.loads((await receive())['body']))
            self.assertIsNone(CURRENT.get())
        for payload, allowed in [({'jsonrpc':'2.0','id':1,'method':'tools/list'}, True),
                                 ({'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':'investigate_pdl'}}, False),
                                 ([{'jsonrpc':'2.0','id':1,'method':'tools/list'},
                                   {'jsonrpc':'2.0','id':2,'method':'tools/call'}], False)]:
            messages = []
            async def receive():
                return {'type':'http.request','body':json.dumps(payload).encode(),'more_body':False}
            async def send(message):
                messages.append(message)
            before = len(forwarded)
            with patch.object(AccessGate, 'configured', return_value=self.gate):
                await AccessMiddleware(app)({'type':'http','path':'/mcp','method':'POST','headers':[]}, receive, send)
            self.assertEqual(len(forwarded)-before, int(allowed))
            if not allowed:
                self.assertEqual(messages[0]['status'],403)

    async def test_identity_survives_worker_dispatch_and_is_reset(self):
        from starlette.concurrency import run_in_threadpool
        seen = []
        async def app(scope, receive, send):
            seen.append(await run_in_threadpool(lambda: CURRENT.get()[1].subject))
        scope = {'type': 'http', 'path': '/mcp', 'headers': [(b'x-openwebui-user-jwt', self.assertion().encode())]}
        with patch.object(AccessGate, 'configured', return_value=self.gate):
            await AccessMiddleware(app)(scope, None, None)
        self.assertEqual(seen, ['user-01']); self.assertIsNone(CURRENT.get())


if __name__ == '__main__':
    unittest.main()
