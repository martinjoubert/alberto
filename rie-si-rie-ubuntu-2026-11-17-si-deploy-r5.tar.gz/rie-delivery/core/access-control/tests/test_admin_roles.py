"""Administration requires a dedicated current LDAP membership, never internality."""
from contextlib import ExitStack
import json
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from dinum_access.security import AccessDenied, AccessGate, Directory, sign, validate_administrator_groups
from dinum_access.user_tokens import UserTokens


class AdministratorRoleTests(unittest.TestCase):
    def setUp(self):
        stack = ExitStack(); self.addCleanup(stack.close)
        self.root = Path(stack.enter_context(tempfile.TemporaryDirectory()))
        (self.root / 'reader').write_text('fictional-directory-reader-password')
        self.key = b'fictional-session-key-used-only-for-offline-unit-tests'
        (self.root / 'key').write_bytes(self.key)
        self.attributes = {'mail': ['person@example.test'], 'memberOf': ['cn=internal,dc=test'], 'entryUUID': ['object-1']}
        owner = self
        class Connection:
            def __init__(self, *args, **kwargs):
                self.entries = [SimpleNamespace(entry_attributes_as_dict=owner.attributes, entry_dn='uid=person,dc=test')]
            def __enter__(self): return self
            def __exit__(self, *_args): pass
            def search(self, *_args, **_kwargs): pass
        class Tls:
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)
        modules = {'ldap3': SimpleNamespace(Server=lambda *a, **k: None, Connection=Connection,
                   Tls=Tls, NONE='none', SUBTREE='subtree'),
                   'ldap3.utils': SimpleNamespace(),
                   'ldap3.utils.conv': SimpleNamespace(escape_filter_chars=lambda value: value)}
        stack.enter_context(patch.dict('sys.modules', modules))
        self.ldap = {'use_tls': True, 'validate_cert': True, 'ca_file': 'unused-ca',
                     'host': 'ldap.invalid', 'port': 636, 'app_dn': 'reader',
                     'bind_password_file': str(self.root / 'reader'), 'search_base': 'dc=test',
                     'attribute_for_username': 'uid', 'attribute_for_mail': 'mail',
                     'attribute_for_groups': 'memberOf',
                     'group_dns': {'internal': 'cn=internal,dc=test', 'external': 'cn=external,dc=test'},
                     'administrator_group_dns': ['cn=access-admins,dc=test']}
        self.config = {'version': 1, 'state_directory': str(self.root), 'ldap': self.ldap,
                       'session_key_file': str(self.root / 'key'), 'webui_key_file': str(self.root / 'key'),
                       'allow_webui_assertions': False, 'user_tokens_directory': str(self.root / 'tokens')}
        (self.root / 'policy.json').write_text(json.dumps({'version': 1, 'revision': 1, 'default': 'blocked',
                                                        'indices': {'logs': 'internal', 'secret': 'blocked'}}))
        self.gate = AccessGate(self.config)

    def test_internal_reader_can_read_but_never_administer(self):
        token = self.gate.login('person', 'fictional-password')
        principal = self.gate.authenticate({'authorization': 'Bearer '+token})
        self.assertEqual(principal.category, 'internal')
        self.assertFalse(principal.administrator)
        self.gate.store.authorize(principal, ['logs'])
        with self.assertRaisesRegex(AccessDenied, 'administrator_required'):
            self.gate.store.update(principal, 'logs', 'authenticated', 1)

    def test_portal_session_refreshes_admin_membership_without_relogin(self):
        token = self.gate.login('person', 'fictional-password')
        headers = {'authorization': 'Bearer '+token}
        self.assertFalse(self.gate.authenticate(headers).administrator)
        self.attributes['memberOf'].append('CN=ACCESS-ADMINS,DC=TEST')
        principal = self.gate.authenticate(headers)
        self.assertTrue(principal.administrator)
        with self.assertRaisesRegex(AccessDenied, 'index_forbidden'):
            self.gate.store.authorize(principal, ['secret'])
        self.attributes['memberOf'].pop()
        self.assertFalse(self.gate.authenticate(headers).administrator)

    def test_individual_token_refreshes_role_and_external_can_never_administer(self):
        output = self.root / 'person.token'
        UserTokens(self.root / 'tokens').issue(self.gate.directory, 'person', output)
        headers = {'authorization': 'Bearer '+output.read_text().strip()}
        self.assertFalse(self.gate.authenticate(headers).administrator)
        self.attributes['memberOf'].append('cn=access-admins,dc=test')
        self.assertTrue(self.gate.authenticate(headers).administrator)
        self.attributes['memberOf'][0] = 'cn=external,dc=test'
        self.assertFalse(self.gate.authenticate(headers).administrator)
        self.attributes['memberOf'][0] = 'cn=internal,dc=test'
        self.attributes['memberOf'].pop()
        self.assertFalse(self.gate.authenticate(headers).administrator)

    def test_signed_client_role_does_not_grant_administration(self):
        self.config['allow_webui_assertions'] = True
        now = int(time.time())
        token = sign({'iss': 'open-webui', 'sub': 'client-user', 'email': 'person@example.test',
                      'role': 'admin', 'administrator': True, 'iat': now, 'exp': now+120}, self.key)
        headers = {'x-openwebui-user-jwt': token}
        self.assertFalse(self.gate.authenticate(headers).administrator)
        self.attributes['memberOf'].append('cn=access-admins,dc=test')
        self.assertTrue(self.gate.authenticate(headers).administrator)
        self.attributes['memberOf'].pop()
        self.assertFalse(self.gate.authenticate(headers).administrator)

    def test_old_configuration_grants_no_admin_even_with_existing_credentials(self):
        self.attributes['memberOf'].append('cn=access-admins,dc=test')
        token = self.gate.login('person', 'fictional-password')
        self.assertTrue(self.gate.authenticate({'authorization': 'Bearer '+token}).administrator)
        del self.ldap['administrator_group_dns']
        self.assertFalse(self.gate.authenticate({'authorization': 'Bearer '+token}).administrator)
        self.assertEqual(Directory(self.ldap).lookup('person'), ('person@example.test', 'internal'))

    def test_malformed_or_classification_group_as_admin_group_fails_closed(self):
        for groups in ('cn=admins', None, [True], [''], ['x'*2049], ['CN=INTERNAL,DC=TEST'], ['x']*33):
            with self.subTest(groups=groups), self.assertRaisesRegex(AccessDenied, 'invalid_administrator_groups'):
                validate_administrator_groups({**self.ldap, 'administrator_group_dns': groups})

    def test_ambiguous_classification_is_denied_even_if_administrator(self):
        self.attributes['memberOf'] += ['cn=external,dc=test', 'cn=access-admins,dc=test']
        with self.assertRaisesRegex(AccessDenied, 'unclassified_identity'):
            self.gate.directory.lookup('person', authorization=True)


if __name__ == '__main__':
    unittest.main()
