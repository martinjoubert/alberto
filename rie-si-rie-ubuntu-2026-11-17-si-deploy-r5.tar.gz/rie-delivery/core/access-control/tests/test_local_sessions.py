"""Short portal sessions bind to a stable LDAP object in user-owned deployments."""
import hashlib
from pathlib import Path
import tempfile
import time
import unittest

from dinum_access.security import AccessDenied, AccessGate, sign, verify


class Directory:
    def __init__(self):
        self.subject = 'object-original'
        self.kind = 'internal'
        self.administrator = True
        self.available = True
        self.calls = []

    def lookup(self, value, *, username=False, password=None, identity=False, authorization=False):
        self.calls.append((value, username, password is not None, identity))
        if not self.available:
            raise AccessDenied('directory_unavailable_or_denied')
        if value not in {'person', 'person@example.test'} or self.kind is None:
            raise AccessDenied('unclassified_identity')
        result = ('person@example.test', self.kind)
        result = (*result, self.subject) if identity else result
        return (*result, self.kind == 'internal' and self.administrator) if authorization else result


class LocalSessionTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.key = b'synthetic-session-signing-key-only-for-unit-tests'
        (self.root / 'key').write_bytes(self.key)
        self.directory = Directory()
        # Stable sessions are mandatory without requiring an opaque-token store.
        self.config = {'state_directory': str(self.root), 'session_key_file': str(self.root / 'key'),
                       'allow_webui_assertions': False}
        self.gate = AccessGate(self.config, self.directory)

    def login(self):
        return self.gate.login('person', 'synthetic-password')

    def authenticate(self, token):
        return self.gate.authenticate({'authorization': 'Bearer ' + token})

    def test_login_binds_stable_object_with_password_and_dedicated_claim(self):
        token = self.login()
        self.assertEqual(self.directory.calls, [('person', True, True, True)])
        claims = verify(token, self.key, 'dinum-access', audience='dinum-mcp')
        self.assertEqual(claims['ldap_subject'], self.directory.subject)
        self.assertEqual(claims['exp'] - claims['iat'], 600)
        principal = self.authenticate(token)
        self.assertEqual(principal.subject, 'ldap:' + hashlib.sha256(self.directory.subject.encode()).hexdigest())
        self.assertEqual(self.directory.calls[-1], ('person@example.test', False, False, True))

    def test_recreated_object_refuses_old_session_then_new_login_succeeds(self):
        old = self.login()
        original = self.authenticate(old)
        self.directory.subject = 'object-recreated-same-email'
        with self.assertRaisesRegex(AccessDenied, 'directory_identity_changed'):
            self.authenticate(old)
        current = self.authenticate(self.login())
        self.assertNotEqual(original.subject, current.subject)
        self.assertEqual(original.email, current.email)
        self.assertTrue(current.administrator)

    def test_legacy_or_malformed_claim_refused_before_directory_read(self):
        now = int(time.time())
        original = {'iss': 'dinum-access', 'aud': 'dinum-mcp', 'sub': 'ldap:person@example.test',
                    'email': 'person@example.test', 'iat': now, 'exp': now + 600}
        for extra in ({}, {'ldap_subject': ''}, {'ldap_subject': 1}, {'ldap_subject': 'x' * 513}):
            with self.subTest(extra=extra), self.assertRaisesRegex(AccessDenied, 'directory_stable_identity_required'):
                self.authenticate(sign({**original, **extra}, self.key))
        self.assertEqual(self.directory.calls, [])

    def test_group_changes_and_directory_outage_are_rechecked(self):
        token = self.login()
        self.assertTrue(self.authenticate(token).administrator)
        self.directory.kind = 'external'
        self.assertFalse(self.authenticate(token).administrator)
        self.directory.kind = None
        with self.assertRaises(AccessDenied):
            self.authenticate(token)
        self.directory.kind = 'internal'
        self.directory.available = False
        with self.assertRaises(AccessDenied):
            self.authenticate(token)

    def test_missing_stable_identity_cannot_mint_a_session(self):
        for subject in ('', None, 'x' * 513):
            self.directory.subject = subject
            with self.subTest(subject=subject), self.assertRaisesRegex(AccessDenied, 'directory_stable_identity_required'):
                self.login()

    def test_legacy_deployments_keep_existing_two_attribute_lookup(self):
        for explicit in (True, None):
            if explicit is None:
                self.config.pop('allow_webui_assertions', None)
            else:
                self.config['allow_webui_assertions'] = explicit
            self.directory.calls.clear()
            token = self.login()
            claims = verify(token, self.key, 'dinum-access', audience='dinum-mcp')
            self.assertNotIn('ldap_subject', claims)
            self.assertEqual(claims['sub'], 'ldap:person@example.test')
            self.assertEqual(self.authenticate(token).email, 'person@example.test')
            self.assertEqual(self.directory.calls, [('person', True, True, False),
                                                    ('person@example.test', False, False, False)])


if __name__ == '__main__':
    unittest.main()
