"""Verify individual local clients cannot assert another user's identity."""
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import time
from types import SimpleNamespace
import unittest
from contextlib import redirect_stdout
from unittest.mock import patch

from dinum_access.security import AccessDenied, AccessGate, AccessMiddleware, CURRENT, Directory, sign
from dinum_access.user_tokens import UserTokens, main


class DirectoryStub:
    def __init__(self):
        self.category = 'external'
        self.administrator = True
        self.subject = 'ldap-stable-id-001'
        self.calls = []
        self.available = True

    def lookup(self, value, **options):
        self.calls.append((value, options))
        if not self.available:
            raise AccessDenied('directory_unavailable_or_denied')
        if value != 'alice':
            raise AccessDenied('unclassified_identity')
        result = ('alice@example.org', self.category, self.subject)
        return (*result, self.category == 'internal' and self.administrator) if options.get('authorization') else result


class TokenFixture:
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.directory = DirectoryStub()
        self.store = UserTokens(self.root / 'tokens')
        self.output = self.root / 'alice.token'
        self.record = self.store.issue(self.directory, 'alice', self.output)
        self.token = self.output.read_text().strip()
        self.config = {'version': 1, 'state_directory': str(self.root),
                       'user_tokens_directory': str(self.store.directory),
                       'allow_webui_assertions': False, 'ldap': {}}
        self.gate = AccessGate(self.config, self.directory)

    def tearDown(self):
        self.temporary.cleanup()


class UserTokenTests(TokenFixture, unittest.TestCase):
    def test_directory_reads_explicit_stable_attribute_and_preserves_legacy_lookup(self):
        password = self.root / 'ldap.password'
        password.write_text('private-reader-password')
        attributes = {'mail': ['alice@example.org'], 'memberOf': ['cn=external'], 'entryUUID': ['uuid-1']}
        calls = []
        class Connection:
            entries = [SimpleNamespace(entry_attributes_as_dict=attributes)]
            def __init__(self, *args, **kwargs):
                pass
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
            def search(self, *args, **kwargs):
                calls.append(kwargs)
        class Tls:
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)
        modules = {'ldap3': SimpleNamespace(Server=lambda *a, **k: None, Connection=Connection,
                    Tls=Tls, NONE='none', SUBTREE='subtree'),
                   'ldap3.utils': SimpleNamespace(),
                   'ldap3.utils.conv': SimpleNamespace(escape_filter_chars=lambda value: value)}
        configuration = {'use_tls': True, 'validate_cert': True, 'ca_file': 'unused-ca',
                         'host': 'ldap.invalid', 'port': 636, 'app_dn': 'reader',
                         'bind_password_file': str(password), 'search_base': 'dc=example',
                         'attribute_for_username': 'uid', 'attribute_for_mail': 'mail',
                         'attribute_for_groups': 'memberOf', 'group_dns': {'external': 'cn=external'}}
        with patch.dict('sys.modules', modules):
            directory = Directory(configuration)
            self.assertEqual(directory.lookup('alice', username=True), ('alice@example.org', 'external'))
            self.assertNotIn('entryUUID', calls[-1]['attributes'])
            self.assertEqual(directory.lookup('alice', username=True, identity=True),
                             ('alice@example.org', 'external', 'uuid-1'))
            self.assertIn('entryUUID', calls[-1]['attributes'])
            del attributes['entryUUID']
            with self.assertRaisesRegex(AccessDenied, 'directory_stable_identity_required'):
                directory.lookup('alice', username=True, identity=True)
            configuration['attribute_for_subject'] = 'objectGUID'
            attributes['objectGUID'] = [b'guid-bytes']
            self.assertIsInstance(directory.lookup('alice', username=True, identity=True)[2], str)
            self.assertIn('objectGUID', calls[-1]['attributes'])

    def test_issue_binds_ldap_stable_identity_and_stores_only_a_digest(self):
        self.assertEqual(self.directory.calls, [('alice', {'username': True, 'identity': True})])
        record_path = self.store.directory / (self.record['id'] + '.json')
        raw = record_path.read_text()
        self.assertNotIn(self.token, raw)
        self.assertNotIn(self.token.split('_')[-1], raw)
        self.assertEqual(stat.S_IMODE(self.output.stat().st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(record_path.stat().st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(self.store.directory.stat().st_mode), 0o700)
        self.assertEqual(json.loads(raw)['ldap_subject'], self.directory.subject)

    def test_token_ignores_forged_assertion_and_recovery_override(self):
        self.config['recovery_subjects'] = {'forged': 'admin@example.org'}
        assertion = sign({'iss': 'open-webui', 'sub': 'forged', 'email': 'admin@example.org',
                          'iat': time.time(), 'exp': time.time() + 120}, b'x' * 40)
        principal = self.gate.authenticate({'authorization': 'Bearer ' + self.token,
                                          'x-openwebui-user-jwt': assertion})
        self.assertEqual(principal.email, 'alice@example.org')
        self.assertFalse(principal.administrator)
        with self.assertRaisesRegex(AccessDenied, 'untrusted_webui_assertion'):
            self.gate.authenticate({'x-openwebui-user-jwt': assertion})

    def test_membership_is_refreshed_and_directory_failure_denies(self):
        headers = {'authorization': 'Bearer ' + self.token}
        self.assertFalse(self.gate.authenticate(headers).administrator)
        self.directory.category = 'internal'
        self.assertTrue(self.gate.authenticate(headers).administrator)
        self.directory.category = 'external'
        self.assertFalse(self.gate.authenticate(headers).administrator)
        self.directory.available = False
        with self.assertRaises(AccessDenied):
            self.gate.authenticate(headers)

    def test_recreated_ldap_account_cannot_reuse_an_existing_token(self):
        self.directory.subject = 'a-different-directory-object'
        with self.assertRaisesRegex(AccessDenied, 'directory_identity_changed'):
            self.gate.authenticate({'authorization': 'Bearer ' + self.token})

    def test_expiration_future_record_and_revocation_are_immediate(self):
        record = self.store.authenticate(self.token)
        for clock in (record['created_at'] - 1, record['expires_at'], record['expires_at'] + 1):
            with self.subTest(clock=clock), self.assertRaises(AccessDenied):
                self.store.authenticate(self.token, now=clock)
        self.store.revoke(self.record['id'])
        with self.assertRaisesRegex(AccessDenied, 'expired_or_revoked_user_token'):
            self.gate.authenticate({'authorization': 'Bearer ' + self.token})
        self.assertTrue(self.store.revoke(self.record['id'])['revoked'])

    def test_invalid_and_unrelated_tokens_fail_without_ldap_queries(self):
        count = len(self.directory.calls)
        for token in ('', self.token[:-1] + ('x' if self.token[-1] != 'x' else 'y'),
                      'dinum_ut1_' + 'a' * 32 + '_' + 'A' * 43, 'dinum_ut1_../../secret'):
            with self.subTest(token=token), self.assertRaises(AccessDenied):
                self.store.authenticate(token)
        self.assertEqual(len(self.directory.calls), count)

    def test_output_and_ttl_failures_preserve_existing_credentials(self):
        for days in (0, 91, True, 1.5):
            with self.subTest(days=days), self.assertRaises(ValueError):
                self.store.issue(self.directory, 'alice', self.root / 'new.token', days=days)
        with self.assertRaises(ValueError):
            self.store.issue(self.directory, 'alice', self.output)
        target = self.root / 'link.token'
        target.symlink_to(self.root / 'absent.token')
        with self.assertRaises(ValueError):
            self.store.issue(self.directory, 'alice', target)
        with self.assertRaises(ValueError):
            self.store.issue(self.directory, 'alice', self.root / 'missing' / 'out.token')
        self.assertEqual(len(self.store.list()), 1)
        self.assertEqual(self.output.read_text().strip(), self.token)

    def test_unknown_account_or_missing_stable_identity_cannot_issue(self):
        for username in ('unknown', 'alice'):
            self.directory.subject = ''
            with self.subTest(username=username), self.assertRaises(AccessDenied):
                self.store.issue(self.directory, username, self.root / 'absent.token')
        self.assertFalse((self.root / 'absent.token').exists())

    def test_tampered_store_permissions_and_symlinks_fail_closed(self):
        path = self.store.directory / (self.record['id'] + '.json')
        path.chmod(0o644)
        with self.assertRaises(AccessDenied):
            self.store.authenticate(self.token)
        path.chmod(0o600)
        original = self.root / 'record.json'
        path.rename(original)
        path.symlink_to(original)
        with self.assertRaises(AccessDenied):
            self.store.authenticate(self.token)
        path.unlink()
        original.rename(path)
        self.store.directory.chmod(0o755)
        with self.assertRaises(AccessDenied):
            self.store.authenticate(self.token)

    def test_listing_and_cli_issue_never_print_token_or_digest(self):
        listing = json.dumps(self.store.list())
        self.assertNotIn(self.token, listing)
        self.assertNotIn('digest', listing)
        self.assertNotIn('ldap_subject', listing)
        config = self.root / 'config.json'
        config.write_text(json.dumps(self.config))
        capture = io.StringIO()
        with patch('dinum_access.user_tokens.AccessGate', return_value=self.gate), redirect_stdout(capture):
            self.assertEqual(main(['--config', str(config), 'issue', '--username', 'alice',
                                   '--output', str(self.root / 'second.token'), '--days', '1']), 0)
        self.assertNotIn((self.root / 'second.token').read_text().strip(), capture.getvalue())
        self.assertEqual(json.loads(capture.getvalue())['username'], 'alice')
        capture = io.StringIO()
        with redirect_stdout(capture):
            self.assertEqual(main(['--config', str(config), 'list']), 0)
        self.assertNotIn('digest', capture.getvalue())
        with redirect_stdout(io.StringIO()):
            self.assertEqual(main(['--config', str(config), 'revoke', '--id', self.record['id']]), 0)
        with self.assertRaises(AccessDenied):
            self.store.authenticate(self.token)


class MiddlewareTests(TokenFixture, unittest.IsolatedAsyncioTestCase):
    async def call(self, payload, token):
        entered, messages = [], []
        async def receive():
            return {'type': 'http.request', 'body': json.dumps(payload).encode(), 'more_body': False}
        async def send(message):
            messages.append(message)
        async def app(scope, receive, send):
            entered.append((CURRENT.get(), dict(scope['headers']).get(b'authorization')))
        headers = [] if token is None else [(b'authorization', ('Bearer ' + token).encode())]
        with patch.object(AccessGate, 'configured', return_value=self.gate):
            await AccessMiddleware(app, service_token='inner-service-secret')(
                {'type': 'http', 'method': 'POST', 'path': '/mcp', 'headers': headers}, receive, send)
        return entered, messages

    async def test_individual_identity_precedes_internal_service_token_and_resets(self):
        entered, messages = await self.call({'jsonrpc': '2.0', 'method': 'tools/call'}, self.token)
        self.assertEqual(messages, [])
        self.assertEqual(entered[0][0][1].email, 'alice@example.org')
        self.assertEqual(entered[0][1], b'Bearer inner-service-secret')
        self.assertIsNone(CURRENT.get())

    async def test_service_discovery_cannot_be_reused_for_tool_calls_or_batches(self):
        for payload, allowed in (({'jsonrpc': '2.0', 'method': 'tools/list'}, True),
                                 ({'jsonrpc': '2.0', 'method': 'tools/call'}, False),
                                 ([{'jsonrpc': '2.0', 'method': 'tools/list'},
                                   {'jsonrpc': '2.0', 'method': 'tools/call'}], False)):
            entered, messages = await self.call(payload, 'inner-service-secret')
            self.assertEqual(bool(entered), allowed)
            if not allowed:
                self.assertEqual(messages[0]['status'], 403)
        self.store.revoke(self.record['id'])
        entered, messages = await self.call({'jsonrpc': '2.0', 'method': 'tools/call'}, self.token)
        self.assertEqual(entered, [])
        self.assertEqual(messages[0]['status'], 403)
