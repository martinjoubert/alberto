"""UC2 source permissions share the existing identity, revision and audit boundary."""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from dinum_access import AccessDenied, AccessGate, PolicyStore, require_indices, require_resources, guard_result
from dinum_access.security import CURRENT, Principal


class ResourcePolicyTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.policy = {'version': 1, 'revision': 1, 'default': 'blocked',
                       'indices': {'pdl-public': 'authenticated', 'incident-logs': 'internal'}}
        self.path = self.root / 'policy.json'; self.path.write_text(json.dumps(self.policy))
        self.internal = Principal('internal', 'inside@example.invalid', 'internal', True)
        self.external = Principal('external', 'outside@example.invalid', 'external', False)

    def store(self):
        return PolicyStore(self.root)

    @contextmanager
    def acting(self, principal):
        gate = AccessGate({'state_directory': str(self.root)}, directory=object())
        token = CURRENT.set((gate, principal))
        try:
            yield gate
        finally:
            CURRENT.reset(token)

    def test_old_policy_keeps_pdl_access_and_blocks_uc2_without_rewriting(self):
        before = self.path.read_bytes()
        with self.acting(self.internal) as gate:
            self.assertEqual(require_indices('pdl-public'), 'pdl-public')
            self.assertEqual(gate.store.accessible(self.internal)['allowed_resources'], [])
            with self.assertRaisesRegex(AccessDenied, 'resource_forbidden'):
                require_resources(('incidents.metrics', 'incidents.tickets'))
        self.assertEqual(self.path.read_bytes(), before)
        self.assertNotIn('resources', self.store().read())

    def test_independent_visibility_rules_no_administrator_bypass_and_removal(self):
        store = self.store()
        store.update_resource(self.internal, 'incidents.metrics', 'authenticated', 1)
        store.update_resource(self.internal, 'incidents.tickets', 'internal', 2)
        self.assertEqual(store.authorize_resources(self.external, ['incidents.metrics']), ['incidents.metrics'])
        with self.assertRaises(AccessDenied):
            store.authorize_resources(self.external, ['incidents.tickets'])
        self.assertEqual(store.authorize_resources(self.internal, ['incidents.tickets']), ['incidents.tickets'])
        store.update_resource(self.internal, 'incidents.metrics', 'blocked', 3)
        with self.assertRaises(AccessDenied):
            store.authorize_resources(self.internal, ['incidents.metrics'])
        store.remove_resource(self.internal, 'incidents.tickets', 4)
        with self.assertRaises(AccessDenied):
            store.authorize_resources(self.internal, ['incidents.tickets'])
        self.assertEqual(store.read()['indices'], self.policy['indices'])

    def test_index_and_resource_changes_share_one_revision_and_audit(self):
        store = self.store()
        store.update_resource(self.internal, 'incidents.metrics', 'internal', 1)
        with self.assertRaisesRegex(AccessDenied, 'policy_conflict_reload'):
            store.update(self.internal, 'pdl-public', 'blocked', 1)
        store.update(self.internal, 'pdl-public', 'internal', 2)
        with self.assertRaisesRegex(AccessDenied, 'policy_conflict_reload'):
            store.remove_resource(self.internal, 'incidents.metrics', 2)
        store.remove_resource(self.internal, 'incidents.metrics', 3)
        rows = [json.loads(line) for line in (self.root / 'audit.jsonl').read_text().splitlines()]
        self.assertEqual([row['revision'] for row in rows], [2, 3, 4])
        self.assertEqual(rows[0]['resources'], ['incidents.metrics'])
        self.assertEqual(rows[1]['indices'], ['pdl-public'])
        self.assertEqual(rows[2]['operation'], 'remove_resource_internal_to_default_blocked')
        self.assertNotIn(self.internal.email, json.dumps(rows))

    def test_external_invalid_target_or_failed_audit_cannot_change_policy(self):
        original = self.path.read_bytes(); store = self.store()
        for resource in ('unknown.source', 'incidents.*', '../policy', None):
            with self.subTest(resource=resource), self.assertRaises(AccessDenied):
                store.update_resource(self.internal, resource, 'internal', 1)
        with self.assertRaises(AccessDenied):
            store.update_resource(self.external, 'incidents.metrics', 'authenticated', 1)
        with patch.object(store, 'audit', side_effect=OSError('full disk')):
            with self.assertRaises(OSError):
                store.update_resource(self.internal, 'incidents.metrics', 'internal', 1)
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(list(self.root.glob('policy-*.tmp')), [])

    def test_corrupt_or_unknown_resource_policy_fails_closed(self):
        for resources in (None, [], {'unknown.source': 'internal'}, {'incidents.metrics': 'public'}):
            self.path.write_text(json.dumps({**self.policy, 'resources': resources}))
            with self.subTest(resources=resources), self.assertRaisesRegex(AccessDenied, 'policy_unavailable'):
                self.store().authorize_resources(self.internal, ['incidents.metrics'])

    def test_current_policy_and_principal_are_used_on_each_read(self):
        store = self.store()
        store.update_resource(self.internal, 'incidents.metrics', 'authenticated', 1)
        with self.acting(self.external):
            require_resources('incidents.metrics')
            store.update_resource(self.internal, 'incidents.metrics', 'internal', 2)
            with self.assertRaises(AccessDenied):
                require_resources('incidents.metrics')
        with self.acting(self.internal):
            require_resources('incidents.metrics')
        self.assertEqual(store.accessible(self.external)['allowed_resources'], [])
        self.assertEqual(store.accessible(self.internal)['allowed_resources'], ['incidents.metrics'])

    def test_resource_refusal_drops_all_evidence_and_guides_the_administrator(self):
        with self.acting(self.internal):
            with self.assertRaises(AccessDenied):
                require_resources('incidents.metrics')
            result = guard_result({'application': 'observability', 'request_id': 'current',
                                   'metrics': ['PRIVATE_DATA'], 'sources': ['PRIVATE_DATA'], 'context': {'equipment': 'PRIVATE_HOST'}})
        self.assertEqual(result['status'], 'denied')
        self.assertEqual(result['request_id'], 'current')
        self.assertEqual(result['metrics'], [])
        self.assertNotIn('PRIVATE_', json.dumps(result))
        self.assertEqual(result['access_control']['administration']['resource_rules'][0]['resource'], 'incidents.metrics')

    def test_legacy_opt_out_and_enabled_missing_identity(self):
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(require_resources('incidents.metrics'), 'incidents.metrics')
        with patch.dict(os.environ, {'DINUM_ACCESS_CONFIG': '/configured/access.json'}):
            with self.assertRaisesRegex(AccessDenied, 'identity_required'):
                require_resources('incidents.metrics')


if __name__ == '__main__':
    unittest.main()
