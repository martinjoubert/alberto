#!/usr/bin/env python3
"""Run the server-side individual credential CLI from the source checkout."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / 'src'))
from dinum_access.user_tokens import main

if __name__ == '__main__':
    raise SystemExit(main())
