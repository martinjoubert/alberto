"""Native MCP OAuth 2.1 authorization with LDAP, PKCE and rotating refresh grants.

The SDK owns protocol validation. This adapter owns identity and persistent
state; it never trusts identities asserted by a user-owned Open WebUI server.
"""
from __future__ import annotations

import asyncio
from contextvars import ContextVar
import hmac
from html import escape
from pathlib import Path
import re
from urllib.parse import parse_qs, urlsplit

from mcp.server.auth.provider import (AccessToken, AuthorizationCode, RefreshToken,
    OAuthAuthorizationServerProvider, AuthorizeError, RegistrationError, TokenError, construct_redirect_uri)
from mcp.server.auth.routes import create_auth_routes, create_protected_resource_routes
from mcp.server.auth.settings import ClientRegistrationOptions, RevocationOptions
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken
from pydantic import AnyHttpUrl, ConfigDict, TypeAdapter
from starlette.concurrency import run_in_threadpool
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, RedirectResponse
from starlette.routing import Route
from starlette.applications import Starlette

from .security import AccessGate, AccessDenied
from .oauth_store import OAuthStore, RESOURCE, SCOPE, configuration, digest, secret

TOKEN_RESOURCE = ContextVar('dinum_oauth_token_resource', default=None)
HTTP_URL = TypeAdapter(AnyHttpUrl, config=ConfigDict(url_preserve_empty_path=True))
# Keep the Origin on same-origin form posts; no-referrer makes Chrome send
# Origin: null and defeats the origin/CSRF check. Never send a cross-origin referrer.
HEADERS = {'Cache-Control': 'no-store', 'Pragma': 'no-cache', 'Referrer-Policy': 'same-origin',
           'X-Content-Type-Options': 'nosniff',
           'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'"}


class GrantFailure(ValueError):
    def __init__(self, code, description):
        super().__init__(description)
        self.code, self.description = code, description


class DirectoryUnavailable(RuntimeError):
    pass


class Provider(OAuthAuthorizationServerProvider[AuthorizationCode, RefreshToken, AccessToken]):
    def __init__(self, config, gate_factory=AccessGate.configured, *, store=None):
        self.config, self.gate_factory = config, gate_factory
        gate = self.gate_factory()
        if gate is None or gate.config.get('allow_webui_assertions') is not False:
            raise ValueError('OAuth requires the individual LDAP identity mode')
        self.store = store or OAuthStore(Path(gate.config['state_directory']) / 'oauth')

    def identity(self, row):
        gate = self.gate_factory()
        email, category, subject, administrator = gate.directory.lookup(
            row['username'], username=True, identity=True, authorization=True)
        if not hmac.compare_digest(subject.encode(), row['ldap_subject'].encode()):
            raise AccessDenied('directory_identity_changed')
        return email, category, subject, administrator

    def audit(self, action, row):
        from .security import Principal
        gate = self.gate_factory()
        email, category, subject, administrator = self.identity(row)
        principal = Principal('ldap:' + digest(subject), email, category, administrator)
        gate.store.audit(principal, action, allowed=True, resources=[row['resource']], revision=gate.store.read()['revision'])

    async def get_client(self, client_id):
        row = await run_in_threadpool(self.store.read, 'client', client_id)
        return OAuthClientInformationFull.model_validate(row) if row else None

    async def register_client(self, client_info):
        allowed = set(self.config['redirect_uris'])
        if (not client_info.redirect_uris or len(client_info.redirect_uris) > 4
                or any(str(uri) not in allowed for uri in client_info.redirect_uris)
                or client_info.token_endpoint_auth_method not in {'client_secret_post', 'client_secret_basic', 'none'}
                or set(client_info.grant_types) - {'authorization_code', 'refresh_token'}
                or set(client_info.response_types) != {'code'}):
            raise RegistrationError('invalid_redirect_uri', 'Use an approved local Open WebUI callback.')
        now = int(self.store.clock())
        client_info.client_secret_expires_at = now + 365 * 86400 if client_info.client_secret else None
        await run_in_threadpool(self.store.save, 'client', client_info.client_id,
                                client_info.model_dump(mode='json'), now + 365 * 86400)

    async def authorize(self, client, params):
        if params.resource not in self.config['resources'].values():
            raise AuthorizeError('invalid_target', 'Select a configured MCP resource.')
        if params.scopes != [SCOPE] or not re.fullmatch(r'[A-Za-z0-9_-]{43}', params.code_challenge):
            raise AuthorizeError('invalid_scope', 'A read-only MCP authorization with PKCE is required.')
        flow = secret()
        row = {'client_id': client.client_id, 'params': params.model_dump(mode='json')}
        await run_in_threadpool(self.store.save, 'flow', digest(flow), row, int(self.store.clock()) + 300)
        return self.config['issuer'] + '/login?flow=' + flow

    async def load_authorization_code(self, client, authorization_code):
        row = await run_in_threadpool(self.store.read, 'code', digest(authorization_code))
        if not row or row['client_id'] != client.client_id:
            return None
        return AuthorizationCode(code=authorization_code, scopes=[SCOPE], expires_at=row['expires'],
            client_id=row['client_id'], code_challenge=row['params']['code_challenge'],
            redirect_uri=row['params']['redirect_uri'], redirect_uri_provided_explicitly=row['params']['redirect_uri_provided_explicitly'],
            resource=row['resource'], subject='ldap:' + digest(row['ldap_subject']))

    def exchange_code(self, client, code):
        if TOKEN_RESOURCE.get() != code.resource:
            raise GrantFailure('invalid_target', 'Resource must match the authorization.')
        with self.store.transaction() as connection:
            row = self.store.get(connection, 'code', digest(code.code))
            if not row or row['client_id'] != client.client_id:
                raise GrantFailure('invalid_grant', 'Authorization is no longer available.')
            self.identity(row)
            grant = {key: row[key] for key in ('username', 'ldap_subject', 'client_id', 'resource')}
            grant.update(id=secret(), created=int(self.store.clock()),
                         expires=int(self.store.clock()) + self.config['refresh_seconds'], revoked=False)
            # Audit failure denies issuance; no credential is returned or committed.
            self.audit('oauth_authorized', grant)
            self.store.remove(connection, 'code', digest(code.code))
            self.store.put(connection, 'grant', grant['id'], grant, grant['expires'])
            return self.store.issue(connection, grant, self.config['access_seconds'])

    async def exchange_authorization_code(self, client, authorization_code):
        try:
            return OAuthToken(**await run_in_threadpool(self.exchange_code, client, authorization_code))
        except GrantFailure as error:
            raise TokenError(error.code, error.description) from None
        except AccessDenied as error:
            if error.code == 'directory_unavailable_or_denied':
                raise DirectoryUnavailable() from None
            raise TokenError('invalid_grant', 'Directory identity is unavailable or denied.') from None

    async def load_refresh_token(self, client, refresh_token):
        row = await run_in_threadpool(self.store.read, 'refresh', digest(refresh_token))
        grant = await run_in_threadpool(self.store.read, 'grant', row['grant']) if row else None
        if not grant or grant['revoked'] or grant['client_id'] != client.client_id:
            return None
        return RefreshToken(token=refresh_token, client_id=client.client_id, scopes=[SCOPE],
                            expires_at=grant['expires'], resource=grant['resource'], subject='ldap:' + digest(grant['ldap_subject']))

    def rotate(self, client, token, scopes):
        if scopes != [SCOPE] or TOKEN_RESOURCE.get() != token.resource:
            raise GrantFailure('invalid_target', 'Resource and scope must match the authorization.')
        replayed = False
        with self.store.transaction() as connection:
            previous = self.store.get(connection, 'refresh', digest(token.token))
            grant = self.store.get(connection, 'grant', previous['grant']) if previous else None
            if not grant or grant['revoked'] or grant['client_id'] != client.client_id:
                raise GrantFailure('invalid_grant', 'Authorization is no longer available.')
            if previous['used']:
                grant['revoked'] = True
                self.store.put(connection, 'grant', grant['id'], grant, grant['expires'])
                replayed = True
            else:
                self.identity(grant)
                previous['used'] = True
                self.store.put(connection, 'refresh', digest(token.token), previous, grant['expires'])
                result = self.store.issue(connection, grant, self.config['access_seconds'])
        if replayed:
            raise GrantFailure('invalid_grant', 'A reused refresh credential invalidated this authorization.')
        return result

    async def exchange_refresh_token(self, client, refresh_token, scopes):
        try:
            return OAuthToken(**await run_in_threadpool(self.rotate, client, refresh_token, scopes))
        except GrantFailure as error:
            raise TokenError(error.code, error.description) from None
        except AccessDenied as error:
            if error.code == 'directory_unavailable_or_denied':
                raise DirectoryUnavailable() from None
            raise TokenError('invalid_grant', 'Directory identity is unavailable or denied.') from None

    async def load_access_token(self, token):
        row = await run_in_threadpool(self.store.read, 'access', digest(token))
        grant = await run_in_threadpool(self.store.read, 'grant', row['grant']) if row else None
        if not grant or grant['revoked']:
            return None
        return AccessToken(token=token, client_id=grant['client_id'], scopes=[SCOPE], resource=grant['resource'])

    async def revoke_token(self, token):
        kind = 'refresh' if isinstance(token, RefreshToken) else 'access'
        row = await run_in_threadpool(self.store.read, kind, digest(token.token))
        if row:
            await run_in_threadpool(self.store.revoke, row['grant'])

    def login(self, flow, values, cookies):
        row = self.store.read('flow', digest(flow))
        if not row or not row.get('csrf') or not values.get('csrf') or not cookies.get('rie_oauth_flow'):
            raise AccessDenied('oauth_login_expired')
        if not (hmac.compare_digest(row['csrf'], digest(values['csrf']))
                and hmac.compare_digest(row['csrf'], digest(cookies['rie_oauth_flow']))):
            raise AccessDenied('oauth_invalid_csrf')
        if values.get('confirm') != 'yes':
            raise AccessDenied('oauth_consent_required')
        gate = self.gate_factory()
        session = self.store.read('browser', digest(cookies.get('rie_oauth_session', '')))
        if session and values.get('reuse') == 'yes':
            email, _, _, _ = self.identity(session)
            identity = {**session, 'email': email}
        else:
            username, password = values.get('username', ''), values.get('password', '')
            if not isinstance(username, str) or not 1 <= len(username) <= 254 or not 1 <= len(password) <= 1024:
                raise AccessDenied('invalid_credentials')
            # Bound failed attempts per live flow and username, never log a password.
            key = digest(username.casefold())
            with self.store.transaction() as connection:
                attempts = self.store.get(connection, 'attempt', key) or {'count': 0}
                if attempts['count'] >= 5:
                    raise AccessDenied('oauth_login_limited')
                attempts['count'] += 1
                self.store.put(connection, 'attempt', key, attempts, int(self.store.clock()) + 300)
            email, _, subject = gate.directory.lookup(username, username=True, password=password, identity=True)
            identity = {'username': username, 'ldap_subject': subject, 'email': email}
        code, browser = secret(), secret()
        now = int(self.store.clock())
        with self.store.transaction() as connection:
            current = self.store.get(connection, 'flow', digest(flow))
            if not current or current.get('csrf') != row['csrf']:
                raise AccessDenied('oauth_login_expired')
            self.store.remove(connection, 'flow', digest(flow))
            self.store.remove(connection, 'attempt', digest(identity['username'].casefold()))
            self.store.put(connection, 'browser', digest(browser), identity, now + self.config['login_seconds'])
            result = {**identity, 'client_id': row['client_id'], 'params': row['params'],
                      'resource': row['params']['resource'], 'expires': now + 60}
            self.store.put(connection, 'code', digest(code), result, now + 60)
        target = construct_redirect_uri(row['params']['redirect_uri'], code=code, state=row['params']['state'], iss=self.config['issuer'])
        return target, browser

    async def login_page(self, request: Request):
        try:
            if request.method == 'POST':
                if request.headers.get('origin') != self.config['issuer']:
                    raise AccessDenied('oauth_invalid_origin')
                values = parse_form(await request.body())
                target, browser = await run_in_threadpool(self.login, values.get('flow', ''), values, request.cookies)
                response = RedirectResponse(target, status_code=303, headers=HEADERS)
                response.set_cookie('rie_oauth_session', browser, max_age=self.config['login_seconds'], httponly=True,
                                    secure=self.config['issuer'].startswith('https://'), samesite='lax')
                response.delete_cookie('rie_oauth_flow')
                return response
            flow = request.query_params.get('flow', '')
            if not re.fullmatch(r'[A-Za-z0-9_-]{43}', flow):
                raise AccessDenied('oauth_login_expired')
            row = await run_in_threadpool(self.store.read, 'flow', digest(flow))
            if not row:
                raise AccessDenied('oauth_login_expired')
            csrf = secret(); row['csrf'] = digest(csrf)
            await run_in_threadpool(self.store.save, 'flow', digest(flow), row, int(self.store.clock()) + 300)
            session = await run_in_threadpool(self.store.read, 'browser', digest(request.cookies.get('rie_oauth_session', '')))
            reuse = bool(session) and request.query_params.get('account') != 'new'
            if reuse:
                try:
                    await run_in_threadpool(self.identity, session)
                except AccessDenied:
                    reuse = False
            who = ('<p>Compte LDAP : <strong>' + escape(session['email']) + '</strong></p><input type="hidden" name="reuse" value="yes">'
                   + '<p><a href="/login?flow=' + escape(flow) + '&amp;account=new">Utiliser un autre compte</a></p>') if reuse else (
                   '<label>Identifiant LDAP<input name="username" autocomplete="username" required maxlength="254"></label>'
                   '<label>Mot de passe LDAP<input name="password" type="password" autocomplete="current-password" required maxlength="1024"></label>')
            role = next(key for key, value in self.config['resources'].items() if value == row['params']['resource'])
            target = escape(urlsplit(row['params']['redirect_uri']).netloc)
            body = ('<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width">'
                '<title>Connexion aux sources SI-RIE</title><style>body{font:18px system-ui;max-width:34em;margin:4em auto;padding:1em;color:#161616}label,input{display:block;margin:.8em 0}input{padding:.6em;width:95%}button{background:#000091;color:white;padding:1em;border:0;border-radius:.3em}</style>'
                '<h1>Connecter Open WebUI aux sources</h1><p>Accès individuel à ' + escape(role.upper()) + ' depuis ' + target + '.</p>'
                '<p>Vos droits LDAP et ACL restent vérifiés à chaque demande. Aucun jeton à copier.</p><form method="post" action="/login">'
                '<input type="hidden" name="flow" value="' + escape(flow) + '"><input type="hidden" name="csrf" value="' + csrf + '">'
                + who + '<input type="hidden" name="confirm" value="yes"><button type="submit">Autoriser la connexion</button></form></html>')
            callback = urlsplit(row['params']['redirect_uri'])
            callback_origin = callback.scheme + '://' + callback.netloc
            headers = {**HEADERS, 'Content-Security-Policy': HEADERS['Content-Security-Policy'].replace(
                "form-action 'self';", "form-action 'self' " + callback_origin + ';')}
            response = HTMLResponse(body, headers=headers)
            response.set_cookie('rie_oauth_flow', csrf, max_age=300, httponly=True,
                                secure=self.config['issuer'].startswith('https://'), samesite='lax')
            return response
        except (AccessDenied, ValueError, OSError):
            return HTMLResponse('<!doctype html><html lang="fr"><h1>Connexion non établie</h1><p>Identifiants refusés, session expirée ou annuaire indisponible. Reprenez la connexion depuis Open WebUI.</p></html>', status_code=403, headers=HEADERS)


def parse_form(body):
    if len(body) > 16384:
        raise ValueError('Bounded form required')
    values = parse_qs(body.decode(), keep_blank_values=True, strict_parsing=True, max_num_fields=16)
    if any(len(items) != 1 for items in values.values()):
        raise ValueError('Duplicate form fields')
    return {key: items[0] for key, items in values.items()}


class ProtocolBoundary:
    """Bound protocol bodies and propagate the token request's resource safely."""
    def __init__(self, app): self.app = app

    async def __call__(self, scope, receive, send):
        original = receive
        marker = None
        try:
            if scope.get('method') == 'POST':
                body = bytearray()
                while True:
                    event = await asyncio.wait_for(original(), timeout=5)
                    if event['type'] != 'http.request':
                        raise ValueError('Incomplete request')
                    body.extend(event.get('body', b''))
                    if len(body) > 16384:
                        raise ValueError('Bounded request required')
                    if not event.get('more_body'): break
                replayed = False
                async def replay():
                    nonlocal replayed
                    if replayed: return await original()
                    replayed = True
                    return {'type': 'http.request', 'body': bytes(body), 'more_body': False}
                receive = replay
                if scope['path'] == '/token':
                    values = parse_form(body)
                    marker = TOKEN_RESOURCE.set(values.get('resource'))
            await self.app(scope, receive, send)
        except DirectoryUnavailable:
            await JSONResponse({'error': 'temporarily_unavailable'}, status_code=503, headers=HEADERS)(scope, receive, send)
        except (ValueError, TimeoutError, AccessDenied, OSError):
            await JSONResponse({'error': 'invalid_request'}, status_code=400, headers=HEADERS)(scope, receive, send)
        finally:
            if marker is not None: TOKEN_RESOURCE.reset(marker)


class OAuthBoundary:
    def __init__(self, app, config, role, *, provider=None):
        self.app, self.config, self.role = app, config, role
        resource = config['resources'][role]
        routes = create_protected_resource_routes(HTTP_URL.validate_python(resource), [HTTP_URL.validate_python(config['issuer'])],
                                                   scopes_supported=[SCOPE], resource_name=role.upper())
        # Also serve the origin-level fallback used by existing native clients.
        routes.append(Route('/.well-known/oauth-protected-resource', routes[0].endpoint, methods=['GET', 'OPTIONS']))
        if role == 'pdl':
            self.provider = provider or Provider(config)
            routes += create_auth_routes(self.provider, HTTP_URL.validate_python(config['issuer']),
                client_registration_options=ClientRegistrationOptions(enabled=True, valid_scopes=[SCOPE], default_scopes=[SCOPE]),
                revocation_options=RevocationOptions(enabled=True))
            routes.append(Route('/login', self.provider.login_page, methods=['GET', 'POST']))
        for route in routes: route.app = ProtocolBoundary(route.app)
        self.paths = {route.path for route in routes}
        self.authority = Starlette(routes=routes)

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            await self.app(scope, receive, send); return
        if scope['path'] in self.paths:
            await self.authority(scope, receive, send); return
        marker = RESOURCE.set(self.config['resources'][self.role])
        try:
            await self.app(scope, receive, send)
        finally:
            RESOURCE.reset(marker)


def install(app, role):
    config = configuration()
    return OAuthBoundary(app, config, role) if config else app
