"""Operator-issued individual credentials for user-owned Open WebUI clients.

Only a random token's digest is retained on the server. LDAP remains the
authority for stable identity and current groups on every authenticated request.
The operator runs this CLI on the server, never on an end user's workstation.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import stat
import sys
import time

from .security import AccessDenied, AccessGate


TOKEN = re.compile(r'dinum_ut1_([a-f0-9]{32})_([A-Za-z0-9_-]{43})\Z')
IDENTIFIER = re.compile(r'[a-f0-9]{32}\Z')
MAX_RECORD_BYTES = 4096
MAX_TOKENS = 10000


class UserTokens:
    """Read every token from private files; revocation has no process cache."""

    def __init__(self, directory):
        self.directory = Path(directory)

    def validate_directory(self, *, create=False):
        try:
            if create:
                self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
            info = self.directory.lstat()
            if not stat.S_ISDIR(info.st_mode) or info.st_mode & 0o077:
                raise ValueError()
        except (OSError, ValueError):
            raise AccessDenied('user_token_store_unavailable') from None

    def _read(self, identifier):
        if not IDENTIFIER.fullmatch(identifier):
            raise AccessDenied('invalid_user_token')
        self.validate_directory()
        try:
            descriptor = os.open(self.directory / (identifier + '.json'), os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(descriptor, 'rb') as stream:
                info = os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077:
                    raise ValueError()
                raw = stream.read(MAX_RECORD_BYTES + 1)
            if len(raw) > MAX_RECORD_BYTES:
                raise ValueError()
            record = json.loads(raw)
            if (record['version'] != 1 or record['id'] != identifier
                    or not re.fullmatch(r'[a-f0-9]{64}', record['digest'])
                    or type(record['created_at']) is not int or type(record['expires_at']) is not int
                    or not record['created_at'] < record['expires_at'] <= record['created_at'] + 90 * 86400
                    or type(record['revoked']) is not bool
                    or not isinstance(record['username'], str) or not 1 <= len(record['username']) <= 254
                    or not isinstance(record['ldap_subject'], str) or not 1 <= len(record['ldap_subject']) <= 512
                    or ('issued_category' in record and record['issued_category'] not in {'internal', 'external'})
                    or not isinstance(record['email'], str) or not 3 <= len(record['email']) <= 254):
                raise ValueError()
            return record
        except (OSError, ValueError, KeyError, TypeError):
            raise AccessDenied('invalid_user_token') from None

    @staticmethod
    def _new_file(path, value):
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, 'w') as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())

    def issue(self, directory, username, output, *, days=30, now=None):
        """Bind a new credential to a classified LDAP account and stable ID."""
        if type(days) is not int or not 1 <= days <= 90:
            raise ValueError('La durée doit être comprise entre 1 et 90 jours.')
        if not isinstance(username, str) or not 1 <= len(username) <= 254 or any(ord(c) < 32 for c in username):
            raise ValueError('Identifiant LDAP invalide.')
        output = Path(output)
        if output.exists() or output.is_symlink():
            raise ValueError('Le fichier de sortie doit être nouveau.')
        # This check is meaningful in a checkout and in the packaged source tree.
        for ancestor in Path(__file__).resolve().parents:
            if (ancestor / '.git').exists() or (ancestor / 'core/access-control').is_dir():
                resolved = output.resolve()
                if resolved == ancestor or ancestor in resolved.parents:
                    raise ValueError('Le jeton doit être enregistré hors du dépôt.')
                break
        email, category, subject = directory.lookup(username, username=True, identity=True)
        if (category not in {'internal', 'external'} or not isinstance(subject, str) or not 1 <= len(subject) <= 512
                or not isinstance(email, str) or not 3 <= len(email) <= 254):
            raise AccessDenied('directory_stable_identity_required')
        self.validate_directory(create=True)
        if sum(1 for _ in self.directory.glob('*.json')) >= MAX_TOKENS:
            raise ValueError('La limite de jetons est atteinte ; archiver les anciens enregistrements révoqués.')
        identifier = secrets.token_hex(16)
        token = 'dinum_ut1_' + identifier + '_' + secrets.token_urlsafe(32)
        clock = int(time.time()) if now is None else int(now)
        record = {'version': 1, 'id': identifier, 'username': username, 'email': email,
                  'ldap_subject': subject, 'created_at': clock, 'expires_at': clock + days * 86400,
                  'revoked': False, 'digest': hashlib.sha256(token.encode()).hexdigest(),
                  # Historical audit metadata only; authorization always rereads LDAP.
                  'issued_category': category}
        serialized = json.dumps(record, separators=(',', ':')) + '\n'
        if len(serialized.encode()) > MAX_RECORD_BYTES:
            raise ValueError('Identité LDAP trop longue pour un jeton individuel.')
        destination = self.directory / (identifier + '.json')
        self._new_file(destination, serialized)
        try:
            self._new_file(output, token + '\n')
        except OSError:
            destination.unlink()
            raise ValueError('Impossible de créer le fichier privé de sortie ; aucun jeton émis.') from None
        return self.summary(record, now=clock)

    def authenticate(self, token, *, now=None):
        match = TOKEN.fullmatch(token) if isinstance(token, str) else None
        if match is None:
            raise AccessDenied('invalid_user_token')
        record = self._read(match[1])
        if not hmac.compare_digest(record['digest'], hashlib.sha256(token.encode()).hexdigest()):
            raise AccessDenied('invalid_user_token')
        clock = time.time() if now is None else now
        if record['revoked'] or not record['created_at'] <= clock < record['expires_at']:
            raise AccessDenied('expired_or_revoked_user_token')
        return record

    @staticmethod
    def summary(record, *, now=None):
        clock = time.time() if now is None else now
        return {**{key: record[key] for key in ('id', 'username', 'email', 'created_at', 'expires_at', 'revoked')},
                'expired': record['expires_at'] <= clock}

    def list(self):
        self.validate_directory()
        rows = []
        for position, path in enumerate(sorted(self.directory.glob('*.json'))):
            if position >= MAX_TOKENS:
                raise AccessDenied('user_token_store_limit')
            rows.append(self.summary(self._read(path.stem)))
        return rows

    def revoke(self, identifier):
        record = self._read(identifier)
        record['revoked'] = True
        temporary = self.directory / (identifier + '.' + secrets.token_hex(8) + '.tmp')
        try:
            self._new_file(temporary, json.dumps(record, separators=(',', ':')) + '\n')
            os.replace(temporary, self.directory / (identifier + '.json'))
        finally:
            temporary.unlink(missing_ok=True)
        return self.summary(record)

    def discard_revoked(self, identifier):
        """Remove one already-revoked temporary credential, never a live token."""
        record = self._read(identifier)
        if not record['revoked']:
            raise ValueError('Révoquer le jeton avant de retirer son enregistrement.')
        (self.directory / (identifier + '.json')).unlink()


def main(argv=None):
    parser = argparse.ArgumentParser(description='Gérer les accès individuels des clients Open WebUI locaux.')
    parser.add_argument('--config', required=True, type=Path)
    commands = parser.add_subparsers(dest='operation', required=True)
    issue = commands.add_parser('issue')
    issue.add_argument('--username', required=True)
    issue.add_argument('--output', required=True, type=Path)
    issue.add_argument('--days', default=30, type=int)
    commands.add_parser('list')
    revoke = commands.add_parser('revoke')
    revoke.add_argument('--id', required=True)
    args = parser.parse_args(argv)
    os.umask(0o077)
    try:
        config = json.loads(args.config.read_text())
        if config.get('version') != 1 or not config.get('user_tokens_directory'):
            raise ValueError('Configurer user_tokens_directory dans une configuration version 1.')
        store = UserTokens(config['user_tokens_directory'])
        if args.operation == 'issue':
            result = store.issue(AccessGate(config).directory, args.username, args.output, days=args.days)
        elif args.operation == 'list':
            result = store.list()
        else:
            result = store.revoke(args.id)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (AccessDenied, ValueError, OSError, KeyError, TypeError) as exc:
        # OS/JSON errors can include private paths or file fragments.
        message = str(exc) if isinstance(exc, AccessDenied) else 'Commande refusée : vérifier la configuration, les permissions et les arguments.'
        print(message, file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
