"""Private, transactional OAuth state shared by the two portable backends.

Bearer credentials are indexed by digest. LDAP passwords are never persisted.
The resource context is set by the server boundary, never by a client header.
"""
from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import stat
import time
from urllib.parse import urlsplit

from .security import AccessDenied

RESOURCE = ContextVar('dinum_oauth_resource', default=None)
SCOPE = 'mcp:read'
TOKEN = re.compile(r'dinum_o[ar]1_[A-Za-z0-9_-]{43}\Z')
# Keep used refresh digests until the absolute grant expiry to detect replay.
# Ten users, two sources and renewal every five minutes need about 40,320
# such records over seven days; short-lived protocol objects stay at 10,000.
LIMITS = {'client': 1000, 'refresh': 100000}


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def secret(prefix=''):
    return prefix + secrets.token_urlsafe(32)


def configuration(path=None):
    path = path or os.getenv('DINUM_OAUTH_CONFIG')
    if not path:
        return None
    source = Path(path)
    if not source.is_absolute() or any(p.is_symlink() for p in (source, *source.parents)):
        raise ValueError('Invalid OAuth configuration path')
    if source.stat().st_mode & 0o077 or source.stat().st_size > 16384:
        raise ValueError('OAuth configuration must be private and bounded')
    data = json.loads(source.read_text())
    keys = {'version', 'issuer', 'resources', 'redirect_uris', 'access_seconds', 'refresh_seconds', 'login_seconds'}
    if not isinstance(data, dict) or set(data) != keys or type(data['version']) is not int or data['version'] != 1:
        raise ValueError('Invalid OAuth configuration')
    def url(value):
        if not isinstance(value, str) or len(value) > 2048 or any(ord(c) <= 32 for c in value):
            raise ValueError('Invalid OAuth URL')
        parsed = urlsplit(value)
        if (not parsed.hostname or parsed.hostname.lower().endswith('.invalid')
                or parsed.username or parsed.password or parsed.query or parsed.fragment
                or parsed.scheme != 'https' and not (parsed.scheme == 'http' and parsed.hostname in {'127.0.0.1', 'localhost', '::1'})):
            raise ValueError('OAuth URLs require HTTPS, or loopback HTTP')
        return parsed
    issuer = url(data['issuer'])
    if issuer.path or data['issuer'].endswith('/'):
        raise ValueError('OAuth issuer must be a canonical origin without a trailing slash')
    if (not isinstance(data['resources'], dict) or set(data['resources']) != {'pdl', 'incidents'}
            or any(not isinstance(value, str) for value in data['resources'].values())
            or len(set(data['resources'].values())) != 2):
        raise ValueError('Declare the two distinct OAuth resources')
    for role, resource in data['resources'].items():
        parsed = url(resource)
        expected = '/mcp' if role == 'pdl' else '/gptoss/assistant/mcp'
        if parsed.path != expected:
            raise ValueError('Use the portable MCP resource paths')
    if not isinstance(data['redirect_uris'], list) or not 1 <= len(data['redirect_uris']) <= 32:
        raise ValueError('Declare approved Open WebUI callbacks')
    for redirect in data['redirect_uris']:
        parsed = url(redirect)
        if not re.fullmatch(r'/oauth/clients/mcp:[a-zA-Z0-9_-]{1,64}/callback', parsed.path):
            raise ValueError('Use an exact Open WebUI MCP callback')
    for key, low, high in [('access_seconds', 60, 3600), ('refresh_seconds', 600, 604800), ('login_seconds', 300, 28800)]:
        if type(data[key]) is not int or not low <= data[key] <= high:
            raise ValueError('Invalid OAuth lifetime')
    if data['refresh_seconds'] <= data['access_seconds']:
        raise ValueError('Refresh lifetime must exceed access lifetime')
    return data


class OAuthStore:
    def __init__(self, directory, *, clock=time.time):
        self.directory, self.clock = Path(directory), clock

    @contextmanager
    def transaction(self):
        directory = self.directory
        if not directory.is_absolute() or any(p.is_symlink() for p in (directory, *directory.parents)):
            raise AccessDenied('oauth_store_unavailable')
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        path = directory / 'state.sqlite3'
        try:
            descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        except FileExistsError:
            descriptor = None
        if descriptor is not None:
            os.close(descriptor)
        if directory.stat().st_mode & 0o077 or not stat.S_ISREG(path.lstat().st_mode) or path.stat().st_mode & 0o077:
            raise AccessDenied('oauth_store_unavailable')
        connection = sqlite3.connect(path, timeout=5, isolation_level=None)
        try:
            connection.execute('CREATE TABLE IF NOT EXISTS objects (kind TEXT, id TEXT, data TEXT, expires INTEGER, PRIMARY KEY(kind,id))')
            connection.execute('BEGIN IMMEDIATE')
            # Only protocol/session state expires here; policy audit records remain.
            connection.execute('DELETE FROM objects WHERE expires <= ?', (int(self.clock()),))
            yield connection
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    def put(self, connection, kind, identifier, data, expires):
        count = connection.execute('SELECT COUNT(*) FROM objects WHERE kind=?', (kind,)).fetchone()[0]
        exists = connection.execute('SELECT 1 FROM objects WHERE kind=? AND id=?', (kind, identifier)).fetchone()
        if not exists and count >= LIMITS.get(kind, 10000):
            raise AccessDenied('oauth_capacity_reached')
        raw = json.dumps(data, separators=(',', ':'))
        if len(raw.encode()) > 16384:
            raise AccessDenied('oauth_invalid_state')
        connection.execute('INSERT OR REPLACE INTO objects VALUES (?,?,?,?)', (kind, identifier, raw, int(expires)))

    def get(self, connection, kind, identifier):
        row = connection.execute('SELECT data,expires FROM objects WHERE kind=? AND id=?', (kind, identifier)).fetchone()
        return json.loads(row[0]) if row and row[1] > self.clock() else None

    def read(self, kind, identifier):
        with self.transaction() as connection:
            return self.get(connection, kind, identifier)

    def save(self, kind, identifier, data, expires):
        with self.transaction() as connection:
            self.put(connection, kind, identifier, data, expires)

    def remove(self, connection, kind, identifier):
        connection.execute('DELETE FROM objects WHERE kind=? AND id=?', (kind, identifier))

    def revoke(self, identifier):
        with self.transaction() as connection:
            grant = self.get(connection, 'grant', identifier)
            if grant:
                grant['revoked'] = True
                self.put(connection, 'grant', identifier, grant, grant['expires'])
            return grant is not None

    def sessions(self):
        with self.transaction() as connection:
            return [{key: row[key] for key in ('id', 'username', 'client_id', 'resource', 'created', 'expires', 'revoked')}
                    for data, in connection.execute("SELECT data FROM objects WHERE kind='grant' ORDER BY expires")
                    for row in [json.loads(data)]]

    def authenticate(self, token, resource):
        if not isinstance(token, str) or not token.startswith('dinum_oa1_') or not TOKEN.fullmatch(token) or not resource:
            raise AccessDenied('invalid_oauth_token')
        with self.transaction() as connection:
            access = self.get(connection, 'access', digest(token))
            grant = self.get(connection, 'grant', access['grant']) if access else None
            if not grant or grant['revoked'] or grant['resource'] != resource:
                raise AccessDenied('expired_revoked_or_wrong_resource')
            return grant

    def issue(self, connection, grant, access_seconds):
        now = int(self.clock())
        access, refresh = secret('dinum_oa1_'), secret('dinum_or1_')
        access_end = min(now + access_seconds, grant['expires'])
        self.put(connection, 'access', digest(access), {'grant': grant['id']}, access_end)
        self.put(connection, 'refresh', digest(refresh), {'grant': grant['id'], 'used': False}, grant['expires'])
        return {'access_token': access, 'refresh_token': refresh, 'expires_in': access_end - now,
                'token_type': 'Bearer', 'scope': SCOPE}
