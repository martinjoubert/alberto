"""Fail-closed application authorization; no model decides access rights.

Trusted OpenWebUI assertions or individual tokens identify a user. LDAP supplies current membership. The operator policy
is evaluated against concrete index names immediately before a source request.
This is an application boundary, not a replacement for OpenSearch security.
"""
from __future__ import annotations

import base64
from contextvars import ContextVar
from dataclasses import dataclass
import fcntl
from fnmatch import fnmatchcase
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import ssl
import time
import unicodedata
import uuid
from urllib.parse import urlencode, urlsplit

INDEX = re.compile(r'[a-z0-9][a-z0-9_.-]{0,254}\Z')
VISIBILITIES = {'blocked', 'internal', 'authenticated'}
RESOURCES = frozenset({'incidents.metrics', 'incidents.tickets'})
OPTIONAL_RESOURCE = re.compile(r'(?:pdl\.zabbix\.host\.[1-9][0-9]{0,19}|pdl\.grafana\.dashboard\.[A-Za-z0-9_-]{1,40})\Z')
CURRENT = ContextVar('dinum_access', default=None)


class AccessDenied(ValueError):
    """Expose a stable denial without source contents or directory details."""
    def __init__(self, code='access_denied'):
        self.code = code
        active = CURRENT.get()
        if active:
            active[0].store.denied = True
        super().__init__('Accès refusé par la politique de sécurité (' + code + ').')


@dataclass(frozen=True)
class Principal:
    subject: str
    email: str
    category: str
    administrator: bool


def _encode(value):
    return base64.urlsafe_b64encode(value).rstrip(b'=').decode('ascii')


def _decode(value):
    return base64.b64decode(value + '=' * (-len(value) % 4), altchars=b'-_', validate=True)


def _key(path):
    try:
        key = Path(path).read_bytes().strip()
    except OSError:
        raise AccessDenied('invalid_signing_configuration') from None
    if len(key) < 32:
        raise AccessDenied('invalid_signing_configuration')
    return key


def sign(claims, key):
    """Mint the local test-client session; never emit it in receipts or logs."""
    body = '.'.join(_encode(json.dumps(v, separators=(',', ':')).encode())
                    for v in ({'alg': 'HS256', 'typ': 'JWT'}, claims))
    return body + '.' + _encode(hmac.digest(key, body.encode(), 'sha256'))


def verify(token, key, issuer, *, audience=None, now=None):
    """Accept only bounded, signed, unexpired HS256 identity assertions."""
    try:
        if not isinstance(token, str) or len(token) > 8192:
            raise ValueError()
        header, body, signature = token.split('.')
        if json.loads(_decode(header)).get('alg') != 'HS256':
            raise ValueError()
        if not hmac.compare_digest(_decode(signature), hmac.digest(key, (header+'.'+body).encode(), 'sha256')):
            raise ValueError()
        claims = json.loads(_decode(body)); clock = time.time() if now is None else now
        if claims['iss'] != issuer or not isinstance(claims['sub'], str) or not claims['sub'] or len(claims['sub']) > 256:
            raise ValueError()
        if not isinstance(claims['email'], str) or not 3 <= len(claims['email']) <= 254:
            raise ValueError()
        if type(claims['exp']) not in (int, float) or type(claims['iat']) not in (int, float):
            raise ValueError()
        if not clock < claims['exp'] <= claims['iat'] + 900 or not clock-900 <= claims['iat'] <= clock+10:
            raise ValueError()
        if audience is not None and claims.get('aud') != audience:
            raise ValueError()
        return claims
    except (ValueError, KeyError, TypeError, UnicodeError, AttributeError):
        raise AccessDenied('invalid_identity') from None


def validate_administrator_groups(config):
    """Require a distinct, explicit group list; old files grant no administration."""
    groups = config.get('administrator_group_dns', [])
    categories = config.get('group_dns', {})
    category_dns = {dn.casefold() for dn in categories.values() if isinstance(dn, str)} if isinstance(categories, dict) else set()
    if (not isinstance(groups, list) or len(groups) > 32
            or any(not isinstance(dn, str) or not dn.strip() or len(dn) > 2048
                   or dn.casefold() in category_dns for dn in groups)):
        raise AccessDenied('invalid_administrator_groups')
    return tuple(dn.casefold() for dn in groups)


def _verified_directory_tls(ca_file):
    """Let OpenSSL verify DNS and IP SANs, including on Python 3.12+.

    ldap3 2.9.1 otherwise uses a legacy hostname matcher which ignores IP SANs
    when ssl.match_hostname is absent. Keep verification on the actual socket,
    before any LDAP credentials are sent.
    """
    from ldap3 import Tls

    class VerifiedDirectoryTls(Tls):
        def wrap_socket(self, connection, do_handshake=False):
            context = ssl.create_default_context(cafile=self.ca_certs_file)
            connection.socket = context.wrap_socket(
                connection.socket, server_hostname=connection.server.host,
                do_handshake_on_connect=do_handshake)

    return VerifiedDirectoryTls(validate=ssl.CERT_REQUIRED, ca_certs_file=ca_file)


class Directory:
    """Resolve one identity with a read-only bind and verified LDAPS.

    Both/unknown memberships are denied. Email naming conventions grant nothing.
    The same connection/schema profile is usable against the real SI-RIE LDAP.
    """
    def __init__(self, config):
        validate_administrator_groups(config)
        self.config = config

    def lookup(self, value, *, username=False, password=None, identity=False, authorization=False):
        from ldap3 import Server, Connection, NONE, SUBTREE
        from ldap3.utils.conv import escape_filter_chars
        c = self.config
        if c.get('use_tls') is not True or c.get('validate_cert') is not True:
            raise AccessDenied('unverified_directory')
        try:
            tls = _verified_directory_tls(c['ca_file'])
            server = Server(c['host'], port=c['port'], use_ssl=True, tls=tls,
                            connect_timeout=5, get_info=NONE)
            with Connection(server, user=c['app_dn'], password=Path(c['bind_password_file']).read_text().strip(),
                            auto_bind=True, receive_timeout=5, raise_exceptions=True) as conn:
                attribute = c['attribute_for_username'] if username else c['attribute_for_mail']
                if not re.fullmatch(r'[A-Za-z][A-Za-z0-9-]*', attribute):
                    raise AccessDenied('invalid_directory_attribute')
                subject_attribute = c.get('attribute_for_subject', 'entryUUID')
                if identity and not re.fullmatch(r'[A-Za-z][A-Za-z0-9-]*', subject_attribute):
                    raise AccessDenied('invalid_directory_attribute')
                attributes = [c['attribute_for_mail'], c['attribute_for_groups']]
                if identity:
                    attributes.append(subject_attribute)
                conn.search(c['search_base'], '('+attribute+'='+escape_filter_chars(value)+')', SUBTREE,
                            attributes=attributes, size_limit=2)
                if len(conn.entries) != 1:
                    raise AccessDenied('unclassified_identity')
                entry = conn.entries[0]; attrs = entry.entry_attributes_as_dict
                emails = attrs.get(c['attribute_for_mail'], [])
                if len(emails) != 1:
                    raise AccessDenied('ambiguous_directory_identity')
                memberships = {str(g).casefold() for g in attrs.get(c['attribute_for_groups'], [])}
                kinds = [kind for kind, dn in c['group_dns'].items() if dn.casefold() in memberships]
                if len(kinds) != 1 or kinds[0] not in {'internal', 'external'}:
                    raise AccessDenied('unclassified_identity')
                admin_dns = validate_administrator_groups(c)
                administrator = kinds[0] == 'internal' and any(dn in memberships for dn in admin_dns)
                if password is not None:
                    if not password or len(password) > 1024:
                        raise AccessDenied('invalid_credentials')
                    with Connection(server, user=entry.entry_dn, password=password,
                                    auto_bind=True, receive_timeout=5, raise_exceptions=True):
                        pass
                result = (str(emails[0]).casefold(), kinds[0])
                if identity:
                    subjects = attrs.get(subject_attribute, [])
                    if len(subjects) != 1 or not subjects[0]:
                        raise AccessDenied('directory_stable_identity_required')
                    # objectGUID may be binary; entryUUID is normally a string.
                    subject = (_encode(subjects[0]) if isinstance(subjects[0], bytes) else str(subjects[0]))
                    if len(subject) > 512:
                        raise AccessDenied('directory_stable_identity_required')
                    result = (*result, subject)
                return (*result, administrator) if authorization else result
        except AccessDenied:
            raise
        except Exception:
            # Never expose LDAP errors: they may contain DNs, filters or data.
            raise AccessDenied('directory_unavailable_or_denied') from None


def valid_resource(name):
    """Recognize exact source/object names; wildcards never grant connector access."""
    return isinstance(name, str) and (name in RESOURCES or OPTIONAL_RESOURCE.fullmatch(name) is not None)


class PolicyStore:
    """Keep index/source rules, their shared revision and decisions together."""
    def __init__(self, directory):
        self.directory = Path(directory)
        self.audit_directory = Path(os.getenv('DINUM_ACCESS_AUDIT_DIRECTORY', str(self.directory)))
        self.denied = False
        # This store belongs to one authenticated request, never to a shared cache.
        self.denied_indices = {}
        self.denied_resources = {}

    def read(self):
        try:
            value = json.loads((self.directory/'policy.json').read_text())
            if value['version'] != 1 or type(value['revision']) is not int or value['revision'] < 1:
                raise ValueError()
            if value.get('default') != 'blocked' or not isinstance(value['indices'], dict):
                raise ValueError()
            if any(not INDEX.fullmatch(k) or v not in VISIBILITIES for k, v in value['indices'].items()):
                raise ValueError()
            resources = value.get('resources', {})
            if not isinstance(resources, dict) or any(not valid_resource(k) or v not in VISIBILITIES for k, v in resources.items()):
                raise ValueError()
            return value
        except (OSError, ValueError, TypeError, KeyError):
            raise AccessDenied('policy_unavailable') from None

    def audit(self, principal, operation, *, allowed, indices=(), resources=(), revision=None):
        """Store subject hashes, exact targets and decisions; no question/token."""
        row = {'at': time.time(), 'subject_hash': hashlib.sha256(principal.subject.encode()).hexdigest()[:24],
               'category': principal.category, 'operation': operation, 'allowed': allowed,
               'indices': list(indices), 'revision': revision}
        if resources:
            row['resources'] = list(resources)
        self.audit_directory.mkdir(exist_ok=True, mode=0o700)
        fd = os.open(self.audit_directory/'audit.jsonl', os.O_APPEND|os.O_CREAT|os.O_WRONLY|os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'a') as out:
            out.write(json.dumps(row, separators=(',', ':'))+'\n')

    def authorize(self, principal, indices):
        policy = self.read(); indices = list(dict.fromkeys(indices))
        allowed = bool(indices) and all(self._allowed(principal, i, policy) for i in indices)
        self.audit(principal, 'read_indices', allowed=allowed, indices=indices, revision=policy['revision'])
        if not allowed:
            self.denied = True
            for index in indices:
                if INDEX.fullmatch(index) and not self._allowed(principal, index, policy):
                    self.denied_indices[index] = policy['indices'].get(index)
            raise AccessDenied('index_forbidden')
        return indices

    @staticmethod
    def _allowed(principal, index, policy):
        """Use the same decision for data reads and the user's own access summary."""
        return bool(INDEX.fullmatch(index) and (policy['indices'].get(index) == 'authenticated'
                    or policy['indices'].get(index) == 'internal' and principal.category == 'internal'))

    @staticmethod
    def _resource_allowed(principal, resource, policy):
        visibility = policy.get('resources', {}).get(resource, 'blocked')
        return valid_resource(resource) and (visibility == 'authenticated'
                or visibility == 'internal' and principal.category == 'internal')

    def authorize_resources(self, principal, resources):
        """Authorize named non-index sources with the same current policy/audit."""
        policy = self.read(); resources = list(dict.fromkeys(resources))
        allowed = bool(resources) and all(self._resource_allowed(principal, resource, policy) for resource in resources)
        self.audit(principal, 'read_resources', allowed=allowed, resources=resources, revision=policy['revision'])
        if not allowed:
            self.denied = True
            for resource in resources:
                if valid_resource(resource) and not self._resource_allowed(principal, resource, policy):
                    self.denied_resources[resource] = policy.get('resources', {}).get(resource)
            raise AccessDenied('resource_forbidden')
        return resources

    def accessible(self, principal, patterns=None):
        """List only policy-authorized names; never enumerate rejected index names."""
        policy = self.read()
        scoped = {index: rule for index, rule in policy['indices'].items()
                  if patterns is None or any(fnmatchcase(index, pattern) for pattern in patterns)}
        names = sorted(index for index in scoped if self._allowed(principal, index, policy))
        resources = sorted(resource for resource in policy.get('resources', {}) if self._resource_allowed(principal, resource, policy))
        reasons = []
        if principal.category == 'external' and 'internal' in scoped.values():
            reasons.append('internal_only')
        if 'blocked' in scoped.values():
            reasons.append('blocked')
        if patterns is not None and not scoped:
            reasons.append('no_rule_for_scope')
        self.audit(principal, 'list_own_access', allowed=True, indices=names, resources=resources, revision=policy['revision'])
        return {'category': principal.category, 'policy_revision': policy['revision'],
                'allowed_indices': names[:50], 'allowed_total': len(names), 'truncated': len(names) > 50,
                'allowed_resources': resources, 'restriction_reasons': reasons}

    def update(self, principal, index, visibility, revision):
        """Add or replace one exact-index rule without losing concurrent changes."""
        if not isinstance(visibility, str) or visibility not in VISIBILITIES:
            raise AccessDenied('invalid_policy_change')
        return self._change(principal, index, visibility, revision)

    def remove(self, principal, index, revision):
        """Remove a rule; the surviving OpenSearch index becomes denied by default."""
        return self._change(principal, index, None, revision)

    def update_resource(self, principal, resource, visibility, revision):
        if not isinstance(visibility, str) or visibility not in VISIBILITIES:
            raise AccessDenied('invalid_policy_change')
        return self._change(principal, resource, visibility, revision, resource=True)

    def remove_resource(self, principal, resource, revision):
        return self._change(principal, resource, None, revision, resource=True)

    def _change(self, principal, index, visibility, revision, *, resource=False):
        """Lock, check the revision, audit, and atomically persist one policy edit."""
        if not principal.administrator:
            raise AccessDenied('administrator_required')
        if not isinstance(index, str) or (not valid_resource(index) if resource else not INDEX.fullmatch(index)):
            raise AccessDenied('invalid_policy_change')
        fd = os.open(self.directory/'policy.lock', os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'a+') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            policy = self.read()
            if type(revision) is not int or revision != policy['revision']:
                raise AccessDenied('policy_conflict_reload')
            rules = policy.setdefault('resources', {}) if resource else policy['indices']
            before = rules.get(index, 'blocked')
            if visibility is None:
                if index not in rules:
                    raise AccessDenied('policy_resource_not_found' if resource else 'policy_index_not_found')
                del rules[index]
                operation = ('remove_resource_' if resource else 'remove_')+before+'_to_default_blocked'
            else:
                rules[index] = visibility
                operation = ('set_resource_' if resource else 'set_')+before+'_to_'+visibility
            policy['revision'] += 1
            tmp = self.directory/('policy-'+secrets.token_hex(8)+'.tmp')
            try:
                descriptor = os.open(tmp, os.O_CREAT|os.O_EXCL|os.O_WRONLY, 0o600)
                with os.fdopen(descriptor, 'w') as out:
                    json.dump(policy, out, indent=2); out.write('\n'); out.flush(); os.fsync(out.fileno())
                # Write the decision first. A disk/audit failure must not authorize more reads.
                self.audit(principal, operation, allowed=True, indices=[] if resource else [index],
                           resources=[index] if resource else [], revision=policy['revision'])
                os.replace(tmp, self.directory/'policy.json')
            finally:
                tmp.unlink(missing_ok=True)
            return policy


class AccessGate:
    """Authenticate the client identity and refresh group membership every request."""
    def __init__(self, config, directory=None):
        if type(config.get('allow_webui_assertions', True)) is not bool:
            raise AccessDenied('access_configuration_unavailable')
        token_directory = config.get('user_tokens_directory')
        if token_directory is not None and (not isinstance(token_directory, str) or not Path(token_directory).is_absolute()):
            raise AccessDenied('access_configuration_unavailable')
        validate_administrator_groups(config.get('ldap', {}))
        self.config = config; self.directory = directory or Directory(config['ldap'])
        self.store = PolicyStore(config['state_directory'])

    @classmethod
    def configured(cls):
        path = os.getenv('DINUM_ACCESS_CONFIG')
        if not path:
            return None  # Historical local demo only; explicit opt-in deployment.
        try:
            config = json.loads(Path(path).read_text())
            if config['version'] != 1:
                raise ValueError()
            return cls(config)
        except (OSError, ValueError, KeyError):
            raise AccessDenied('access_configuration_unavailable') from None

    def principal(self, claims):
        if claims['iss'] == 'dinum-access' and self.config.get('allow_webui_assertions', True) is False:
            # A user-owned client deployment also binds its short portal session
            # to the directory object, never only to a reusable email address.
            expected = claims.get('ldap_subject')
            if not isinstance(expected, str) or not 1 <= len(expected) <= 512:
                raise AccessDenied('directory_stable_identity_required')
            email, kind, subject, administrator = self.directory.lookup(claims['email'], identity=True, authorization=True)
            if not hmac.compare_digest(subject.encode(), expected.encode()):
                raise AccessDenied('directory_identity_changed')
            return Principal('ldap:' + hashlib.sha256(subject.encode()).hexdigest(), email, kind, administrator)
        # An explicit local recovery subject is never inferred from role/email.
        # Global index prohibitions also apply to this recovery administrator.
        recovery = self.config.get('recovery_subjects', {}).get(claims['sub'])
        if recovery and claims['iss'] == 'open-webui' and hmac.compare_digest(recovery.casefold(), claims['email'].casefold()):
            return Principal(claims['sub'], claims['email'].casefold(), 'internal', True)
        email, kind, administrator = self.directory.lookup(claims['email'], authorization=True)
        return Principal(claims['sub'], email, kind, administrator)

    def authenticate(self, headers):
        authorization = headers.get('authorization', '')
        if authorization.startswith('Bearer dinum_oa1_'):
            from .oauth_store import OAuthStore, RESOURCE
            record = OAuthStore(Path(self.config['state_directory']) / 'oauth').authenticate(authorization[7:], RESOURCE.get())
            email, kind, subject, administrator = self.directory.lookup(record['username'], username=True, identity=True, authorization=True)
            if not hmac.compare_digest(subject.encode(), record['ldap_subject'].encode()):
                raise AccessDenied('directory_identity_changed')
            return Principal('ldap:' + hashlib.sha256(subject.encode()).hexdigest(), email, kind, administrator)
        if self.config.get('user_tokens_directory') and authorization.startswith('Bearer dinum_ut1_'):
            from .user_tokens import UserTokens
            record = UserTokens(self.config['user_tokens_directory']).authenticate(authorization[7:])
            email, kind, subject, administrator = self.directory.lookup(record['username'], username=True, identity=True, authorization=True)
            if not hmac.compare_digest(subject.encode(), record['ldap_subject'].encode()):
                raise AccessDenied('directory_identity_changed')
            # Never accept client claims/recovery overrides for an individual token.
            return Principal('ldap:' + hashlib.sha256(subject.encode()).hexdigest(), email, kind, administrator)
        forwarded = headers.get('x-openwebui-user-jwt')
        if forwarded:
            if not self.config.get('allow_webui_assertions', True):
                raise AccessDenied('untrusted_webui_assertion')
            claims = verify(forwarded, _key(self.config.get('webui_key_file', '')), 'open-webui')
        else:
            if not authorization.startswith('Bearer '):
                raise AccessDenied('identity_required')
            claims = verify(authorization[7:], _key(self.config.get('session_key_file', '')), 'dinum-access', audience='dinum-mcp')
        return self.principal(claims)

    def login(self, username, password):
        """Bind the LDAP user and mint a short local admin/test session."""
        if not isinstance(username, str) or not 1 <= len(username) <= 254 or not isinstance(password, str) or not password:
            raise AccessDenied('invalid_credentials')
        if self.config.get('allow_webui_assertions', True) is False:
            email, _, subject = self.directory.lookup(username, username=True, password=password, identity=True)
            if not isinstance(subject, str) or not 1 <= len(subject) <= 512:
                raise AccessDenied('directory_stable_identity_required')
            now = int(time.time())
            return sign({'iss': 'dinum-access', 'aud': 'dinum-mcp',
                         'sub': 'ldap:' + hashlib.sha256(subject.encode()).hexdigest(),
                         'ldap_subject': subject, 'email': email, 'iat': now, 'exp': now+600},
                        _key(self.config['session_key_file']))
        email, _ = self.directory.lookup(username, username=True, password=password)
        now = int(time.time())
        return sign({'iss': 'dinum-access', 'aud': 'dinum-mcp', 'sub': 'ldap:'+email,
                     'email': email, 'iat': now, 'exp': now+600}, _key(self.config['session_key_file']))


def current_subject():
    """Bind resumable dialogue to its authenticated owner, when access is active."""
    active = CURRENT.get()
    if active:
        return active[1].subject
    if os.getenv('DINUM_ACCESS_CONFIG'):
        raise AccessDenied('identity_required')
    return ''


def is_access_question(question):
    """Recognize self-access questions, preserving ordinary refused-traffic analysis."""
    if not isinstance(question, str) or not 1 <= len(question.strip()) <= 2000:
        return False
    text = ''.join(c for c in unicodedata.normalize('NFKD', question.casefold())
                   if not unicodedata.combining(c)).replace('’', "'")
    if re.search(r"\b(?:mes droits|mes permissions|mon perimetre autorise|a quoi ai.je acces)\b", text):
        return True
    if (re.search(r'\b(?:index|indices|sources|donnees)\b', text)
            and re.search(r"\b(?:accessibles?|autorise[es]*|interdits?|permissions?|droits?|j'ai acces|ai.je acces|je peux|puis.je)\b", text)):
        return True
    return bool(re.search(r'\b(?:pourquoi|explique|raison|qui contacter|comment demander)\b', text)
                and re.search(r"\b(?:interdiction|interdit[es]*|ce refus|refus d'acces|acces (?:est )?refuse|pas acces|pas autorise|ma demande.{0,20}refus)", text))


def access_information(question, *, patterns=None, scope='', confirmed_intent=False):
    """Answer from current identity and policy before dates, models or source reads.

    Patterns narrow the display to a configured source family; they grant nothing.
    The summary describes policy permissions, not source existence or availability.
    confirmed_intent is server-only dialogue routing, never an authorization.
    """
    if not confirmed_intent and not is_access_question(question):
        return None
    active = CURRENT.get()
    if not active:
        # Never infer a principal from the question, a role claim, or an old chat.
        raise AccessDenied('identity_required')
    gate, principal = active
    summary = gate.store.accessible(principal, patterns)
    profile = 'interne' if principal.category == 'internal' else 'externe'
    lines = ['Vos droits sont vérifiés pour le compte connecté, classé **'+profile+'**.']
    if scope:
        lines.append('Périmètre demandé : **'+scope+'**.')
    if summary['allowed_indices']:
        lines += ['', '**Index autorisés par la politique actuelle :**',
                  *['- `'+name+'`' for name in summary['allowed_indices']]]
        if summary['truncated']:
            lines.append('Liste limitée à 50 index sur '+str(summary['allowed_total'])+' autorisés. Précisez une famille pour affiner.')
    else:
        lines += ['', 'Aucun index n’est autorisé pour votre compte dans ce périmètre.' if scope
                  else 'Aucun index n’est autorisé pour votre compte par la politique actuelle.']
    if summary['allowed_resources'] and patterns is None:
        lines += ['', '**Sources complémentaires autorisées :**',
                  *['- `'+name+'`' for name in summary['allowed_resources']]]
    explanations = {'internal_only': 'Certains index de ce périmètre sont réservés aux internes : votre compte externe ne peut pas les lire.',
                    'blocked': 'Certains index de ce périmètre sont interdits à tous, y compris aux administrateurs.',
                    'no_rule_for_scope': 'Aucune règle d’accès ne correspond à ce périmètre configuré ; le défaut interdit s’applique.'}
    lines += ['', *[explanations[reason] for reason in summary['restriction_reasons']]]
    lines += ['', 'Les groupes LDAP et les règles des index déterminent les accès : une règle peut réserver '
              'un index aux internes ou l’interdire à tous ; un index sans règle est également interdit. '
              'Un rôle administrateur ne contourne pas une interdiction.',
              '', 'Pour faire vérifier un refus, contactez un administrateur des accès. '
              'Votre profil ou les règles doivent être modifiés avant de rejouer la demande. '
              'Cette liste ne garantit ni la disponibilité des index ni un mapping approuvé. '
              'Aucun journal n’a été consulté et aucune période n’est nécessaire pour consulter ces droits.']
    return {'status': 'success', 'route': 'access_information', 'result_state': 'access_information',
            'validation_level': 'authenticated_access_policy', 'request_id': uuid.uuid4().hex,
            'answer': '\n'.join(lines),
            'access_control': {'decision': 'information', 'subject_scope': 'current_user', 'requested_scope': scope, **summary},
            'evidence': [], 'sources': [], 'indices': [], 'dsl': [], 'results': [], 'opensearch_resources': [],
            'execution': {'albert_calls': 0, 'source_reads': 0}}


def _administration_help(gate):
    """Build admin-only remediation from denied targets, without changing policy.

    The configured browser URL is a navigation hint. It carries no credentials
    and grants no authority: the editor requires a fresh LDAP login and save.
    """
    base = gate.config.get('administration_url', 'http://127.0.0.1:8090/admin-acces')
    try:
        parsed = urlsplit(base)
        if (parsed.scheme not in {'http', 'https'} or not parsed.hostname or
                parsed.username is not None or parsed.password is not None or
                parsed.query or parsed.fragment or any(c.isspace() or c in '<>\\' for c in base)):
            raise ValueError()
        parsed.port  # Reject malformed ports before publishing a browser link.
    except (ValueError, TypeError, AttributeError):
        base = ''
    names = sorted(gate.store.denied_indices)
    resources = sorted(gate.store.denied_resources)
    rules = [{'index': name, 'rule': gate.store.denied_indices[name],
              'action': 'create' if gate.store.denied_indices[name] is None else 'edit',
              'url': base+'?'+urlencode({'index': name}) if base else ''}
             for name in names[:20]]
    lines = ['**Vous êtes administrateur des accès.**']
    for rule in rules:
        description = 'règle absente, accès interdit par défaut' if rule['action'] == 'create' else 'règle interdisant cet accès'
        link = ' — [Administrer cet index](<'+rule['url']+'>)' if rule['url'] else ''
        lines.append('- `'+rule['index']+'` : '+description+link+'.')
    resource_rules = [{'resource': name, 'rule': gate.store.denied_resources[name],
                       'action': 'create' if gate.store.denied_resources[name] is None else 'edit',
                       'url': base+'?'+urlencode({'resource': name}) if base else ''} for name in resources]
    for rule in resource_rules:
        lines.append('- Source `'+rule['resource']+'` : accès interdit ; vérifier sa règle dans l’administration des accès.')
    if len(names) > len(rules):
        lines.append('Liste limitée à 20 index sur '+str(len(names))+' refusés.')
    if not rules and base:
        lines.append('[Ouvrir l’administration des accès](<'+base+'>).')
    lines += ['', 'Connectez-vous avec votre compte LDAP membre du groupe d’administration des accès.']
    if rules or not resource_rules:
        lines.append('Si la règle existe, sélectionnez l’index ; sinon, cliquez sur **Ajouter un index** et saisissez son nom exact. '
                     'Choisissez **Réservé aux internes** ou **Ouvert aux utilisateurs authentifiés**, selon le périmètre à autoriser, '
                     'puis enregistrez la règle.')
    if resource_rules:
        lines.append('Dans **Sources Incidents**, sélectionnez une source Incidents concernée, choisissez sa visibilité '
                     'puis enregistrez la règle. Les objets Zabbix/Grafana facultatifs se gèrent par la commande opérateur de politique. Une règle d’index ne remplace pas cette autorisation de source.')
    lines += ['', 'Rejouez ensuite votre demande. L’ouverture du lien ne modifie aucun droit ; '
              'une interdiction s’applique aussi aux administrateurs.']
    return {'url': base, 'rules': rules, 'resource_rules': resource_rules, 'denied_total': len(names)+len(resources),
            'truncated': len(names) > len(rules)}, '\n'.join(lines)


def guard_result(result):
    """Publish a deterministic refusal after any denied source in this request.

    Generic orchestrators may represent adapter exceptions as source failures.
    Never turn an authorization failure into a partial business conclusion.
    """
    active = CURRENT.get()
    if active and active[0].store.denied:
        # A refusal is a completed authorization decision, not a broken MCP call.
        # Clients can display it without accepting a failed tool as valid evidence.
        summary = active[0].store.accessible(active[1])
        answer = ('Accès refusé : une ou plusieurs sources nécessaires à cette demande sont interdites pour votre profil.'
                  if active[0].store.denied_resources else
                  'Accès refusé : un ou plusieurs index nécessaires à cette demande sont interdits pour votre profil.')
        if summary['allowed_indices']:
            answer += '\n\nVous pouvez demander « Quels sont mes index accessibles ? » ou préciser une famille, par exemple PFAING. '
            answer += 'Ces informations concernent uniquement votre compte et ne nécessitent pas de période.'
        administration = None
        if active[1].administrator:
            administration, instructions = _administration_help(active[0])
            answer += '\n\n'+instructions
        else:
            answer += '\n\nLes règles d’accès et vos groupes LDAP déterminent ce refus. Contactez un administrateur des accès pour le faire vérifier.'
        # Drop plans and traces too: they can contain names of forbidden targets.
        result = {**{k: result[k] for k in ('application', 'request_id', 'route', 'mode', 'assistant_contract') if k in result},
                  'status': 'denied', 'code': 'access_denied',
                  'result_state': 'access_denied', 'validation_level': 'denied',
                  'answer': answer,
                  'access_control': {'decision': 'denied', 'subject_scope': 'current_user', **summary}}
        if administration is not None:
            result['access_control']['administration'] = administration
        result.pop('error', None)
        for field in ('evidence', 'results', 'sources', 'metrics', 'events', 'logs', 'documents', 'indices', 'dsl', 'opensearch_resources'):
            result[field] = []
        result.pop('answer_core', None)
        result.pop('review', None)
    return result


def require_resources(resources):
    """Authorize exact configured sources/objects; legacy opt-out stays explicit."""
    active = CURRENT.get()
    if not active:
        if os.getenv('DINUM_ACCESS_CONFIG'):
            raise AccessDenied('identity_required')
        return resources
    names = resources.split(',') if isinstance(resources, str) else resources
    if not isinstance(names, (list, tuple)) or not 1 <= len(names) <= 128 or any(not valid_resource(name) for name in names):
        raise AccessDenied('invalid_resource_expression')
    gate, principal = active
    return gate.store.authorize_resources(principal, names)


def require_indices(expression, resolver=None):
    """Resolve patterns once, authorize every concrete index and freeze targets.

    No filtering away denied targets: a mixed permitted/forbidden request fails
    as a whole. Newly created/unmanaged indices are denied by default.
    """
    active = CURRENT.get()
    if not active:
        if os.getenv('DINUM_ACCESS_CONFIG'):
            raise AccessDenied('identity_required')
        return expression
    gate, principal = active
    parts = expression.split(',')
    if not parts or len(parts) > 128 or any(not re.fullmatch(r'[a-z0-9][a-z0-9_.?*-]{0,254}', p) for p in parts):
        raise AccessDenied('invalid_index_expression')
    if resolver is not None or any('*' in p or '?' in p for p in parts):
        if resolver is None:
            raise AccessDenied('index_resolution_required')
        try:
            found = resolver(expression)
            # Aliases/data streams require an explicit future implementation;
            # never authorize an alias name hiding other concrete indices.
            if found.get('aliases') or found.get('data_streams'):
                raise AccessDenied('alias_or_stream_not_supported')
            names = [v['name'] for v in found['indices']]
            if not 1 <= len(names) <= 128 or any(not any(fnmatchcase(n, p) for p in parts) for n in names):
                raise ValueError()
        except AccessDenied:
            raise
        except Exception:
            raise AccessDenied('index_resolution_failed') from None
    else:
        names = parts
    return ','.join(gate.store.authorize(principal, sorted(set(names))))


def authorize_path(path, base_url, session, timeout=10):
    """Protect schema discovery and alternate readers at the HTTP boundary too."""
    if not CURRENT.get() and not os.getenv('DINUM_ACCESS_CONFIG'):
        return path
    def resolve(expression):
        response = session.get(base_url.rstrip('/')+'/_resolve/index/'+expression,
                               timeout=timeout, allow_redirects=False, stream=True)
        try:
            response.raise_for_status()
            payload = bytearray()
            for chunk in response.iter_content(chunk_size=65536):
                if not isinstance(chunk, bytes) or len(payload) + len(chunk) > 2_000_000:
                    raise ValueError('Index resolution response exceeds its bound')
                payload.extend(chunk)
            return json.loads(payload)
        finally:
            response.close()
    for prefix in ('/_resolve/index/', '/_cat/indices/'):
        if path.startswith(prefix):
            return prefix+require_indices(path[len(prefix):], resolve)
    match = re.fullmatch(r'/([^/]+)/_(search|mapping|field_caps|alias)', path)
    if not match:
        raise AccessDenied('unscoped_source_endpoint')
    return '/'+require_indices(match[1], resolve)+'/_'+match[2]


class AccessMiddleware:
    """Set request-scoped identity before MCP dispatch, including worker threads."""
    def __init__(self, app, *, service_token='', public_paths=('/healthz',), diagnostic_logger=None):
        self.app, self.service_token, self.public_paths = app, service_token, public_paths
        self.diagnostic_logger = diagnostic_logger

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http' or scope['path'] in self.public_paths:
            await self.app(scope, receive, send); return
        from starlette.responses import JSONResponse
        try:
            gate = AccessGate.configured()
            if gate is None:
                await self.app(scope, receive, send); return
            # LDAP and filesystem operations run outside the ASGI event loop.
            from starlette.concurrency import run_in_threadpool
            headers = {k.decode().lower(): v.decode() for k, v in scope['headers']}
            if scope.get('method') == 'POST' and scope['path'].endswith('/mcp') and not headers.get('x-openwebui-user-jwt'):
                # Native connection verification has no acting user. Permit only
                # protocol/schema discovery, never a tool call or a JSON-RPC batch.
                body = bytearray()
                while True:
                    message = await receive()
                    if message['type'] != 'http.request':
                        raise AccessDenied('invalid_request')
                    body.extend(message.get('body', b''))
                    if len(body) > 16384:
                        raise AccessDenied('request_too_large')
                    if not message.get('more_body'):
                        break
                original_receive = receive
                replayed = False
                async def replay():
                    nonlocal replayed
                    if not replayed:
                        replayed = True
                        return {'type': 'http.request', 'body': bytes(body), 'more_body': False}
                    return await original_receive()
                receive = replay
                try:
                    rpc = json.loads(body)
                except (ValueError, UnicodeError):
                    rpc = None
                if isinstance(rpc, dict) and rpc.get('jsonrpc') == '2.0' and rpc.get('method') in {
                        'initialize', 'tools/list', 'notifications/initialized'}:
                    if self.service_token and not hmac.compare_digest(
                            headers.get('authorization', ''), 'Bearer '+self.service_token):
                        # A short user session can also initialize a client.
                        await run_in_threadpool(gate.authenticate, headers)
                        scope = {**scope, 'headers': [(k, v) for k, v in scope['headers'] if k.lower() != b'authorization']+
                                 [(b'authorization', ('Bearer '+self.service_token).encode())]}
                    await self.app(scope, receive, send)
                    return
            principal = await run_in_threadpool(gate.authenticate, headers)
            marker = CURRENT.set((gate, principal))
            try:
                if self.service_token:
                    scope = {**scope, 'headers': [(k, v) for k, v in scope['headers'] if k.lower() != b'authorization']+
                             [(b'authorization', ('Bearer '+self.service_token).encode())]}
                await self.app(scope, receive, send)
            finally:
                CURRENT.reset(marker)
        except AccessDenied as exc:
            if self.diagnostic_logger is not None:
                try:
                    authorization = exc.code in {'index_forbidden', 'administrator_required',
                        'resource_forbidden', 'unscoped_source_endpoint', 'connector_authorization_unavailable'}
                    self.diagnostic_logger.emit(
                        'rie.authorization.denied' if authorization else 'rie.authentication.failed',
                        code='access_denied' if authorization else 'invalid_credentials', error_type='AccessDenied')
                except Exception:
                    pass
            from .oauth_store import RESOURCE
            resource = RESOURCE.get()
            denied = exc.code in {'index_forbidden', 'administrator_required', 'resource_forbidden',
                                  'unscoped_source_endpoint', 'connector_authorization_unavailable'}
            response_headers = {}
            if resource and not denied:
                parsed = urlsplit(resource)
                metadata = parsed.scheme + '://' + parsed.netloc + '/.well-known/oauth-protected-resource' + parsed.path
                response_headers['WWW-Authenticate'] = 'Bearer resource_metadata="' + metadata + '", scope="mcp:read"'
            await JSONResponse({'error': exc.code, 'message': str(exc)}, status_code=401 if resource and not denied else 403,
                               headers=response_headers)(scope, receive, send)


def protect(app, **kwargs):
    """Install a transport boundary, retaining explicit disabled-demo compatibility."""
    return AccessMiddleware(app, **kwargs)
