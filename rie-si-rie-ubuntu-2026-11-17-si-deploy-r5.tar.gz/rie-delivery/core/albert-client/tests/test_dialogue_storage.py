"""Deterministic real-file cleanup races and bounded conversation storage."""
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from threading import Barrier, Event, current_thread
import time
import unittest
from unittest.mock import patch

from dinum_albert.dialogue import Dialogue, DialogueError, StateStore, dialogue_max_states
import dinum_albert.dialogue as dialogue_module


STATE = {'request': 'Synthetic bounded request', 'replies': [], 'status': 'success',
         'clarification': '', 'pending_message': ''}


class DialogueStorageTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.now = time.time()

    def store(self, **options):
        return StateStore(self.root / 'states', 'qualification', lambda: 'owner', clock=lambda: self.now, **options)

    def test_expired_file_removed_between_listing_and_stat_does_not_break_issuance(self):
        first = self.store()
        self.now -= 4000
        expired = first.issue(STATE)
        expired_path = first.directory / (expired.split('.')[0] + '.json')
        os.utime(expired_path, (self.now, self.now))
        self.now += 4000
        entered, deleted = Event(), Event()
        original_stat, original_unlink = Path.stat, Path.unlink

        def stat(path, *args, **kwargs):
            if path == expired_path and current_thread().name == 'listing-reader':
                entered.set()
                if not deleted.wait(3):
                    raise AssertionError('Concurrent cleaner did not remove the expired file')
            return original_stat(path, *args, **kwargs)

        def unlink(path, *args, **kwargs):
            value = original_unlink(path, *args, **kwargs)
            if path == expired_path:
                deleted.set()
            return value

        def issue_first():
            current_thread().name = 'listing-reader'
            return first.issue(STATE)

        def clean_outside_writer_lock():
            if not entered.wait(3):
                raise AssertionError('First cleaner did not reach the listed expired file')
            # Another process running the old cleanup code, or a cancellation,
            # can remove a listed file without the new issue lock.
            expired_path.unlink()

        with patch.object(Path, 'stat', stat), patch.object(Path, 'unlink', unlink), ThreadPoolExecutor(max_workers=2) as pool:
            slow = pool.submit(issue_first)
            fast = pool.submit(clean_outside_writer_lock)
            fast.result(timeout=5)
            handles = [slow.result(timeout=5)]
        self.assertFalse(expired_path.exists())
        for handle in handles:
            self.assertEqual(first.read(handle), STATE)
        with self.assertRaisesRegex(DialogueError, 'dialogue_invalid_continuation'):
            first.read(expired)

    def test_full_store_returns_structured_error_without_second_storage_failure(self):
        store = self.store()
        for index in range(2048):
            (store.directory / (format(index, '032x') + '.json')).write_text('{}')
        engine = Dialogue(lambda question: {'status': 'success', 'answer': 'Must not publish stale result',
                                           'evidence': [{'private': 'CURRENT_SOURCE_EVIDENCE'}]},
                          lambda *args: ({'action': 'new', 'confidence': 1, 'clarification': ''}, {'albert_calls': 1}),
                          store)
        with patch.object(store, 'issue', wraps=store.issue) as issue:
            result = engine.run('Synthetic bounded question')
        self.assertEqual(issue.call_count, 1)
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['dialogue']['error_code'], 'dialogue_capacity')
        self.assertIsNone(result['continuation_token'])
        self.assertEqual(result['evidence'], [])
        self.assertNotIn('CURRENT_SOURCE_EVIDENCE', json.dumps(result))
        self.assertEqual(len(list(store.directory.glob('*.json'))), 2048)

    def test_capacity_is_explicit_bounded_and_rejects_invalid_configuration(self):
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(dialogue_max_states(), 2048)
        with patch.dict(os.environ, {'DINUM_DIALOGUE_MAX_STATES': '8192'}):
            self.assertEqual(self.store().max_states, 8192)
            self.assertEqual(self.store(max_states=3).max_states, 3)
        for invalid in (True, 0, 32769, 1.5, '', ' 8192', '8192.0', '-1', 'unlimited'):
            with self.subTest(invalid=invalid), self.assertRaisesRegex(DialogueError, 'dialogue_invalid_capacity'):
                dialogue_max_states(invalid)

    def test_independent_store_instances_enforce_one_shared_capacity_under_contention(self):
        stores = [self.store(max_states=4) for _ in range(12)]
        start = Barrier(len(stores))

        def issue(store):
            start.wait(timeout=5)
            try:
                return store.issue(STATE)
            except DialogueError as error:
                self.assertEqual(str(error), 'dialogue_capacity')
                return None

        with ThreadPoolExecutor(max_workers=len(stores)) as pool:
            handles = list(pool.map(issue, stores))
        accepted = [handle for handle in handles if handle is not None]
        self.assertEqual(len(accepted), 4)
        self.assertEqual(len(list(stores[0].directory.glob('*.json'))), 4)
        for handle in accepted:
            self.assertEqual(stores[0].read(handle), STATE)

    def test_expired_cleanup_preserves_live_owner_signature_and_deadline(self):
        store = self.store(max_states=2)
        self.now -= 4000
        expired = store.issue(STATE)
        old_path = store.directory / (expired.split('.')[0] + '.json')
        os.utime(old_path, (self.now, self.now))
        self.now += 4000
        live = store.issue(STATE)
        another = store.issue(STATE)
        self.assertEqual(store.read(live), STATE)
        self.assertEqual(store.read(another), STATE)
        self.assertFalse(old_path.exists())
        original_owner = store.owner
        store.owner = lambda: 'another-owner'
        with self.assertRaisesRegex(DialogueError, 'dialogue_invalid_continuation'):
            store.read(live)
        store.owner = original_owner
        tampered = live[:-1] + ('0' if live[-1] != '0' else '1')
        with self.assertRaisesRegex(DialogueError, 'dialogue_invalid_continuation'):
            store.read(tampered)
        self.now += 3600
        with self.assertRaisesRegex(DialogueError, 'dialogue_invalid_continuation'):
            store.read(live)

    def test_persistent_storage_error_still_produces_no_evidence_or_handle(self):
        store = self.store()
        engine = Dialogue(lambda question: {'status': 'success', 'evidence': [{'raw': 'PRIVATE_EVIDENCE'}]},
                          lambda *args: ({'action': 'new', 'confidence': 1, 'clarification': ''}, {'albert_calls': 1}),
                          store)
        with patch.object(store, 'issue', side_effect=PermissionError('PRIVATE_STORAGE_PATH')):
            result = engine.run('Synthetic question')
        self.assertEqual(result['status'], 'error')
        self.assertIsNone(result['continuation_token'])
        self.assertEqual(result['evidence'], [])
        self.assertNotIn('PRIVATE_', json.dumps(result))

    def test_old_mtime_does_not_evict_unexpired_state_or_bypass_saturation(self):
        store = self.store(max_states=1)
        live = store.issue(STATE)
        path = store.directory / (live.split('.')[0] + '.json')
        os.utime(path, (self.now - 4000, self.now - 4000))
        with self.assertRaisesRegex(DialogueError, 'dialogue_capacity'):
            store.issue(STATE)
        self.assertEqual(store.read(live), STATE)
        self.assertEqual(len(list(store.directory.glob('*.json'))), 1)

    def test_separate_processes_respect_the_same_directory_capacity(self):
        store = self.store(max_states=4)  # Create the server key before forking writers.
        code = '''
import json,os,sys,time
from pathlib import Path
from dinum_albert.dialogue import StateStore,DialogueError
root=Path(sys.argv[1]);store=StateStore(root/'states','qualification',lambda:'owner',max_states=4)
(root/('ready-'+str(os.getpid()))).touch()
deadline=time.monotonic()+5
while not (root/'start').exists():
    if time.monotonic()>deadline:raise RuntimeError('test barrier expired')
    time.sleep(.005)
state=json.loads(sys.argv[2]);accepted=0
for _ in range(3):
    try:store.issue(state);accepted+=1
    except DialogueError as error:
        if str(error)!='dialogue_capacity':raise
print(json.dumps({'accepted':accepted}))
'''
        env = {**os.environ, 'PYTHONPATH': str(Path(dialogue_module.__file__).resolve().parents[1])}
        processes = [subprocess.Popen([sys.executable, '-B', '-c', code, str(self.root), json.dumps(STATE)],
                                      env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                     for _ in range(4)]
        try:
            deadline = time.monotonic() + 5
            while len(list(self.root.glob('ready-*'))) != 4:
                if time.monotonic() >= deadline:
                    self.fail('Writers did not reach the shared test barrier')
                time.sleep(.005)
            (self.root / 'start').touch()
            accepted = 0
            for process in processes:
                output, error = process.communicate(timeout=8)
                self.assertEqual(process.returncode, 0, error)
                accepted += json.loads(output)['accepted']
            self.assertEqual(accepted, 4)
            self.assertEqual(len(list(store.directory.glob('*.json'))), 4)
        finally:
            for process in processes:
                if process.poll() is None:
                    process.kill()
                    process.communicate(timeout=3)


if __name__ == '__main__':
    unittest.main()
