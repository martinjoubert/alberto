"""Exercise intent transitions, isolation and fresh authorization without models."""
import json
from pathlib import Path
import tempfile
import unittest

from dinum_albert.dialogue import Dialogue, StateStore, DialogueError
from dinum_access.security import AccessGate, Principal, CURRENT, require_indices, guard_result, access_information


class InterpretationContractTests(unittest.TestCase):
    def invoke(self,responses):
        from unittest.mock import MagicMock, patch
        from dinum_albert.dialogue import Interpreter
        client=MagicMock();client.chat.side_effect=responses
        factory=MagicMock();factory.return_value.__enter__.return_value=client
        with patch('dinum_albert.dialogue.AlbertClient',factory):
            result=Interpreter('https://provider.invalid','fixture-secret','fixture-model')('Compare les équipements du site.',None)
        return result,client,factory

    def response(self,content,finish='stop'):
        return {'model':'fixture-model','choices':[{'message':{'content':content},'finish_reason':finish}],
                'usage':{'prompt_tokens':12,'completion_tokens':7,'total_tokens':19,'private':'NEVER_LOG'}}

    def valid(self):
        return self.response(json.dumps({'action':'new','confidence':.99,'clarification':'','source_change':'unchanged'}))

    def test_valid_decision_uses_one_call_and_bounded_safe_metadata(self):
        (decision,usage),client,factory=self.invoke([self.valid()])
        self.assertEqual(client.chat.call_count,1)
        self.assertEqual(usage['albert_calls'],1)
        self.assertEqual(decision['action'],'new')
        self.assertNotIn('NEVER_LOG',json.dumps(usage))
        self.assertIn('deadline',factory.call_args.kwargs)

    def test_truncation_malformed_json_and_invalid_values_get_only_one_format_repair(self):
        invalid=[self.response('PRIVATE_REJECTED_TEXT','length'),self.response('{PRIVATE_REJECTED_TEXT'),
                 self.response(json.dumps({'action':'invented','confidence':1,'clarification':'','source_change':'unchanged'})),
                 self.response(json.dumps({'action':'new','confidence':True,'clarification':'','source_change':'unchanged'})),
                 {'choices':[]}]
        for first in invalid:
            with self.subTest(first=first):
                (_,usage),client,_=self.invoke([first,self.valid()])
                self.assertEqual(client.chat.call_count,2)
                self.assertEqual(usage['albert_calls'],2)
                self.assertEqual(client.chat.call_args.kwargs['max_tokens'],4096)
                self.assertNotIn('PRIVATE_REJECTED_TEXT',json.dumps(client.chat.call_args.args))
                self.assertNotIn('PRIVATE_REJECTED_TEXT',json.dumps(usage))

    def test_second_invalid_reply_remains_an_explicit_error(self):
        with self.assertRaises(DialogueError) as error:
            self.invoke([self.response('{PRIVATE_REJECTED_TEXT'),self.response('{PRIVATE_REJECTED_TEXT')])
        self.assertEqual(str(error.exception),'dialogue_invalid_json')
        self.assertEqual(error.exception.diagnostics['albert_calls'],2)
        self.assertNotIn('PRIVATE_REJECTED_TEXT',json.dumps(error.exception.diagnostics))

    def test_transport_error_has_no_hidden_retry(self):
        from dinum_albert.client import AlbertError
        with self.assertRaises(AlbertError):self.invoke([AlbertError('timeout')])


class CapabilityBoundaryTests(unittest.TestCase):
    def test_explicit_foreign_log_queries_do_not_reach_provider_or_inherit_incident_state(self):
        from dinum_albert.dialogue import Interpreter
        from unittest.mock import patch
        interpreter=Interpreter('https://provider.invalid','fixture-key','fixture-model',domain='incidents')
        for question in ('Compte les refus PFS dans secteur-ouest.',
                         'Recherche les authentifications TACACS de cette adresse.',
                         'Liste les accès PFAING pour ce client.',
                         'Combien de journaux BB pour cette machine ?'):
            with self.subTest(question=question),patch('dinum_albert.dialogue.AlbertClient',side_effect=AssertionError('Provider must not be called')):
                decision,usage=interpreter(question,{'request':'Diagnostic routeur-X','replies':[]})
                self.assertEqual(decision['action'],'out_of_scope')
                self.assertEqual(usage['albert_calls'],0)

    def test_monitoring_and_ambiguous_requests_keep_the_ordinary_interpreter(self):
        from dinum_albert.dialogue import standalone_pdl_query
        for question in ('Compare les mesures, alertes et logs des équipements.',
                         'Diagnostique la congestion avec les logs PFS.',
                         'Recherche les précédents ITSM de cet incident.',
                         'Combien de points de latence pour PFS ?',
                         'Même équipement, même période.',
                         'Explique la panne et les authentifications TACACS.'):
            with self.subTest(question=question):self.assertFalse(standalone_pdl_query(question))


class DialogueTests(unittest.TestCase):
    def test_ten_related_turns_keep_constraints_and_read_again_each_time(self):
        first=self.turn('Compte les refus PFS le 12 octobre 2026 de 08h à 09h UTC.')
        token=first['continuation_token']
        for index in range(9):
            result=self.turn('Précise le regroupement '+str(index)+'.',token,'follow_up')
            self.assertEqual(result['status'],'success');token=result['continuation_token']
        self.assertEqual(len(self.reads),10)
        self.assertIn('12 octobre 2026',self.reads[-1][1])

    def test_out_of_scope_does_not_execute_and_preserves_the_last_context(self):
        first=self.turn('Compte les refus PFS hier.')
        before=len(self.reads)
        result=self.turn('Diagnostique un incident réseau.',first['continuation_token'],'out_of_scope')
        self.assertEqual(result['status'],'needs_clarification')
        self.assertIn('profil',result['answer'])
        self.assertEqual(len(self.reads),before)
        self.assertEqual(self.store.read(result['continuation_token'])['request'],'Compte les refus PFS hier.')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.owner = 'alice'
        self.action, self.confidence, self.ask = 'new', .99, ''
        self.source_change = None
        self.interpretations, self.reads = [], []
        self.store = StateStore(self.root/'dialogue', 'pdl-test', lambda: self.owner)
        self.policy = {'version': 1, 'revision': 1, 'default': 'blocked',
                       'indices': {'pfs': 'authenticated', 'pfaing': 'internal', 'tacacs': 'blocked'}}
        self.save_policy()
        def interpret(message, state):
            self.interpretations.append((message, state))
            decision = {'action': self.action, 'confidence': self.confidence, 'clarification': self.ask}
            if self.source_change is not None:
                decision['source_change'] = self.source_change
            return decision, {'albert_calls': 1}
        self.engine = Dialogue(self.execute, interpret, self.store)

    def save_policy(self):
        (self.root/'policy.json').write_text(json.dumps(self.policy))

    def execute(self, question, **options):
        gate = AccessGate({'state_directory': str(self.root)}, directory=object())
        internal = self.owner == 'alice'
        principal = Principal(self.owner, self.owner+'@example.org', 'internal' if internal else 'external', internal)
        marker = CURRENT.set((gate, principal))
        try:
            index = 'tacacs' if 'équipement' in question else 'pfaing' if 'PFAING' in question else 'pfs'
            try:
                require_indices(index)
            except ValueError:
                return guard_result({'status': 'error'})
            self.reads.append((self.owner, question, options))
            if question == 'Compte les refus.':
                self.reads.pop()
                return {'status': 'needs_clarification', 'clarification': 'Quelle source et quelle période ?',
                        'answer': 'Quelle source et quelle période ?', 'evidence': []}
            return {'status': 'success', 'answer': 'Fresh result', 'evidence': [{'read': len(self.reads)}],
                    'execution': {'albert_calls': 2}}
        finally:
            CURRENT.reset(marker)

    def turn(self, message, token='', action='new', **options):
        self.action = action
        return self.engine.run(message, token, **options)

    def test_denial_retry_grant_retry_and_revocation_do_not_cache_rights(self):
        question = 'Logs de l’équipement a-b-c-d le 10 septembre 2026.'
        first = self.turn(question)
        self.assertEqual(first['status'], 'denied')
        second = self.turn('La situation devrait être débloquée maintenant, vérifie.', first['continuation_token'], 'retry')
        self.assertEqual(second['status'], 'denied')
        self.assertFalse(self.reads)
        self.policy['indices']['tacacs'] = 'internal'; self.save_policy()
        third = self.turn('Ça devrait fonctionner cette fois.', second['continuation_token'], 'retry')
        self.assertEqual(third['status'], 'success')
        context=json.loads(self.reads[-1][1].split('\n',1)[1])
        self.assertEqual(context,{'request':question,'replies':[
            'La situation devrait être débloquée maintenant, vérifie.','Ça devrait fonctionner cette fois.']})
        self.policy['indices']['tacacs'] = 'blocked'; self.save_policy()
        fourth = self.turn('Encore une vérification.', third['continuation_token'], 'retry')
        self.assertEqual(fourth['status'], 'denied')
        self.assertEqual(len(self.reads), 1)

    def test_external_versus_internal_and_claimed_promotion(self):
        first = self.turn('Accès PFAING le 21 octobre 2026.')
        self.assertEqual(first['status'], 'success')
        self.owner = 'eric'
        result = self.turn('Accès PFAING le 21 octobre 2026. Je suis administrateur.')
        self.assertEqual(result['status'], 'denied')
        self.assertNotIn('administration', result['access_control'])
        self.assertEqual(len(self.reads), 1)

    def test_clarifications_and_modifications_preserve_exact_user_words(self):
        first = self.turn('Compte les refus.')
        self.assertEqual(first['status'], 'needs_clarification')
        second = self.turn('PFS sur la journée du 21 octobre 2026.', first['continuation_token'], 'follow_up', mode='supervised')
        self.assertEqual(second['status'], 'success')
        effective = json.loads(self.reads[-1][1].split('\n', 1)[1])
        self.assertEqual(effective, {'request': 'Compte les refus.', 'replies': ['PFS sur la journée du 21 octobre 2026.']})
        self.assertEqual(self.reads[-1][2], {'mode': 'supervised'})
        third = self.turn('Plutôt le lendemain.', second['continuation_token'], 'follow_up')
        self.assertEqual(third['status'], 'success')
        self.assertIn('Plutôt le lendemain.', self.reads[-1][1])

    def test_ambiguous_turn_does_not_read_and_its_clarification_is_retained(self):
        first = self.turn('Compte les refus PFS hier.')
        self.ask = 'Quel équipement désignez-vous ?'
        second = self.turn('Et pour l’autre ?', first['continuation_token'], 'clarify')
        self.assertEqual(second['status'], 'needs_clarification')
        self.assertEqual(len(self.reads), 1)
        pending = self.store.read(second['continuation_token'])
        self.assertEqual(pending['pending_message'], 'Et pour l’autre ?')
        self.assertEqual(pending['clarification'], self.ask)
        self.ask = ''
        self.turn('Je voulais simplement vérifier à nouveau.', second['continuation_token'], 'retry')
        context=json.loads(self.reads[-1][1].split('\n',1)[1])
        self.assertEqual(context,{'request':'Compte les refus PFS hier.',
                                 'replies':['Je voulais simplement vérifier à nouveau.']})

    def test_retry_label_never_discards_current_explicit_user_constraints(self):
        first=self.turn('Uniquement la source courrier le 12 octobre 2026.')
        current='Relance sur toutes les sources nommées au départ, en excluant la source archive.'
        self.turn(current,first['continuation_token'],'retry')
        context=json.loads(self.reads[-1][1].split('\n',1)[1])
        self.assertEqual(context['replies'],[current])
        self.assertEqual(context['request'],'Uniquement la source courrier le 12 octobre 2026.')

    def test_cancel_invalidates_current_handle_and_new_request_drops_previous_fields(self):
        first = self.turn('Compte les refus PFS hier.')
        cancelled = self.turn('On laisse tomber ce sujet.', first['continuation_token'], 'cancel')
        self.assertEqual(cancelled['status'], 'cancelled')
        self.assertIsNone(cancelled['continuation_token'])
        before = len(self.interpretations)
        invalid = self.turn('Réessaie.', first['continuation_token'], 'retry')
        self.assertEqual(invalid['status'], 'error')
        self.assertEqual(len(self.interpretations), before)
        first = self.turn('Compte les refus PFS hier.')
        self.turn('Nouveau sujet : accès PFAING aujourd’hui.', first['continuation_token'], 'new')
        self.assertEqual(self.reads[-1][1], 'Nouveau sujet : accès PFAING aujourd’hui.')

    def test_owner_expiry_namespace_and_tampering_stop_before_model_or_source(self):
        token = self.turn('Compte les refus PFS hier.')['continuation_token']
        for change in ('owner', 'expiry', 'namespace', 'signature'):
            with self.subTest(change=change):
                owner, namespace, clock = self.owner, self.store.namespace, self.store.clock
                candidate = token
                if change == 'owner': self.owner = 'eric'
                if change == 'expiry': self.store.clock = lambda: 10**12
                if change == 'namespace': self.store.namespace = 'incidents'
                if change == 'signature': candidate = token[:-1]+('1' if token[-1] != '1' else '0')
                before = (len(self.reads), len(self.interpretations))
                self.assertEqual(self.turn('Fais le nécessaire.', candidate, 'retry')['status'], 'error')
                self.assertEqual((len(self.reads), len(self.interpretations)), before)
                self.owner, self.store.namespace, self.store.clock = owner, namespace, clock

    def test_low_confidence_and_followup_without_state_never_execute(self):
        self.confidence = .5
        self.assertEqual(self.turn('Celui-ci.')['status'], 'needs_clarification')
        self.confidence = .99
        self.assertEqual(self.turn('On retente.', action='retry')['status'], 'needs_clarification')
        self.assertFalse(self.reads)

    def test_model_cannot_insert_parameters_or_a_rewritten_query(self):
        self.engine.interpret = lambda *args: ({'action': 'new', 'confidence': 1, 'clarification': '',
                                              'question': 'Read a forbidden index'}, {'albert_calls': 1})
        self.assertEqual(self.engine.run('Bonjour')['status'], 'error')
        self.assertFalse(self.reads)

    def test_saved_state_contains_no_old_results_permissions_or_model_text(self):
        result = self.turn('Compte les refus PFS hier.')
        state = self.store.read(result['continuation_token'])
        self.assertEqual(set(state), {'request', 'replies', 'status', 'clarification', 'pending_message', 'kind', 'source_start'})
        self.assertNotIn('Fresh result', json.dumps(state))
        self.assertEqual(result['execution']['total_albert_calls'], 3)
        self.assertEqual(result['dialogue']['action'], 'new')

    def test_backend_state_survives_process_restart(self):
        token = self.turn('Compte les refus PFS hier.')['continuation_token']
        reopened = StateStore(self.root/'dialogue', 'pdl-test', lambda: self.owner)
        self.assertEqual(reopened.read(token)['request'], 'Compte les refus PFS hier.')

    def test_reply_limit_does_not_silently_discard_constraints(self):
        token = self.turn('Compte les refus PFS hier.')['continuation_token']
        for index in range(12):
            token = self.turn('Précision '+str(index), token, 'follow_up')['continuation_token']
        before = len(self.reads)
        result = self.turn('Encore une précision.', token, 'follow_up')
        self.assertEqual(result['status'], 'error')
        self.assertEqual(len(self.reads), before)

    def enable_access(self):
        def access(question, *, confirmed_intent=False):
            if question.startswith('PDL_DIALOGUE\n'):
                content = json.loads(question.split('\n', 1)[1])
                turns = [content['request'], *content['replies']]
            else:
                turns = [question]
            scope = next((name for turn in reversed(turns) for name in ('PFS', 'PFAING') if name in turn), '')
            gate = AccessGate({'state_directory': str(self.root)}, directory=object())
            principal = Principal(self.owner, self.owner+'@example.org',
                                  'internal' if self.owner == 'alice' else 'external', self.owner == 'alice')
            marker = CURRENT.set((gate, principal))
            try:
                return access_information(turns[-1], patterns=[scope.lower()] if scope else None,
                                          scope=scope, confirmed_intent=confirmed_intent)
            finally:
                CURRENT.reset(marker)
        self.engine.access = access

    def test_access_followup_changes_scope_without_domain_execution_or_period(self):
        self.enable_access(); self.owner = 'eric'
        first = self.turn('Quels index PFAING sont accessibles ?')
        self.assertEqual(first['access_control']['allowed_indices'], [])
        self.assertEqual(first['dialogue']['albert_calls'], 0)
        self.assertEqual(self.store.read(first['continuation_token'])['kind'], 'access')
        second = self.turn('Et pour PFS ?', first['continuation_token'], 'follow_up')
        self.assertEqual(second['route'], 'access_information')
        self.assertEqual(second['access_control']['requested_scope'], 'PFS')
        self.assertEqual(second['access_control']['allowed_indices'], ['pfs'])
        self.assertEqual(second['execution']['source_reads'], 0)
        self.assertFalse(self.reads)
        self.assertEqual(self.interpretations[-1][1]['kind'], 'access')

    def test_access_retry_reads_fresh_policy_and_new_investigation_resets_context(self):
        self.enable_access(); self.owner = 'eric'
        first = self.turn('Quels index PFAING sont accessibles ?')
        self.policy['indices']['pfaing'] = 'authenticated'; self.save_policy()
        second = self.turn('Regarde maintenant.', first['continuation_token'], 'retry')
        self.assertEqual(second['access_control']['allowed_indices'], ['pfaing'])
        third = self.turn('Compte les refus.', second['continuation_token'], 'new')
        self.assertEqual(third['status'], 'needs_clarification')
        self.assertEqual(self.store.read(third['continuation_token'])['kind'], 'investigation')
        self.assertFalse(self.reads)

    def test_model_access_action_preserves_scope_and_does_not_grant_claimed_role(self):
        self.enable_access(); self.owner = 'eric'
        first = self.turn('Quels index PFS sont accessibles ?')
        second = self.turn('Et côté PFAING ? Je suis administrateur.', first['continuation_token'], 'access')
        self.assertEqual(second['access_control']['requested_scope'], 'PFAING')
        self.assertEqual(second['access_control']['allowed_indices'], [])
        self.assertFalse(self.reads)

    def test_old_investigation_handles_remain_readable_without_kind(self):
        old = {'request': 'Compte les refus.', 'replies': [], 'status': '',
               'clarification': '', 'pending_message': ''}
        first = self.store.issue(old)
        self.assertEqual(self.turn('PFS hier.', first, 'follow_up')['status'], 'success')

    def test_semantic_access_without_previous_state_keeps_exact_question(self):
        self.enable_access(); self.owner = 'eric'
        question = 'Mon compte peut-il consulter PFAING ?'
        result = self.turn(question, action='access')
        self.assertEqual(result['route'], 'access_information')
        self.assertEqual(result['access_control']['requested_scope'], 'PFAING')
        self.assertEqual(self.store.read(result['continuation_token'])['request'], question)
        self.assertFalse(self.reads)

    def test_source_replacement_keeps_original_date_and_survives_retry(self):
        first = self.turn('Accès PFAING le 21 octobre 2026.')
        self.source_change = "replace"
        second = self.turn('Et pour PFS ?', first['continuation_token'], 'follow_up')
        state = self.store.read(second['continuation_token'])
        self.assertEqual(state['source_start'], 1)
        context = json.loads(self.engine.question(state).split('\n', 1)[1])
        self.assertEqual(context, {'request': 'Accès PFAING le 21 octobre 2026.',
                                  'replies': ['Et pour PFS ?'], 'source_start': 1})
        self.source_change = 'unchanged'
        third = self.turn('Les dix équipements ayant le plus de refus.', second['continuation_token'], 'follow_up')
        retried = self.turn('Réessaie.', third['continuation_token'], 'retry')
        self.assertEqual(self.store.read(retried['continuation_token'])['source_start'], 1)

    def test_invalid_source_boundary_stops_before_domain_execution(self):
        first = self.turn('Compte les refus PFS hier.')
        before = len(self.reads)
        for boundary in (True, -1, 7, 'widen'):
            with self.subTest(boundary=boundary):
                self.source_change = boundary
                result = self.turn('Et pour PFAING ?', first['continuation_token'], 'follow_up')
                self.assertEqual(result['status'], 'error')
                self.assertEqual(len(self.reads), before)


if __name__ == '__main__':
    unittest.main()
