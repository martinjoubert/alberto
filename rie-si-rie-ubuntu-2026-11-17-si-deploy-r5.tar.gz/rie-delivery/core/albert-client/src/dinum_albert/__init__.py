"""Server-side client and pure contracts, without implicit provider calls."""

__all__ = ['AlbertClient', 'AlbertError']


def __getattr__(name):
    # Pure versioning/replay helpers also run in the standard-library CI job.
    if name in __all__:
        from .client import AlbertClient, AlbertError
        globals().update(AlbertClient=AlbertClient, AlbertError=AlbertError)
        return globals()[name]
    raise AttributeError(name)
