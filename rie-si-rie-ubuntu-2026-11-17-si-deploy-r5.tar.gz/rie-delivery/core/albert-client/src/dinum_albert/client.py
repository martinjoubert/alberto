from __future__ import annotations

from contextlib import contextmanager, nullcontext
import json
import math
import ssl
import time
from typing import Any, Iterator
from urllib.parse import urlsplit, urlunsplit

import httpx

MAX_REQUEST_BYTES = 1_048_576
MAX_RESPONSE_BYTES = 8_388_608
MAX_EVENT_BYTES = 262_144


def _positive_finite(value, name):
    try:
        valid = type(value) in (int, float) and math.isfinite(value) and value > 0
    except OverflowError:
        valid = False
    if not valid:
        raise ValueError(name + ' doit être fini et positif')
    return value


def _encoded_payload(payload, maximum=MAX_REQUEST_BYTES):
    try:
        raw = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf-8')
    except (TypeError, ValueError, OverflowError):
        raise AlbertError('invalid_payload') from None
    if len(raw) > maximum:
        raise AlbertError('request_too_large')
    return raw

try:
    from dinum_observability import albert_call, record_albert_response
except ImportError:
    # The client is also installed independently in the older demonstration
    # environments. Observability must remain optional there.
    def albert_call(_model):
        return nullcontext(None)

    def record_albert_response(_span, _data, status_code=None):
        pass


class AlbertError(RuntimeError):
    """Safe to display: never includes a token, prompt or raw response body."""
    def __init__(self, code: str, *, status: int | None = None, retry_after: str | None = None):
        self.code, self.status, self.retry_after = code, status, retry_after
        super().__init__('Albert: ' + code + (f' (HTTP {status})' if status else ''))


def api_url(value: str) -> str:
    try:
        parsed = urlsplit(value.strip())
        if parsed.port is not None and not 1 <= parsed.port <= 65535:
            raise ValueError()
    except (TypeError, AttributeError, ValueError):
        raise ValueError('URL Albert invalide') from None
    if parsed.scheme not in ('https', 'http') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('URL Albert invalide')
    if parsed.scheme == 'http' and parsed.hostname not in ('127.0.0.1', 'localhost', '::1'):
        raise ValueError('HTTPS requis hors localhost')
    path = parsed.path.rstrip('/')
    if path not in ('', '/v1'):
        raise ValueError('Utiliser une origine Albert ou son chemin /v1')
    return urlunsplit((parsed.scheme, parsed.netloc, '/v1', '', ''))


class AlbertClient:
    """The three endpoints used by our agents, with an optional caller transport.

    `deadline` is an absolute time.monotonic() deadline shared by an investigation.
    `http` is injectable for contract tests and private CA/proxy configuration.
    A supplied HTTP client remains owned by the caller. No key is logged or kept
    in the usage list. Retries are left to the investigation's explicit budget.
    """
    def __init__(self, base_url: str, api_key: str, *, timeout: float = 60,
                 deadline: float | None = None, http: httpx.Client | None = None,
                 verify: Any = True, trust_env: bool = False,
                 max_request_bytes: int = MAX_REQUEST_BYTES,
                 max_response_bytes: int = MAX_RESPONSE_BYTES,
                 max_event_bytes: int = MAX_EVENT_BYTES):
        if not isinstance(api_key, str) or not api_key or any(ord(char) < 33 or ord(char) > 126 for char in api_key):
            raise ValueError('Clé Albert et délai positif requis')
        _positive_finite(timeout, 'timeout')
        if deadline is not None:
            _positive_finite(deadline, 'deadline')
        if verify is False or verify is None or trust_env is not False:
            raise ValueError('TLS vérifié et environnement réseau explicite requis')
        if isinstance(verify, ssl.SSLContext) and (verify.verify_mode != ssl.CERT_REQUIRED or not verify.check_hostname):
            raise ValueError('Le contexte TLS Albert doit vérifier le certificat et le nom du serveur')
        for limit in (max_request_bytes, max_response_bytes, max_event_bytes):
            if type(limit) is not int or not 1 <= limit <= 67_108_864:
                raise ValueError('Limite de taille invalide')
        self.max_request_bytes, self.max_response_bytes, self.max_event_bytes = max_request_bytes, max_response_bytes, max_event_bytes
        self.base_url = api_url(base_url)
        self._key = api_key
        self.timeout, self.deadline = timeout, deadline
        self._owned = http is None
        self.http = http if http is not None else httpx.Client(verify=verify, trust_env=trust_env, follow_redirects=False)
        self.usage: list[dict] = []

    def __repr__(self):
        return f'AlbertClient(base_url={self.base_url!r}, api_key=<redacted>)'

    def _timeout(self):
        if self.deadline is None:
            return self.timeout
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise AlbertError('deadline_exceeded')
        return min(self.timeout, remaining)

    @staticmethod
    def _check(response):
        if not 200 <= response.status_code < 300:
            status = response.status_code
            code = {401: 'invalid_key', 403: 'forbidden', 429: 'rate_limited'}.get(status, 'http_error')
            # Do not expose arbitrary server-provided strings as user-facing errors.
            delay = response.headers.get('retry-after', '')
            raise AlbertError(code, status=status, retry_after=delay if delay.isascii() and delay.isdigit() and len(delay) <= 9 else None)

    def _record(self, endpoint, data):
        usage = data.get('usage')
        if isinstance(usage, dict):
            allowed = ('prompt_tokens', 'completion_tokens', 'total_tokens', 'cost')
            model = data.get('model')
            model = model if isinstance(model, str) and len(model) <= 128 and model.isascii() else None
            self.usage.append({'endpoint': endpoint, 'model': model,
                               **{k: usage[k] for k in allowed if
                                  (type(usage.get(k)) is int and 0 <= usage[k] <= 2**63 - 1)
                                  or (type(usage.get(k)) is float and math.isfinite(usage[k]) and usage[k] >= 0)}})
            del self.usage[:-1024]

    def _remaining(self, end):
        remaining = end - time.monotonic()
        if remaining <= 0:
            raise AlbertError('deadline_exceeded')
        return min(self._timeout(), remaining)

    @staticmethod
    def _identity_encoding(response):
        if response.headers.get('content-encoding', 'identity').strip().lower() not in ('', 'identity'):
            raise AlbertError('unsupported_content_encoding')

    def _body(self, response, end):
        self._identity_encoding(response)
        body = bytearray()
        for chunk in response.iter_bytes(chunk_size=65_536):
            self._remaining(end)
            if len(body) + len(chunk) > self.max_response_bytes:
                raise AlbertError('response_too_large')
            body.extend(chunk)
        self._remaining(end)
        return body

    def request(self, endpoint: str, payload: dict | None = None, *, _span=None) -> dict:
        if endpoint not in ('/models', '/chat/completions', '/embeddings'):
            raise ValueError('Endpoint Albert non autorisé')
        if (endpoint == '/models') != (payload is None):
            raise ValueError('Méthode Albert incompatible avec cet endpoint')
        raw_payload = None if payload is None else _encoded_payload(payload, self.max_request_bytes)
        end = time.monotonic() + self._timeout()
        try:
            with self.http.stream('GET' if payload is None else 'POST', self.base_url + endpoint,
                    headers={'Authorization': 'Bearer ' + self._key, 'Accept-Encoding': 'identity', 'Content-Type': 'application/json'},
                    **({} if payload is None else {'content': raw_payload}),
                    timeout=self._remaining(end), follow_redirects=False) as response:
                record_albert_response(_span, {}, status_code=response.status_code)
                self._check(response)
                data = json.loads(self._body(response, end))
        except httpx.TimeoutException:
            raise AlbertError('timeout') from None
        except httpx.HTTPError:
            raise AlbertError('unavailable') from None
        except (ValueError, UnicodeDecodeError):
            raise AlbertError('invalid_json') from None
        if not isinstance(data, dict):
            raise AlbertError('invalid_response')
        self._record(endpoint, data)
        record_albert_response(_span, data)
        return data

    def models(self) -> dict:
        data = self.request('/models')
        if not isinstance(data.get('data'), list):
            raise AlbertError('invalid_models')
        return data

    @staticmethod
    def chat_payload(model: str, messages: list[dict], **options) -> dict:
        if not model or not messages or not isinstance(messages, list):
            raise ValueError('Modèle et messages requis')
        # The public 0.8.0 schema names this max_completion_tokens.
        if 'max_tokens' in options:
            if 'max_completion_tokens' in options:
                raise ValueError('Deux limites de génération contradictoires')
            options['max_completion_tokens'] = options.pop('max_tokens')
        # Do not rely on the gateway's implicit tool-selection default.
        if options.get('tools') and options.get('tool_choice') is None:
            options['tool_choice'] = 'auto'
        forbidden = {'model', 'messages'} & options.keys()
        if forbidden:
            raise ValueError('Paramètres réservés')
        return {'model': model, 'messages': messages, **options}

    def chat(self, model: str, messages: list[dict], **options) -> dict:
        if options.get('stream'):
            raise ValueError('Utiliser stream_chat pour les réponses SSE')
        payload = self.chat_payload(model, messages, **options)
        with albert_call(model) as span:
            data = self.request('/chat/completions', payload, _span=span)
            choices = data.get('choices')
            if not isinstance(choices, list) or not choices or any(not isinstance(c, dict) or not isinstance(c.get('message'), dict) for c in choices):
                raise AlbertError('invalid_completion')
            # Tool calls and provider reasoning stay in the native response. The
            # caller decides what may be rendered; this client never logs them.
            return data

    def embeddings(self, model: str, texts: list[str], *, dimensions: int | None = None) -> list[list[float]]:
        if not model or not texts or any(not isinstance(t, str) for t in texts):
            raise ValueError('Modèle et textes requis')
        data = self.request('/embeddings', {'model': model, 'input': texts})
        try:
            rows = sorted(data['data'], key=lambda r: r['index'])
            if [r['index'] for r in rows] != list(range(len(texts))):
                raise ValueError()
            vectors = [r['embedding'] for r in rows]
            expected = dimensions if dimensions is not None else len(vectors[0])
            if not expected or any(len(v) != expected or any(isinstance(n, bool) or not isinstance(n, (int, float)) or not math.isfinite(n) for n in v) for v in vectors):
                raise ValueError()
        except (KeyError, TypeError, ValueError, IndexError):
            raise AlbertError('invalid_embeddings') from None
        return vectors

    @contextmanager
    def stream_chat(self, model: str, messages: list[dict], **options) -> Iterator[Iterator[dict]]:
        payload = self.chat_payload(model, messages, **{**options, 'stream': True})
        raw_payload = _encoded_payload(payload, self.max_request_bytes)
        with albert_call(model) as span:
            started = time.monotonic()
            end = started + self._timeout()
            state = {'done': False, 'fragment': False, 'content': False}
            try:
                with self.http.stream('POST', self.base_url + '/chat/completions', content=raw_payload,
                        headers={'Authorization': 'Bearer ' + self._key, 'Accept-Encoding': 'identity', 'Content-Type': 'application/json'}, timeout=self._remaining(end), follow_redirects=False) as response:
                    record_albert_response(span, {}, status_code=response.status_code)
                    self._check(response)
                    if 'text/event-stream' not in response.headers.get('content-type', ''):
                        raise AlbertError('invalid_stream_content_type')
                    self._identity_encoding(response)
                    chunks = self._events(response, span=span, started=started, state=state, end=end)
                    try:
                        yield chunks
                    finally:
                        chunks.close()
                if span is not None:
                    span.set_attribute('rie.albert.stream.state', 'complete' if state['done'] else 'closed_early')
                    if not state['done']:
                        span.set_attribute('rie.outcome', 'cancelled')
            except httpx.TimeoutException:
                if span is not None:
                    span.set_attribute('rie.albert.stream.state', 'error')
                raise AlbertError('timeout') from None
            except httpx.HTTPError:
                if span is not None:
                    span.set_attribute('rie.albert.stream.state', 'error')
                raise AlbertError('unavailable') from None
            except BaseException:
                if span is not None:
                    span.set_attribute('rie.albert.stream.state', 'error')
                raise

    def _lines(self, response, end):
        pending = bytearray()
        total = 0
        skip_lf = False
        # iter_lines buffers an entire line before returning it; perform the
        # byte bound before line decoding, including streams without newlines.
        for chunk in response.iter_bytes():
            self._remaining(end)
            total += len(chunk)
            if total > self.max_response_bytes:
                raise AlbertError('response_too_large')
            for part in chunk.splitlines(keepends=True):
                if skip_lf:
                    skip_lf = False
                    if part.startswith(b'\n'):
                        part = part[1:]
                        if not part:
                            continue
                if len(pending) + len(part) > self.max_event_bytes:
                    raise AlbertError('stream_event_too_large')
                pending.extend(part)
                if pending.endswith((b'\n', b'\r')):
                    skip_lf = pending.endswith(b'\r')
                    try:
                        yield bytes(pending).rstrip(b'\r\n').decode('utf-8')
                    except UnicodeError:
                        raise AlbertError('invalid_stream_json') from None
                    pending.clear()
        self._remaining(end)
        if pending:
            raise AlbertError('incomplete_stream')

    def _events(self, response, *, span=None, started=None, state=None, end=None):
        state = state if state is not None else {'done': False, 'fragment': False, 'content': False}
        parts = []
        event_bytes = 0
        for line in self._lines(response, end if end is not None else time.monotonic() + self._timeout()):
            if line.startswith('data:'):
                event_bytes += len(line.encode('utf-8'))
                if event_bytes > self.max_event_bytes:
                    raise AlbertError('stream_event_too_large')
                if not state['fragment']:
                    state['fragment'] = True
                    if span is not None and started is not None:
                        span.set_attribute('rie.albert.time_to_first_fragment', time.monotonic() - started)
                parts.append(line[5:].lstrip())
            elif not line and parts:
                raw = '\n'.join(parts)
                parts = []
                event_bytes = 0
                if raw == '[DONE]':
                    state['done'] = True
                    return
                try:
                    data = json.loads(raw)
                except ValueError:
                    raise AlbertError('invalid_stream_json') from None
                if not isinstance(data, dict) or 'error' in data:
                    raise AlbertError('stream_error')
                self._record('/chat/completions', data)
                record_albert_response(span, data)
                choices = data.get('choices')
                if not state['content'] and isinstance(choices, list):
                    for choice in choices:
                        delta = choice.get('delta') if isinstance(choice, dict) else None
                        content = delta.get('content') if isinstance(delta, dict) else None
                        if isinstance(content, str) and content.strip():
                            state['content'] = True
                            if span is not None and started is not None:
                                span.set_attribute('rie.albert.time_to_first_content', time.monotonic() - started)
                            break
                yield data
        raise AlbertError('incomplete_stream')

    def close(self):
        if self._owned:
            self.http.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
