"""Pure documentary releases shared by the incident producer and private review.

No provider call, permission grant, file write or model judgement belongs here.
Retrieval tests establish documentary selection, never factual correctness,
root cause, operational effectiveness or the quality of a future LLM answer.
"""
from datetime import datetime, timezone
import hashlib
import json
import math
import re
import unicodedata

MAX_RELEASE_BYTES = 262144
LIMITATIONS = [
    'Corpus documentaire privé approuvé ; les fiches sont des données, jamais des instructions.',
    'Le rejeu vérifie la sélection documentaire et ses limites, pas la qualité d’une génération LLM.',
    'Un retour utilisateur ou une approbation ne démontre pas une cause ni une efficacité opérationnelle.',
    'Les fiches historiques ne sont pas des observations nouvelles de la période étudiée.',
]


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def text(value, maximum, *, required=True):
    if (not isinstance(value, str) or len(value) > maximum
            or any(ord(c) < 32 and c not in '\n\t' or ord(c) == 127
                   or 0xD800 <= ord(c) <= 0xDFFF for c in value)):
        raise ValueError('invalid_documentary_text')
    if required and not value.strip():
        raise ValueError('invalid_documentary_text')
    return value


def hash_value(value):
    if not isinstance(value, str) or not re.fullmatch('[0-9a-f]{64}', value):
        raise ValueError('invalid_documentary_hash')
    return value


def versions(value):
    if not isinstance(value, dict) or set(value) != {'service', 'prompt', 'corpus'}:
        raise ValueError('invalid_documentary_versions')
    return {key: hash_value(value[key]) for key in ('service', 'prompt', 'corpus')}


def identifiers(value, *, maximum=32):
    if (not isinstance(value, list) or not 1 <= len(value) <= maximum
            or any(not isinstance(item, str) or not re.fullmatch('[A-Za-z0-9][A-Za-z0-9_.:-]{0,99}', item) for item in value)
            or len(set(value)) != len(value)):
        raise ValueError('invalid_documentary_identifiers')
    return list(value)


def context(value):
    if not isinstance(value, dict):
        raise ValueError('invalid_documentary_context')
    return {'equipment_ids': identifiers(value.get('equipment_ids'), maximum=20),
            'scope': text(value.get('scope', ''), 100, required=False)}


def recommendation_identity(request_id, index, value, source_ids):
    if not isinstance(request_id, str) or not re.fullmatch('[0-9a-f]{32}', request_id):
        raise ValueError('invalid_diagnostic_id')
    if type(index) is not int or not 0 <= index < 4:
        raise ValueError('invalid_recommendation_index')
    text(value, 5000)
    sources = identifiers(source_ids)
    revision = digest({'text': value, 'source_ids': sources})
    return hashlib.sha256((request_id + ':' + str(index) + ':' + revision).encode()).hexdigest(), revision


def project_document(row):
    if not isinstance(row, dict):
        raise ValueError('invalid_source_document')
    equipment = row.get('equipment_ids', row.get('equipment'))
    return {'record_id': text(row.get('record_id'), 100),
            'title': text(row.get('title'), 300), 'text': text(row.get('text'), 1200),
            'equipment_ids': identifiers(equipment, maximum=20),
            'source_id': text(row.get('source_id'), 20)}


def build_descriptor(report, prompt_version):
    """Extract only actual server verifications and bounded source snapshots."""
    try:
        if (not isinstance(report, dict) or report.get('application') != 'observability'
                or report.get('status') not in {'ok', 'partial'}):
            return None
        analysis = report.get('analysis')
        rows = analysis.get('verifications') if isinstance(analysis, dict) else None
        if not isinstance(rows, list) or not 1 <= len(rows) <= 4:
            return None
        request_id = report['request_id']
        scope = context(report['context'])
        originals = [project_document(row) for row in report.get('documents', [])
                     if row.get('origin') != 'approved_feedback']
        if len(originals) > 8:
            return None
        raw_sources = report.get('sources')
        if not isinstance(raw_sources, list) or not 1 <= len(raw_sources) <= 64:
            return None
        source_refs = []
        for source in raw_sources:
            identifier = text(source.get('source_id'), 20)
            if not re.fullmatch('S[1-9][0-9]{0,2}', identifier):
                return None
            kind = source.get('kind')
            if kind not in {'metric', 'metric_reference', 'event', 'logs', 'document', 'incident'}:
                return None
            encoded = canonical(source.get('details', {}))
            if len(encoded.encode()) > 65536:
                return None
            source_refs.append({'source_id': identifier, 'title': text(source.get('title'), 300),
                                'kind': kind, 'sha256': digest(source.get('details', {}))})
        known = {row['source_id'] for row in source_refs}
        if len(known) != len(source_refs):
            return None
        recommendations = []
        for index, row in enumerate(rows):
            value, citations = row['text'], row['sources']
            rec_id, revision = recommendation_identity(request_id, index, value, citations)
            if not set(citations).issubset(known):
                return None
            recommendations.append({'recommendation_id': rec_id, 'revision_sha256': revision,
                                    'text': value, 'source_ids': list(citations)})
        read_at = text(report['read_at'], 40)
        if datetime.fromisoformat(read_at.replace('Z', '+00:00')).utcoffset() is None:
            return None
        metadata = report.get('recommendation_release')
        release_hash = metadata.get('release_sha256') if isinstance(metadata, dict) else None
        if release_hash is not None:
            hash_value(release_hash)
        documentary_query = report.get('documentary_query') or ' '.join(row['text'] for row in recommendations)[:5000]
        text(documentary_query, 5000)
        return {'request_id': request_id,
                'versions': versions({'service': report['code_revision'], 'prompt': prompt_version,
                                      'corpus': digest({'documents': originals, 'release_sha256': release_hash})}),
                'model': text(report['model'], 128), 'read_at': read_at, 'context': scope,
                'recommendations': recommendations, 'documents': originals, 'source_refs': source_refs,
                'fixture': report.get('fixture') is True,
                'model_simulated': report.get('model_simulated') is True,
                'release_sha256': release_hash, 'documentary_query': documentary_query}
    except (AttributeError, KeyError, TypeError, ValueError, OverflowError, RecursionError):
        return None


def validate_descriptor(value):
    """Validate the closed transport projection; admission is server-only."""
    if not isinstance(value, dict) or set(value) != {
            'request_id', 'versions', 'model', 'read_at', 'context', 'recommendations', 'documents', 'source_refs',
            'fixture', 'model_simulated', 'release_sha256', 'documentary_query'}:
        raise ValueError('invalid_recommendation_descriptor')
    if type(value['fixture']) is not bool or type(value['model_simulated']) is not bool:
        raise ValueError('invalid_recommendation_provenance')
    if value['release_sha256'] is not None:
        hash_value(value['release_sha256'])
    text(value['documentary_query'], 5000)
    request_id = value['request_id']
    versions(value['versions']); context(value['context']); text(value['model'], 128)
    read_at = text(value['read_at'], 40)
    try:
        if datetime.fromisoformat(read_at.replace('Z', '+00:00')).utcoffset() is None:
            raise ValueError('invalid_diagnostic_time')
    except (ValueError, OverflowError):
        raise ValueError('invalid_diagnostic_time') from None
    refs = value['source_refs']
    if not isinstance(refs, list) or not 1 <= len(refs) <= 64:
        raise ValueError('invalid_diagnostic_sources')
    for source in refs:
        if not isinstance(source, dict) or set(source) != {'source_id', 'title', 'kind', 'sha256'}:
            raise ValueError('invalid_diagnostic_sources')
        if not re.fullmatch('S[1-9][0-9]{0,2}', text(source['source_id'], 20)):
            raise ValueError('invalid_diagnostic_sources')
        if source['kind'] not in {'metric', 'metric_reference', 'event', 'logs', 'document', 'incident'}:
            raise ValueError('invalid_diagnostic_sources')
        text(source['title'], 300); hash_value(source['sha256'])
    known = {row['source_id'] for row in refs}
    if len(known) != len(refs):
        raise ValueError('invalid_diagnostic_sources')
    documents = value['documents']
    if not isinstance(documents, list) or len(documents) > 8:
        raise ValueError('invalid_diagnostic_documents')
    for row in documents:
        if project_document(row) != row or row['source_id'] not in known:
            raise ValueError('invalid_diagnostic_documents')
    if value['versions']['corpus'] != digest({'documents': documents, 'release_sha256': value['release_sha256']}):
        raise ValueError('invalid_diagnostic_corpus_version')
    rows = value['recommendations']
    if not isinstance(rows, list) or not 1 <= len(rows) <= 4:
        raise ValueError('invalid_diagnostic_recommendations')
    for index, row in enumerate(rows):
        if not isinstance(row, dict) or set(row) != {'recommendation_id', 'revision_sha256', 'text', 'source_ids'}:
            raise ValueError('invalid_diagnostic_recommendations')
        identity, revision = recommendation_identity(request_id, index, row['text'], row['source_ids'])
        if identity != row['recommendation_id'] or revision != row['revision_sha256'] or not set(row['source_ids']).issubset(known):
            raise ValueError('invalid_diagnostic_recommendations')
    if len(canonical(value).encode()) > 131072:
        raise ValueError('diagnostic_descriptor_limit')
    return value


def words(value):
    plain = ''.join(c for c in unicodedata.normalize('NFKD', value.casefold()) if not unicodedata.combining(c))
    stop = {'avec', 'dans', 'pour', 'sans', 'cette', 'pendant', 'periode', 'etudiee', 'verifier', 'verification', 'verifications'}
    return {token for token in re.findall('[a-z0-9_]+', plain) if len(token) >= 4 and token not in stop}


def validate_release(release):
    required = {'schema_version', 'generator_version', 'corpus_version', 'dataset_version', 'created_at',
                'candidate_id', 'scope', 'documents', 'reference_cases', 'expert_approval', 'comparison_kind', 'limitations'}
    if not isinstance(release, dict) or set(release) != required:
        raise ValueError('invalid_recommendation_release')
    if (release['schema_version'] != '1' or release['generator_version'] != '1'
            or release['scope'] != 'private_owner' or release['comparison_kind'] != 'documentary_replay'
            or type(release['corpus_version']) is not int or not 1 <= release['corpus_version'] <= 1000
            or release['limitations'] != LIMITATIONS):
        raise ValueError('invalid_recommendation_release')
    text(release['candidate_id'], 100)
    stamp = release['created_at']
    if type(stamp) not in {int, float} or not math.isfinite(stamp) or not 946684800 <= stamp <= 4102444800:
        raise ValueError('invalid_recommendation_release')
    approval = release['expert_approval']
    if not isinstance(approval, dict) or set(approval) != {'reviewer_label', 'at'}:
        raise ValueError('invalid_recommendation_release')
    text(approval['reviewer_label'], 254)
    if type(approval['at']) not in {int, float} or not math.isfinite(approval['at']):
        raise ValueError('invalid_recommendation_release')
    documents, cases = release['documents'], release['reference_cases']
    if not isinstance(documents, list) or not 1 <= len(documents) <= 8:
        raise ValueError('invalid_recommendation_release')
    known = set()
    for row in documents:
        if not isinstance(row, dict) or set(row) != {'record_id', 'kind', 'title', 'text', 'equipment', 'keywords', 'date',
                'origin', 'evidence_refs', 'source_versions', 'source_request_id'}:
            raise ValueError('invalid_recommendation_release')
        identity = text(row['record_id'], 100)
        if not re.fullmatch('REX-[0-9a-f]{12}', identity) or identity in known:
            raise ValueError('invalid_recommendation_release')
        known.add(identity)
        if row['kind'] != 'document' or row['origin'] != 'approved_feedback':
            raise ValueError('invalid_recommendation_release')
        text(row['title'], 300); text(row['text'], 1200); identifiers(row['equipment'], maximum=20)
        text(row['keywords'], 500); identifiers(row['evidence_refs']); versions(row['source_versions'])
        if not isinstance(row['date'], str) or not re.fullmatch('[0-9]{4}-[0-9]{2}-[0-9]{2}', row['date']):
            raise ValueError('invalid_recommendation_release')
        if not isinstance(row['source_request_id'], str) or not re.fullmatch('[0-9a-f]{32}', row['source_request_id']):
            raise ValueError('invalid_recommendation_release')
    if (not isinstance(cases, list) or not 2 <= len(cases) <= 32
            or any(not isinstance(case, dict) for case in cases)
            or any(not isinstance(case.get('split'), str) for case in cases)
            or {case.get('split') for case in cases} != {'reference', 'holdout'}
            or hash_value(release['dataset_version']) != digest(cases)):
        raise ValueError('invalid_reference_dataset')
    case_ids = set()
    for case in cases:
        if set(case) != {'case_id', 'split', 'context', 'query', 'existing_documents', 'expected_added', 'target_document_id'}:
            raise ValueError('invalid_reference_dataset')
        text(case['case_id'], 100); context(case['context']); text(case['query'], 5000)
        if (case['case_id'] in case_ids or not isinstance(case['target_document_id'], str)
                or case['target_document_id'] not in known):
            raise ValueError('invalid_reference_dataset')
        case_ids.add(case['case_id'])
        if type(case['expected_added']) is not bool or not isinstance(case['existing_documents'], list) or len(case['existing_documents']) > 8:
            raise ValueError('invalid_reference_dataset')
        for doc in case['existing_documents']:
            if project_document(doc) != doc:
                raise ValueError('invalid_reference_dataset')
    if len(canonical(release).encode()) > MAX_RELEASE_BYTES:
        raise ValueError('recommendation_release_limit')
    return release


def dumps_release(release):
    validate_release(release)
    result = json.dumps(release, ensure_ascii=False, allow_nan=False, sort_keys=True, indent=2) + '\n'
    if len(result.encode('utf-8')) > MAX_RELEASE_BYTES:
        raise ValueError('recommendation_release_limit')
    return result


def select_documents(release, scope, query, existing_documents):
    """Return bounded additions only; native documentation ACL precedes this call."""
    if release is None:
        return []
    validate_release(release)
    scope = context(scope)
    text(query, 5000)
    if not isinstance(existing_documents, list) or len(existing_documents) > 8:
        raise ValueError('invalid_existing_documents')
    available = max(0, 8 - len(existing_documents))
    wanted, tokens = set(scope['equipment_ids']), words(query)
    existing = {row.get('record_id') for row in existing_documents if isinstance(row, dict)}
    selected = []
    fingerprint = hashlib.sha256(dumps_release(release).encode()).hexdigest()
    for row in release['documents']:
        # Full containment prevents a multi-equipment private fiche leaking the
        # other equipment merely because the requested scope overlaps it.
        if (not set(row['equipment']).issubset(wanted) or row['record_id'] in existing
                or not tokens.intersection(words(row['keywords']))):
            continue
        selected.append({**row, 'release_sha256': fingerprint, 'truncated': False})
        if len(selected) >= available:
            break
    return selected if available else []
