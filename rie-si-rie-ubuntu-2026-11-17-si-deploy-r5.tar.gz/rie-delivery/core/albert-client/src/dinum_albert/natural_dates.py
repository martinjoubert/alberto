"""Unambiguous French calendar windows; internal bounds are [start, end)."""
import re
import json
import unicodedata
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

NUMBERS = dict(zip('zero un deux trois quatre cinq six sept huit neuf dix onze douze treize quatorze quinze seize'.split(),range(17)))
NUMBERS.update({'une':1,'dix-sept':17,'dix-huit':18,'dix-neuf':19,'vingt':20,
                'vingt et un':21,'vingt et une':21,'vingt-deux':22,'vingt-trois':23})
NUMBER = '(?:'+'|'.join(re.escape(word).replace(r'\ ',r'[ -]').replace(r'\-',r'[ -]')
                       for word in sorted(NUMBERS,key=len,reverse=True))+')'
CLOCK = r'(?:midi|minuit|(?:\d{1,2}|'+NUMBER+r')(?:\s*:\s*\d{2}|\s*(?:heures?\b|h(?=\s|\d|$|[,.!?;]))\s*(?:\d{1,2}(?:\s*(?:minutes?|min))?)?)?)'
CLOCK_RANGE = re.compile(r'\b(?:de|entre)\s+(?P<a>'+CLOCK+r')\s+(?:a|et)\s+(?P<b>'+CLOCK+r')(?!\w)')
HOUR_HINT = re.compile(r'\b(?:de|entre|a|avant|apres|vers)\s+(?:\d|'+NUMBER+r'\b|midi|minuit)|\b(?:midi|minuit)\b|\b\d{1,2}\s*(?:heures?\b|h\b|:\d{2})')


def clock_window(text):
    """Read one exact interval; never discard an incomplete or second interval."""
    pairs=list(CLOCK_RANGE.finditer(text))
    if not pairs:
        if HOUR_HINT.search(text):raise ValueError('Créneau horaire incomplet ; préciser début et fin.')
        return None
    if len(pairs)!=1:raise ValueError('Plusieurs créneaux : préciser une seule période.')
    pair=pairs[0]
    remaining=text[:pair.start()]+' '+text[pair.end():]
    if (HOUR_HINT.search(remaining) or re.match(r'\s*(?:et\s+(?:demi|quart)|:\d)',text[pair.end():])
            or not re.search(r'heures?|h\b|h\d|:|midi|minuit',pair[0])):
        raise ValueError('Créneau horaire ambigu ; préciser les heures et minutes.')
    def parse(value):
        if value in ('midi','minuit'):return (12 if value=='midi' else 0,0)
        value=re.sub(NUMBER,lambda match:str(NUMBERS[match[0].replace(' ','-')]
                     if match[0].replace(' ','-') in NUMBERS else NUMBERS[match[0].replace('-',' ')]),value)
        match=re.fullmatch(r'(\d{1,2})(?:\s*(?::|heures?|h)\s*(\d{1,2})?(?:\s*(?:minutes?|min))?)?',value)
        if not match:raise ValueError('Heure invalide.')
        return int(match[1]),int(match[2] or 0)
    return parse(pair['a']),parse(pair['b']),pair['b']=='minuit'


def calendar_zone(text):
    """Never confuse an unsupported numeric zone label with zero-offset UTC."""
    if re.search(r'\b(?:utc|gmt)\s*[+−-]',text):
        raise ValueError('Utiliser deux bornes ISO 8601 avec leur décalage, ou l’heure de Paris/UTC.')
    universal=bool(re.search(r'\b(?:utc|gmt)\b',text))
    if universal and re.search(r'\bparis\b',text):
        raise ValueError('Fuseaux contradictoires ; préciser un seul fuseau ou deux bornes ISO 8601.')
    return timezone.utc if universal else ZoneInfo('Europe/Paris')


def relative_window(text, now=None):
    """Resolve rolling durations and Paris calendar weeks against one aware clock."""
    text = ''.join(c for c in unicodedata.normalize('NFKD', text.casefold()) if not unicodedata.combining(c))
    anchor = now or datetime.now(timezone.utc)
    if anchor.tzinfo is None:
        raise ValueError('Un instant de référence avec fuseau est requis.')
    end = anchor.astimezone(timezone.utc)
    week = re.search(r'\bsemaine\s+(derniere|precedente|passee)\b|\bcette\s+semaine\b', text)
    if week:
        zone = calendar_zone(text)
        local = anchor.astimezone(zone)
        monday = local.replace(hour=0, minute=0, second=0, microsecond=0)-timedelta(days=local.weekday())
        start, finish = (monday-timedelta(days=7), monday) if week[1] else (monday, end)
        return {'start':start.isoformat(), 'end':finish.isoformat()}
    numbers = {'un':1, 'une':1, 'deux':2, 'trois':3, 'quatre':4, 'cinq':5,
               'six':6, 'sept':7, 'huit':8, 'neuf':9, 'dix':10, 'quinze':15, 'trente':30}
    number = r'(?:\d+|'+'|'.join(numbers)+')'
    unit = r'(?:semaines?|jours?|heures?|minutes?|min|h|j|d|w)'
    since = re.search(r'\bdepuis\s+('+number+r')\s*('+unit+r')\b', text)
    past = re.search(r'\b(?:('+number+r')\s+dernier(?:e)?s?|dernier(?:e)?s?\s+('+number+r'))\s*('+unit+r')\b', text)
    compact = re.fullmatch(r'\s*(?:(?:depuis|sur)\s+)?(\d+)\s*(min|h|j|d|w)\s*[.!?]?\s*', text)
    if since or compact:
        value, label = (since or compact).groups()
    elif past:
        value, label = past[1] or past[2], past[3]
    else:
        return None
    amount = int(value) if value.isdigit() else numbers[value]
    seconds = amount*(604800 if label.startswith('semaine') or label=='w' else
                      86400 if label.startswith('j') or label=='d' else 3600 if label.startswith('h') else 60)
    if not 0 < seconds <= 31*86400:
        raise ValueError('Fenêtre relative positive limitée à 31 jours.')
    return {'start':(end-timedelta(seconds=seconds)).isoformat(), 'end':end.isoformat()}


def french_window(text, now=None):
    """Return exact ISO bounds, or None for dates requiring further interpretation.

    Civil date ranges include the last day. Explicit hours are exact bounds.
    Paris is the default; invalid dates and ambiguous local hours are rejected.
    """
    if text.startswith('PDL_DIALOGUE\n'):
        # Parse each raw user turn separately. An older ISO date must not win
        # over a later French correction simply because ISO is matched first.
        state = json.loads(text.split('\n', 1)[1])
        if len(text) > 2000 or not isinstance(state, dict) or not isinstance(state.get('request'), str) or \
                not isinstance(state.get('replies'), list) or len(state['replies']) > 12 or \
                any(not isinstance(turn, str) or not turn.strip() for turn in state['replies']):
            raise ValueError('Demande en attente invalide.')
        bounds, fragment = None, ''
        pending_error = None
        months = 'janvier fevrier mars avril mai juin juillet aout septembre octobre novembre decembre'.split()
        for turn in [state['request'], *state['replies']]:
            normalized = ''.join(c for c in unicodedata.normalize('NFKD', turn.casefold()) if not unicodedata.combining(c))
            # A new incomplete date supersedes an older confirmed period. A
            # following year completes only this fragment, never another date.
            date = re.search(r'\b\d{1,2}(?:er)?\s+(?:'+'|'.join(months)+r')\b', normalized)
            if date and not re.search(r'\b\d{4}\b', normalized[date.end():]):
                fragment, bounds = normalized, None
                continue
            year = re.match(r'^\s*(?:en\s+|annee\s+)?(\d{4})\b(.*)', normalized)
            candidate = turn
            try:
                if bounds and re.search(r'\b(?:lendemain|veille|jour suivant|jour precedent)\b', normalized):
                    zone = calendar_zone(normalized)
                    offset = -1 if re.search(r'\b(?:veille|jour precedent)\b', normalized) else 1
                    shifted = {key: datetime.fromisoformat(value).astimezone(zone)+timedelta(days=offset)
                               for key, value in bounds.items()}
                    for value in shifted.values():
                        naive = value.replace(tzinfo=None)
                        if (value.astimezone(timezone.utc).astimezone(zone).replace(tzinfo=None) != naive or
                                value.utcoffset() != naive.replace(tzinfo=zone, fold=1).utcoffset()):
                            raise ValueError('Décalage de date ambigu : précisez les heures et le fuseau.')
                    bounds = {key: value.isoformat() for key, value in shifted.items()}
                    continue
                if fragment and year:
                    date = re.search(r'\b\d{1,2}(?:er)?\s+(?:'+'|'.join(months)+r')\b', fragment)
                    tail = fragment[date.end():].strip(' .!?;,')
                    if re.match(r'\s*(?:de|entre)\s+', year[2]):
                        tail = ''  # The latest clock correction supersedes an older one.
                    candidate = fragment[:date.end()] + ' ' + year[1] + ' ' + tail + year[2]
                    if re.match(r'^\d', candidate):
                        candidate = 'le ' + candidate
                parsed = french_window(candidate, now)
                if parsed:
                    bounds, fragment = parsed, ''
                    pending_error = None
                elif bounds and re.match(r'^\s*(?:plutot\s+)?(?:de|entre)\s+', normalized):
                    zone = calendar_zone(normalized)
                    day = datetime.fromisoformat(bounds['start']).astimezone(zone)
                    clock = re.sub(r'^\s*plutot\s+', '', normalized)
                    bounds = french_window(f'le {day.day} {months[day.month-1]} {day.year} '+clock, now)
            except ValueError as exc:
                # A later complete user correction may replace this error.
                # Until then, never reuse the previous successful bounds.
                bounds, fragment, pending_error = None, '', exc
        if pending_error is not None:raise pending_error
        return bounds
    text = ''.join(c for c in unicodedata.normalize('NFKD', text.casefold()) if not unicodedata.combining(c))
    def numeric_date(match):
        day, month, year = map(int, match.groups())
        datetime(year, month, day)  # Reject invalid civil dates before planning.
        months = 'janvier fevrier mars avril mai juin juillet aout septembre octobre novembre decembre'.split()
        return f'{day} {months[month-1]} {year}'
    text = re.sub(r'\b(\d{1,2})/(\d{1,2})/(\d{4})\b', numeric_date, text)
    relative_day = re.search(r"\b(?:hier|aujourd['’]hui)\b", text)
    if relative_day:
        zone = calendar_zone(text)
        day = (now or datetime.now(timezone.utc)).astimezone(zone)
        if relative_day.group() == 'hier':
            day -= timedelta(days=1)
        months = 'janvier fevrier mars avril mai juin juillet aout septembre octobre novembre decembre'.split()
        # Resolve relative civil dates once, then reuse the exact hour/DST parser.
        text = text[:relative_day.start()] + f'le {day.day} {months[day.month-1]} {day.year}' + text[relative_day.end():]
    # A labelled comparison window is not the principal investigation window.
    # In mixed French/ISO questions, searching ISO first would otherwise select
    # the reference and reject a correct main-window diagnosis.
    text = re.split(r'\b(?:reference|periode de comparaison|fenetre de reference)\s*:\s*(?=(?:du|le)\s+\d)',text,maxsplit=1)[0]
    stamp = r'(\d{4}-\d{2}-\d{2}t\d{2}:\d{2}(?::\d{2})?(?:z|[+-]\d{2}:\d{2}))'
    iso = re.search(r'\bdu\s+'+stamp+r'\s+au\s+'+stamp, text)
    if iso:
        start, end = [datetime.fromisoformat(s.upper().replace('Z', '+00:00')) for s in iso.groups()]
    else:
        months = 'janvier fevrier mars avril mai juin juillet aout septembre octobre novembre decembre'.split()
        month = '(?:'+'|'.join(months)+')'
        # A date range may share its month/year, or spell out both dates.
        date_range = re.search(r'\bdu\s+(?P<ad>\d{1,2})(?:er)?(?:\s+(?P<am>'+month+r')(?:\s+(?P<ay>\d{4}))?)?\s+au\s+(?P<bd>\d{1,2})(?:er)?\s+(?P<bm>'+month+r')\s+(?P<by>\d{4})\b', text)
        day = re.search(r'\b(?:le|du)\s+(?P<d>\d{1,2})(?:er)?\s+(?P<m>'+month+r')\s+(?P<y>\d{4})\b(?P<tail>.*)', text)
        if not date_range and not day:
            return relative_window(text, now)
        zone = calendar_zone(text)

        def local(y, m, d, h=0, minute=0):
            naive = datetime(int(y), months.index(m)+1, int(d), int(h), int(minute))
            value = naive.replace(tzinfo=zone)
            if value.astimezone(timezone.utc).astimezone(zone).replace(tzinfo=None) != naive:
                raise ValueError('Heure locale inexistante ; préciser une heure valide.')
            if value.utcoffset() != naive.replace(tzinfo=zone, fold=1).utcoffset():
                raise ValueError('Heure locale ambiguë ; préciser le décalage UTC.')
            return value

        if date_range:
            if HOUR_HINT.search(text[date_range.end():]):
                raise ValueError('Préciser les dates et heures complètes de chaque borne.')
            g = date_range.groupdict()
            start = local(g['ay'] or g['by'], g['am'] or g['bm'], g['ad'])
            end = local(g['by'], g['bm'], g['bd']) + timedelta(days=1)
        else:
            g = day.groupdict()
            clocks = clock_window(g['tail'])
            if clocks:
                first,last,midnight=clocks
                start = local(g['y'],g['m'],g['d'],*first)
                end = local(g['y'],g['m'],g['d'],*last)
                if midnight and first!=(0,0):
                    next_day=datetime(int(g['y']),months.index(g['m'])+1,int(g['d']))+timedelta(days=1)
                    end=local(next_day.year,months[next_day.month-1],next_day.day)
            else:
                start = local(g['y'], g['m'], g['d'])
                end = start + timedelta(days=1)
    if start >= end:
        raise ValueError('La fin doit être postérieure au début.')
    return {'start': start.isoformat(), 'end': end.isoformat()}
