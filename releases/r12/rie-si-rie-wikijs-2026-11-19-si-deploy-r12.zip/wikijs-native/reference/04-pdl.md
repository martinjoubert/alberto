# Technique PDL : de la question aux preuves

> Complément de référence — le [guide principal](/dinum-rie) reste le seul parcours de déploiement à exécuter.

## Exemple complet illustré : des champs PDL aux accès TACACS

Cet exemple accompagne le formulaire **Mappings PDL** de NiceGUI
(`/admin-mappings`). Il est placé dans le bloc **« Exemple complet illustré ·
PFS, Backbone, PFAING et TACACS »**, fermé par défaut, avant la connexion.
Le consulter n’importe aucun fichier et ne change aucun mapping.

**Cadre des captures : 17 novembre 2026, Ubuntu 24.04 ARM64, instance de
qualification autonome**, avec son propre LDAP, OpenSearch et catalogue.
Les comptes, adresses, noms et événements sont fictifs. Les validations et
approbations visibles sont réelles dans cette instance ; elles ne valent pas
approbation du SI-RIE. Le mapping est une configuration déterministe : sa
préparation ne demande aucune génération IA. Les conversations métier avec
Albert se valident séparément à l’[étape 11](/dinum-rie#11-jouer-les-deux-uc-et-leurs-acl-avec-albert).

### 1. Partir d’une question et des preuves attendues

Nous voulons retrouver les événements de **`edge-a`**, dans **`demo-alpha`**,
le **12 octobre 2026 de 08:00 à 09:00 UTC** — soit de **10:00 à 11:00 à Paris**.
Une même machine apparaît sous plusieurs identifiants selon les sources :

| Famille | Informations présentes dans les documents fictifs utiles |
| --- | --- |
| PFS | `observer.name = edge-a`, `asset.id = asset-001`, `observer.ip = 10.20.0.1`, `asset.reference = gateway-73` |
| Backbone | `host.name = edge-a`, même ID `asset-001`, tableau `host.ip = [10.20.0.1, 2001:db8::10]` |
| PFAING | `gateway.ref = gateway-73` ; ni le nom `edge-a`, ni son ID ne sont nécessaires dans cet événement |
| TACACS | `log.tacacs.dest = 10.20.0.1` ou `2001:db8::10` ; ni nom d’équipement, ni ID stable dans ces événements |

Le chemin à faire confirmer est donc : **nom → ID stable → IP de gestion →
événements TACACS**, et **nom → ID stable → référence → événements PFAING**.
Les relations ne sont pas déduites du nom des champs ou de valeurs identiques.
Le responsable des sources confirme ce qu’identifient réellement ces champs.

### 2. Découvrir les sources et charger une proposition

1. Se connecter au formulaire avec un **vrai compte LDAP administrateur** du SI.
   Alice est le compte fictif du laboratoire, pas une valeur à reprendre en production.
2. Cliquer sur **« Actualiser les sources »**. Les index autorisés et le nombre
   de champs découverts apparaissent ; cette lecture n’approuve rien.
3. Si le responsable du SI a fourni un fichier, cliquer sur **« Charger le
   fichier initial »** pour `config/mappings.yaml`, ou utiliser **« Importer un
   fichier YAML/JSON »**. Sinon, choisir **« Ajouter un index découvert »**,
   puis **« Ajouter cet index »**, et ajouter les concepts ci-dessous.
4. Le champ **« Profil à modifier »** permet de passer d’une source à l’autre.
   Les noms `pfs`, `bb`, `pfaing` et `tacacs` de l’exemple sont des profils du
   fichier ; ils ne donnent aucun droit d’accès.

![Sources fictives découvertes, sans mapping actif](/dinum-rie/assets/screenshots-2026-11-17/mapping-01-sources.png)

*Les quatre sources de départ sont visibles. « En attente » dans la colonne
Mapping actif signifie qu’il manque une approbation ; ce n’est pas un défaut
OpenSearch. Les quatre revues ne seront créées qu’à l’étape 6 de cet exemple.*

### 3. Renseigner les concepts, types et valeurs

Dans chaque profil, ouvrir un concept, sélectionner **« Champ physique »**,
puis contrôler **« Type détecté »**. Ajouter les concepts manquants avec
**« Ajouter un concept métier »**. Pour une création manuelle du profil TACACS,
le concept proposé **« IP de gestion »** (`management_ip`) convient aussi :
il doit utiliser le même champ, rôle et groupe que `management_destination`
dans le fichier fourni. Les noms des concepts sont distincts des champs physiques.

| Concept | PFS | Backbone | PFAING | TACACS structuré |
| --- | --- | --- | --- | --- |
| `timestamp` — heure de l’événement | `@timestamp` · `date` | identique | identique | identique |
| `network_scope` — périmètre | `network.scope` · `keyword` | identique | identique | identique |
| `equipment` — nom | `observer.name` · `keyword` | `host.name` · `keyword` | `observer.hostname` · `keyword`, sans rôle d’identité dans ce corpus | absent |
| `stable_id` — identifiant stable | `asset.id` · `keyword` | `asset.id` · `keyword` | absent | absent |
| `management_ip` — IP de gestion | `observer.ip` · `ip` | `host.ip` · `ip`, parfois plusieurs valeurs | absent | voir `management_destination` |
| `equipment_reference` — référence | `asset.reference` · `keyword` | absent | `gateway.ref` · `keyword` | absent |
| `equipment_fqdn` — nom DNS complet | `observer.fqdn` · `keyword` | absent | absent | absent |
| `source_ip` — IP du trafic source | `source.ip` · `ip` | absent | `client.ip` · `ip` | absent |
| `destination_ip` — IP du trafic destination | `destination.ip` · `ip` | absent | `server.ip` · `ip` | absent |
| `action` — action réseau | `event.action` · `keyword` | absent | `event.action` · `keyword` | `event.action` · `keyword` |
| `management_destination` — équipement cible TACACS | absent | absent | absent | `log.tacacs.dest` · `ip` |

Les autres concepts de l’exemple complet — domaine virtuel, règle, gravité,
domaine web, URL et message — sont conservés dans le YAML de fin d’exemple.
L’import permet de conserver les concepts personnalisés, y compris ceux dont
le nom anglais n’a pas de libellé particulier dans le formulaire.

Dans **« Valeurs métier possibles, une par ligne »**, saisir uniquement les
valeurs confirmées, en respectant leur casse :

| Concept / profil | Valeurs de cet exemple |
| --- | --- |
| `network_scope` / tous | `demo-alpha`, puis `demo-beta` sur une autre ligne |
| `action` / PFS et PFAING | `deny`, puis `allow` |
| `action` / TACACS | `login`, `logout`, `command` |

Une valeur absente des quelques exemples observés n’est pas forcément impossible.
Ces listes ne traduisent pas automatiquement `deny` en une autre valeur du SI.
Le champ doit porter l’heure de l’événement, pas une date d’ingestion choisie
par commodité. Les fuseaux et valeurs réelles sont à confirmer avec le métier.

### 4. Déclarer l’identité stable et les relations entre sources

Ouvrir **« Identité et lecture avancée »** pour chaque concept d’identité.
Renseigner le rôle et exactement le même **« Groupe de correspondance entre
sources »** pour les informations de même sens :

| Groupe à saisir | Membres de l’exemple | Rôle dans le formulaire |
| --- | --- | --- |
| `equipment-name` | PFS `equipment` et BB `equipment` | Nom d’équipement |
| `asset-id` | PFS `stable_id` et BB `stable_id` | Identifiant stable |
| `management-ip` | PFS `management_ip`, BB `management_ip`, TACACS `management_destination` | IP d’équipement à rapprocher |
| `asset-reference` | PFS `equipment_reference`, PFAING `equipment_reference` | Référence |
| `equipment-fqdn` | PFS `equipment_fqdn` | FQDN d’équipement |

**`asset-id` est l’unique groupe d’ancre** : le rôle `id` suffit ici.
Ne pas cocher en plus le nom comme ancre. Une ancre stable relie les documents
PFS et BB, puis permet de réunir leurs identifiants sans confondre deux machines.
Le FQDN reste dans un groupe distinct du nom court.

![ID stable et groupe asset-id dans le formulaire](/dinum-rie/assets/screenshots-2026-11-17/mapping-02-stable-identity.png)

*Sur PFS, `stable_id` lit `asset.id`, de type `keyword`, avec le rôle
Identifiant stable et le groupe `asset-id`. Le profil BB utilise le même groupe.*

![Mapping de l’IP de gestion TACACS](/dinum-rie/assets/screenshots-2026-11-17/mapping-03-tacacs-ip.png)

*Le concept personnalisé `management_destination` lit `log.tacacs.dest`, de type
`ip`. Son rôle est IP d’équipement à rapprocher et son groupe `management-ip`.
Une IPv6 n’exige pas de second concept : le type `ip` et la normalisation du
moteur couvrent IPv4 et IPv6. Le tableau BB n’est pas une chaîne à découper.*

**Ne pas ajouter** `source.ip`, `destination.ip`, `client.ip` ou `server.ip`
à `management-ip` au seul motif qu’ils ont le type `ip`. Dans ce corpus, ce
sont des adresses de trafic. Les y ajouter ferait entrer des événements leurres.
Dans **« Rapprochements prévus entre sources »**, vérifier les membres avant
la validation : un groupe cohérent n’associe pas des rôles différents.

![Tableau des groupes et correspondances entre sources](/dinum-rie/assets/screenshots-2026-11-17/mapping-04-relations.png)

### 5. Vérifier et corriger avant toute approbation

Cliquer sur **« Vérifier la proposition »**. Le résultat attendu est
**« Proposition valide techniquement »**. Cette vérification confronte les
champs, types, dates et relations à l’inventaire ; elle ne confirme pas leur
signification métier et ne rend pas le mapping actif.

![Valeur numérique invalide refusée avant enregistrement](/dinum-rie/assets/screenshots-2026-11-17/mapping-05-validation-error.png)

*Erreur volontaire du laboratoire : une chaîne dans le concept de gravité BB,
qui attend un nombre. Le formulaire bloque la vérification et aucune revue
n’est créée. Corriger ou vider la valeur fautive, puis vérifier de nouveau.*

| Problème | Correction / contrôle à réaliser |
| --- | --- |
| Champ absent ou mauvais type | Actualiser ; sélectionner le vrai champ du bon profil. Un autre champ de même type peut malgré tout porter un sens erroné. |
| Valeur incompatible | Respecter le type : nombre pour `long`, `true` / `false` pour un booléen ; pas un libellé arbitraire. |
| Identité incohérente | Vérifier rôles, groupes et ancre commune. Ne pas fusionner nom, IP et référence dans un groupe unique. |
| Schéma changé entre deux actions | Actualiser, vérifier de nouveau et examiner la nouvelle revue. L’ancienne décision ne se réutilise pas automatiquement. |
| Index non visible ou refusé | Faire vérifier les droits LDAP/ACL et les motifs de découverte. Le mapping n’accorde aucun accès. |

**« Exporter le YAML »** télécharge la proposition courante. Cela ne l’approuve
pas et ne réécrit pas automatiquement le fichier initial côté serveur.
Conserver l’export approuvé dans le dossier de configuration géré par l’équipe,
selon sa procédure de mise à jour ; le catalogue reste la référence d’exécution.

### 6. Examiner les différences et approuver chaque index

1. Renseigner **« Motif de la proposition »**, puis cliquer sur **« Enregistrer
   une proposition »**. Une première proposition pour les quatre index crée
   **quatre revues en attente**, sans activation.
2. Choisir une entrée dans **« Revue à examiner »**, puis **« Examiner cette
   revue »**. Contrôler le vrai nom d’index, les champs et les différences.
3. Pour TACACS, retrouver le champ `log.tacacs.dest`, le rôle IP et le groupe
   `management-ip`. Si le tableau montre une adresse cliente ou un mauvais rôle,
   corriger la proposition et la faire vérifier de nouveau.
4. Après confirmation par le responsable des sources, cocher **« Je confirme
   le sens des champs et des relations avec le responsable des sources »**,
   renseigner **« Justification de l’approbation »**, puis **« Approuver ce mapping »**.
5. Recommencer pour les autres index. Une approbation concerne **un index
   physique**, pas toute une famille, un joker ou la totalité du fichier.

![Différences TACACS à examiner avant approbation](/dinum-rie/assets/screenshots-2026-11-17/mapping-06-review.png)

![Quatre mappings actifs après quatre approbations explicites](/dinum-rie/assets/screenshots-2026-11-17/mapping-07-approved.png)

*Les quatre lignes sont actives et il ne reste aucune revue en attente pour
ce premier parcours. Le bouton de vérification seul n’aurait pas produit cet état.*

### 7. Cas avancé et limite actuelle : TACACS ne fournit qu’un message texte

**Pour publier des logs TACACS, fournir un champ `ip` structuré à
l’ingestion. Le parcours où le texte est le seul lien d’identité de la source
cible n’est pas pris en charge actuellement.** Le test réel de cet exemple
retourne `incomplete`, sans logs publiés : « Aucune relation d’identité
compatible avec l’index rie-tacacs-raw-fixture ».

L’option visible dans le formulaire sert une compatibilité textuelle temporaire
pour la résolution d’identité, sur un format précis, par exemple :

```text
TACACS access from '10.20.0.1'
TACACS access from "2001:db8::10"
```

Le responsable doit confirmer que l’IP après `from` identifie bien l’équipement
à rapprocher dans **ce** flux, et non l’utilisateur ou un autre pair réseau.
Le parseur enregistré **`quoted_from_ip_v1`** ne sait pas interpréter n’importe
quel message TACACS. Il attend `from` suivi d’une IPv4/IPv6 entre guillemets
appariés. Il ne crée pas de champ physique dans OpenSearch.

Pour comprendre et tester cette limite **dans le laboratoire uniquement**,
un index distinct `rie-tacacs-raw-fixture` a été créé avec des messages
fictifs. Sa proposition remplace la cible TACACS du fichier d’exemple et sa
correspondance :

```yaml
  tacacs:
    match: rie-tacacs-raw-fixture
    concepts:
      timestamp:
        field: '@timestamp'
        type: date
      network_scope:
        field: network.scope
        type: keyword
        values: [demo-alpha, demo-beta]
      management_destination:
        field: message
        type: text
        identity_role: ip
        identity_extractor: quoted_from_ip_v1
      action:
        field: event.action
        type: keyword
        values: [login, logout, command]
      message:
        field: message
        type: text
```

Cet extrait **remplace le profil TACACS**, ce n’est pas un fichier autonome :
conserver `version`, les profils d’identité PFS/BB, PFAING et les relations du
fichier complet ci-dessous. En particulier, `management_destination` reste
membre de `relations.management-ip.tacacs`.

Dans le formulaire : choisir **Champ physique = `message`**, contrôler le type
`text`, ouvrir **Identité et lecture avancée**, garder le rôle IP et le groupe
`management-ip`, puis choisir **Extraction textuelle approuvée =
`quoted_from_ip_v1`**. Dans le laboratoire, la proposition a été vérifiée,
exportée, examinée et approuvée pour constater la limite de bout en bout.
**Ne pas reproduire cette approbation comme une solution opérationnelle dans
le SI** : la validation technique ne vérifie pas à elle seule que le parcours
de recherche visé est pris en charge. Les mappings actifs identiques ne sont
pas recréés par le formulaire ; le nouvel index reçoit sa propre revue.

![Extraction IP explicitement configurée sur un message TACACS](/dinum-rie/assets/screenshots-2026-11-17/mapping-08-tacacs-text.png)

*Variante de laboratoire avec des messages fabriqués pour ce format. Elle ne
modifie pas l’index TACACS structuré du premier parcours. Le parseur extrait
bien les deux adresses IPv4/IPv6 de ces messages ; la recherche de logs sur
cette cible textuelle seule reste incomplète. Cette capture montre une option
de configuration et sa limite, pas un résultat métier validé.*

Le scan reste borné : 16 Kio de texte et 32 fragments/candidats par extraction,
puis budgets de documents, de période et de réponse OpenSearch. Des IP candidates
invalides sont ignorées ; trop de texte ou de candidats déclenche une erreur.
Une troncature, une identité partagée ou un budget dépassé doit donner un état
incomplet/ambigu, pas une recherche annoncée exhaustive. Avant le SI réel,
recevoir ce format sur ses messages représentatifs et ses volumes ; un autre
format demande une normalisation à l’ingestion ou une évolution du parseur.
Pour le parcours TACACS de ce PoC, faire fournir un champ de gestion `ip`
compatible, puis reprendre l’étape 4 et rejouer les exclusions. Si le SI ne peut
le fournir, traiter le raccordement de ce flux comme **non qualifié**, avec une
évolution à prévoir ; ne pas annoncer que le réglage du formulaire suffit.

### 8. Autres options avancées : quand les utiliser

| Situation du SI | Saisie à faire confirmer | Limite à connaître |
| --- | --- | --- |
| Champ `text` avec sous-champ exact `.keyword` | Sélectionner le sous-champ `keyword` pour chercher ; le **Champ de lecture dans le document source** doit désigner le parent réellement présent dans `_source`. | Exemple : recherche `host.name.keyword`, lecture `host.name`. Le sous-champ doit être découvert et compatible ; ne pas l’inventer. |
| Uniquement un FQDN stable, sans ID métier | Rôle FQDN, groupe dédié, case **Nom/FQDN confirmé comme point de départ de l’identité**, après preuve d’unicité. | Un seul groupe d’ancre commun. Il s’agit d’une alternative à l’ancre `asset-id`, pas d’un ajout à cocher dans cet exemple. |
| Nom court à rapprocher d’un FQDN | Pour un rôle FQDN, choisir **Rapprochement FQDN → Préfixe de nom court confirmé**. | Un préfixe partagé ou ambigu reste à clarifier. Un rapprochement approuvé ne prouve pas la stabilité d’un nom. |
| Rollover ou plusieurs index d’une famille | Préparer le sélecteur borné dans le YAML, puis vérifier chaque index physique résolu. | Chaque index reçoit son propre mapping et sa revue. La validation métier d’une famille n’approuve pas ses futurs index. |

Ces options sont conditionnelles. Les captures du parcours principal montrent
les champs du corpus structuré ; elles ne démontrent pas la compatibilité
avec un schéma réel différent.

### 9. Recette de la correspondance approuvée

Pour le corpus structuré de départ, la recherche croisée doit retenir
**six documents** :

| Index | Documents attendus |
| --- | --- |
| `rie-pfs-fixture` | `pfs-a-1`, `pfs-a-2` |
| `rie-bb-fixture` | `bb-a-1` |
| `rie-pfaing-fixture` | `pfaing-reference-only` |
| `rie-tacacs-fixture` | `tacacs-ipv4-only`, `tacacs-ipv6-only` |

Les événements `tacacs-client-ip-decoy`, `tacacs-unrelated`,
`tacacs-other-scope` et `tacacs-other-day` doivent rester exclus. Une recherche
limitée à TACACS doit utiliser les sources PFS/BB nécessaires à l’identité,
mais ne publier que les deux événements TACACS demandés.

Dans une conversation PDL avec Albert, par exemple :

```text
Retrouve les logs de edge-a dans demo-alpha, le 12 octobre 2026 de 08:00 à 09:00 UTC, dans PFS, Backbone, PFAING et TACACS.
```

Puis, pour contrôler la restriction des sources :

```text
Même équipement, même période et même périmètre : garde seulement TACACS.
```

Contrôler les index réellement lus, les preuves de résolution, la période,
le périmètre et les exclusions ; ne pas se fier uniquement à la prose générée.
Un compte sans droit sur une source nécessaire doit être refusé avant lecture.
La réception SI utilise ses vrais identifiants et événements de référence,
pas les noms et les nombres de cet exemple.

### Fichier YAML complet du parcours structuré

Ce fichier est l’exemple synthétique livré sous
`deploy/ubuntu/examples/pdl-demo-mappings.yaml`. Il peut être importé dans
le laboratoire correspondant. Pour le SI réel, les champs, valeurs, sélecteurs
et relations sont à renseigner d’après son inventaire et à faire confirmer.

```yaml
# Operator mapping file: synthetic demonstration only, never a production template.
# Change match to an allowed physical index name or a bounded wildcard selector.
# field/type must match the current inventory; preserve business value casing.
# Loading creates pending reviews. A human must approve every physical index.
# Relations declare business equivalence; an IP type alone proves no equipment identity.
# Client traffic IPs are intentionally absent from management-ip.
# One anchor namespace (asset-id here) joins the identity sources.
# Names, FQDNs, stable IDs, management IPs and references remain distinct namespaces.
version: 1
indices:
  pfs:
    match: rie-pfs-fixture
    concepts:
      timestamp:
        field: '@timestamp'
        type: date
      network_scope:
        field: network.scope
        type: keyword
        values:
        - demo-alpha
        - demo-beta
      equipment:
        field: observer.name
        type: keyword
        identity_role: name
      stable_id:
        field: asset.id
        type: keyword
        identity_role: id
      management_ip:
        field: observer.ip
        type: ip
        identity_role: ip
      equipment_reference:
        field: asset.reference
        type: keyword
        identity_role: reference
      source_ip:
        field: source.ip
        type: ip
      destination_ip:
        field: destination.ip
        type: ip
      virtual_domain:
        field: observer.virtual_domain
        type: keyword
      rule:
        field: rule.id
        type: keyword
      action:
        field: event.action
        type: keyword
        values:
        - deny
        - allow
      equipment_fqdn:
        field: observer.fqdn
        type: keyword
        identity_role: fqdn
  bb:
    match: rie-bb-fixture
    concepts:
      timestamp:
        field: '@timestamp'
        type: date
      network_scope:
        field: network.scope
        type: keyword
        values:
        - demo-alpha
        - demo-beta
      equipment:
        field: host.name
        type: keyword
        identity_role: name
      stable_id:
        field: asset.id
        type: keyword
        identity_role: id
      management_ip:
        field: host.ip
        type: ip
        identity_role: ip
      event_type:
        field: event.code
        type: keyword
      severity:
        field: event.severity
        type: long
  pfaing:
    match: rie-pfaing-fixture
    concepts:
      timestamp:
        field: '@timestamp'
        type: date
      network_scope:
        field: network.scope
        type: keyword
        values:
        - demo-alpha
        - demo-beta
      equipment_reference:
        field: gateway.ref
        type: keyword
        identity_role: reference
      equipment:
        field: observer.hostname
        type: keyword
      source_ip:
        field: client.ip
        type: ip
      destination_ip:
        field: server.ip
        type: ip
      domain:
        field: url.domain
        type: keyword
      url:
        field: url.original
        type: keyword
      action:
        field: event.action
        type: keyword
        values:
        - deny
        - allow
  tacacs:
    match: rie-tacacs-fixture
    concepts:
      timestamp:
        field: '@timestamp'
        type: date
      network_scope:
        field: network.scope
        type: keyword
        values:
        - demo-alpha
        - demo-beta
      management_destination:
        field: log.tacacs.dest
        type: ip
        identity_role: ip
      action:
        field: event.action
        type: keyword
        values:
        - login
        - logout
        - command
      message:
        field: message
        type: text
relations:
  equipment-name:
    pfs:
    - equipment
    bb:
    - equipment
  asset-id:
    pfs:
    - stable_id
    bb:
    - stable_id
  management-ip:
    pfs:
    - management_ip
    bb:
    - management_ip
    tacacs:
    - management_destination
  asset-reference:
    pfs:
    - equipment_reference
    pfaing:
    - equipment_reference
  equipment-fqdn:
    pfs:
    - equipment_fqdn
```

## Référence technique du moteur

Le moteur portable transforme une question métier en lectures bornées. Le
contrat MCP est `investigate_pdl(question, continuation_token='')` : aucun DSL,
nom de champ arbitraire, email ou rôle n'est transmis comme autorisation.


```diagram
PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgwIiBoZWlnaHQ9IjkwMCIgdmlld0JveD0iMCAwIDEyODAgOTAwIiByb2xlPSJpbWciIGFyaWEtbGFiZWxsZWRieT0idGl0bGUgZGVzYyIgY29udGVudD0iJmx0Oz94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPyZndDsmIzEwOyZsdDtteGZpbGUgaG9zdD0mcXVvdDthcHAuZGlhZ3JhbXMubmV0JnF1b3Q7IHR5cGU9JnF1b3Q7ZGV2aWNlJnF1b3Q7Jmd0OyZsdDtkaWFncmFtIGlkPSZxdW90OzAzLWZsdXgtcGRsJnF1b3Q7IG5hbWU9JnF1b3Q7UERMIOKAlCBkZSBsYSBxdWVzdGlvbiBhdXggcHJldXZlcyZxdW90OyZndDsmbHQ7bXhHcmFwaE1vZGVsIGR4PSZxdW90OzEyODAmcXVvdDsgZHk9JnF1b3Q7OTAwJnF1b3Q7IGdyaWQ9JnF1b3Q7MSZxdW90OyBncmlkU2l6ZT0mcXVvdDsxMCZxdW90OyBndWlkZXM9JnF1b3Q7MSZxdW90OyB0b29sdGlwcz0mcXVvdDsxJnF1b3Q7IGNvbm5lY3Q9JnF1b3Q7MSZxdW90OyBhcnJvd3M9JnF1b3Q7MSZxdW90OyBmb2xkPSZxdW90OzEmcXVvdDsgcGFnZT0mcXVvdDsxJnF1b3Q7IHBhZ2VTY2FsZT0mcXVvdDsxJnF1b3Q7IHBhZ2VXaWR0aD0mcXVvdDsxMjgwJnF1b3Q7IHBhZ2VIZWlnaHQ9JnF1b3Q7OTAwJnF1b3Q7IG1hdGg9JnF1b3Q7MCZxdW90OyBzaGFkb3c9JnF1b3Q7MCZxdW90OyZndDsmbHQ7cm9vdCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90OzAmcXVvdDsgLyZndDsmbHQ7bXhDZWxsIGlkPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzAmcXVvdDsgLyZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2hlYWRpbmcmcXVvdDsgdmFsdWU9JnF1b3Q7UERMIOKAlCBkZSBsYSBxdWVzdGlvbiBhdXggcHJldXZlcyZxdW90OyBzdHlsZT0mcXVvdDt0ZXh0O2h0bWw9MDthbGlnbj1sZWZ0O3ZlcnRpY2FsQWxpZ249bWlkZGxlO2ZvbnRTaXplPTI1O2ZvbnRTdHlsZT0xO2ZvbnRDb2xvcj0jMTcyYjRkOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzM1JnF1b3Q7IHk9JnF1b3Q7MjAmcXVvdDsgd2lkdGg9JnF1b3Q7MTIxMCZxdW90OyBoZWlnaHQ9JnF1b3Q7NDAmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O3N1YnRpdGxlJnF1b3Q7IHZhbHVlPSZxdW90O0xlIHNlcnZldXIgY29tcGlsZSBldCBjb250csO0bGUgOyBsZSBtb2TDqGxlIHByb3Bvc2UgdW5lIGludGVudGlvbiwgamFtYWlzIGRlcyBkcm9pdHMmcXVvdDsgc3R5bGU9JnF1b3Q7dGV4dDtodG1sPTA7YWxpZ249bGVmdDt2ZXJ0aWNhbEFsaWduPW1pZGRsZTtmb250U2l6ZT0xNDtmb250Q29sb3I9IzU0NjE3MDsmcXVvdDsgdmVydGV4PSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgeD0mcXVvdDszNSZxdW90OyB5PSZxdW90OzY1JnF1b3Q7IHdpZHRoPSZxdW90OzEyMTAmcXVvdDsgaGVpZ2h0PSZxdW90OzMwJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtjbGllbnQmcXVvdDsgdmFsdWU9JnF1b3Q7UXVlc3Rpb24gY29tcGzDqHRlJmFtcDsjMTA7KyBqZXRvbiBkZSByZXByaXNlJnF1b3Q7IHN0eWxlPSZxdW90O3JvdW5kZWQ9MTt3aGl0ZVNwYWNlPXdyYXA7aHRtbD0wO2FyY1NpemU9MTI7ZmlsbENvbG9yPSNlYWYxZmI7c3Ryb2tlQ29sb3I9IzI0NGU4Njtmb250Q29sb3I9IzE3MmI0ZDtmb250U2l6ZT0xNztzcGFjaW5nPTEwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzU1JnF1b3Q7IHk9JnF1b3Q7MTIwJnF1b3Q7IHdpZHRoPSZxdW90OzI4MCZxdW90OyBoZWlnaHQ9JnF1b3Q7OTUmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2lkZW50aXR5JnF1b3Q7IHZhbHVlPSZxdW90O0pldG9uIGluZGl2aWR1ZWwmYW1wOyMxMDtMREFQICsgcG9saXRpcXVlJnF1b3Q7IHN0eWxlPSZxdW90O3JvdW5kZWQ9MTt3aGl0ZVNwYWNlPXdyYXA7aHRtbD0wO2FyY1NpemU9MTI7ZmlsbENvbG9yPSNkZmYzZTg7c3Ryb2tlQ29sb3I9IzE4NmI1Mztmb250Q29sb3I9IzE3MmI0ZDtmb250U2l6ZT0xNztzcGFjaW5nPTEwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzQ4MCZxdW90OyB5PSZxdW90OzEyMCZxdW90OyB3aWR0aD0mcXVvdDsyODUmcXVvdDsgaGVpZ2h0PSZxdW90Ozk1JnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtkaWFsb2d1ZSZxdW90OyB2YWx1ZT0mcXVvdDtEaWFsb2d1ZSBzZXJ2ZXVyJmFtcDsjMTA7Q2xhcmlmaWNhdGlvbiBvdSBpbnRlbnRpb24mcXVvdDsgc3R5bGU9JnF1b3Q7cm91bmRlZD0xO3doaXRlU3BhY2U9d3JhcDtodG1sPTA7YXJjU2l6ZT0xMjtmaWxsQ29sb3I9I2ZmZmZmZjtzdHJva2VDb2xvcj0jMjQ0ZTg2O2ZvbnRDb2xvcj0jMTcyYjRkO2ZvbnRTaXplPTE3O3NwYWNpbmc9MTA7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7OTIwJnF1b3Q7IHk9JnF1b3Q7MTIwJnF1b3Q7IHdpZHRoPSZxdW90OzMwMCZxdW90OyBoZWlnaHQ9JnF1b3Q7OTUmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2NhdGFsb2cmcXVvdDsgdmFsdWU9JnF1b3Q7SW52ZW50YWlyZSArIGNhdGFsb2d1ZSZhbXA7IzEwO01hcHBpbmdzIGFwcHJvdXbDqXMmcXVvdDsgc3R5bGU9JnF1b3Q7cm91bmRlZD0xO3doaXRlU3BhY2U9d3JhcDtodG1sPTA7YXJjU2l6ZT0xMjtmaWxsQ29sb3I9I2VhZjZmMTtzdHJva2VDb2xvcj0jMTg2YjUzO2ZvbnRDb2xvcj0jMTcyYjRkO2ZvbnRTaXplPTE3O3NwYWNpbmc9MTA7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7NjUmcXVvdDsgeT0mcXVvdDszNzUmcXVvdDsgd2lkdGg9JnF1b3Q7MzAwJnF1b3Q7IGhlaWdodD0mcXVvdDs5NSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7cGxhbiZxdW90OyB2YWx1ZT0mcXVvdDtWYWxpZGF0aW9uIGR1IHBsYW4mYW1wOyMxMDtQw6lyaW9kZSwgcG9ydMOpZSwgbGltaXRlcyZxdW90OyBzdHlsZT0mcXVvdDtyb3VuZGVkPTE7d2hpdGVTcGFjZT13cmFwO2h0bWw9MDthcmNTaXplPTEyO2ZpbGxDb2xvcj0jZmZmZmZmO3N0cm9rZUNvbG9yPSMyNDRlODY7Zm9udENvbG9yPSMxNzJiNGQ7Zm9udFNpemU9MTc7c3BhY2luZz0xMDsmcXVvdDsgdmVydGV4PSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgeD0mcXVvdDs0ODAmcXVvdDsgeT0mcXVvdDszNzUmcXVvdDsgd2lkdGg9JnF1b3Q7MzEwJnF1b3Q7IGhlaWdodD0mcXVvdDs5NSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7Y29tcGlsZSZxdW90OyB2YWx1ZT0mcXVvdDtDb21waWxhdGlvbiBEU0wmYW1wOyMxMDtSZXF1w6p0ZXMgYXV0b3Jpc8OpZXMmcXVvdDsgc3R5bGU9JnF1b3Q7cm91bmRlZD0xO3doaXRlU3BhY2U9d3JhcDtodG1sPTA7YXJjU2l6ZT0xMjtmaWxsQ29sb3I9I2ZmZmZmZjtzdHJva2VDb2xvcj0jMjQ0ZTg2O2ZvbnRDb2xvcj0jMTcyYjRkO2ZvbnRTaXplPTE3O3NwYWNpbmc9MTA7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7OTMwJnF1b3Q7IHk9JnF1b3Q7Mzc1JnF1b3Q7IHdpZHRoPSZxdW90OzI4NSZxdW90OyBoZWlnaHQ9JnF1b3Q7OTUmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O29zJnF1b3Q7IHZhbHVlPSZxdW90O09wZW5TZWFyY2gmYW1wOyMxMDtMZWN0dXJlcyBzZXVsZW1lbnQmcXVvdDsgc3R5bGU9JnF1b3Q7cm91bmRlZD0xO3doaXRlU3BhY2U9d3JhcDtodG1sPTA7YXJjU2l6ZT0xMjtmaWxsQ29sb3I9I2VhZjZmMTtzdHJva2VDb2xvcj0jMTg2YjUzO2ZvbnRDb2xvcj0jMTcyYjRkO2ZvbnRTaXplPTE3O3NwYWNpbmc9MTA7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7NTAwJnF1b3Q7IHk9JnF1b3Q7NjUwJnF1b3Q7IHdpZHRoPSZxdW90OzI4NSZxdW90OyBoZWlnaHQ9JnF1b3Q7OTUmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O3Byb29mJnF1b3Q7IHZhbHVlPSZxdW90O1LDqXN1bHRhdCBzdHJ1Y3R1csOpJmFtcDsjMTA7RmFpdHMsIERTTCwgcHJvdmVuYW5jZSZhbXA7IzEwO1JlZnVzIG91IHJldnVlIHNpIG7DqWNlc3NhaXJlJnF1b3Q7IHN0eWxlPSZxdW90O3JvdW5kZWQ9MTt3aGl0ZVNwYWNlPXdyYXA7aHRtbD0wO2FyY1NpemU9MTI7ZmlsbENvbG9yPSNlYWYxZmI7c3Ryb2tlQ29sb3I9IzI0NGU4Njtmb250Q29sb3I9IzE3MmI0ZDtmb250U2l6ZT0xNztzcGFjaW5nPTEwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90Ozg4MCZxdW90OyB5PSZxdW90OzY1MCZxdW90OyB3aWR0aD0mcXVvdDszNDAmcXVvdDsgaGVpZ2h0PSZxdW90OzExMiZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS0wJnF1b3Q7IHZhbHVlPSZxdW90O01DUCZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0xO2V4aXRZPTAuNDIxMDUyNjMxNTc4OTQ3MzU7ZW50cnlYPTA7ZW50cnlZPTAuNDIxMDUyNjMxNTc4OTQ3MzU7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7Y2xpZW50JnF1b3Q7IHRhcmdldD0mcXVvdDtpZGVudGl0eSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzAuMCZxdW90OyB5PSZxdW90Oy0xNC4wJnF1b3Q7IGFzPSZxdW90O29mZnNldCZxdW90OyAvJmd0OyZsdDsvbXhHZW9tZXRyeSZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2VkZ2UtMSZxdW90OyB2YWx1ZT0mcXVvdDtTdWpldCB2w6lyaWZpw6kmcXVvdDsgc3R5bGU9JnF1b3Q7ZWRnZVN0eWxlPW9ydGhvZ29uYWxFZGdlU3R5bGU7cm91bmRlZD0xO2h0bWw9MDtlbmRBcnJvdz1ibG9jaztlbmRGaWxsPTE7c3Ryb2tlQ29sb3I9IzY4Nzc4YjtzdHJva2VXaWR0aD0yO2ZvbnRTaXplPTEyO2ZvbnRDb2xvcj0jM2M0ZDYyO2xhYmVsQmFja2dyb3VuZENvbG9yPSNmZmZmZmY7ZXhpdFg9MTtleGl0WT0wLjQyMTA1MjYzMTU3ODk0NzM1O2VudHJ5WD0wO2VudHJ5WT0wLjQyMTA1MjYzMTU3ODk0NzM1O2V4aXRQZXJpbWV0ZXI9MDtlbnRyeVBlcmltZXRlcj0wOyZxdW90OyBlZGdlPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsgc291cmNlPSZxdW90O2lkZW50aXR5JnF1b3Q7IHRhcmdldD0mcXVvdDtkaWFsb2d1ZSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzAuMCZxdW90OyB5PSZxdW90Oy0xNC4wJnF1b3Q7IGFzPSZxdW90O29mZnNldCZxdW90OyAvJmd0OyZsdDsvbXhHZW9tZXRyeSZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2VkZ2UtMiZxdW90OyB2YWx1ZT0mcXVvdDsmcXVvdDsgc3R5bGU9JnF1b3Q7ZWRnZVN0eWxlPW9ydGhvZ29uYWxFZGdlU3R5bGU7cm91bmRlZD0xO2h0bWw9MDtlbmRBcnJvdz1ibG9jaztlbmRGaWxsPTE7c3Ryb2tlQ29sb3I9IzY4Nzc4YjtzdHJva2VXaWR0aD0yO2ZvbnRTaXplPTEyO2ZvbnRDb2xvcj0jM2M0ZDYyO2xhYmVsQmFja2dyb3VuZENvbG9yPSNmZmZmZmY7ZXhpdFg9MTtleGl0WT0wLjQ3MzY4NDIxMDUyNjMxNTc2O2VudHJ5WD0wO2VudHJ5WT0wLjQ3MzY4NDIxMDUyNjMxNTc2O2V4aXRQZXJpbWV0ZXI9MDtlbnRyeVBlcmltZXRlcj0wOyZxdW90OyBlZGdlPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsgc291cmNlPSZxdW90O2NhdGFsb2cmcXVvdDsgdGFyZ2V0PSZxdW90O3BsYW4mcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgcmVsYXRpdmU9JnF1b3Q7MSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyZndDsmbHQ7QXJyYXkgYXM9JnF1b3Q7cG9pbnRzJnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS0zJnF1b3Q7IHZhbHVlPSZxdW90O1Byb3Bvc2l0aW9uJnF1b3Q7IHN0eWxlPSZxdW90O2VkZ2VTdHlsZT1vcnRob2dvbmFsRWRnZVN0eWxlO3JvdW5kZWQ9MTtodG1sPTA7ZW5kQXJyb3c9YmxvY2s7ZW5kRmlsbD0xO3N0cm9rZUNvbG9yPSM2ODc3OGI7c3Ryb2tlV2lkdGg9Mjtmb250U2l6ZT0xMjtmb250Q29sb3I9IzNjNGQ2MjtsYWJlbEJhY2tncm91bmRDb2xvcj0jZmZmZmZmO2V4aXRYPTA7ZXhpdFk9MC40MjEwNTI2MzE1Nzg5NDczNTtlbnRyeVg9MTtlbnRyeVk9MC40NzM2ODQyMTA1MjYzMTU3NjtleGl0UGVyaW1ldGVyPTA7ZW50cnlQZXJpbWV0ZXI9MDsmcXVvdDsgZWRnZT0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7IHNvdXJjZT0mcXVvdDtkaWFsb2d1ZSZxdW90OyB0YXJnZXQ9JnF1b3Q7cGxhbiZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs4ODAmcXVvdDsgeT0mcXVvdDsxNjAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90Ozg4MCZxdW90OyB5PSZxdW90OzQyMCZxdW90OyAvJmd0OyZsdDsvQXJyYXkmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDswLjAmcXVvdDsgeT0mcXVvdDstMzkuMCZxdW90OyBhcz0mcXVvdDtvZmZzZXQmcXVvdDsgLyZndDsmbHQ7L214R2VvbWV0cnkmZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtlZGdlLTQmcXVvdDsgdmFsdWU9JnF1b3Q7UGxhbiBhY2NlcHTDqSZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0xO2V4aXRZPTAuNDczNjg0MjEwNTI2MzE1NzY7ZW50cnlYPTA7ZW50cnlZPTAuNDczNjg0MjEwNTI2MzE1NzY7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7cGxhbiZxdW90OyB0YXJnZXQ9JnF1b3Q7Y29tcGlsZSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzAuMCZxdW90OyB5PSZxdW90Oy0xNC4wJnF1b3Q7IGFzPSZxdW90O29mZnNldCZxdW90OyAvJmd0OyZsdDsvbXhHZW9tZXRyeSZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2VkZ2UtNSZxdW90OyB2YWx1ZT0mcXVvdDtJbmRleCBjb25jcmV0cyZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0wO2V4aXRZPTAuNDczNjg0MjEwNTI2MzE1NzY7ZW50cnlYPTE7ZW50cnlZPTAuNTI2MzE1Nzg5NDczNjg0MjtleGl0UGVyaW1ldGVyPTA7ZW50cnlQZXJpbWV0ZXI9MDsmcXVvdDsgZWRnZT0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7IHNvdXJjZT0mcXVvdDtjb21waWxlJnF1b3Q7IHRhcmdldD0mcXVvdDtvcyZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs5MDAmcXVvdDsgeT0mcXVvdDs0MjAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzkwMCZxdW90OyB5PSZxdW90OzYyMCZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7ODIwJnF1b3Q7IHk9JnF1b3Q7NjIwJnF1b3Q7IC8mZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs4MjAmcXVvdDsgeT0mcXVvdDs3MDAmcXVvdDsgLyZndDsmbHQ7L0FycmF5Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7MC4wJnF1b3Q7IHk9JnF1b3Q7LTk2LjUmcXVvdDsgYXM9JnF1b3Q7b2Zmc2V0JnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS02JnF1b3Q7IHZhbHVlPSZxdW90OyZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0xO2V4aXRZPTAuNTI2MzE1Nzg5NDczNjg0MjtlbnRyeVg9MDtlbnRyeVk9MC40NDY0Mjg1NzE0Mjg1NzE0NTtleGl0UGVyaW1ldGVyPTA7ZW50cnlQZXJpbWV0ZXI9MDsmcXVvdDsgZWRnZT0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7IHNvdXJjZT0mcXVvdDtvcyZxdW90OyB0YXJnZXQ9JnF1b3Q7cHJvb2YmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgcmVsYXRpdmU9JnF1b3Q7MSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyZndDsmbHQ7QXJyYXkgYXM9JnF1b3Q7cG9pbnRzJnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS03JnF1b3Q7IHZhbHVlPSZxdW90O1LDqXBvbnNlICsgbGltaXRlcyZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0wO2V4aXRZPTAuNDQ2NDI4NTcxNDI4NTcxNDU7ZW50cnlYPTE7ZW50cnlZPTAuNDIxMDUyNjMxNTc4OTQ3MzU7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7cHJvb2YmcXVvdDsgdGFyZ2V0PSZxdW90O2NsaWVudCZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs4NDAmcXVvdDsgeT0mcXVvdDs3MDAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90Ozg0MCZxdW90OyB5PSZxdW90OzI0MCZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7MzYwJnF1b3Q7IHk9JnF1b3Q7MjQwJnF1b3Q7IC8mZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDszNjAmcXVvdDsgeT0mcXVvdDsxNjAmcXVvdDsgLyZndDsmbHQ7L0FycmF5Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7LTE5Ny41JnF1b3Q7IHk9JnF1b3Q7MTQuMCZxdW90OyBhcz0mcXVvdDtvZmZzZXQmcXVvdDsgLyZndDsmbHQ7L214R2VvbWV0cnkmZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0Oy9yb290Jmd0OyZsdDsvbXhHcmFwaE1vZGVsJmd0OyZsdDsvZGlhZ3JhbSZndDsmbHQ7L214ZmlsZSZndDsiPjx0aXRsZSBpZD0idGl0bGUiPlBETCDigJQgZGUgbGEgcXVlc3Rpb24gYXV4IHByZXV2ZXM8L3RpdGxlPjxkZXNjIGlkPSJkZXNjIj5MZSBzZXJ2ZXVyIGNvbXBpbGUgZXQgY29udHLDtGxlIDsgbGUgbW9kw6hsZSBwcm9wb3NlIHVuZSBpbnRlbnRpb24sIGphbWFpcyBkZXMgZHJvaXRzPC9kZXNjPjxkZWZzPjxtYXJrZXIgaWQ9ImFycm93IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHJlZlg9IjkiIHJlZlk9IjUiIG1hcmtlcldpZHRoPSI4IiBtYXJrZXJIZWlnaHQ9IjgiIG9yaWVudD0iYXV0by1zdGFydC1yZXZlcnNlIj48cGF0aCBkPSJNIDAgMCBMIDEwIDUgTCAwIDEwIHoiIGZpbGw9IiM2ODc3OGIiIC8+PC9tYXJrZXI+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMjgwIiBoZWlnaHQ9IjkwMCIgZmlsbD0iI2ZmZmZmZiIgLz48dGV4dCB4PSIzNSIgeT0iNDgiIGZpbGw9IiMxNzJiNGQiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNSIgZm9udC13ZWlnaHQ9IjcwMCI+UERMIOKAlCBkZSBsYSBxdWVzdGlvbiBhdXggcHJldXZlczwvdGV4dD48dGV4dCB4PSIzNSIgeT0iNzgiIGZpbGw9IiM1NDYxNzAiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCI+TGUgc2VydmV1ciBjb21waWxlIGV0IGNvbnRyw7RsZSA7IGxlIG1vZMOobGUgcHJvcG9zZSB1bmUgaW50ZW50aW9uLCBqYW1haXMgZGVzIGRyb2l0czwvdGV4dD48cG9seWxpbmUgcG9pbnRzPSIzMzUuMCwxNjAgNDgwLjAsMTYwIiBmaWxsPSJub25lIiBzdHJva2U9IiM2ODc3OGIiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgbWFya2VyLWVuZD0idXJsKCNhcnJvdykiIC8+PHBvbHlsaW5lIHBvaW50cz0iNzY1LjAsMTYwIDkyMC4wLDE2MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjg3NzhiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIG1hcmtlci1lbmQ9InVybCgjYXJyb3cpIiAvPjxwb2x5bGluZSBwb2ludHM9IjM2NS4wLDQyMCA0ODAuMCw0MjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI5MjAuMCwxNjAgODgwLDE2MCA4ODAsNDIwIDc5MC4wLDQyMCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjg3NzhiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIG1hcmtlci1lbmQ9InVybCgjYXJyb3cpIiAvPjxwb2x5bGluZSBwb2ludHM9Ijc5MC4wLDQyMCA5MzAuMCw0MjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI5MzAuMCw0MjAgOTAwLDQyMCA5MDAsNjIwIDgyMCw2MjAgODIwLDcwMCA3ODUuMCw3MDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI3ODUuMCw3MDAgODgwLjAsNzAwIiBmaWxsPSJub25lIiBzdHJva2U9IiM2ODc3OGIiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgbWFya2VyLWVuZD0idXJsKCNhcnJvdykiIC8+PHBvbHlsaW5lIHBvaW50cz0iODgwLjAsNzAwIDg0MCw3MDAgODQwLDI0MCAzNjAsMjQwIDM2MCwxNjAgMzM1LjAsMTYwIiBmaWxsPSJub25lIiBzdHJva2U9IiM2ODc3OGIiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgbWFya2VyLWVuZD0idXJsKCNhcnJvdykiIC8+PHJlY3QgeD0iNTUuMCIgeT0iMTIwLjAiIHdpZHRoPSIyODAuMCIgaGVpZ2h0PSI5NS4wIiByeD0iMTIiIGZpbGw9IiNlYWYxZmIiIHN0cm9rZT0iIzI0NGU4NiIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjE5NS4wIiB5PSIxNjIuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5RdWVzdGlvbiBjb21wbMOodGU8L3RleHQ+PHRleHQgeD0iMTk1LjAiIHk9IjE4NC41IiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPisgamV0b24gZGUgcmVwcmlzZTwvdGV4dD48cmVjdCB4PSI0ODAuMCIgeT0iMTIwLjAiIHdpZHRoPSIyODUuMCIgaGVpZ2h0PSI5NS4wIiByeD0iMTIiIGZpbGw9IiNkZmYzZTgiIHN0cm9rZT0iIzE4NmI1MyIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjYyMi41IiB5PSIxNjIuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5KZXRvbiBpbmRpdmlkdWVsPC90ZXh0Pjx0ZXh0IHg9IjYyMi41IiB5PSIxODQuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5MREFQICsgcG9saXRpcXVlPC90ZXh0PjxyZWN0IHg9IjkyMC4wIiB5PSIxMjAuMCIgd2lkdGg9IjMwMC4wIiBoZWlnaHQ9Ijk1LjAiIHJ4PSIxMiIgZmlsbD0iI2ZmZmZmZiIgc3Ryb2tlPSIjMjQ0ZTg2IiBzdHJva2Utd2lkdGg9IjIiIC8+PHRleHQgeD0iMTA3MC4wIiB5PSIxNjIuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5EaWFsb2d1ZSBzZXJ2ZXVyPC90ZXh0Pjx0ZXh0IHg9IjEwNzAuMCIgeT0iMTg0LjUiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjQwMCI+Q2xhcmlmaWNhdGlvbiBvdSBpbnRlbnRpb248L3RleHQ+PHJlY3QgeD0iNjUuMCIgeT0iMzc1LjAiIHdpZHRoPSIzMDAuMCIgaGVpZ2h0PSI5NS4wIiByeD0iMTIiIGZpbGw9IiNlYWY2ZjEiIHN0cm9rZT0iIzE4NmI1MyIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjIxNS4wIiB5PSI0MTcuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5JbnZlbnRhaXJlICsgY2F0YWxvZ3VlPC90ZXh0Pjx0ZXh0IHg9IjIxNS4wIiB5PSI0MzkuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5NYXBwaW5ncyBhcHByb3V2w6lzPC90ZXh0PjxyZWN0IHg9IjQ4MC4wIiB5PSIzNzUuMCIgd2lkdGg9IjMxMC4wIiBoZWlnaHQ9Ijk1LjAiIHJ4PSIxMiIgZmlsbD0iI2ZmZmZmZiIgc3Ryb2tlPSIjMjQ0ZTg2IiBzdHJva2Utd2lkdGg9IjIiIC8+PHRleHQgeD0iNjM1LjAiIHk9IjQxNy41IiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI2MDAiPlZhbGlkYXRpb24gZHUgcGxhbjwvdGV4dD48dGV4dCB4PSI2MzUuMCIgeT0iNDM5LjUiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjQwMCI+UMOpcmlvZGUsIHBvcnTDqWUsIGxpbWl0ZXM8L3RleHQ+PHJlY3QgeD0iOTMwLjAiIHk9IjM3NS4wIiB3aWR0aD0iMjg1LjAiIGhlaWdodD0iOTUuMCIgcng9IjEyIiBmaWxsPSIjZmZmZmZmIiBzdHJva2U9IiMyNDRlODYiIHN0cm9rZS13aWR0aD0iMiIgLz48dGV4dCB4PSIxMDcyLjUiIHk9IjQxNy41IiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI2MDAiPkNvbXBpbGF0aW9uIERTTDwvdGV4dD48dGV4dCB4PSIxMDcyLjUiIHk9IjQzOS41IiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPlJlcXXDqnRlcyBhdXRvcmlzw6llczwvdGV4dD48cmVjdCB4PSI1MDAuMCIgeT0iNjUwLjAiIHdpZHRoPSIyODUuMCIgaGVpZ2h0PSI5NS4wIiByeD0iMTIiIGZpbGw9IiNlYWY2ZjEiIHN0cm9rZT0iIzE4NmI1MyIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjY0Mi41IiB5PSI2OTIuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5PcGVuU2VhcmNoPC90ZXh0Pjx0ZXh0IHg9IjY0Mi41IiB5PSI3MTQuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5MZWN0dXJlcyBzZXVsZW1lbnQ8L3RleHQ+PHJlY3QgeD0iODgwLjAiIHk9IjY1MC4wIiB3aWR0aD0iMzQwLjAiIGhlaWdodD0iMTEyLjAiIHJ4PSIxMiIgZmlsbD0iI2VhZjFmYiIgc3Ryb2tlPSIjMjQ0ZTg2IiBzdHJva2Utd2lkdGg9IjIiIC8+PHRleHQgeD0iMTA1MC4wIiB5PSI2OTAuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5Sw6lzdWx0YXQgc3RydWN0dXLDqTwvdGV4dD48dGV4dCB4PSIxMDUwLjAiIHk9IjcxMi4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPkZhaXRzLCBEU0wsIHByb3ZlbmFuY2U8L3RleHQ+PHRleHQgeD0iMTA1MC4wIiB5PSI3MzQuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5SZWZ1cyBvdSByZXZ1ZSBzaSBuw6ljZXNzYWlyZTwvdGV4dD48dGV4dCB4PSIzNSIgeT0iODg0IiBmaWxsPSIjNTQ2MTcwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTIiPkRvY3VtZW50YXRpb24gU0ktUklFIOKAoiBTb3VyY2UgbmF0aXZlIC5kcmF3aW8gw6lkaXRhYmxlIOKAoiBEb25uw6llcyBmaWN0aXZlcyBwb3VyIGxlcyBkw6ltb25zdHJhdGlvbnM8L3RleHQ+PHJlY3QgeD0iMzkxLjkiIHk9IjEzNi4wIiB3aWR0aD0iMzEuMjAwMDAwMDAwMDAwMDAzIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMC45NiIgLz48dGV4dCB4PSI0MDcuNSIgeT0iMTUwLjAiIGZpbGw9IiMzYzRkNjIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxMiI+TUNQPC90ZXh0PjxyZWN0IHg9Ijc5NC45IiB5PSIxMzYuMCIgd2lkdGg9Ijk1LjIiIGhlaWdodD0iMjAiIHJ4PSIzIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjk2IiAvPjx0ZXh0IHg9Ijg0Mi41IiB5PSIxNTAuMCIgZmlsbD0iIzNjNGQ2MiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5TdWpldCB2w6lyaWZpw6k8L3RleHQ+PHJlY3QgeD0iODM4LjgiIHk9IjI2Ni4wIiB3aWR0aD0iODIuNCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjAuOTYiIC8+PHRleHQgeD0iODgwLjAiIHk9IjI4MC4wIiBmaWxsPSIjM2M0ZDYyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTIiPlByb3Bvc2l0aW9uPC90ZXh0PjxyZWN0IHg9IjgxNS42IiB5PSIzOTYuMCIgd2lkdGg9Ijg4LjgwMDAwMDAwMDAwMDAxIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMC45NiIgLz48dGV4dCB4PSI4NjAuMCIgeT0iNDEwLjAiIGZpbGw9IiMzYzRkNjIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxMiI+UGxhbiBhY2NlcHTDqTwvdGV4dD48cmVjdCB4PSI4NDkuMiIgeT0iNDk2LjAiIHdpZHRoPSIxMDEuNjAwMDAwMDAwMDAwMDEiIGhlaWdodD0iMjAiIHJ4PSIzIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjk2IiAvPjx0ZXh0IHg9IjkwMC4wIiB5PSI1MTAuMCIgZmlsbD0iIzNjNGQ2MiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5JbmRleCBjb25jcmV0czwvdGV4dD48cmVjdCB4PSI1MzkuNiIgeT0iMjQ0LjAiIHdpZHRoPSIxMjAuODAwMDAwMDAwMDAwMDEiIGhlaWdodD0iMjAiIHJ4PSIzIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjk2IiAvPjx0ZXh0IHg9IjYwMC4wIiB5PSIyNTguMCIgZmlsbD0iIzNjNGQ2MiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5Sw6lwb25zZSArIGxpbWl0ZXM8L3RleHQ+PC9zdmc+Cg==
```


[Source draw.io du flux PDL](/dinum-rie/diagrams/03-pdl-flow.drawio)

## Dialogue et validation

Le backend reçoit le message complet et le dernier jeton de reprise émis pour
cette conversation. Il distingue nouvelle question, précision, modification,
relance et annulation. L'état est lié au sujet authentifié. Il conserve l'intention
et ses précisions, pas d'anciennes observations comme résultat courant.

Dans le profil Open WebUI portable, le filtre protège le message et le jeton
de reprise avant l'appel MCP. Le modèle de relais sélectionne seulement la
fonction, avec le marqueur technique `question: ""` ; le callable protégé transmet les
valeurs exactes au serveur. La signature MCP réelle reste inchangée. Le relais
ne reçoit ni question métier, ni jeton opaque ni anciennes preuves ; la planification Albert
et les autorisations du backend restent les mêmes.

Un comptage autonome, avec période complète, périmètre approuvé et une source
courante non ambiguë, repart de sa propre question. Il n'hérite pas d'un ancien
équipement omis, même si l'interpréteur propose une suite de conversation.
Cette protection ne s'applique pas aux formulations référentielles (« ce même
équipement », « encore », « aussi »), aux questions incomplètes ni à plusieurs
sources possibles. Les autres transitions restent interprétées par Albert.

Une recherche d'équipement autonome suit la même règle lorsqu'elle nomme
l'équipement, ses sources, un périmètre approuvé et une période complète.
Elle ne reprend donc pas le critère de refus d'un ancien comptage. Les demandes
de conservation ou d'ajout (« mêmes filtres », « aussi ») gardent leur contexte.
Une date civile complète sans heures signifie la journée entière ; ce contrôle
ne change pas les règles de dates, de compilation ou d'autorisation.

Le planner propose un objet structuré : source, index, opération, période,
filtres, regroupement et limite. Le serveur valide ce plan contre l'inventaire,
le catalogue approuvé et les bornes de la configuration. Une ambiguïté demande
une clarification ; un mapping absent ou modifié ouvre une revue humaine.
Un résultat `awaiting_human` n'est pas une réponse métier publiable.

Une seule correction de proposition est autorisée pour trois ambiguïtés
techniques : une référence que les relations approuvées permettent au moteur
de retrouver, un nom de source pris pour un équipement dans un comptage,
ou deux sélections successives de sources prises pour une contradiction.
La correction repart de la demande originale et du catalogue courant ; les
affirmations du premier plan non validé ne sont pas réinjectées. Pour la
réparation d'identité, Albert extrait le nom, FQDN, IP ou identifiant demandé,
les sources cibles et les éventuels critères supplémentaires, dans une fonction
structurée imposée par le fournisseur. Il ne reçoit pas le schéma physique pour
cette extraction. Les dates et le périmètre confirmés restent contrôlés côté
serveur. Les critères supplémentaires ne peuvent pas être supprimés pour
obtenir un résultat : s'ils ne sont pas pris en charge, une précision est demandée.

Python choisit ensuite un unique ensemble de relations d'identité déjà
approuvées. Plusieurs ensembles possibles, une ancre absente ou des arguments
invalides entraînent une clarification ou un refus avant lecture. Les sources
ajoutées pour résoudre l'identité n'élargissent pas les cibles de logs demandées.
Les références intermédiaires sont lues par le moteur ; elles ne sont pas
réclamées à l'utilisateur lorsque les relations approuvées permettent de les
retrouver. Le plan reste soumis aux validations habituelles des schémas,
relations, budgets et ACL. Cette fonction interne de structuration n'ajoute
aucun outil MCP public.

Les deux propositions éventuelles sont comptées dans `planner.attempts` ;
`planner.repair` indique le motif. Aucun nouvel essai de transport n'est ajouté.
Une ambiguïté métier persistante reste une clarification explicite.

Pour une sélection de sources remplacée, cette réparation reprend les derniers
choix reconnus dans le catalogue actif avant de choisir le pool d'identité.
Cette réparation ne contourne pas une clarification portant sur une addition,
une contradiction dans le message courant ou un critère non pris en charge.
Les cibles inconnues ou mal formées
ne sont pas effacées pour obtenir un succès. Il s'agit du même budget de deux
propositions au maximum, sans nouvel essai de transport.

Avant la validation du plan, les noms et alias du catalogue courant servent
aussi à contrôler les cibles de logs explicitement demandées. Une source
nommée ne peut être oubliée par le modèle ; une exclusion est conservée, y
compris après un changement de recherche. Seules les sources déjà approuvées
et nommées par l'utilisateur peuvent compléter une proposition partielle.
Cette correction ne fournit pas une ancre absente et ne valide aucun mapping.
Une exclusion seule n'élargit jamais une mauvaise sélection du modèle.
Les synonymes interprétés par Albert restent préservés lorsqu'une liste n'est
pas entièrement reconnue localement. Un alias administré ambigu, un index inconnu
ou une sélection mal formée reste soumis au refus avant lecture.
Une nouvelle sélection de sources exprimée sans noms reconnus localement n'est
pas écrasée par une ancienne restriction. Le planificateur l'interprète, puis les
validations habituelles des sources, relations, budgets et droits s'appliquent.
Même lorsqu'une demande est classée comme une relance, le dernier message est
conservé ; ses critères explicites ne sont pas remplacés par l'ancien plan.

Le compilateur construit le DSL. Les seules requêtes exécutées sont celles
acceptées par les garde-fous et les droits de l'utilisateur. Le résultat contient
les faits, la requête réellement exécutée, la provenance et les limites de lecture.

## Quatre familles du corpus portable

| Famille | Index fictif | Utilité dans la démo |
| --- | --- | --- |
| PFS | `rie-pfs-fixture` | Actions de filtrage, portée et identités structurées |
| Backbone | `rie-bb-fixture` | Équipements, adresses de gestion et agrégations |
| PFAING | `rie-pfaing-fixture` | Événements et référence de passerelle, sans reprendre forcément le nom initial |
| TACACS | `rie-tacacs-fixture` | Événements reliés par IP de gestion, y compris IPv6 |

Le corpus est fixé au **12 octobre 2026 de 08:00 à 09:00 UTC** pour les questions
ci-dessous. Ses champs sont structurés ; la cible ne dépend pas d'une extraction
générale de `event.original` pour reconnaître un équipement.

## Périmètre et budgets à configurer

L'opérateur règle ces valeurs dans `config/pdl.yaml`, sur le serveur Ubuntu,
avant la validation et le redémarrage de l'instance. Les mêmes clés figurent
dans le modèle `deploy/ubuntu/examples/pdl.json`.

| Clé | Défaut | Borne admise et effet |
| --- | --- | --- |
| `discovery.max_indices` | 20 | 1 à 200 index physiques découverts et participants à une résolution d'identité |
| `discovery.max_fields_per_index` | 500 | 1 à 10 000 champs par index ; aucun champ n'est supprimé silencieusement |
| `discovery.required_index_patterns` | liste vide | Un index résolu avec mapping actif au hash du dernier inventaire est nécessaire pour chaque motif ; si la liste est vide, chaque motif de `allowed_index_patterns` est requis |
| `limits.max_identity_documents` | 1 000 | 1 à 10 000 documents par lecture d'identité, indépendamment de la limite des logs affichés |
| `limits.max_context_bytes` | 1 048 576 | 1 à 1 048 576 octets pour la requête complète au planner, à adapter à la capacité du modèle |

Déclarer les familles métier nécessaires par des motifs distincts dans
`required_index_patterns`. Avec un seul motif large comme `rie-*`, la disponibilité
d'une famille peut satisfaire ce seul motif : elle ne prouve pas la présence des
quatre familles. La préparation de démonstration déclare les quatre index fictifs
comme sources requises. Le résultat `/readiness` détaille les motifs satisfaits
et manquants ; la présence d'un seul mapping approuvé ne suffit plus à valider
plusieurs motifs requis.
Cette couverture minimale par motif ne garantit pas que tous les index physiques
d'un rollover possèdent déjà un mapping approuvé.

Une résolution examine tous les documents d'identité de chaque lecture avant
d'accepter l'ancre. Un équipement ayant plus de 50 événements peut ainsi être
résolu dans le budget configuré. Si le total dépasse ce budget, le résultat est
`incomplete` et les logs cibles ne sont pas lus. Après examen, les preuves
d'identité regroupent les jeux d'identifiants identiques avec un document
représentatif et `equivalent_documents` ; cette présentation ne remplace aucune
vérification d'ambiguïté.

Le transport conserve une limite de **2 Mo (2 000 000 octets) par réponse OpenSearch** et ses
délais de lecture. Augmenter le nombre de documents autorisés ne garantit donc
pas que des documents volumineux seront acceptés. Le scan temporaire de texte
brut, lorsqu'il est explicitement approuvé, reste soumis au même budget.
Les lectures successives ne constituent pas un instantané transactionnel du
cluster ni une preuve de causalité.

Le planner reçoit les champs des mappings courants pour les index approuvés,
et le schéma découvert pour les index encore à revoir. Il conserve tous les
index autorisés du contexte ; une requête trop grosse est refusée avant l'appel
IA avec une indication du budget dépassé. Le budget en octets ne mesure pas les
tokens disponibles du modèle.

Pour ajuster un budget, partir d'un échantillon représentatif et d'un besoin
métier, réduire si possible les motifs, la période ou le périmètre, puis rejouer
les cas nominaux, ambigus et interdits. Une limite admise par la configuration
n'est pas une capacité de charge mesurée. Rollover, cardinalités, documents
volumineux, données arrivant pendant les lectures et évolution des valeurs
métier restent à recevoir dans le SI-RIE, selon la
[matrice de recette](/dinum-rie/reference/14-si-rie-acceptance). Un changement de schéma invalide les
approbations lors de sa détection par un rafraîchissement ; `/readiness` résout
les noms d'index en direct mais compare les approbations au dernier inventaire
local, sans relire tous les schémas. Une simple modification des valeurs, sans changement de schéma,
n'établit aucune nouvelle validation sémantique automatique.

## Relations entre index


```diagram
PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgwIiBoZWlnaHQ9IjkwMCIgdmlld0JveD0iMCAwIDEyODAgOTAwIiByb2xlPSJpbWciIGFyaWEtbGFiZWxsZWRieT0idGl0bGUgZGVzYyIgY29udGVudD0iJmx0Oz94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPyZndDsmIzEwOyZsdDtteGZpbGUgaG9zdD0mcXVvdDthcHAuZGlhZ3JhbXMubmV0JnF1b3Q7IHR5cGU9JnF1b3Q7ZGV2aWNlJnF1b3Q7Jmd0OyZsdDtkaWFncmFtIGlkPSZxdW90OzA2LXJlbGF0aW9ucy1pbmRleCZxdW90OyBuYW1lPSZxdW90O1BETCDigJQgcmVsYXRpb25zIHPDqW1hbnRpcXVlcyBlbnRyZSBpbmRleCZxdW90OyZndDsmbHQ7bXhHcmFwaE1vZGVsIGR4PSZxdW90OzEyODAmcXVvdDsgZHk9JnF1b3Q7OTAwJnF1b3Q7IGdyaWQ9JnF1b3Q7MSZxdW90OyBncmlkU2l6ZT0mcXVvdDsxMCZxdW90OyBndWlkZXM9JnF1b3Q7MSZxdW90OyB0b29sdGlwcz0mcXVvdDsxJnF1b3Q7IGNvbm5lY3Q9JnF1b3Q7MSZxdW90OyBhcnJvd3M9JnF1b3Q7MSZxdW90OyBmb2xkPSZxdW90OzEmcXVvdDsgcGFnZT0mcXVvdDsxJnF1b3Q7IHBhZ2VTY2FsZT0mcXVvdDsxJnF1b3Q7IHBhZ2VXaWR0aD0mcXVvdDsxMjgwJnF1b3Q7IHBhZ2VIZWlnaHQ9JnF1b3Q7OTAwJnF1b3Q7IG1hdGg9JnF1b3Q7MCZxdW90OyBzaGFkb3c9JnF1b3Q7MCZxdW90OyZndDsmbHQ7cm9vdCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90OzAmcXVvdDsgLyZndDsmbHQ7bXhDZWxsIGlkPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzAmcXVvdDsgLyZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2hlYWRpbmcmcXVvdDsgdmFsdWU9JnF1b3Q7UERMIOKAlCByZWxhdGlvbnMgc8OpbWFudGlxdWVzIGVudHJlIGluZGV4JnF1b3Q7IHN0eWxlPSZxdW90O3RleHQ7aHRtbD0wO2FsaWduPWxlZnQ7dmVydGljYWxBbGlnbj1taWRkbGU7Zm9udFNpemU9MjU7Zm9udFN0eWxlPTE7Zm9udENvbG9yPSMxNzJiNGQ7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7MzUmcXVvdDsgeT0mcXVvdDsyMCZxdW90OyB3aWR0aD0mcXVvdDsxMjEwJnF1b3Q7IGhlaWdodD0mcXVvdDs0MCZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7c3VidGl0bGUmcXVvdDsgdmFsdWU9JnF1b3Q7RGVzIGlkZW50aXTDqXMgdHlww6llcyBldCBkZXMgcmVsYXRpb25zIGFwcHJvdXbDqWVzIDsgYXVjdW5lIMOpZ2FsaXTDqSBkZSBjaGHDrm5lIG5lIHN1ZmZpdCBzZXVsZSZxdW90OyBzdHlsZT0mcXVvdDt0ZXh0O2h0bWw9MDthbGlnbj1sZWZ0O3ZlcnRpY2FsQWxpZ249bWlkZGxlO2ZvbnRTaXplPTE0O2ZvbnRDb2xvcj0jNTQ2MTcwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzM1JnF1b3Q7IHk9JnF1b3Q7NjUmcXVvdDsgd2lkdGg9JnF1b3Q7MTIxMCZxdW90OyBoZWlnaHQ9JnF1b3Q7MzAmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O3F1ZXN0aW9uJnF1b3Q7IHZhbHVlPSZxdW90O05vbSBkZW1hbmTDqSZhbXA7IzEwO2VkZ2UtYSZxdW90OyBzdHlsZT0mcXVvdDtyb3VuZGVkPTE7d2hpdGVTcGFjZT13cmFwO2h0bWw9MDthcmNTaXplPTEyO2ZpbGxDb2xvcj0jZWFmMWZiO3N0cm9rZUNvbG9yPSMyNDRlODY7Zm9udENvbG9yPSMxNzJiNGQ7Zm9udFNpemU9MTc7c3BhY2luZz0xMDsmcXVvdDsgdmVydGV4PSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgeD0mcXVvdDs3MCZxdW90OyB5PSZxdW90OzEzMCZxdW90OyB3aWR0aD0mcXVvdDsyNTAmcXVvdDsgaGVpZ2h0PSZxdW90OzkyJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtwZnMmcXVvdDsgdmFsdWU9JnF1b3Q7UEZTIC8gQmFja2JvbmUmYW1wOyMxMDtOb20sIGlkZW50aWZpYW50IHN0YWJsZSZhbXA7IzEwO0lQdjQgLyBJUHY2IGRlIGdlc3Rpb24mcXVvdDsgc3R5bGU9JnF1b3Q7cm91bmRlZD0xO3doaXRlU3BhY2U9d3JhcDtodG1sPTA7YXJjU2l6ZT0xMjtmaWxsQ29sb3I9I2VhZjZmMTtzdHJva2VDb2xvcj0jMTg2YjUzO2ZvbnRDb2xvcj0jMTcyYjRkO2ZvbnRTaXplPTE3O3NwYWNpbmc9MTA7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7NDcwJnF1b3Q7IHk9JnF1b3Q7MTE1JnF1b3Q7IHdpZHRoPSZxdW90OzM2MCZxdW90OyBoZWlnaHQ9JnF1b3Q7MTEyJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtpZGVudGl0eSZxdW90OyB2YWx1ZT0mcXVvdDtJZGVudGl0w6kgcsOpc29sdWUmYW1wOyMxMDtFc3BhY2VzIGRlIG5vbXMgdHlww6lzJmFtcDsjMTA7UG9ydMOpZSBkZW1vLWFscGhhJnF1b3Q7IHN0eWxlPSZxdW90O3JvdW5kZWQ9MTt3aGl0ZVNwYWNlPXdyYXA7aHRtbD0wO2FyY1NpemU9MTI7ZmlsbENvbG9yPSNmZmZmZmY7c3Ryb2tlQ29sb3I9IzI0NGU4Njtmb250Q29sb3I9IzE3MmI0ZDtmb250U2l6ZT0xNztzcGFjaW5nPTEwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90Ozk0MCZxdW90OyB5PSZxdW90OzExNSZxdW90OyB3aWR0aD0mcXVvdDsyODUmcXVvdDsgaGVpZ2h0PSZxdW90OzExMiZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7cGZhaW5nJnF1b3Q7IHZhbHVlPSZxdW90O1BGQUlORyZhbXA7IzEwO1LDqWbDqXJlbmNlIGRlIHBhc3NlcmVsbGUmYW1wOyMxMDtTYW5zIG5vbSBpbml0aWFsJnF1b3Q7IHN0eWxlPSZxdW90O3JvdW5kZWQ9MTt3aGl0ZVNwYWNlPXdyYXA7aHRtbD0wO2FyY1NpemU9MTI7ZmlsbENvbG9yPSNlYWY2ZjE7c3Ryb2tlQ29sb3I9IzE4NmI1Mztmb250Q29sb3I9IzE3MmI0ZDtmb250U2l6ZT0xNztzcGFjaW5nPTEwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzY1JnF1b3Q7IHk9JnF1b3Q7Mzk1JnF1b3Q7IHdpZHRoPSZxdW90OzMzMCZxdW90OyBoZWlnaHQ9JnF1b3Q7MTEyJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDt0YWNhY3MmcXVvdDsgdmFsdWU9JnF1b3Q7VEFDQUNTJmFtcDsjMTA7RGVzdGluYXRpb24gZGUgZ2VzdGlvbiZhbXA7IzEwO1NhbnMgbm9tIGluaXRpYWwmcXVvdDsgc3R5bGU9JnF1b3Q7cm91bmRlZD0xO3doaXRlU3BhY2U9d3JhcDtodG1sPTA7YXJjU2l6ZT0xMjtmaWxsQ29sb3I9I2VhZjZmMTtzdHJva2VDb2xvcj0jMTg2YjUzO2ZvbnRDb2xvcj0jMTcyYjRkO2ZvbnRTaXplPTE3O3NwYWNpbmc9MTA7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7NDg1JnF1b3Q7IHk9JnF1b3Q7Mzk1JnF1b3Q7IHdpZHRoPSZxdW90OzMzMCZxdW90OyBoZWlnaHQ9JnF1b3Q7MTEyJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtwcm9vZiZxdW90OyB2YWx1ZT0mcXVvdDtSYXBwcm9jaGVtZW50IGJvcm7DqSZhbXA7IzEwO1DDqXJpb2RlICsgaW5kZXggKyBBQ0wmYW1wOyMxMDtTaXggZG9jdW1lbnRzIGRlIHLDqWbDqXJlbmNlJnF1b3Q7IHN0eWxlPSZxdW90O3JvdW5kZWQ9MTt3aGl0ZVNwYWNlPXdyYXA7aHRtbD0wO2FyY1NpemU9MTI7ZmlsbENvbG9yPSNkZmYzZTg7c3Ryb2tlQ29sb3I9IzE4NmI1Mztmb250Q29sb3I9IzE3MmI0ZDtmb250U2l6ZT0xNztzcGFjaW5nPTEwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzkwNSZxdW90OyB5PSZxdW90OzM5NSZxdW90OyB3aWR0aD0mcXVvdDszMjUmcXVvdDsgaGVpZ2h0PSZxdW90OzExMiZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7Z3VhcmQmcXVvdDsgdmFsdWU9JnF1b3Q7SVAgZGUgdHJhZmljIHPDqXBhcsOpZXMmYW1wOyMxMDtMZXVycmVzIGhvcnMgcMOpcmltw6h0cmUgZXhjbHVzJmFtcDsjMTA7UmVsYXRpb25zIGNvbmZpcm3DqWVzIHBhciB1biBodW1haW4mcXVvdDsgc3R5bGU9JnF1b3Q7cm91bmRlZD0xO3doaXRlU3BhY2U9d3JhcDtodG1sPTA7YXJjU2l6ZT0xMjtmaWxsQ29sb3I9I2ZmZjNkZjtzdHJva2VDb2xvcj0jYTY1OTEzO2ZvbnRDb2xvcj0jMTcyYjRkO2ZvbnRTaXplPTE3O3NwYWNpbmc9MTA7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7MzQwJnF1b3Q7IHk9JnF1b3Q7NjkwJnF1b3Q7IHdpZHRoPSZxdW90OzU5MCZxdW90OyBoZWlnaHQ9JnF1b3Q7MTEyJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtlZGdlLTAmcXVvdDsgdmFsdWU9JnF1b3Q7UmVjaGVyY2hlIGTigJlpZGVudGl0w6kmcXVvdDsgc3R5bGU9JnF1b3Q7ZWRnZVN0eWxlPW9ydGhvZ29uYWxFZGdlU3R5bGU7cm91bmRlZD0xO2h0bWw9MDtlbmRBcnJvdz1ibG9jaztlbmRGaWxsPTE7c3Ryb2tlQ29sb3I9IzY4Nzc4YjtzdHJva2VXaWR0aD0yO2ZvbnRTaXplPTEyO2ZvbnRDb2xvcj0jM2M0ZDYyO2xhYmVsQmFja2dyb3VuZENvbG9yPSNmZmZmZmY7ZXhpdFg9MTtleGl0WT0wLjU0MzQ3ODI2MDg2OTU2NTI7ZW50cnlYPTA7ZW50cnlZPTAuNTgwMzU3MTQyODU3MTQyOTtleGl0UGVyaW1ldGVyPTA7ZW50cnlQZXJpbWV0ZXI9MDsmcXVvdDsgZWRnZT0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7IHNvdXJjZT0mcXVvdDtxdWVzdGlvbiZxdW90OyB0YXJnZXQ9JnF1b3Q7cGZzJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHJlbGF0aXZlPSZxdW90OzEmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsmZ3Q7Jmx0O0FycmF5IGFzPSZxdW90O3BvaW50cyZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7MC4wJnF1b3Q7IHk9JnF1b3Q7LTE0LjAmcXVvdDsgYXM9JnF1b3Q7b2Zmc2V0JnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS0xJnF1b3Q7IHZhbHVlPSZxdW90OyZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0xO2V4aXRZPTAuNTgwMzU3MTQyODU3MTQyOTtlbnRyeVg9MDtlbnRyeVk9MC41ODAzNTcxNDI4NTcxNDI5O2V4aXRQZXJpbWV0ZXI9MDtlbnRyeVBlcmltZXRlcj0wOyZxdW90OyBlZGdlPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsgc291cmNlPSZxdW90O3BmcyZxdW90OyB0YXJnZXQ9JnF1b3Q7aWRlbnRpdHkmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgcmVsYXRpdmU9JnF1b3Q7MSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyZndDsmbHQ7QXJyYXkgYXM9JnF1b3Q7cG9pbnRzJnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS0yJnF1b3Q7IHZhbHVlPSZxdW90O1LDqWbDqXJlbmNlIGFwcHJvdXbDqWUmcXVvdDsgc3R5bGU9JnF1b3Q7ZWRnZVN0eWxlPW9ydGhvZ29uYWxFZGdlU3R5bGU7cm91bmRlZD0xO2h0bWw9MDtlbmRBcnJvdz1ibG9jaztlbmRGaWxsPTE7c3Ryb2tlQ29sb3I9IzY4Nzc4YjtzdHJva2VXaWR0aD0yO2ZvbnRTaXplPTEyO2ZvbnRDb2xvcj0jM2M0ZDYyO2xhYmVsQmFja2dyb3VuZENvbG9yPSNmZmZmZmY7ZXhpdFg9MDtleGl0WT0wLjU4MDM1NzE0Mjg1NzE0Mjk7ZW50cnlYPTE7ZW50cnlZPTAuNTgwMzU3MTQyODU3MTQyOTtleGl0UGVyaW1ldGVyPTA7ZW50cnlQZXJpbWV0ZXI9MDsmcXVvdDsgZWRnZT0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7IHNvdXJjZT0mcXVvdDtpZGVudGl0eSZxdW90OyB0YXJnZXQ9JnF1b3Q7cGZhaW5nJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHJlbGF0aXZlPSZxdW90OzEmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsmZ3Q7Jmx0O0FycmF5IGFzPSZxdW90O3BvaW50cyZxdW90OyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzkwMCZxdW90OyB5PSZxdW90OzE4MCZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7OTAwJnF1b3Q7IHk9JnF1b3Q7MzgwJnF1b3Q7IC8mZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs0MjAmcXVvdDsgeT0mcXVvdDszODAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzQyMCZxdW90OyB5PSZxdW90OzQ2MCZxdW90OyAvJmd0OyZsdDsvQXJyYXkmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDstNjcuNSZxdW90OyB5PSZxdW90Oy0xNC4wJnF1b3Q7IGFzPSZxdW90O29mZnNldCZxdW90OyAvJmd0OyZsdDsvbXhHZW9tZXRyeSZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2VkZ2UtMyZxdW90OyB2YWx1ZT0mcXVvdDttYW5hZ2VtZW50LWlwJnF1b3Q7IHN0eWxlPSZxdW90O2VkZ2VTdHlsZT1vcnRob2dvbmFsRWRnZVN0eWxlO3JvdW5kZWQ9MTtodG1sPTA7ZW5kQXJyb3c9YmxvY2s7ZW5kRmlsbD0xO3N0cm9rZUNvbG9yPSM2ODc3OGI7c3Ryb2tlV2lkdGg9Mjtmb250U2l6ZT0xMjtmb250Q29sb3I9IzNjNGQ2MjtsYWJlbEJhY2tncm91bmRDb2xvcj0jZmZmZmZmO2V4aXRYPTA7ZXhpdFk9MC41ODAzNTcxNDI4NTcxNDI5O2VudHJ5WD0xO2VudHJ5WT0wLjU4MDM1NzE0Mjg1NzE0Mjk7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7aWRlbnRpdHkmcXVvdDsgdGFyZ2V0PSZxdW90O3RhY2FjcyZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs4ODAmcXVvdDsgeT0mcXVvdDsxODAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90Ozg4MCZxdW90OyB5PSZxdW90OzQ2MCZxdW90OyAvJmd0OyZsdDsvQXJyYXkmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDswLjAmcXVvdDsgeT0mcXVvdDstMTYuNSZxdW90OyBhcz0mcXVvdDtvZmZzZXQmcXVvdDsgLyZndDsmbHQ7L214R2VvbWV0cnkmZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtlZGdlLTQmcXVvdDsgdmFsdWU9JnF1b3Q7RG9jdW1lbnRzIGxpw6lzJnF1b3Q7IHN0eWxlPSZxdW90O2VkZ2VTdHlsZT1vcnRob2dvbmFsRWRnZVN0eWxlO3JvdW5kZWQ9MTtodG1sPTA7ZW5kQXJyb3c9YmxvY2s7ZW5kRmlsbD0xO3N0cm9rZUNvbG9yPSM2ODc3OGI7c3Ryb2tlV2lkdGg9Mjtmb250U2l6ZT0xMjtmb250Q29sb3I9IzNjNGQ2MjtsYWJlbEJhY2tncm91bmRDb2xvcj0jZmZmZmZmO2V4aXRYPTE7ZXhpdFk9MC41ODAzNTcxNDI4NTcxNDI5O2VudHJ5WD0wO2VudHJ5WT0wLjU4MDM1NzE0Mjg1NzE0Mjk7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7cGZhaW5nJnF1b3Q7IHRhcmdldD0mcXVvdDtwcm9vZiZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs0MjAmcXVvdDsgeT0mcXVvdDs0NjAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzQyMCZxdW90OyB5PSZxdW90OzU0MCZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7ODgwJnF1b3Q7IHk9JnF1b3Q7NTQwJnF1b3Q7IC8mZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs4ODAmcXVvdDsgeT0mcXVvdDs0NjAmcXVvdDsgLyZndDsmbHQ7L0FycmF5Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7MC4wJnF1b3Q7IHk9JnF1b3Q7LTE0LjAmcXVvdDsgYXM9JnF1b3Q7b2Zmc2V0JnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS01JnF1b3Q7IHZhbHVlPSZxdW90OyZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0xO2V4aXRZPTAuNTgwMzU3MTQyODU3MTQyOTtlbnRyeVg9MDtlbnRyeVk9MC41ODAzNTcxNDI4NTcxNDI5O2V4aXRQZXJpbWV0ZXI9MDtlbnRyeVBlcmltZXRlcj0wOyZxdW90OyBlZGdlPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsgc291cmNlPSZxdW90O3RhY2FjcyZxdW90OyB0YXJnZXQ9JnF1b3Q7cHJvb2YmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgcmVsYXRpdmU9JnF1b3Q7MSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyZndDsmbHQ7QXJyYXkgYXM9JnF1b3Q7cG9pbnRzJnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS02JnF1b3Q7IHZhbHVlPSZxdW90O1ByZXV2ZXMgZGUgZMOpcGFydCZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0xO2V4aXRZPTAuNTgwMzU3MTQyODU3MTQyOTtlbnRyeVg9MDtlbnRyeVk9MC41ODAzNTcxNDI4NTcxNDI5O2V4aXRQZXJpbWV0ZXI9MDtlbnRyeVBlcmltZXRlcj0wOyZxdW90OyBlZGdlPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsgc291cmNlPSZxdW90O3BmcyZxdW90OyB0YXJnZXQ9JnF1b3Q7cHJvb2YmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgcmVsYXRpdmU9JnF1b3Q7MSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyZndDsmbHQ7QXJyYXkgYXM9JnF1b3Q7cG9pbnRzJnF1b3Q7Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7ODYwJnF1b3Q7IHk9JnF1b3Q7MTgwJnF1b3Q7IC8mZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs4NjAmcXVvdDsgeT0mcXVvdDs0NjAmcXVvdDsgLyZndDsmbHQ7L0FycmF5Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7MC4wJnF1b3Q7IHk9JnF1b3Q7Ni41JnF1b3Q7IGFzPSZxdW90O29mZnNldCZxdW90OyAvJmd0OyZsdDsvbXhHZW9tZXRyeSZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2VkZ2UtNyZxdW90OyB2YWx1ZT0mcXVvdDtHYXJkZS1mb3VzJnF1b3Q7IHN0eWxlPSZxdW90O2VkZ2VTdHlsZT1vcnRob2dvbmFsRWRnZVN0eWxlO3JvdW5kZWQ9MTtodG1sPTA7ZW5kQXJyb3c9YmxvY2s7ZW5kRmlsbD0xO3N0cm9rZUNvbG9yPSM2ODc3OGI7c3Ryb2tlV2lkdGg9Mjtmb250U2l6ZT0xMjtmb250Q29sb3I9IzNjNGQ2MjtsYWJlbEJhY2tncm91bmRDb2xvcj0jZmZmZmZmO2V4aXRYPTE7ZXhpdFk9MC40NDY0Mjg1NzE0Mjg1NzE0NTtlbnRyeVg9MDtlbnRyeVk9MC41ODAzNTcxNDI4NTcxNDI5O2V4aXRQZXJpbWV0ZXI9MDtlbnRyeVBlcmltZXRlcj0wOyZxdW90OyBlZGdlPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsgc291cmNlPSZxdW90O2d1YXJkJnF1b3Q7IHRhcmdldD0mcXVvdDtwcm9vZiZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs5NjAmcXVvdDsgeT0mcXVvdDs3NDAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90Ozk2MCZxdW90OyB5PSZxdW90OzU0MCZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7ODgwJnF1b3Q7IHk9JnF1b3Q7NTQwJnF1b3Q7IC8mZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs4ODAmcXVvdDsgeT0mcXVvdDs0NjAmcXVvdDsgLyZndDsmbHQ7L0FycmF5Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7MC4wJnF1b3Q7IHk9JnF1b3Q7NjMuNSZxdW90OyBhcz0mcXVvdDtvZmZzZXQmcXVvdDsgLyZndDsmbHQ7L214R2VvbWV0cnkmZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0Oy9yb290Jmd0OyZsdDsvbXhHcmFwaE1vZGVsJmd0OyZsdDsvZGlhZ3JhbSZndDsmbHQ7L214ZmlsZSZndDsiPjx0aXRsZSBpZD0idGl0bGUiPlBETCDigJQgcmVsYXRpb25zIHPDqW1hbnRpcXVlcyBlbnRyZSBpbmRleDwvdGl0bGU+PGRlc2MgaWQ9ImRlc2MiPkRlcyBpZGVudGl0w6lzIHR5cMOpZXMgZXQgZGVzIHJlbGF0aW9ucyBhcHByb3V2w6llcyA7IGF1Y3VuZSDDqWdhbGl0w6kgZGUgY2hhw65uZSBuZSBzdWZmaXQgc2V1bGU8L2Rlc2M+PGRlZnM+PG1hcmtlciBpZD0iYXJyb3ciIHZpZXdCb3g9IjAgMCAxMCAxMCIgcmVmWD0iOSIgcmVmWT0iNSIgbWFya2VyV2lkdGg9IjgiIG1hcmtlckhlaWdodD0iOCIgb3JpZW50PSJhdXRvLXN0YXJ0LXJldmVyc2UiPjxwYXRoIGQ9Ik0gMCAwIEwgMTAgNSBMIDAgMTAgeiIgZmlsbD0iIzY4Nzc4YiIgLz48L21hcmtlcj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEyODAiIGhlaWdodD0iOTAwIiBmaWxsPSIjZmZmZmZmIiAvPjx0ZXh0IHg9IjM1IiB5PSI0OCIgZmlsbD0iIzE3MmI0ZCIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjI1IiBmb250LXdlaWdodD0iNzAwIj5QREwg4oCUIHJlbGF0aW9ucyBzw6ltYW50aXF1ZXMgZW50cmUgaW5kZXg8L3RleHQ+PHRleHQgeD0iMzUiIHk9Ijc4IiBmaWxsPSIjNTQ2MTcwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTQiPkRlcyBpZGVudGl0w6lzIHR5cMOpZXMgZXQgZGVzIHJlbGF0aW9ucyBhcHByb3V2w6llcyA7IGF1Y3VuZSDDqWdhbGl0w6kgZGUgY2hhw65uZSBuZSBzdWZmaXQgc2V1bGU8L3RleHQ+PHBvbHlsaW5lIHBvaW50cz0iMzIwLjAsMTgwIDQ3MC4wLDE4MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjg3NzhiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIG1hcmtlci1lbmQ9InVybCgjYXJyb3cpIiAvPjxwb2x5bGluZSBwb2ludHM9IjgzMC4wLDE4MCA5NDAuMCwxODAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI5NDAuMCwxODAgOTAwLDE4MCA5MDAsMzgwIDQyMCwzODAgNDIwLDQ2MCAzOTUuMCw0NjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI5NDAuMCwxODAgODgwLDE4MCA4ODAsNDYwIDgxNS4wLDQ2MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjg3NzhiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIG1hcmtlci1lbmQ9InVybCgjYXJyb3cpIiAvPjxwb2x5bGluZSBwb2ludHM9IjM5NS4wLDQ2MCA0MjAsNDYwIDQyMCw1NDAgODgwLDU0MCA4ODAsNDYwIDkwNS4wLDQ2MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjg3NzhiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIG1hcmtlci1lbmQ9InVybCgjYXJyb3cpIiAvPjxwb2x5bGluZSBwb2ludHM9IjgxNS4wLDQ2MCA5MDUuMCw0NjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI4MzAuMCwxODAgODYwLDE4MCA4NjAsNDYwIDkwNS4wLDQ2MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjg3NzhiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIG1hcmtlci1lbmQ9InVybCgjYXJyb3cpIiAvPjxwb2x5bGluZSBwb2ludHM9IjkzMC4wLDc0MCA5NjAsNzQwIDk2MCw1NDAgODgwLDU0MCA4ODAsNDYwIDkwNS4wLDQ2MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjg3NzhiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIG1hcmtlci1lbmQ9InVybCgjYXJyb3cpIiAvPjxyZWN0IHg9IjcwLjAiIHk9IjEzMC4wIiB3aWR0aD0iMjUwLjAiIGhlaWdodD0iOTIuMCIgcng9IjEyIiBmaWxsPSIjZWFmMWZiIiBzdHJva2U9IiMyNDRlODYiIHN0cm9rZS13aWR0aD0iMiIgLz48dGV4dCB4PSIxOTUuMCIgeT0iMTcxLjAiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjYwMCI+Tm9tIGRlbWFuZMOpPC90ZXh0Pjx0ZXh0IHg9IjE5NS4wIiB5PSIxOTMuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5lZGdlLWE8L3RleHQ+PHJlY3QgeD0iNDcwLjAiIHk9IjExNS4wIiB3aWR0aD0iMzYwLjAiIGhlaWdodD0iMTEyLjAiIHJ4PSIxMiIgZmlsbD0iI2VhZjZmMSIgc3Ryb2tlPSIjMTg2YjUzIiBzdHJva2Utd2lkdGg9IjIiIC8+PHRleHQgeD0iNjUwLjAiIHk9IjE1NS4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI2MDAiPlBGUyAvIEJhY2tib25lPC90ZXh0Pjx0ZXh0IHg9IjY1MC4wIiB5PSIxNzcuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5Ob20sIGlkZW50aWZpYW50IHN0YWJsZTwvdGV4dD48dGV4dCB4PSI2NTAuMCIgeT0iMTk5LjAiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjQwMCI+SVB2NCAvIElQdjYgZGUgZ2VzdGlvbjwvdGV4dD48cmVjdCB4PSI5NDAuMCIgeT0iMTE1LjAiIHdpZHRoPSIyODUuMCIgaGVpZ2h0PSIxMTIuMCIgcng9IjEyIiBmaWxsPSIjZmZmZmZmIiBzdHJva2U9IiMyNDRlODYiIHN0cm9rZS13aWR0aD0iMiIgLz48dGV4dCB4PSIxMDgyLjUiIHk9IjE1NS4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI2MDAiPklkZW50aXTDqSByw6lzb2x1ZTwvdGV4dD48dGV4dCB4PSIxMDgyLjUiIHk9IjE3Ny4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPkVzcGFjZXMgZGUgbm9tcyB0eXDDqXM8L3RleHQ+PHRleHQgeD0iMTA4Mi41IiB5PSIxOTkuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5Qb3J0w6llIGRlbW8tYWxwaGE8L3RleHQ+PHJlY3QgeD0iNjUuMCIgeT0iMzk1LjAiIHdpZHRoPSIzMzAuMCIgaGVpZ2h0PSIxMTIuMCIgcng9IjEyIiBmaWxsPSIjZWFmNmYxIiBzdHJva2U9IiMxODZiNTMiIHN0cm9rZS13aWR0aD0iMiIgLz48dGV4dCB4PSIyMzAuMCIgeT0iNDM1LjAiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjYwMCI+UEZBSU5HPC90ZXh0Pjx0ZXh0IHg9IjIzMC4wIiB5PSI0NTcuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5Sw6lmw6lyZW5jZSBkZSBwYXNzZXJlbGxlPC90ZXh0Pjx0ZXh0IHg9IjIzMC4wIiB5PSI0NzkuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5TYW5zIG5vbSBpbml0aWFsPC90ZXh0PjxyZWN0IHg9IjQ4NS4wIiB5PSIzOTUuMCIgd2lkdGg9IjMzMC4wIiBoZWlnaHQ9IjExMi4wIiByeD0iMTIiIGZpbGw9IiNlYWY2ZjEiIHN0cm9rZT0iIzE4NmI1MyIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjY1MC4wIiB5PSI0MzUuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5UQUNBQ1M8L3RleHQ+PHRleHQgeD0iNjUwLjAiIHk9IjQ1Ny4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPkRlc3RpbmF0aW9uIGRlIGdlc3Rpb248L3RleHQ+PHRleHQgeD0iNjUwLjAiIHk9IjQ3OS4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPlNhbnMgbm9tIGluaXRpYWw8L3RleHQ+PHJlY3QgeD0iOTA1LjAiIHk9IjM5NS4wIiB3aWR0aD0iMzI1LjAiIGhlaWdodD0iMTEyLjAiIHJ4PSIxMiIgZmlsbD0iI2RmZjNlOCIgc3Ryb2tlPSIjMTg2YjUzIiBzdHJva2Utd2lkdGg9IjIiIC8+PHRleHQgeD0iMTA2Ny41IiB5PSI0MzUuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5SYXBwcm9jaGVtZW50IGJvcm7DqTwvdGV4dD48dGV4dCB4PSIxMDY3LjUiIHk9IjQ1Ny4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPlDDqXJpb2RlICsgaW5kZXggKyBBQ0w8L3RleHQ+PHRleHQgeD0iMTA2Ny41IiB5PSI0NzkuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5TaXggZG9jdW1lbnRzIGRlIHLDqWbDqXJlbmNlPC90ZXh0PjxyZWN0IHg9IjM0MC4wIiB5PSI2OTAuMCIgd2lkdGg9IjU5MC4wIiBoZWlnaHQ9IjExMi4wIiByeD0iMTIiIGZpbGw9IiNmZmYzZGYiIHN0cm9rZT0iI2E2NTkxMyIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjYzNS4wIiB5PSI3MzAuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5JUCBkZSB0cmFmaWMgc8OpcGFyw6llczwvdGV4dD48dGV4dCB4PSI2MzUuMCIgeT0iNzUyLjAiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjQwMCI+TGV1cnJlcyBob3JzIHDDqXJpbcOodHJlIGV4Y2x1czwvdGV4dD48dGV4dCB4PSI2MzUuMCIgeT0iNzc0LjAiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjQwMCI+UmVsYXRpb25zIGNvbmZpcm3DqWVzIHBhciB1biBodW1haW48L3RleHQ+PHRleHQgeD0iMzUiIHk9Ijg4NCIgZmlsbD0iIzU0NjE3MCIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5Eb2N1bWVudGF0aW9uIFNJLVJJRSDigKIgU291cmNlIG5hdGl2ZSAuZHJhd2lvIMOpZGl0YWJsZSDigKIgRG9ubsOpZXMgZmljdGl2ZXMgcG91ciBsZXMgZMOpbW9uc3RyYXRpb25zPC90ZXh0PjxyZWN0IHg9IjMyNS4wIiB5PSIxNTYuMCIgd2lkdGg9IjE0MC4wIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMC45NiIgLz48dGV4dCB4PSIzOTUuMCIgeT0iMTcwLjAiIGZpbGw9IiMzYzRkNjIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxMiI+UmVjaGVyY2hlIGTigJlpZGVudGl0w6k8L3RleHQ+PHJlY3QgeD0iNTkzLjIiIHk9IjM1Ni4wIiB3aWR0aD0iMTMzLjYwMDAwMDAwMDAwMDAyIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMC45NiIgLz48dGV4dCB4PSI2NjAuMCIgeT0iMzcwLjAiIGZpbGw9IiMzYzRkNjIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxMiI+UsOpZsOpcmVuY2UgYXBwcm91dsOpZTwvdGV4dD48cmVjdCB4PSI4MzIuNCIgeT0iMjk2LjAiIHdpZHRoPSI5NS4yIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMC45NiIgLz48dGV4dCB4PSI4ODAuMCIgeT0iMzEwLjAiIGZpbGw9IiMzYzRkNjIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxMiI+bWFuYWdlbWVudC1pcDwvdGV4dD48cmVjdCB4PSI1OTkuMiIgeT0iNTE2LjAiIHdpZHRoPSIxMDEuNjAwMDAwMDAwMDAwMDEiIGhlaWdodD0iMjAiIHJ4PSIzIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjk2IiAvPjx0ZXh0IHg9IjY1MC4wIiB5PSI1MzAuMCIgZmlsbD0iIzNjNGQ2MiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5Eb2N1bWVudHMgbGnDqXM8L3RleHQ+PHJlY3QgeD0iNzk5LjYiIHk9IjMyNC4wIiB3aWR0aD0iMTIwLjgwMDAwMDAwMDAwMDAxIiBoZWlnaHQ9IjIwIiByeD0iMyIgZmlsbD0iI2ZmZmZmZiIgb3BhY2l0eT0iMC45NiIgLz48dGV4dCB4PSI4NjAuMCIgeT0iMzM4LjAiIGZpbGw9IiMzYzRkNjIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxMiI+UHJldXZlcyBkZSBkw6lwYXJ0PC90ZXh0PjxyZWN0IHg9IjkyMi4wIiB5PSI2MTYuMCIgd2lkdGg9Ijc2LjAiIGhlaWdodD0iMjAiIHJ4PSIzIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjk2IiAvPjx0ZXh0IHg9Ijk2MC4wIiB5PSI2MzAuMCIgZmlsbD0iIzNjNGQ2MiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5HYXJkZS1mb3VzPC90ZXh0Pjwvc3ZnPgo=
```


[Source draw.io des relations](/dinum-rie/diagrams/06-index-relations.drawio)

Une relation approuvée associe des concepts de même sens. Le runtime peut
retrouver une identité à partir d'un nom, puis relier IP de gestion, identifiant
stable et référence de passerelle. Une égalité de valeur n'est pas une preuve
que deux champs ont le même rôle. Les adresses de trafic restent distinctes des
adresses de gestion.

Pour la fixture `edge-a`, le scénario croisé de référence retrouve six documents
sur les quatre familles. Les documents PFAING et TACACS utiles n'ont pas besoin
de recopier le nom `edge-a`. Les leurres d'un autre périmètre doivent rester exclus.

## Revoir puis approuver les mappings

### Définir le mapping dans le SI réel

**Le fichier opérateur `config/mappings.yaml` décrit les correspondances
souhaitées ; les revues préparent leur validation ; le catalogue approuvé est
la configuration réellement utilisée par les recherches.** Ce fichier appartient
au PoC. Il ne redéfinit pas le mapping natif ni les données d’OpenSearch.

Le portail Ubuntu fournit **Mappings PDL** (`/admin-mappings`) aux comptes
LDAP administrateurs habilités. Il propose les champs découverts, détecte les
types, vérifie les propositions, présente les différences et demande une
approbation explicite. Le [parcours guidé de déploiement](/dinum-rie#8-revoir-et-approuver-les-mappings-pdl)
décrit chaque action. Le YAML reste disponible pour l’import/export et les
commandes `manage.py pdl` pour l’exploitation sans portail. L’interface autonome
historique `rie_agent/admin_app.py` reste distincte et n’est pas installée dans
cette image Ubuntu.

Captures du **16 novembre 2026**, obtenues par navigateur sur une instance de
qualification Ubuntu distincte, avec le SI fictif : [formulaire guidé](/dinum-rie/assets/screenshots-2026-11-16/mapping-editor.png)
et [revue des différences](/dinum-rie/assets/screenshots-2026-11-16/mapping-review.png).
Elles illustrent les contrôles réels, sans valoir approbation des données du SI
ni des quatre revues de la recette manuelle.

Dans le SI réel, l’opérateur associe un concept métier à un chemin de champ
avec le responsable des sources et le métier. Exemples illustratifs à vérifier
sur les données réelles, sans présumer leur présence dans le SI-RIE :

| Concept du PoC | Champ physique possible | Ce qu’il faut confirmer |
| --- | --- | --- |
| `timestamp` : heure de l’événement | `@timestamp` | Heure de l’événement ou de sa collecte, format et fuseau. |
| `equipment` : équipement concerné | `observer.name` | Nom de l’équipement qui produit le log, distinct d’un poste client ou d’une destination. |
| `action` : action réseau observée | `event.action` | Sens exact des valeurs, par exemple `deny`/`allow`, en conservant leur casse réelle. |
| `network_scope` : périmètre réseau métier | `network.scope` | Signification du périmètre et valeurs autorisées pour les questions prévues. |
| `management_ip` : IP de gestion | `observer.ip` | Adresse de gestion de l’équipement, distincte des IP de trafic `source.ip` et `destination.ip`. |

Le parcours est le suivant :

1. Faire fournir les index physiques, leurs schémas et des exemples autorisés,
   puis les questions/résultats de référence avec les responsables du SI.
2. Déclarer les index autorisés dans `pdl.yaml` et les ACL, puis exécuter
   `refresh` pour découvrir leurs champs, types et capacités. Des profils prédéfinis peuvent
   suggérer des candidats ; noms et types ne suffisent pas à confirmer leur sens.
3. Choisir les concepts, champs et valeurs dans le formulaire, ou renseigner
   `match`, `concepts`, `field` et les types dans `config/mappings.yaml`. Pour les rapprochements, déclarer dans `relations`
   uniquement des identités dont l’équivalence est confirmée. Deux champs de type
   `ip` ne prouvent pas qu’ils désignent le même équipement.
4. Cliquer **Vérifier la proposition** ou exécuter `validate-mappings`. `valid: true` démontre la cohérence technique
   avec l’inventaire ; il ne constitue pas une validation métier.
5. **Enregistrer une proposition**, puis **Examiner cette revue** ; en CLI,
   utiliser `load-mappings` puis `inspect --review-id`. L’import reste en attente et n’active pas le fichier.
6. Après revue métier, l’administrateur LDAP habilité approuve chaque index
   physique avec **Approuver ce mapping** ou `approve-review`, et un motif. Le système conserve auteur,
   justification, version et empreinte de schéma. Rejouer ensuite les questions
   de référence pour vérifier les résultats et les refus attendus.

Un fichier peut sélectionner plusieurs index avec un motif borné, mais chaque
index physique nécessite sa revue. Une nouvelle génération d’index doit donc
être découverte et approuvée. Un changement de schéma détecté au rafraîchissement
invalide les versions concernées ; réexaminer le mapping avant de reprendre.
Le mapping ne remplace jamais l’autorisation ACL de lire l’index.

### Commandes de revue sur Ubuntu


```diagram
PD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz4KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjgwIiBoZWlnaHQ9IjkwMCIgdmlld0JveD0iMCAwIDEyODAgOTAwIiByb2xlPSJpbWciIGFyaWEtbGFiZWxsZWRieT0idGl0bGUgZGVzYyIgY29udGVudD0iJmx0Oz94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPyZndDsmIzEwOyZsdDtteGZpbGUgaG9zdD0mcXVvdDthcHAuZGlhZ3JhbXMubmV0JnF1b3Q7IHR5cGU9JnF1b3Q7ZGV2aWNlJnF1b3Q7Jmd0OyZsdDtkaWFncmFtIGlkPSZxdW90OzA3LWFwcHJvYmF0aW9uLW1hcHBpbmcmcXVvdDsgbmFtZT0mcXVvdDtNYXBwaW5nIOKAlCBkw6ljb3V2ZXJ0ZSwgcmV2dWUgZXQgYWN0aXZhdGlvbiZxdW90OyZndDsmbHQ7bXhHcmFwaE1vZGVsIGR4PSZxdW90OzEyODAmcXVvdDsgZHk9JnF1b3Q7OTAwJnF1b3Q7IGdyaWQ9JnF1b3Q7MSZxdW90OyBncmlkU2l6ZT0mcXVvdDsxMCZxdW90OyBndWlkZXM9JnF1b3Q7MSZxdW90OyB0b29sdGlwcz0mcXVvdDsxJnF1b3Q7IGNvbm5lY3Q9JnF1b3Q7MSZxdW90OyBhcnJvd3M9JnF1b3Q7MSZxdW90OyBmb2xkPSZxdW90OzEmcXVvdDsgcGFnZT0mcXVvdDsxJnF1b3Q7IHBhZ2VTY2FsZT0mcXVvdDsxJnF1b3Q7IHBhZ2VXaWR0aD0mcXVvdDsxMjgwJnF1b3Q7IHBhZ2VIZWlnaHQ9JnF1b3Q7OTAwJnF1b3Q7IG1hdGg9JnF1b3Q7MCZxdW90OyBzaGFkb3c9JnF1b3Q7MCZxdW90OyZndDsmbHQ7cm9vdCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90OzAmcXVvdDsgLyZndDsmbHQ7bXhDZWxsIGlkPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzAmcXVvdDsgLyZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2hlYWRpbmcmcXVvdDsgdmFsdWU9JnF1b3Q7TWFwcGluZyDigJQgZMOpY291dmVydGUsIHJldnVlIGV0IGFjdGl2YXRpb24mcXVvdDsgc3R5bGU9JnF1b3Q7dGV4dDtodG1sPTA7YWxpZ249bGVmdDt2ZXJ0aWNhbEFsaWduPW1pZGRsZTtmb250U2l6ZT0yNTtmb250U3R5bGU9MTtmb250Q29sb3I9IzE3MmI0ZDsmcXVvdDsgdmVydGV4PSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgeD0mcXVvdDszNSZxdW90OyB5PSZxdW90OzIwJnF1b3Q7IHdpZHRoPSZxdW90OzEyMTAmcXVvdDsgaGVpZ2h0PSZxdW90OzQwJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtzdWJ0aXRsZSZxdW90OyB2YWx1ZT0mcXVvdDtMZSBzZWVkIGZpY3RpZiBlc3QgaWRlbnRpZmnDqSA7IGxlcyBtYXBwaW5ncyBkdSBTSSByw6llbCBnYXJkZW50IHVuZSBhcHByb2JhdGlvbiBodW1haW5lIGV4cGxpY2l0ZSZxdW90OyBzdHlsZT0mcXVvdDt0ZXh0O2h0bWw9MDthbGlnbj1sZWZ0O3ZlcnRpY2FsQWxpZ249bWlkZGxlO2ZvbnRTaXplPTE0O2ZvbnRDb2xvcj0jNTQ2MTcwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzM1JnF1b3Q7IHk9JnF1b3Q7NjUmcXVvdDsgd2lkdGg9JnF1b3Q7MTIxMCZxdW90OyBoZWlnaHQ9JnF1b3Q7MzAmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O3Njb3BlJnF1b3Q7IHZhbHVlPSZxdW90O1BvcnTDqWUgYXV0b3Jpc8OpZSZhbXA7IzEwO1NvdXJjZXMgZXQgaW5kZXggY29uY3JldHMmcXVvdDsgc3R5bGU9JnF1b3Q7cm91bmRlZD0xO3doaXRlU3BhY2U9d3JhcDtodG1sPTA7YXJjU2l6ZT0xMjtmaWxsQ29sb3I9I2RmZjNlODtzdHJva2VDb2xvcj0jMTg2YjUzO2ZvbnRDb2xvcj0jMTcyYjRkO2ZvbnRTaXplPTE3O3NwYWNpbmc9MTA7JnF1b3Q7IHZlcnRleD0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHg9JnF1b3Q7NjAmcXVvdDsgeT0mcXVvdDsxMTUmcXVvdDsgd2lkdGg9JnF1b3Q7MzAwJnF1b3Q7IGhlaWdodD0mcXVvdDs5NSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7aW52ZW50b3J5JnF1b3Q7IHZhbHVlPSZxdW90O0ludmVudGFpcmUgcGh5c2lxdWUmYW1wOyMxMDtNYXBwaW5nICsgZmllbGRfY2FwcyZhbXA7IzEwO0VtcHJlaW50ZSBkdSBzY2jDqW1hJnF1b3Q7IHN0eWxlPSZxdW90O3JvdW5kZWQ9MTt3aGl0ZVNwYWNlPXdyYXA7aHRtbD0wO2FyY1NpemU9MTI7ZmlsbENvbG9yPSNlYWY2ZjE7c3Ryb2tlQ29sb3I9IzE4NmI1Mztmb250Q29sb3I9IzE3MmI0ZDtmb250U2l6ZT0xNztzcGFjaW5nPTEwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzQ3MCZxdW90OyB5PSZxdW90OzExNSZxdW90OyB3aWR0aD0mcXVvdDszMzAmcXVvdDsgaGVpZ2h0PSZxdW90OzExMiZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7cHJvcG9zYWwmcXVvdDsgdmFsdWU9JnF1b3Q7UHJvcG9zaXRpb24gZGUgbWFwcGluZyZhbXA7IzEwO0NvbmNlcHRzIGV0IHJlbGF0aW9ucyZxdW90OyBzdHlsZT0mcXVvdDtyb3VuZGVkPTE7d2hpdGVTcGFjZT13cmFwO2h0bWw9MDthcmNTaXplPTEyO2ZpbGxDb2xvcj0jZmZmZmZmO3N0cm9rZUNvbG9yPSMyNDRlODY7Zm9udENvbG9yPSMxNzJiNGQ7Zm9udFNpemU9MTc7c3BhY2luZz0xMDsmcXVvdDsgdmVydGV4PSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgeD0mcXVvdDs5MjAmcXVvdDsgeT0mcXVvdDsxMTUmcXVvdDsgd2lkdGg9JnF1b3Q7MzAwJnF1b3Q7IGhlaWdodD0mcXVvdDs5NSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7cmV2aWV3JnF1b3Q7IHZhbHVlPSZxdW90O1JldnVlIGVuIGF0dGVudGUmYW1wOyMxMDtUeXBlcywgc2VucyBldCBwb3J0w6llJmFtcDsjMTA7RXNzYWlzIERTTCBib3Juw6lzJnF1b3Q7IHN0eWxlPSZxdW90O3JvdW5kZWQ9MTt3aGl0ZVNwYWNlPXdyYXA7aHRtbD0wO2FyY1NpemU9MTI7ZmlsbENvbG9yPSNmZmYzZGY7c3Ryb2tlQ29sb3I9I2E2NTkxMztmb250Q29sb3I9IzE3MmI0ZDtmb250U2l6ZT0xNztzcGFjaW5nPTEwOyZxdW90OyB2ZXJ0ZXg9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSB4PSZxdW90OzkyMCZxdW90OyB5PSZxdW90OzM5NSZxdW90OyB3aWR0aD0mcXVvdDszMDAmcXVvdDsgaGVpZ2h0PSZxdW90OzExMiZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyAvJmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7aHVtYW4mcXVvdDsgdmFsdWU9JnF1b3Q7T3DDqXJhdGV1ciBpbnRlcm5lJmFtcDsjMTA7UmVsaXQgcHVpcyBhcHByb3V2ZSZhbXA7IzEwO0F1dGV1ciBldCBtb3RpZiZxdW90OyBzdHlsZT0mcXVvdDtyb3VuZGVkPTE7d2hpdGVTcGFjZT13cmFwO2h0bWw9MDthcmNTaXplPTEyO2ZpbGxDb2xvcj0jZWFmMWZiO3N0cm9rZUNvbG9yPSMyNDRlODY7Zm9udENvbG9yPSMxNzJiNGQ7Zm9udFNpemU9MTc7c3BhY2luZz0xMDsmcXVvdDsgdmVydGV4PSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgeD0mcXVvdDs0NjUmcXVvdDsgeT0mcXVvdDszOTUmcXVvdDsgd2lkdGg9JnF1b3Q7MzMwJnF1b3Q7IGhlaWdodD0mcXVvdDsxMTImcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2FjdGl2ZSZxdW90OyB2YWx1ZT0mcXVvdDtDYXRhbG9ndWUgYWN0aWYgdmVyc2lvbm7DqSZhbXA7IzEwO1BsYW4gY29tcGlsYWJsZSZxdW90OyBzdHlsZT0mcXVvdDtyb3VuZGVkPTE7d2hpdGVTcGFjZT13cmFwO2h0bWw9MDthcmNTaXplPTEyO2ZpbGxDb2xvcj0jZmZmZmZmO3N0cm9rZUNvbG9yPSMyNDRlODY7Zm9udENvbG9yPSMxNzJiNGQ7Zm9udFNpemU9MTc7c3BhY2luZz0xMDsmcXVvdDsgdmVydGV4PSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgeD0mcXVvdDs1NSZxdW90OyB5PSZxdW90OzM5NSZxdW90OyB3aWR0aD0mcXVvdDszMzAmcXVvdDsgaGVpZ2h0PSZxdW90Ozk1JnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7IC8mZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtjaGFuZ2UmcXVvdDsgdmFsdWU9JnF1b3Q7U2Now6ltYSBtb2RpZmnDqSZhbXA7IzEwO0FwcHJvYmF0aW9uIGludmFsaWTDqWUmYW1wOyMxMDtOb3V2ZWxsZSByZXZ1ZSBuw6ljZXNzYWlyZSZxdW90OyBzdHlsZT0mcXVvdDtyb3VuZGVkPTE7d2hpdGVTcGFjZT13cmFwO2h0bWw9MDthcmNTaXplPTEyO2ZpbGxDb2xvcj0jZmZmM2RmO3N0cm9rZUNvbG9yPSNhNjU5MTM7Zm9udENvbG9yPSMxNzJiNGQ7Zm9udFNpemU9MTc7c3BhY2luZz0xMDsmcXVvdDsgdmVydGV4PSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgeD0mcXVvdDs0NjUmcXVvdDsgeT0mcXVvdDs2ODAmcXVvdDsgd2lkdGg9JnF1b3Q7NDAwJnF1b3Q7IGhlaWdodD0mcXVvdDsxMTImcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsgLyZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2VkZ2UtMCZxdW90OyB2YWx1ZT0mcXVvdDsmcXVvdDsgc3R5bGU9JnF1b3Q7ZWRnZVN0eWxlPW9ydGhvZ29uYWxFZGdlU3R5bGU7cm91bmRlZD0xO2h0bWw9MDtlbmRBcnJvdz1ibG9jaztlbmRGaWxsPTE7c3Ryb2tlQ29sb3I9IzY4Nzc4YjtzdHJva2VXaWR0aD0yO2ZvbnRTaXplPTEyO2ZvbnRDb2xvcj0jM2M0ZDYyO2xhYmVsQmFja2dyb3VuZENvbG9yPSNmZmZmZmY7ZXhpdFg9MTtleGl0WT0wLjQ3MzY4NDIxMDUyNjMxNTc2O2VudHJ5WD0wO2VudHJ5WT0wLjU4MDM1NzE0Mjg1NzE0Mjk7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7c2NvcGUmcXVvdDsgdGFyZ2V0PSZxdW90O2ludmVudG9yeSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs0NDAmcXVvdDsgeT0mcXVvdDsxNjAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzQ0MCZxdW90OyB5PSZxdW90OzE4MCZxdW90OyAvJmd0OyZsdDsvQXJyYXkmZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS0xJnF1b3Q7IHZhbHVlPSZxdW90OyZxdW90OyBzdHlsZT0mcXVvdDtlZGdlU3R5bGU9b3J0aG9nb25hbEVkZ2VTdHlsZTtyb3VuZGVkPTE7aHRtbD0wO2VuZEFycm93PWJsb2NrO2VuZEZpbGw9MTtzdHJva2VDb2xvcj0jNjg3NzhiO3N0cm9rZVdpZHRoPTI7Zm9udFNpemU9MTI7Zm9udENvbG9yPSMzYzRkNjI7bGFiZWxCYWNrZ3JvdW5kQ29sb3I9I2ZmZmZmZjtleGl0WD0xO2V4aXRZPTAuNTgwMzU3MTQyODU3MTQyOTtlbnRyeVg9MDtlbnRyeVk9MC40NzM2ODQyMTA1MjYzMTU3NjtleGl0UGVyaW1ldGVyPTA7ZW50cnlQZXJpbWV0ZXI9MDsmcXVvdDsgZWRnZT0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7IHNvdXJjZT0mcXVvdDtpbnZlbnRvcnkmcXVvdDsgdGFyZ2V0PSZxdW90O3Byb3Bvc2FsJnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHJlbGF0aXZlPSZxdW90OzEmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsmZ3Q7Jmx0O0FycmF5IGFzPSZxdW90O3BvaW50cyZxdW90OyZndDsmbHQ7bXhQb2ludCB4PSZxdW90Ozg4MCZxdW90OyB5PSZxdW90OzE4MCZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7ODgwJnF1b3Q7IHk9JnF1b3Q7MTYwJnF1b3Q7IC8mZ3Q7Jmx0Oy9BcnJheSZndDsmbHQ7L214R2VvbWV0cnkmZ3Q7Jmx0Oy9teENlbGwmZ3Q7Jmx0O214Q2VsbCBpZD0mcXVvdDtlZGdlLTImcXVvdDsgdmFsdWU9JnF1b3Q7Q3LDqWVyIHNhbnMgYXBwcm91dmVyJnF1b3Q7IHN0eWxlPSZxdW90O2VkZ2VTdHlsZT1vcnRob2dvbmFsRWRnZVN0eWxlO3JvdW5kZWQ9MTtodG1sPTA7ZW5kQXJyb3c9YmxvY2s7ZW5kRmlsbD0xO3N0cm9rZUNvbG9yPSM2ODc3OGI7c3Ryb2tlV2lkdGg9Mjtmb250U2l6ZT0xMjtmb250Q29sb3I9IzNjNGQ2MjtsYWJlbEJhY2tncm91bmRDb2xvcj0jZmZmZmZmO2V4aXRYPTAuNTMzMzMzMzMzMzMzMzMzMztleGl0WT0xO2VudHJ5WD0wLjUzMzMzMzMzMzMzMzMzMzM7ZW50cnlZPTA7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7cHJvcG9zYWwmcXVvdDsgdGFyZ2V0PSZxdW90O3JldmlldyZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzAuMCZxdW90OyB5PSZxdW90Oy0xNC4wJnF1b3Q7IGFzPSZxdW90O29mZnNldCZxdW90OyAvJmd0OyZsdDsvbXhHZW9tZXRyeSZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2VkZ2UtMyZxdW90OyB2YWx1ZT0mcXVvdDtFeGFtZW4gaHVtYWluJnF1b3Q7IHN0eWxlPSZxdW90O2VkZ2VTdHlsZT1vcnRob2dvbmFsRWRnZVN0eWxlO3JvdW5kZWQ9MTtodG1sPTA7ZW5kQXJyb3c9YmxvY2s7ZW5kRmlsbD0xO3N0cm9rZUNvbG9yPSM2ODc3OGI7c3Ryb2tlV2lkdGg9Mjtmb250U2l6ZT0xMjtmb250Q29sb3I9IzNjNGQ2MjtsYWJlbEJhY2tncm91bmRDb2xvcj0jZmZmZmZmO2V4aXRYPTA7ZXhpdFk9MC41ODAzNTcxNDI4NTcxNDI5O2VudHJ5WD0xO2VudHJ5WT0wLjU4MDM1NzE0Mjg1NzE0Mjk7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7cmV2aWV3JnF1b3Q7IHRhcmdldD0mcXVvdDtodW1hbiZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzAuMCZxdW90OyB5PSZxdW90Oy0xNC4wJnF1b3Q7IGFzPSZxdW90O29mZnNldCZxdW90OyAvJmd0OyZsdDsvbXhHZW9tZXRyeSZndDsmbHQ7L214Q2VsbCZndDsmbHQ7bXhDZWxsIGlkPSZxdW90O2VkZ2UtNCZxdW90OyB2YWx1ZT0mcXVvdDsmcXVvdDsgc3R5bGU9JnF1b3Q7ZWRnZVN0eWxlPW9ydGhvZ29uYWxFZGdlU3R5bGU7cm91bmRlZD0xO2h0bWw9MDtlbmRBcnJvdz1ibG9jaztlbmRGaWxsPTE7c3Ryb2tlQ29sb3I9IzY4Nzc4YjtzdHJva2VXaWR0aD0yO2ZvbnRTaXplPTEyO2ZvbnRDb2xvcj0jM2M0ZDYyO2xhYmVsQmFja2dyb3VuZENvbG9yPSNmZmZmZmY7ZXhpdFg9MDtleGl0WT0wLjU4MDM1NzE0Mjg1NzE0Mjk7ZW50cnlYPTE7ZW50cnlZPTAuNDczNjg0MjEwNTI2MzE1NzY7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7aHVtYW4mcXVvdDsgdGFyZ2V0PSZxdW90O2FjdGl2ZSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs0MjAmcXVvdDsgeT0mcXVvdDs0NjAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzQyMCZxdW90OyB5PSZxdW90OzQ0MCZxdW90OyAvJmd0OyZsdDsvQXJyYXkmZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS01JnF1b3Q7IHZhbHVlPSZxdW90O0NvbXBhcmVyIGVtcHJlaW50ZXMmcXVvdDsgc3R5bGU9JnF1b3Q7ZWRnZVN0eWxlPW9ydGhvZ29uYWxFZGdlU3R5bGU7cm91bmRlZD0xO2h0bWw9MDtlbmRBcnJvdz1ibG9jaztlbmRGaWxsPTE7c3Ryb2tlQ29sb3I9IzY4Nzc4YjtzdHJva2VXaWR0aD0yO2ZvbnRTaXplPTEyO2ZvbnRDb2xvcj0jM2M0ZDYyO2xhYmVsQmFja2dyb3VuZENvbG9yPSNmZmZmZmY7ZXhpdFg9MC41MTUxNTE1MTUxNTE1MTUxO2V4aXRZPTE7ZW50cnlYPTAuNDg3NTtlbnRyeVk9MDtleGl0UGVyaW1ldGVyPTA7ZW50cnlQZXJpbWV0ZXI9MDsmcXVvdDsgZWRnZT0mcXVvdDsxJnF1b3Q7IHBhcmVudD0mcXVvdDsxJnF1b3Q7IHNvdXJjZT0mcXVvdDtpbnZlbnRvcnkmcXVvdDsgdGFyZ2V0PSZxdW90O2NoYW5nZSZxdW90OyZndDsmbHQ7bXhHZW9tZXRyeSByZWxhdGl2ZT0mcXVvdDsxJnF1b3Q7IGFzPSZxdW90O2dlb21ldHJ5JnF1b3Q7Jmd0OyZsdDtBcnJheSBhcz0mcXVvdDtwb2ludHMmcXVvdDsmZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs2NDAmcXVvdDsgeT0mcXVvdDsyNjAmcXVvdDsgLyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzgyMCZxdW90OyB5PSZxdW90OzI2MCZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7ODIwJnF1b3Q7IHk9JnF1b3Q7NjQwJnF1b3Q7IC8mZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs2NjAmcXVvdDsgeT0mcXVvdDs2NDAmcXVvdDsgLyZndDsmbHQ7L0FycmF5Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7MC4wJnF1b3Q7IHk9JnF1b3Q7LTgzLjUmcXVvdDsgYXM9JnF1b3Q7b2Zmc2V0JnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS02JnF1b3Q7IHZhbHVlPSZxdW90O1Jldm9pciBhdmFudCByZXByaXNlJnF1b3Q7IHN0eWxlPSZxdW90O2VkZ2VTdHlsZT1vcnRob2dvbmFsRWRnZVN0eWxlO3JvdW5kZWQ9MTtodG1sPTA7ZW5kQXJyb3c9YmxvY2s7ZW5kRmlsbD0xO3N0cm9rZUNvbG9yPSM2ODc3OGI7c3Ryb2tlV2lkdGg9Mjtmb250U2l6ZT0xMjtmb250Q29sb3I9IzNjNGQ2MjtsYWJlbEJhY2tncm91bmRDb2xvcj0jZmZmZmZmO2V4aXRYPTE7ZXhpdFk9MC41MzU3MTQyODU3MTQyODU3O2VudHJ5WD0wO2VudHJ5WT0wLjU4MDM1NzE0Mjg1NzE0Mjk7ZXhpdFBlcmltZXRlcj0wO2VudHJ5UGVyaW1ldGVyPTA7JnF1b3Q7IGVkZ2U9JnF1b3Q7MSZxdW90OyBwYXJlbnQ9JnF1b3Q7MSZxdW90OyBzb3VyY2U9JnF1b3Q7Y2hhbmdlJnF1b3Q7IHRhcmdldD0mcXVvdDtyZXZpZXcmcXVvdDsmZ3Q7Jmx0O214R2VvbWV0cnkgcmVsYXRpdmU9JnF1b3Q7MSZxdW90OyBhcz0mcXVvdDtnZW9tZXRyeSZxdW90OyZndDsmbHQ7QXJyYXkgYXM9JnF1b3Q7cG9pbnRzJnF1b3Q7Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7OTAwJnF1b3Q7IHk9JnF1b3Q7NzQwJnF1b3Q7IC8mZ3Q7Jmx0O214UG9pbnQgeD0mcXVvdDs5MDAmcXVvdDsgeT0mcXVvdDs0NjAmcXVvdDsgLyZndDsmbHQ7L0FycmF5Jmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7MC4wJnF1b3Q7IHk9JnF1b3Q7LTIxLjUmcXVvdDsgYXM9JnF1b3Q7b2Zmc2V0JnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDtteENlbGwgaWQ9JnF1b3Q7ZWRnZS03JnF1b3Q7IHZhbHVlPSZxdW90O1JhZnJhw65jaGlzc2VtZW50JnF1b3Q7IHN0eWxlPSZxdW90O2VkZ2VTdHlsZT1vcnRob2dvbmFsRWRnZVN0eWxlO3JvdW5kZWQ9MTtodG1sPTA7ZW5kQXJyb3c9YmxvY2s7ZW5kRmlsbD0xO3N0cm9rZUNvbG9yPSM2ODc3OGI7c3Ryb2tlV2lkdGg9Mjtmb250U2l6ZT0xMjtmb250Q29sb3I9IzNjNGQ2MjtsYWJlbEJhY2tncm91bmRDb2xvcj0jZmZmZmZmO2V4aXRYPTE7ZXhpdFk9MC40NzM2ODQyMTA1MjYzMTU3NjtlbnRyeVg9MDtlbnRyeVk9MC41ODAzNTcxNDI4NTcxNDI5O2V4aXRQZXJpbWV0ZXI9MDtlbnRyeVBlcmltZXRlcj0wOyZxdW90OyBlZGdlPSZxdW90OzEmcXVvdDsgcGFyZW50PSZxdW90OzEmcXVvdDsgc291cmNlPSZxdW90O2FjdGl2ZSZxdW90OyB0YXJnZXQ9JnF1b3Q7aW52ZW50b3J5JnF1b3Q7Jmd0OyZsdDtteEdlb21ldHJ5IHJlbGF0aXZlPSZxdW90OzEmcXVvdDsgYXM9JnF1b3Q7Z2VvbWV0cnkmcXVvdDsmZ3Q7Jmx0O0FycmF5IGFzPSZxdW90O3BvaW50cyZxdW90OyZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzQyMCZxdW90OyB5PSZxdW90OzQ0MCZxdW90OyAvJmd0OyZsdDtteFBvaW50IHg9JnF1b3Q7NDIwJnF1b3Q7IHk9JnF1b3Q7MTgwJnF1b3Q7IC8mZ3Q7Jmx0Oy9BcnJheSZndDsmbHQ7bXhQb2ludCB4PSZxdW90OzAuMCZxdW90OyB5PSZxdW90Oy02LjUmcXVvdDsgYXM9JnF1b3Q7b2Zmc2V0JnF1b3Q7IC8mZ3Q7Jmx0Oy9teEdlb21ldHJ5Jmd0OyZsdDsvbXhDZWxsJmd0OyZsdDsvcm9vdCZndDsmbHQ7L214R3JhcGhNb2RlbCZndDsmbHQ7L2RpYWdyYW0mZ3Q7Jmx0Oy9teGZpbGUmZ3Q7Ij48dGl0bGUgaWQ9InRpdGxlIj5NYXBwaW5nIOKAlCBkw6ljb3V2ZXJ0ZSwgcmV2dWUgZXQgYWN0aXZhdGlvbjwvdGl0bGU+PGRlc2MgaWQ9ImRlc2MiPkxlIHNlZWQgZmljdGlmIGVzdCBpZGVudGlmacOpIDsgbGVzIG1hcHBpbmdzIGR1IFNJIHLDqWVsIGdhcmRlbnQgdW5lIGFwcHJvYmF0aW9uIGh1bWFpbmUgZXhwbGljaXRlPC9kZXNjPjxkZWZzPjxtYXJrZXIgaWQ9ImFycm93IiB2aWV3Qm94PSIwIDAgMTAgMTAiIHJlZlg9IjkiIHJlZlk9IjUiIG1hcmtlcldpZHRoPSI4IiBtYXJrZXJIZWlnaHQ9IjgiIG9yaWVudD0iYXV0by1zdGFydC1yZXZlcnNlIj48cGF0aCBkPSJNIDAgMCBMIDEwIDUgTCAwIDEwIHoiIGZpbGw9IiM2ODc3OGIiIC8+PC9tYXJrZXI+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMjgwIiBoZWlnaHQ9IjkwMCIgZmlsbD0iI2ZmZmZmZiIgLz48dGV4dCB4PSIzNSIgeT0iNDgiIGZpbGw9IiMxNzJiNGQiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNSIgZm9udC13ZWlnaHQ9IjcwMCI+TWFwcGluZyDigJQgZMOpY291dmVydGUsIHJldnVlIGV0IGFjdGl2YXRpb248L3RleHQ+PHRleHQgeD0iMzUiIHk9Ijc4IiBmaWxsPSIjNTQ2MTcwIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTQiPkxlIHNlZWQgZmljdGlmIGVzdCBpZGVudGlmacOpIDsgbGVzIG1hcHBpbmdzIGR1IFNJIHLDqWVsIGdhcmRlbnQgdW5lIGFwcHJvYmF0aW9uIGh1bWFpbmUgZXhwbGljaXRlPC90ZXh0Pjxwb2x5bGluZSBwb2ludHM9IjM2MC4wLDE2MCA0NDAsMTYwIDQ0MCwxODAgNDcwLjAsMTgwIiBmaWxsPSJub25lIiBzdHJva2U9IiM2ODc3OGIiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgbWFya2VyLWVuZD0idXJsKCNhcnJvdykiIC8+PHBvbHlsaW5lIHBvaW50cz0iODAwLjAsMTgwIDg4MCwxODAgODgwLDE2MCA5MjAuMCwxNjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSIxMDgwLDIxMC4wIDEwODAsMzk1LjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI5MjAuMCw0NjAgNzk1LjAsNDYwIiBmaWxsPSJub25lIiBzdHJva2U9IiM2ODc3OGIiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgbWFya2VyLWVuZD0idXJsKCNhcnJvdykiIC8+PHBvbHlsaW5lIHBvaW50cz0iNDY1LjAsNDYwIDQyMCw0NjAgNDIwLDQ0MCAzODUuMCw0NDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI2NDAsMjI3LjAgNjQwLDI2MCA4MjAsMjYwIDgyMCw2NDAgNjYwLDY0MCA2NjAsNjgwLjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzY4Nzc4YiIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBtYXJrZXItZW5kPSJ1cmwoI2Fycm93KSIgLz48cG9seWxpbmUgcG9pbnRzPSI4NjUuMCw3NDAgOTAwLDc0MCA5MDAsNDYwIDkyMC4wLDQ2MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNjg3NzhiIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIG1hcmtlci1lbmQ9InVybCgjYXJyb3cpIiAvPjxwb2x5bGluZSBwb2ludHM9IjM4NS4wLDQ0MCA0MjAsNDQwIDQyMCwxODAgNDcwLjAsMTgwIiBmaWxsPSJub25lIiBzdHJva2U9IiM2ODc3OGIiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgbWFya2VyLWVuZD0idXJsKCNhcnJvdykiIC8+PHJlY3QgeD0iNjAuMCIgeT0iMTE1LjAiIHdpZHRoPSIzMDAuMCIgaGVpZ2h0PSI5NS4wIiByeD0iMTIiIGZpbGw9IiNkZmYzZTgiIHN0cm9rZT0iIzE4NmI1MyIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjIxMC4wIiB5PSIxNTcuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5Qb3J0w6llIGF1dG9yaXPDqWU8L3RleHQ+PHRleHQgeD0iMjEwLjAiIHk9IjE3OS41IiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPlNvdXJjZXMgZXQgaW5kZXggY29uY3JldHM8L3RleHQ+PHJlY3QgeD0iNDcwLjAiIHk9IjExNS4wIiB3aWR0aD0iMzMwLjAiIGhlaWdodD0iMTEyLjAiIHJ4PSIxMiIgZmlsbD0iI2VhZjZmMSIgc3Ryb2tlPSIjMTg2YjUzIiBzdHJva2Utd2lkdGg9IjIiIC8+PHRleHQgeD0iNjM1LjAiIHk9IjE1NS4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI2MDAiPkludmVudGFpcmUgcGh5c2lxdWU8L3RleHQ+PHRleHQgeD0iNjM1LjAiIHk9IjE3Ny4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPk1hcHBpbmcgKyBmaWVsZF9jYXBzPC90ZXh0Pjx0ZXh0IHg9IjYzNS4wIiB5PSIxOTkuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5FbXByZWludGUgZHUgc2Now6ltYTwvdGV4dD48cmVjdCB4PSI5MjAuMCIgeT0iMTE1LjAiIHdpZHRoPSIzMDAuMCIgaGVpZ2h0PSI5NS4wIiByeD0iMTIiIGZpbGw9IiNmZmZmZmYiIHN0cm9rZT0iIzI0NGU4NiIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjEwNzAuMCIgeT0iMTU3LjUiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjYwMCI+UHJvcG9zaXRpb24gZGUgbWFwcGluZzwvdGV4dD48dGV4dCB4PSIxMDcwLjAiIHk9IjE3OS41IiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPkNvbmNlcHRzIGV0IHJlbGF0aW9uczwvdGV4dD48cmVjdCB4PSI5MjAuMCIgeT0iMzk1LjAiIHdpZHRoPSIzMDAuMCIgaGVpZ2h0PSIxMTIuMCIgcng9IjEyIiBmaWxsPSIjZmZmM2RmIiBzdHJva2U9IiNhNjU5MTMiIHN0cm9rZS13aWR0aD0iMiIgLz48dGV4dCB4PSIxMDcwLjAiIHk9IjQzNS4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI2MDAiPlJldnVlIGVuIGF0dGVudGU8L3RleHQ+PHRleHQgeD0iMTA3MC4wIiB5PSI0NTcuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5UeXBlcywgc2VucyBldCBwb3J0w6llPC90ZXh0Pjx0ZXh0IHg9IjEwNzAuMCIgeT0iNDc5LjAiIGZpbGw9IiMxNzJiNGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNyIgZm9udC13ZWlnaHQ9IjQwMCI+RXNzYWlzIERTTCBib3Juw6lzPC90ZXh0PjxyZWN0IHg9IjQ2NS4wIiB5PSIzOTUuMCIgd2lkdGg9IjMzMC4wIiBoZWlnaHQ9IjExMi4wIiByeD0iMTIiIGZpbGw9IiNlYWYxZmIiIHN0cm9rZT0iIzI0NGU4NiIgc3Ryb2tlLXdpZHRoPSIyIiAvPjx0ZXh0IHg9IjYzMC4wIiB5PSI0MzUuMCIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNjAwIj5PcMOpcmF0ZXVyIGludGVybmU8L3RleHQ+PHRleHQgeD0iNjMwLjAiIHk9IjQ1Ny4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPlJlbGl0IHB1aXMgYXBwcm91dmU8L3RleHQ+PHRleHQgeD0iNjMwLjAiIHk9IjQ3OS4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPkF1dGV1ciBldCBtb3RpZjwvdGV4dD48cmVjdCB4PSI1NS4wIiB5PSIzOTUuMCIgd2lkdGg9IjMzMC4wIiBoZWlnaHQ9Ijk1LjAiIHJ4PSIxMiIgZmlsbD0iI2ZmZmZmZiIgc3Ryb2tlPSIjMjQ0ZTg2IiBzdHJva2Utd2lkdGg9IjIiIC8+PHRleHQgeD0iMjIwLjAiIHk9IjQzNy41IiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI2MDAiPkNhdGFsb2d1ZSBhY3RpZiB2ZXJzaW9ubsOpPC90ZXh0Pjx0ZXh0IHg9IjIyMC4wIiB5PSI0NTkuNSIgZmlsbD0iIzE3MmI0ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjE3IiBmb250LXdlaWdodD0iNDAwIj5QbGFuIGNvbXBpbGFibGU8L3RleHQ+PHJlY3QgeD0iNDY1LjAiIHk9IjY4MC4wIiB3aWR0aD0iNDAwLjAiIGhlaWdodD0iMTEyLjAiIHJ4PSIxMiIgZmlsbD0iI2ZmZjNkZiIgc3Ryb2tlPSIjYTY1OTEzIiBzdHJva2Utd2lkdGg9IjIiIC8+PHRleHQgeD0iNjY1LjAiIHk9IjcyMC4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI2MDAiPlNjaMOpbWEgbW9kaWZpw6k8L3RleHQ+PHRleHQgeD0iNjY1LjAiIHk9Ijc0Mi4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPkFwcHJvYmF0aW9uIGludmFsaWTDqWU8L3RleHQ+PHRleHQgeD0iNjY1LjAiIHk9Ijc2NC4wIiBmaWxsPSIjMTcyYjRkIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTciIGZvbnQtd2VpZ2h0PSI0MDAiPk5vdXZlbGxlIHJldnVlIG7DqWNlc3NhaXJlPC90ZXh0Pjx0ZXh0IHg9IjM1IiB5PSI4ODQiIGZpbGw9IiM1NDYxNzAiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxMiI+RG9jdW1lbnRhdGlvbiBTSS1SSUUg4oCiIFNvdXJjZSBuYXRpdmUgLmRyYXdpbyDDqWRpdGFibGUg4oCiIERvbm7DqWVzIGZpY3RpdmVzIHBvdXIgbGVzIGTDqW1vbnN0cmF0aW9uczwvdGV4dD48cmVjdCB4PSIxMDEwLjAiIHk9IjI3OC41IiB3aWR0aD0iMTQwLjAiIGhlaWdodD0iMjAiIHJ4PSIzIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjk2IiAvPjx0ZXh0IHg9IjEwODAuMCIgeT0iMjkyLjUiIGZpbGw9IiMzYzRkNjIiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxMiI+Q3LDqWVyIHNhbnMgYXBwcm91dmVyPC90ZXh0PjxyZWN0IHg9IjgwOS45IiB5PSI0MzYuMCIgd2lkdGg9Ijk1LjIiIGhlaWdodD0iMjAiIHJ4PSIzIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjk2IiAvPjx0ZXh0IHg9Ijg1Ny41IiB5PSI0NTAuMCIgZmlsbD0iIzNjNGQ2MiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5FeGFtZW4gaHVtYWluPC90ZXh0PjxyZWN0IHg9Ijc1My4yIiB5PSIzNTAuMCIgd2lkdGg9IjEzMy42MDAwMDAwMDAwMDAwMiIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjAuOTYiIC8+PHRleHQgeD0iODIwLjAiIHk9IjM2NC4wIiBmaWxsPSIjM2M0ZDYyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTIiPkNvbXBhcmVyIGVtcHJlaW50ZXM8L3RleHQ+PHJlY3QgeD0iODMwLjAiIHk9IjU3Ni4wIiB3aWR0aD0iMTQwLjAiIGhlaWdodD0iMjAiIHJ4PSIzIiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjk2IiAvPjx0ZXh0IHg9IjkwMC4wIiB5PSI1OTAuMCIgZmlsbD0iIzNjNGQ2MiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjEyIj5SZXZvaXIgYXZhbnQgcmVwcmlzZTwvdGV4dD48cmVjdCB4PSIzNjIuOCIgeT0iMjg2LjAiIHdpZHRoPSIxMTQuNCIgaGVpZ2h0PSIyMCIgcng9IjMiIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjAuOTYiIC8+PHRleHQgeD0iNDIwLjAiIHk9IjMwMC4wIiBmaWxsPSIjM2M0ZDYyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTIiPlJhZnJhw65jaGlzc2VtZW50PC90ZXh0Pjwvc3ZnPgo=
```


[Source draw.io du cycle de revue](/dinum-rie/diagrams/07-mapping-approval.drawio)

Depuis le serveur Ubuntu, avec l'identifiant LDAP interne de l'opérateur :

```bash
# Relit les schémas autorisés et actualise l'inventaire et les revues PDL ; n'approuve aucun mapping.
sudo python3 deploy/ubuntu/manage.py pdl "$RIE_INSTANCE" --username LDAP_USERNAME -- refresh
# Affiche l'inventaire, le catalogue actif et les revues en attente pour l'identité de l'opérateur.
sudo python3 deploy/ubuntu/manage.py pdl "$RIE_INSTANCE" --username LDAP_USERNAME -- inspect
```

La découverte relit le schéma et ses capacités. Un changement invalide les
approbations concernées. Pour un fichier opérateur relu dans `config/mappings.yaml` : le modèle public
`deploy/ubuntu/examples/mappings.yaml` permet de commencer sur un index réel.
Le copier seulement dans une instance externe neuve et adapter les champs avec
le responsable métier. Le fichier n’est ni un catalogue actif ni une approbation.
L’option `--input` ouvre le fichier avec les droits de la commande ; elle évite
une redirection shell qui échouerait sur un fichier privé à root.

Puis :

```bash
# Vérifie le fichier de propositions de mappings fourni ; ne l'active pas.
sudo python3 deploy/ubuntu/manage.py pdl "$RIE_INSTANCE" --username LDAP_USERNAME --input "$RIE_INSTANCE/config/mappings.yaml" -- validate-mappings
# Importe les propositions de concepts et relations pour créer des revues ; leur approbation reste manuelle.
sudo python3 deploy/ubuntu/manage.py pdl "$RIE_INSTANCE" --username LDAP_USERNAME --input "$RIE_INSTANCE/config/mappings.yaml" -- load-mappings --reason "Revue métier des concepts et relations"
# Affiche la revue indiquée pour vérifier les champs, relations et preuves avant toute approbation.
sudo python3 deploy/ubuntu/manage.py pdl "$RIE_INSTANCE" --username LDAP_USERNAME -- inspect --review-id REVIEW_ID
# Approuve la revue identifiée après contrôle métier ; cette action rend le mapping utilisable.
sudo python3 deploy/ubuntu/manage.py pdl "$RIE_INSTANCE" --username LDAP_USERNAME -- approve-review REVIEW_ID --reason "Champs et relations confirmés"
```

L'import crée des revues en attente. Relire les champs, types, portée et relations
avant l'approbation d'un identifiant précis. Le seed fictif peut activer les seuls
mappings embarqués après contrôle de leur schéma ; son auteur est identifié comme
fixture de démonstration, pas comme une nouvelle décision humaine sur le SI réel.

## Retrouver une erreur

Les lectures de champs `_source` et empreintes JSON utilisent
`rie_agent/documents.py`, partagé avec le moteur Mac depuis le 11 novembre.
Ce module ne charge ni configuration ni client de source. Les formats des
empreintes, les noms importés existants et les approbations persistées restent
compatibles ; la mutualisation n'active aucun mapping.

Les points d'entrée sont `rie_agent/mcp_app.py`, `service.py`, `planner.py`,
`inventory.py`, `opensearch.py`, `mappings.py`, `equipment.py` et `store.py`.
Commencer par le résultat structuré, le statut, le plan validé et le DSL exécuté.
Un ancien rapport ne se recalcule pas automatiquement après correction d'un mapping.

Ne pas confondre : mapping approuvé, droit d'accès à l'index et disponibilité
physique de la source. Chacun possède son propre contrôle et sa propre cause
d'échec. Voir [ACL](/dinum-rie/reference/06-acl) et [Exploitation](/dinum-rie/reference/07-operations).
