# Compléments du guide de déploiement

**Le seul parcours à exécuter est le [guide principal](/dinum-rie), étapes 1 à 12.**
Ces pages répondent à une question précise ; elles ne se lisent pas dans l'ordre
de leurs numéros et ne constituent pas une deuxième installation.

## Préparer le raccordement

- Assistant **Déploiement** dans NiceGUI : [préparation guidée du raccordement](/dinum-rie#6-préparer-le-raccordement-avec-nicegui).
- [Fiche de raccordement à compléter avec les responsables du SI](/dinum-rie/reference/26-si-connection-sheet).
- [Détail des fichiers et contrats de configuration](/dinum-rie/reference/02-configuration).
- [Glossaire : instance, mapping, LDAP, ACL, jeton et recette](/dinum-rie/reference/23-glossary).

### Fiche de raccordement

Elle rassemble les paramètres fournis par les responsables des sources : URLs,
CA, comptes lecteurs, groupes, index, séries et cas métier. Les secrets sont
remis séparément. Les responsables font confirmer ces valeurs avant le démarrage ; l’étape 6
du guide explique leur saisie dans NiceGUI et l’import des fichiers générés.

## Comprendre le code, les flux et les accès

- [Architecture et services](/dinum-rie/reference/03-architecture).
- [Moteur et mappings PDL](/dinum-rie/reference/04-pdl).
- [Diagnostic Incidents et contrats des sources](/dinum-rie/reference/05-incidents).
- [Identités et ACL des deux UC](/dinum-rie/reference/06-acl).
- [Précédents et solutions ITSM-NG](/dinum-rie/reference/15-itsm-precedents).
- [Connexion personnelle Open WebUI, LDAP et OAuth](/dinum-rie/reference/25-user-access).

## Exploiter et réceptionner

- [Exploitation, mise à jour, sauvegarde et restauration](/dinum-rie/reference/07-operations).
- [Résultats de qualification et limites](/dinum-rie/reference/08-qualification).
- [Grille de recette manuelle](/dinum-rie/reference/12-manual-acceptance).
- [Rapports Allure et intégration continue](/dinum-rie/reference/13-test-reports).
- [Réception dans le SI-RIE réel et responsabilités](/dinum-rie/reference/14-si-rie-acceptance).

## Démontrer et s'exercer dans le laboratoire

- [Démonstrations NiceGUI et captures datées](/dinum-rie/reference/09-demonstrations).
- [Tutoriel métier PDL](/dinum-rie/reference/16-pdl-tutorial).
- [Tutoriel métier Incidents](/dinum-rie/reference/17-incidents-tutorial).
- [Paramètres et état de la sandbox du 16 novembre](/dinum-rie/reference/22-external-sandbox).

## Maintenir le code et publier les images

- [Espace VS Code, builds, publication dans la registry et cycle de correction](/dinum-rie/reference/27-development-and-images).

## Consulter une variante ou exporter vers le wiki

- [Référence d'installation : démonstration autonome, script et construction des images](/dinum-rie/reference/01-installation).
- [Exporter et importer Markdown, images et draw.io dans Wiki.js](/dinum-rie/reference/10-wikijs).

## Retrouver une preuve historique

Ces pages conservent les dates, versions, échecs et limites réellement observés.
Elles ne décrivent pas des commandes supplémentaires à rejouer pour installer.

- [Journal des installations et corrections](/dinum-rie/reference/11-installation-log).
- [Répétition complète du guide sur Ubuntu neuf — 18 novembre 2026](/dinum-rie/reference/28-deployment-rehearsal).
- [Campagne initiale de stabilité Open WebUI](/dinum-rie/reference/18-openwebui-stability).
- [Corrections et conversations requalifiées](/dinum-rie/reference/19-openwebui-corrections).
- [Remise et qualification Ubuntu du 13 novembre](/dinum-rie/reference/20-final-ubuntu-qualification).
- [Réserves et clôture des preuves du 14 novembre](/dinum-rie/reference/21-evidence-reservations).
