"""Guided mapping form and explicit reviews, without exposing operator YAML first."""
from __future__ import annotations

from copy import deepcopy
import json
import os
import re

from nicegui import run, ui
from dinum_access import AccessDenied
from rie_agent.identity_extractors import PARSERS
from rie_agent.operator_mappings import MAX_BYTES

from .backend import PortalError
from .mapping_admin import compatible_fields, document_from_snapshot

CONCEPTS = {
    'timestamp': 'Heure de l’événement', 'network_scope': 'Périmètre réseau',
    'equipment': 'Nom de l’équipement', 'stable_id': 'Identifiant stable de l’équipement',
    'equipment_fqdn': 'FQDN de l’équipement', 'management_ip': 'IP de gestion',
    'equipment_reference': 'Référence de l’équipement', 'source_ip': 'IP du trafic source',
    'destination_ip': 'IP du trafic destination', 'action': 'Action réseau',
    'event_type': 'Type d’événement', 'severity': 'Gravité', 'rule': 'Règle réseau',
    'virtual_domain': 'Domaine virtuel', 'username': 'Compte utilisateur',
}
ROLES = {'': 'Aucun rôle d’identité', 'name': 'Nom d’équipement', 'fqdn': 'FQDN d’équipement',
         'ip': 'IP d’équipement à rapprocher', 'id': 'Identifiant stable', 'reference': 'Référence'}


def value_lines(values):
    return '\n'.join(value if isinstance(value, str) else json.dumps(value) for value in values or [])


def parse_values(text, kind):
    values = [line for line in (text or '').splitlines() if line != '']
    if kind in {'long', 'integer', 'short', 'byte', 'unsigned_long'}:
        return [int(value) for value in values]
    if kind in {'float', 'double', 'half_float', 'scaled_float'}:
        return [float(value) for value in values]
    if kind == 'boolean':
        if any(value not in {'true', 'false'} for value in values):
            raise ValueError('Boolean values require true or false')
        return [value == 'true' for value in values]
    return values


def describe_mapping(spec):
    if spec is None:
        return 'Absent'
    parts = [str(spec.get('field', 'à choisir')), str(spec.get('type', ''))]
    if spec.get('values'):
        parts.append('Valeurs : ' + ', '.join(str(value) for value in spec['values']))
    if spec.get('identity_role'):
        parts.append(ROLES.get(spec['identity_role'], spec['identity_role']))
        parts.append('Groupe : ' + spec.get('identity_namespace', 'à confirmer'))
    if spec.get('source_field', spec.get('field')) != spec.get('field'):
        parts.append('Lecture : ' + spec['source_field'])
    if spec.get('identity_anchor'):
        parts.append('Point de départ confirmé')
    if spec.get('identity_match'):
        parts.append('Préfixe de nom court')
    if spec.get('identity_extractor'):
        parts.append('Extraction : ' + spec['identity_extractor'])
    return ' · '.join(parts)


def page(session, shell, authentication, message, document_panel):
    with ui.column().classes('portal-page gap-5'):
        shell('Administrer les mappings PDL')
        ui.label('Associez les concepts métier aux champs des index autorisés. Une proposition reste inactive jusqu’à son approbation.').classes('portal-note')
        ui.label('L’heure de l’événement, le sens des valeurs et les identités communes doivent être confirmés avec le responsable des sources.')
        with ui.column().classes('w-full').props('data-mapping-example'):
            document_panel('04-pdl', 'Exemple complet illustré · PFS, Backbone, PFAING et TACACS')

        def protected(session, identity, on_error):
            if not identity['administrator']:
                ui.label('Administration réservée aux membres du groupe LDAP d’administration des accès.').props('data-mapping-denied').classes('text-red-8')
                return
            admin = session.mapping_administration()
            ui.label('Instance : ' + os.getenv('RIE_UI_INSTANCE_ID', 'identifiant non fourni')).props('data-mapping-instance')
            state = {'snapshot': None, 'document': {'version': 1, 'indices': {}, 'relations': {}},
                     'profile': None, 'validation': None, 'revision': 0, 'review': None, 'busy': False,
                     'open_concept': 'timestamp', 'invalid_values': set()}
            output = ui.column().classes('w-full').props('data-mapping-output')
            validation_label = ui.label('Proposition non validée.').props('data-mapping-validation')
            busy_label = ui.label().props('data-mapping-busy')

            def changed():
                state['revision'] += 1
                state['validation'] = None
                validation_label.set_text('Modifications à vérifier avant enregistrement.')
                relationships.refresh()

            def fail(error):
                state['validation'] = None
                state['review'] = None
                review_panel.refresh()
                output.clear()
                with output:
                    ui.label(message(error)).classes('text-red-8').props('data-portal-error')
                    for issue in getattr(error, 'issues', []):
                        ui.label(issue).classes('text-red-8')
                if isinstance(error, AccessDenied):
                    # Old fields and review controls disappear on any revoked source access.
                    state['snapshot'] = None
                    state['document'] = {'version': 1, 'indices': {}, 'relations': {}}
                    index_table.rows = []; index_table.update()
                    review_select.options = {}; review_select.value = None; review_select.update()
                    pending_label.set_text('')
                    editor.refresh(); review_panel.refresh()
                    relationships.refresh()
                on_error(error)

            async def invoke(operation, success):
                if state['busy']:
                    return
                state['busy'] = True
                busy_label.set_text('Vérification en cours…')
                epoch = session._epoch
                try:
                    result = await run.io_bound(operation)
                    session._unchanged(epoch)
                    success(result)
                except (AccessDenied, PortalError, OSError, ValueError, KeyError) as error:
                    fail(error)
                finally:
                    state['busy'] = False
                    if not busy_label.is_deleted:
                        busy_label.set_text('')

            def received(snapshot, *, reset=False):
                state['snapshot'] = snapshot
                if reset or not state['document']['indices']:
                    state['invalid_values'].clear()
                    state['document'] = document_from_snapshot(snapshot)
                    state['profile'] = next(iter(state['document']['indices']), None)
                    changed()
                index_table.rows = [{'index': name, 'fields': len(entry['fields']),
                    'approved': '✅ Actif' if any(row.get('active') and row['index'] == name
                                                 for row in snapshot['catalog']) else 'En attente'}
                    for name, entry in snapshot['inventory']['indices'].items()]
                index_table.update()
                pending = [row for row in snapshot['reviews'] if row['status'] == 'pending']
                options = {row['id']: row['index'] + ' · ' + row['id'] for row in pending}
                if review_select.value not in options:
                    review_select.value = None
                review_select.options = options
                review_select.update()
                pending_label.set_text(str(len(pending)) + ' revue(s) en attente.')
                editor.refresh()

            with ui.card().classes('w-full'):
                ui.label('1. Sources autorisées et propositions').classes('text-xl font-semibold')
                index_table = ui.table(columns=[{'name': 'index', 'field': 'index', 'label': 'Index physique'},
                    {'name': 'fields', 'field': 'fields', 'label': 'Champs découverts'},
                    {'name': 'approved', 'field': 'approved', 'label': 'Mapping actif'}], rows=[], row_key='index').classes('w-full').props('data-mapping-indices')
                with ui.row():
                    ui.button('Actualiser les sources', on_click=lambda: invoke(
                        lambda: admin.overview(refresh=True), received)).props('data-mapping-refresh')
                    def imported(document):
                        state['invalid_values'].clear()
                        state['document'] = document
                        state['profile'] = next(iter(document['indices']), None)
                        changed(); editor.refresh()
                        ui.notify('Proposition chargée dans le formulaire ; aucune approbation effectuée.')
                    ui.button('Charger le fichier initial', on_click=lambda: invoke(admin.initial_document, imported)).props('outline data-mapping-load-initial')

                async def upload(event):
                    try:
                        identity = await run.io_bound(session.identity)
                        if not identity['administrator']:
                            raise AccessDenied('administrator_required')
                        data = bytearray()
                        async for chunk in event.file.iterate(chunk_size=65536):
                            data.extend(chunk)
                            if len(data) > MAX_BYTES:
                                raise PortalError('mapping_invalid_document')
                        await invoke(lambda: admin.import_document(bytes(data)), imported)
                    except (AccessDenied, PortalError, OSError, ValueError) as error:
                        fail(error)
                    finally:
                        # A rejected file must not occupy the only upload slot.
                        if not event.sender.is_deleted:
                            event.sender.reset()
                ui.upload(label='Importer un fichier YAML/JSON', auto_upload=True, max_files=1,
                          max_file_size=MAX_BYTES, on_upload=upload).props('accept=.yaml,.yml,.json data-mapping-upload')

            @ui.refreshable
            def editor():
                snapshot = state['snapshot']
                if not snapshot:
                    return
                document = state['document']
                with ui.card().classes('w-full').props('data-mapping-editor'):
                    ui.label('2. Correspondances métier').classes('text-xl font-semibold')
                    profiles = document['indices']
                    with ui.row().classes('w-full items-end'):
                        profile_select = ui.select({key: key + ' · ' + row['match'] for key, row in profiles.items()},
                            value=state['profile'], label='Profil à modifier', with_input=True).classes('grow').props('data-mapping-profile')
                        def select_profile(event):
                            state['profile'] = event.value
                            editor.refresh()
                        profile_select.on_value_change(select_profile)
                        available = {name: name for name in snapshot['inventory']['indices']
                                     if name not in {row['match'] for row in profiles.values()}}
                        add_index = ui.select(available, label='Ajouter un index découvert', with_input=True).classes('grow').props('data-mapping-add-index')
                        def add_profile():
                            if add_index.value not in available:
                                return
                            base = re.sub('[^a-z0-9_]', '_', add_index.value)[:54]
                            if not base[0].isalpha(): base = 'index_' + base
                            key, number = base, 1
                            while key in profiles:
                                number += 1; key = base + '_' + str(number)
                            profiles[key] = {'match': add_index.value, 'concepts': {'timestamp': {'field': '', 'type': 'date'}}}
                            state['profile'] = key
                            changed(); editor.refresh()
                        ui.button('Ajouter cet index', on_click=add_profile).props('data-mapping-add-profile')
                    profile = state['profile']
                    if profile not in profiles:
                        ui.label('Choisissez un index découvert pour commencer sans écrire de YAML.')
                        return
                    definition = profiles[profile]
                    fields = compatible_fields(snapshot['inventory'], definition['match'])
                    ui.label('Index sélectionné : ' + definition['match'])
                    def remove_profile():
                        state['invalid_values'] = {key for key in state['invalid_values'] if key[0] != profile}
                        for namespace in list(document['relations']):
                            document['relations'][namespace].pop(profile, None)
                            if not document['relations'][namespace]: document['relations'].pop(namespace)
                        profiles.pop(profile)
                        state['profile'] = next(iter(profiles), None)
                        changed(); editor.refresh()
                    ui.button('Retirer cet index de la proposition', on_click=remove_profile).props('flat data-mapping-remove-profile')

                    def namespace_for(concept):
                        return next((name for name, members in document['relations'].items()
                                     if concept in members.get(profile, [])), '')

                    def set_namespace(concept, namespace):
                        for name in list(document['relations']):
                            members = document['relations'][name]
                            if concept in members.get(profile, []):
                                members[profile].remove(concept)
                                if not members[profile]: members.pop(profile)
                            if not members: document['relations'].pop(name)
                        if namespace:
                            document['relations'].setdefault(namespace, {}).setdefault(profile, []).append(concept)
                        changed()

                    def remove_concept(concept):
                        state['invalid_values'].discard((profile, concept))
                        set_namespace(concept, '')
                        definition['concepts'].pop(concept)
                        changed(); editor.refresh()

                    for concept, spec in list(definition['concepts'].items()):
                        with ui.expansion(CONCEPTS.get(concept, concept) + ' · ' + str(spec.get('field') or 'champ à choisir'),
                            value=state['open_concept'] == concept, icon='rule').classes('w-full').props('data-mapping-concept=' + concept) as concept_panel:
                            concept_panel.on_value_change(lambda event, name=concept: state.update(open_concept=name) if event.value else None)
                            choices = {name: name + ' · ' + cap['type'] for name, cap in fields.items()
                                       if concept != 'timestamp' or cap['type'] in {'date', 'date_nanos'}}
                            field_select = ui.select(choices, value=spec.get('field') if spec.get('field') in choices else None,
                                label='Champ physique', with_input=True).classes('w-full').props('data-mapping-field=' + concept)
                            def choose_field(event, item=spec, name=concept):
                                item['field'] = event.value or ''
                                item['type'] = fields.get(event.value, {}).get('type', '')
                                parent = (event.value or '').rsplit('.', 1)[0]
                                if parent != event.value and fields.get(parent, {}).get('type') == 'text':
                                    item['source_field'] = parent
                                else:
                                    item.pop('source_field', None)
                                state['invalid_values'].discard((profile, name))
                                changed(); editor.refresh()
                            field_select.on_value_change(choose_field)
                            ui.label('Type détecté : ' + str(spec.get('type', 'à choisir'))).props('data-mapping-type=' + concept)
                            values = ui.textarea('Valeurs métier possibles, une par ligne (facultatif)',
                                value=value_lines(spec.get('values'))).classes('w-full').props('data-mapping-values=' + concept)
                            observed = []
                            for name, entry in snapshot['inventory']['indices'].items():
                                if name == definition['match']:
                                    observed = entry.get('bounded_values', {}).get(spec.get('field'), [])[:5]
                            if observed:
                                ui.label('Exemples observés, non exhaustifs : ' + ', '.join(str(row['value']) for row in observed)[:500]).classes('text-sm text-grey-7')
                            def change_values(event, item=spec, name=concept):
                                try:
                                    parsed = parse_values(event.value, item.get('type'))
                                    if parsed: item['values'] = parsed
                                    else: item.pop('values', None)
                                    state['invalid_values'].discard((profile, name))
                                    changed()
                                except ValueError:
                                    state['invalid_values'].add((profile, name))
                                    changed()
                                    ui.notify('Valeurs incompatibles avec le type détecté ; nombres ou true/false attendus.', type='negative')
                            values.on_value_change(change_values)
                            with ui.expansion('Identité et lecture avancée').classes('w-full'):
                                ui.label('Une IP de trafic n’est pas automatiquement une IP de gestion. Un même groupe de correspondance désigne une identité métier confirmée entre sources.').classes('portal-note')
                                role = ui.select(ROLES, value=spec.get('identity_role', ''), label='Rôle d’identité').classes('w-full').props('data-mapping-role=' + concept)
                                namespace = ui.input('Groupe de correspondance entre sources', value=namespace_for(concept)).classes('w-full').props('data-mapping-namespace=' + concept)
                                namespace.on_value_change(lambda event, name=concept: set_namespace(name, (event.value or '').strip()))
                                def change_role(event, item=spec, name=concept):
                                    if event.value:
                                        item['identity_role'] = event.value
                                        if event.value not in {'name', 'fqdn'}: item.pop('identity_anchor', None)
                                        if event.value != 'fqdn': item.pop('identity_match', None)
                                        if event.value != 'ip': item.pop('identity_extractor', None)
                                    else:
                                        for key in ('identity_role', 'identity_anchor', 'identity_match', 'identity_extractor'):
                                            item.pop(key, None)
                                        set_namespace(name, '')
                                    changed(); editor.refresh()
                                role.on_value_change(change_role)
                                source_choices = {name: name for name in fields if name == spec.get('field')
                                                  or spec.get('field', '').startswith(name + '.')}
                                source = ui.select(source_choices, value=spec.get('source_field', spec.get('field'))
                                    if spec.get('source_field', spec.get('field')) in source_choices else None,
                                    label='Champ de lecture dans le document source').classes('w-full')
                                source.on_value_change(lambda event, item=spec: (item.update(source_field=event.value), changed()))
                                if spec.get('identity_role') in {'name', 'fqdn'}:
                                    anchor = ui.checkbox('Nom/FQDN confirmé comme point de départ de l’identité', value=spec.get('identity_anchor', False))
                                    anchor.on_value_change(lambda event, item=spec: (item.update(identity_anchor=event.value), changed()))
                                if spec.get('identity_role') == 'fqdn':
                                    match = ui.select({'': 'Nom complet', 'short_name_prefix': 'Préfixe de nom court confirmé'}, value=spec.get('identity_match', ''), label='Rapprochement FQDN')
                                    match.on_value_change(lambda event, item=spec: (item.update(identity_match=event.value) if event.value else item.pop('identity_match', None), changed()))
                                if spec.get('identity_role') == 'ip' and spec.get('type') == 'text':
                                    extractor = ui.select({'': 'Aucune extraction', **{name: name for name in PARSERS}}, value=spec.get('identity_extractor', ''), label='Extraction textuelle approuvée')
                                    extractor.on_value_change(lambda event, item=spec: (item.update(identity_extractor=event.value) if event.value else item.pop('identity_extractor', None), changed()))
                            ui.button('Retirer ce concept', on_click=lambda name=concept: remove_concept(name)).props('flat data-mapping-remove-concept=' + concept)
                    add_concept = ui.select({name: label for name, label in CONCEPTS.items() if name not in definition['concepts']}, label='Ajouter un concept métier').props('data-mapping-add-concept')
                    def add():
                        if add_concept.value and add_concept.value not in definition['concepts']:
                            definition['concepts'][add_concept.value] = {'field': '', 'type': ''}
                            state['open_concept'] = add_concept.value
                            changed(); editor.refresh()
                    ui.button('Ajouter ce concept', on_click=add).props('data-mapping-add-concept-button')

            editor()
            @ui.refreshable
            def relationships():
                if not state['snapshot']:
                    return
                rows = []
                document = state['document']
                for namespace, members in document['relations'].items():
                    fields, roles = [], set()
                    for profile, concepts in members.items():
                        for concept in concepts:
                            spec = document['indices'].get(profile, {}).get('concepts', {}).get(concept, {})
                            fields.append(profile + ' / ' + concept + ' → ' + str(spec.get('field', 'à choisir')))
                            roles.add(ROLES.get(spec.get('identity_role'), 'Rôle à choisir'))
                    rows.append({'group': namespace, 'roles': ', '.join(sorted(roles)), 'members': ' ; '.join(fields)})
                with ui.expansion('Rapprochements prévus entre sources', value=True).classes('w-full'):
                    ui.table(columns=[{'name': key, 'field': key, 'label': label} for key, label in
                        [('group', 'Groupe commun'), ('roles', 'Rôle d’identité'), ('members', 'Correspondances')]],
                        rows=rows, row_key='group').classes('w-full').props('data-mapping-relations')
            relationships()
            with ui.card().classes('w-full'):
                reason = ui.input('Motif de la proposition').classes('w-full').props('data-mapping-stage-reason')
                def valid_values():
                    if state['invalid_values']:
                        raise PortalError('mapping_invalid_values')
                async def validate():
                    revision, document = state['revision'], deepcopy(state['document'])
                    def validated(result):
                        if revision != state['revision']:
                            raise PortalError('mapping_draft_changed')
                        state['validation'] = result
                        validation_label.set_text('Proposition valide techniquement ; approbation humaine encore requise.')
                    await invoke(lambda: (valid_values(), admin.validate(document))[1], validated)
                async def stage():
                    document, validation = deepcopy(state['document']), deepcopy(state['validation'])
                    stage_reason = reason.value or ''
                    def saved(result):
                        state['validation'] = None
                        validation_label.set_text('Proposition enregistrée en attente ; aucun mapping activé.' if result['reviews']
                                                  else 'Ces correspondances sont déjà actives ; aucune nouvelle revue nécessaire.')
                        output.clear()
                        with output:
                            for row in result['reviews']:
                                ui.label(row['index'] + ' · revue ' + row['id'])
                        ui.timer(.05, lambda: invoke(admin.overview, received), once=True)
                    await invoke(lambda: (valid_values(), admin.stage(document, validation, stage_reason))[1], saved)
                with ui.row():
                    ui.button('Vérifier la proposition', on_click=validate).props('data-mapping-validate')
                    ui.button('Enregistrer une proposition', on_click=stage).props('data-mapping-stage')
                    async def export():
                        await invoke(lambda: (valid_values(), admin.export(deepcopy(state['document'])))[1],
                            lambda raw: ui.download.content(raw, 'pdl-mappings.yaml', 'application/yaml'))
                    ui.button('Exporter le YAML', on_click=export).props('outline data-mapping-export')

            with ui.card().classes('w-full'):
                ui.label('3. Revue et approbation explicite').classes('text-xl font-semibold')
                pending_label = ui.label().props('data-mapping-pending-count')
                review_select = ui.select({}, label='Revue à examiner', with_input=True).classes('w-full').props('data-mapping-review-select')
                async def inspect_review():
                    def selected(result):
                        state['review'] = result
                        review_panel.refresh()
                    await invoke(lambda: admin.review(review_select.value or ''), selected)
                ui.button('Examiner cette revue', on_click=inspect_review).props('data-mapping-inspect')

                @ui.refreshable
                def review_panel():
                    result = state['review']
                    if not result:
                        return
                    review = result['review']
                    ui.label(review['index'] + ' · ' + review['status']).classes('font-semibold').props('data-mapping-review-title')
                    old = result['active'][0].get('concepts', {}) if result['active'] else {}
                    rows = []
                    for name in sorted(set(old) | set(review['proposed_mapping'])):
                        before, after = old.get(name), review['proposed_mapping'].get(name)
                        rows.append({'concept': CONCEPTS.get(name, name), 'before': describe_mapping(before),
                                     'after': describe_mapping(after) if after else 'Retiré',
                                     'change': 'Identique' if before == after else 'Ajout' if before is None else 'Retrait' if after is None else 'Modification'})
                    ui.table(columns=[{'name': key, 'field': key, 'label': label, 'align': 'left'} for key, label in
                        [('concept', 'Concept métier'), ('before', 'Version active'), ('after', 'Proposition'), ('change', 'Différence')]],
                        rows=rows, row_key='concept').classes('w-full').props('data-mapping-diff')
                    ui.label('Proposée par : ' + review.get('operator_file', {}).get('author', 'opérateur'))
                    confirmed = ui.checkbox('Je confirme le sens des champs et des relations avec le responsable des sources.').props('data-mapping-confirm')
                    approval_reason = ui.input('Justification de l’approbation').classes('w-full').props('data-mapping-approval-reason')
                    async def approve():
                        identifier, fingerprint = review['id'], result['state_hash']
                        decision_reason, confirmation = approval_reason.value or '', confirmed.value
                        def decision():
                            outcome = admin.approve(identifier, fingerprint, decision_reason, confirmed=confirmation)
                            return outcome, admin.overview()
                        def approved(result):
                            outcome, snapshot = result
                            state['review'] = None
                            review_panel.refresh()
                            received(snapshot)
                            ui.notify('Mapping approuvé pour ' + outcome['index'] + ' · version ' + str(outcome['version']), type='positive')
                            validation_label.set_text('Mapping approuvé pour ' + outcome['index'] + '.')
                        await invoke(decision, approved)
                    ui.button('Approuver ce mapping', on_click=approve).props('data-mapping-approve')
                review_panel()
            ui.timer(.05, lambda: invoke(admin.overview, lambda value: received(value, reset=True)), once=True)

        authentication(session, protected)
