# Documentation SI-RIE — PDL, Incidents et ACL

Ouvrir `portable/README.md` pour lire hors du wiki. Le dossier `portable/` conserve les liens relatifs.
Le dossier `wikijs/` contient les pages adaptées au préfixe `/dinum-rie`.
Le dossier `wikijs-native/` propose les mêmes pages avec les blocs diagram natifs de l’éditeur Markdown Wiki.js 2.x.
Importer les pages Markdown et les pièces jointes selon `portable/10-wikijs.md`.
Les fichiers `.drawio` sont éditables ; SVG/PNG servent à la lecture sans moteur externe.
Le manifeste donne les empreintes exactes des fichiers et distingue un checkout modifié.
Aucun envoi au wiki ni installation de service n’est réalisé par cet export.
