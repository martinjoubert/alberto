# Configurer et revoir les mappings PDL

Le [tutoriel des mappings](../../../../../docs/code-tutorial/03-mapping/README.md)
explique le contrat YAML, les correspondances physiques, les identités communes,
les corrections et les limites des preuves. Le [manuel PDL Ubuntu/SI-RIE](../../../../../docs/si-rie/04-pdl.md#revoir-puis-approuver-les-mappings)
donne les commandes de l’instance réellement déployée.

Le modèle [minimal](../../../../../deploy/ubuntu/examples/mappings.yaml) s’adapte
à un index réel. L’[exemple PFS/BB/PFAING/TACACS](../../../../../deploy/ubuntu/examples/pdl-demo-mappings.yaml)
concerne exclusivement les quatre familles synthétiques du tutoriel.

Le parcours est : identité LDAP interne autorisée, rafraîchissement de
l’inventaire, validation du fichier, chargement des propositions, inspection
et approbation d’une revue exacte avec son motif. Un fichier YAML n’est ni une
approbation, ni une autorisation d’accès aux sources.

`rie_agent.operator_mappings` valide les propositions ; `rie_agent.inventory`
observe les champs et leurs empreintes ; `rie_agent.store` conserve les revues
et le catalogue. La requête métier n’utilise que les mappings approuvés encore
compatibles. Le fichier opérateur, les droits ACL et les sources restent
administrés séparément.

Les [captures historiques](../../../../../docs/code-tutorial/assets/screenshots/PROVENANCE.md)
illustrent l’interface du runtime portable. Elles ne prouvent pas qu’elle est
activée dans une installation actuelle ; le parcours Ubuntu utilise la CLI
opérateur documentée.
