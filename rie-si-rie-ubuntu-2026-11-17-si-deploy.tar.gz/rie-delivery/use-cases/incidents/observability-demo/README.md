# Diagnostic réseau DINUM — Gemma avec Albert

**Évolution du 23 octobre 2026 — MCP portable :** le dialogue et les contrôles
incidents sont maintenant côté serveur, via `/gemma/assistant/mcp` (diagnostic)
ou `/visualisations/assistant/mcp` (vues). Le filtre OpenWebUI restant est un
simple affichage facultatif. Les exemples ci-dessous décrivant
`observability_guard` et les anciennes routes restent des références historiques.
Voir l’[architecture et le contrat actuels](../../../docs/demonstrations/incidents-architecture.md).

**Évolution locale du 5 novembre 2026 — retours documentaires :** le moteur expose
les versions et citations de ses préconisations réelles. Il peut lire une release
documentaire approuvée installée explicitement, comme décrit en fin de page.
La qualification de cette boucle utilise des sources et un modèle simulés ; elle
ne remplace pas la recette Albert historique ni une validation dans le SI RIE.

Moteur du cas métier [incidents](../README.md), dans `use-cases/`.
Consulter l'[architecture](../../../docs/ARCHITECTURE.md) et les
[environnements actuels](../../../docs/walkthroughs/02-environments.md)
pour les points d’entrée Mac et Ubuntu/SI-RIE. Les paragraphes de recette
Zabbix décrivent une campagne historique ; le flux VictoriaMetrics/ITSM est
décrit en fin de page.

Évolution distincte : [visualisations adaptées aux incidents](../incident-views-demo/README.md) · [spécification](docs/adaptive-views.md).
La cible reste l'agent Open WebUI : choix contrôlé de gabarits Grafana et liens contextualisés, en lecture seule. NiceGUI présente la démo séparée `/incident-visualisations`. Les preuves et réserves sont propres à cette évolution.

Les anciens déploiements autonomes ont été retirés. Les moteurs utilisent le
[client Python Albert partagé](../../../core/albert-client/README.md).
Les résultats des campagnes antérieures restent dans [le bilan historique](HISTORICAL_STATUS.md).

Gemma 4 31B est retenu pour la démonstration de jeudi. La comparaison exhaustive des trois modèles a été arrêtée à la demande de l'utilisateur. Les preuves de développement restent archivées ; la qualification finale porte uniquement sur Gemma, avec un jeu réservé et une conversation neuve de dix tours.

Voir le [rapport de qualification Gemma et ses réserves](https://gitlab.com/clients_neovelion_tech/dinum_rie_demo_albert_api/-/blob/fb40dc2dc1e97e8d8f3809c3351dff5abe283bda/use-cases/incidents/observability-demo/reports/qualification-gemma.md). Les résultats de développement, le premier passage réservé et les régressions après correction sont présentés séparément.

## Organisation et maintenance

| Fichiers ou dossier | Utilité conservée |
| --- | --- |
| `obs_poc/server.py`, `assistant.py`, `run.py` | Entrées HTTP/MCP et dialogue côté serveur. |
| `obs_poc/service.py`, `domain.py`, `focused_answer.py` | Orchestration, calculs déterministes et réponses aux questions de suivi. |
| `obs_poc/clients.py`, `telemetry.py`, `contracts.py`, `itsm_history.py`, `precedents.py` | Lectures autorisées, normalisation et rapprochement des sources. |
| `obs_poc/config.py`, `agent_observability.py`, `opensearch_links.py` | Configuration, télémétrie technique et liens bornés vers les preuves. |
| `obs_poc/recommendation_*.py` | Contexte documentaire et préconisations versionnées. |
| `fixtures/`, `corpus-documents.json` | Mesures, tickets et fiches synthétiques pour les tests et la préparation. |
| `setup/`, `dashboards/` | Générateurs administratifs et gabarits du corpus historique, encore utilisés par la préparation Mac. |
| `openwebui/`, `configure_openwebui.py` | Affichage des rapports, compatibilité des anciens presets et configuration explicite. |
| `tests/test_*.py`, `pytest.ini` | Tests unitaires et contrats, sans campagne de génération. |
| Autres scripts de `tests/`, `browser_ui.py` | Recettes explicites sur les sources, captures, navigation et conversations. |
| `benchmark.py`, `model_probe.py`, `probe_formats.py`, `review_conversations.py` | Campagnes Albert et revue de leurs résultats ; elles peuvent consommer le quota API. |
| `acceptance-cases.json` | Dix-huit questions avec séparation développement/réservées. Le lanceur Mac externe `incident_recipe_macos.py` copie ce fichier avec son nom anglais. |
| `reports/` | Cinq manifestes ou preuves encore lus par le code, les tests ou NiceGUI ; les nouvelles campagnes restent privées. |
| `requirements*.in`, `requirements*.lock` | Entrées et résolutions distinctes Linux, Mac et tests. Les versions et empreintes ne sont pas interchangeables. |
| `deploy/.env.example`, `deploy/secrets/README.md` | Référence de configuration et explication des secrets locaux, conservées après retrait de l’ancien Compose. |
| `docs/`, `HISTORICAL_STATUS.md` | Guides présentateur, raccordement et limites des campagnes datées. |

Pour les tests hors ligne, utiliser `ci/runners/run_ubuntu_tests.py --suite incidents`
depuis la racine du dépôt. `pytest.ini` référence les sources partagées depuis
l’emplacement actuel du composant. Les scripts sans préfixe `test_` sont des
recettes explicites ; ne pas les exécuter comme une simple vérification unitaire.

## Parcours

Pour la séance complète PDL puis incident : [guide NiceGUI de jeudi](http://127.0.0.1:8090/demo-jeudi) et [plan de test / déroulement présentateur](docs/demo-runbook.md). Questions préconfigurées, diagrammes statiques, animation pédagogique et résultats attendus y sont réunis.

Ouvrir [le portail local](http://127.0.0.1:8090/diagnostic-reseau). Choisir le routeur, la variante et la période. Le bouton Gemma ouvre une **nouvelle conversation** Open WebUI avec la question contextualisée ; l'envoi reste manuel.

Le parcours retenu utilise `albert-observabilite-gemma` et la connexion `/gemma/mcp`. Les deux autres profils restent dans le code et les archives de recette ; ils ne sont plus proposés dans le portail de démonstration.

| Preset | Modèle Albert | Connexion MCP |
|---|---|---|
| `albert-observabilite-gemma` | `gemma-4-31b-it` | `/gemma/mcp` |
| `albert-observabilite-gptoss` | `gpt-oss-120b` | `/gptoss/mcp` |
| `albert-observabilite-deepseek` | `deepseek-v4-flash-0731` | `/deepseek/mcp` |

Le connecteur écoute sur `127.0.0.1:9950`. Chaque connexion expose uniquement `diagnose_observability`, sans paramètre de modèle ni DSL. Le modèle associé à la connexion assure rédaction et contrôle. Un échec reste explicite ; aucun remplacement automatique.

```mermaid
flowchart LR
    N[NiceGUI : contexte et bouton Gemma] --> O[Open WebUI]
    O <--> A[Albert : Gemma 4 31B]
    O --> M[MCP de diagnostic, lecture seule]
    M --> Z[Zabbix API : mesures et incidents]
    M --> S[OpenSearch : logs, tickets, fiches]
    M <--> A
    N --> G[Grafana et Zabbix : écrans lecteurs]
```

## Installation et reprise

Pour les deux UC et leurs ACL, suivre [le guide Ubuntu/SI-RIE](../../../docs/si-rie/01-installation.md).
Sur le Mac préparé, utiliser [les lanceurs Colima](../../../docs/walkthroughs/02-environments.md).
Ces reprises conservent les données. Les commandes de préparation du corpus
sont administratives et distinctes des lectures du moteur.

## Corpus et interprétation

- R1 / OBS-RTR-01, Alpha : congestion commencée à 09:50, résolue à 11:30 ; latence et pertes à partir de 10:15.
- R2 / OBS-RTR-02, Alpha : instabilité de liaison de 10:45 à 11:00, utilisation normale.
- R3 / OBS-RTR-03, Beta : absence de mesures entre 10:00 et 12:00 ; les logs ordinaires ne prouvent pas un réseau sain.
- R4 : exclu des lectures autorisées, utilisé pour vérifier le périmètre.

Ces attentes sont des données de recette, pas des conclusions chargées dans le prompt. Le diagnostic consulte effectivement les API. Six tickets résolus et quatre fiches dédiées sont consultables depuis NiceGUI. Aucun RAG vectoriel, embedding ou reranker dans cette version.

Les comptes, moyennes, maxima, durées et couvertures sont calculés côté serveur. Fenêtres semi-ouvertes `[début, fin[`. La couverture attend un point par minute. Les événements Zabbix sont sélectionnés par recouvrement, même commencés avant la fenêtre et déjà résolus. Les pages de logs affichent au plus cent observations, avec un total calculé sur tous les résultats. Les historiques sont subdivisés au-delà de mille points, jusqu'à cinquante mille par mesure et période ; les dépassements sont signalés.

La recherche documentaire lexicale est filtrée par équipement. Huit documents au maximum, extraits de 1 200 caractères, et un budget commun de 24 000 caractères de preuves structurées. Les logs bruts ne sont pas envoyés au rédacteur : leurs comptes vérifiés le sont. Les chiffres sont restitués par le serveur ; les textes Albert n'ajoutent pas de mesures. Les documents sont des sources non fiables, jamais des instructions.

Les trois parcours partagent les mêmes limites et `temperature=0`, `max_tokens=2000` pour les appels internes. GPT-OSS et DeepSeek utilisent `reasoning_effort=low`. Les délais et consommations réellement observés figurent dans les rapports. Le champ `cost=0` signifie coût déclaré nul par l'API, pas garantie de gratuité du service.

Les appels internes demandent un schéma JSON strict documenté par Albert. Un préfixe incomplet observé (`{"s` avant un objet JSON complet) peut être retiré de façon déterministe et tracée ; aucune extraction arbitraire de texte ni récupération du raisonnement caché. Le reste doit être un document JSON complet, puis passer les contrôles de sources et le contrôle factuel. Une correction de format réutilise les preuves, jamais la réponse rejetée comme preuve. Les réponses vides restent des erreurs explicites.

« Compare avec l'heure précédente » est résolu côté serveur sur exactement soixante minutes avant le début du diagnostic. Les autres références sont des bornes ISO validées. La recette contrôle les instants exacts et enregistre une empreinte du code chargé pour détecter un changement de connecteur pendant une comparaison.

Les questions préremplies utilisent des dates françaises naturelles, par exemple « le 28 septembre 2026 de 10h à 12h ». Les arguments de l’outil restent des dates ISO avec fuseau. Le filtre Open WebUI compare les bornes reconnues avec la période réellement lue et bloque la conclusion en cas de divergence. Le contrôle factuel reçoit le rapport effectivement affiché, avec les tableaux et la chronologie ; les heures présentes dans ceux-ci n'ont pas à être répétées par Albert.

Les quantités mesurées écrites en toutes lettres sont également contrôlées : « dix minutes » ne peut pas contourner le contrôle des chiffres. Les appréciations qualitatives restent soumises au contrôle factuel et à la revue de recette ; ce contrôle par modèle n'est pas une garantie d'absence d'erreur.

L'environnement Albert observé limite la clé à dix requêtes par minute. Le filtre espace les nouveaux diagnostics d'au moins soixante secondes, toutes variantes confondues, et affiche l'attente. Ce délai est configurable dans ses Valves, selon le quota réellement accordé. La planification est bornée à 768 tokens ; le dernier appel se limite à un accusé d'un token, car le rapport validé est déjà construit. La recette désactive titres, tags et suggestions automatiques pour mesurer les appels du parcours seul. Éviter d'utiliser d'autres PoC avec la même clé pendant la comparaison.

Les bornes de calcul sont semi-ouvertes. Les liens natifs utilisent une fin inclusive décalée d'une milliseconde pour Grafana et d'une seconde pour Zabbix : 10:00–12:00 correspond ainsi à exactement 120 points à la minute, sans compter le point de midi.

## Écrans

Grafana : dashboard `obs-network`, variables routeur/interface, période absolue et fuseau Europe/Paris. Compte `obs-viewer` (rôle Viewer). Zabbix : dashboard dédié et liens vers historiques et événements ; compte `obs-reader`. Leur mot de passe local est dans `deploy/secrets/reader_password` ; ne pas le publier dans le portail.

Les zones colorées de Grafana proviennent des événements du corpus vérifiés, avec leurs débuts et résolutions ; elles sont filtrées par routeur et incluent les incidents commencés avant la fenêtre. Le panneau de liens ouvre les événements Zabbix originaux. Ces annotations sont préparées avec le corpus, tandis que le connecteur relit les événements en direct. Les moyennes du dashboard Zabbix suivent la période sélectionnée.

Le rafraîchissement Grafana est fixé à une minute et le délai de requête Zabbix à quarante-cinq secondes pour cette VM QEMU. Un intervalle plus court annulait les lectures encore en cours. La recette vérifie les cinq séries et leurs 120 points sur 10–12 h, ainsi que les moyennes, l'équipement et les bornes ; une page qui s'ouvre ne suffit pas à valider les courbes.

## Recette

Commandes de la recette Windows depuis la racine du dépôt :

```bash
./use-cases/incidents/observability-demo/.venv/bin/python -m pytest use-cases/incidents/observability-demo/tests -q
./use-cases/incidents/observability-demo/.venv/bin/python use-cases/incidents/observability-demo/tests/browser_screens.py
./use-cases/incidents/observability-demo/.venv/bin/python use-cases/incidents/observability-demo/tests/browser_conversation.py --model gemma
./use-cases/incidents/observability-demo/.venv/bin/python use-cases/incidents/observability-demo/benchmark.py --model gemma --set development
```

Pour la démonstration retenue, exécuter uniquement `gemma`. **Ne pas exécuter les conversations en parallèle** : le neuvième tour arrête momentanément la passerelle pour tester la panne ; le dixième vérifie la reprise. Les VM et les sources ne sont pas arrêtées par ce test.

`acceptance-cases.json` contient dix-huit questions, dont six réservées (`--set heldout`). Les contrôles automatiques et la revue factuelle sont distincts. Les résultats `pending` ne comptent pas comme réponses correctes. Le rapport doit distinguer les six questions réservées. Conserver les échecs, versions, date du corpus et paramètres pour interpréter les latences.

## Ubuntu et intranet

Voir [le guide intranet](docs/intranet.md) et [le guide présentateur](docs/presenter-notes.md). Le déploiement des deux UC utilise `deploy/ubuntu/` ; sa qualification doit être consignée pour l’instance effectivement préparée. Aucun accès direct aux bases des outils.

Sources de configuration : [événements Zabbix](https://www.zabbix.com/documentation/current/en/manual/api/reference/event/get), [widgets Zabbix](https://www.zabbix.com/documentation/current/en/manual/api/reference/dashboard/widget_fields/item_value), [API sources Grafana](https://grafana.com/docs/grafana/latest/developer-resources/api-reference/http-api/api-legacy/data_source/).


## Flux de données local — mise à jour du 8 octobre 2026

Zabbix représente la collecte. Le diagnostic relit les métriques dans **VictoriaMetrics**, les logs Zabbix dans l’index **OpenSearch PDL** `pdl-zabbix-observability-demo`, et les alertes avec leur traitement dans un **simulateur ITSM-NG**. Les traces distribuées ne sont pas collectées. Les fiches historiques restent un RAG lexical OpenSearch indépendant des observations courantes.

VictoriaMetrics est un vrai service dans la VM commune, image épinglée dans `simulation-rie/infrastructure-demo/images.macos.lock.json`, limité à 512 Mo de RAM ; son API 8428 reste interne à la VM. Grafana utilise la datasource Prometheus `obs-victoria` et l’alias filtré `pdl-zabbix-observability-authorized`. Les cinq séries sont les mêmes fixtures historiques que précédemment, sans remplissage des trous. Les références aux mesures ouvrent l’export brut via le proxy Grafana et nécessitent la session lecteur Grafana.

Les alertes et leur traitement courant utilisent toujours `fixtures/itsm-tickets.json`, snapshot fictif versionné relu à chaque question. Dans le profil Mac décrit ici, le lecteur `http://127.0.0.1:9950/demo-itsm/tickets/ITSM-001` expose seulement les tickets du périmètre autorisé ; son schéma reste celui du simulateur.

Pour la recherche de **précédents**, le connecteur à l’API native **ITSM-NG 1.6.17** et l’authentification individuelle sont désormais implémentés et vérifiés sur le serveur du laboratoire Ubuntu avec des données fictives. Voir [le raccordement, les quatre US et leur recette](../../../docs/si-rie/15-itsm-precedents.md). Cette API historique et le snapshot des alertes courantes ont des provenances distinctes. Le raccordement au SI réel exige encore ses URL, certificats, identités, profils et vérifications métier ; aucun exporteur de production n’est raccordé.

Exemple R1 : début d’alerte 09:50, résolution technique 11:30, clôture du ticket 12:15 (Paris, 28 septembre 2026). à midi l’alerte est résolue, mais le ticket n’est pas encore clôturé ; le recouvrement 10–12 h est de 90 minutes. R2 : alerte 10:45–11:00, ticket clôturé 11:20. R3 : trou de collecte 10–12 h, ticket en cours, résolution inconnue. L’équipement R4 et son ticket sont exclus.

La préparation actuelle passe par les lanceurs de la plateforme décrits dans
[les environnements](../../../docs/walkthroughs/02-environments.md) ou par
[le déploiement Ubuntu/SI-RIE](../../../deploy/ubuntu/README.md).
`setup/operational_flow.py` reste un générateur explicite du corpus historique,
utilisé par la préparation Mac ; il n’est pas exécuté au démarrage des agents.

La préparation écrit les fixtures et les gabarits ; les deux agents ne font aucune écriture. Le mapping `fixtures/metric-mapping.json` est administré (noms, labels, conversions). `OBS_METRICS_PROVIDER`, `OBS_EVENTS_PROVIDER`, `VICTORIAMETRICS_URL`, `OBS_LOGS_INDEX` sont explicites ; une panne ne déclenche aucun fournisseur de secours silencieux. Le mode historique Zabbix reste disponible explicitement. Les preuves de l’ancienne architecture restent des archives ; elles ne qualifient pas la nouvelle bascule.

## Modèle de dialogue et modèle de diagnostic

Le programme `configure_openwebui.py` utilise `OBS_CONVERSATION_MODEL`
(`gpt-oss-120b` par défaut) pour les appels d’outil OpenWebUI, avec
`custom_params.tool_choice=auto`. Le modèle de synthèse/relecture reste fixé par
la route MCP (`/gemma/assistant/mcp` pour Gemma). Les noms et métadonnées des
presets affichent les deux rôles. Aucun remplacement automatique de modèle
n’est effectué pendant une investigation. La [qualification du 23 octobre](../../../docs/demonstrations/incidents-architecture.md#qualification-du-parcours-portable)
couvre le dialogue, les refus et les vues adaptatives.

## API HTTP et observabilité de l’agent — lot F2

Le serveur existant expose aussi `POST /diagnose`, derrière les mêmes contrôles
Bearer et d’accès que les outils MCP. Le corps JSON accepte `question`, une
variante fixe `variant` (`gptoss` par défaut), `equipment`, `scope`, `start`,
`end`, `reference_start`, `reference_end` et le booléen `synthesize`. Il est
limité à 16 Kio ; les champs inconnus et les types invalides sont refusés avant
toute lecture métier. Les variantes adaptatives nécessitant le balancer restent
sur leurs parcours existants.

Cette route appelle le vrai `Service.diagnose` dans un worker Python. Le cycle
asynchrone conserve le contexte et attend la fin des opérations synchrones
bornées avant de clôturer une requête interrompue. Les collectes de métriques,
événements, logs et documents restent celles du domaine incidents ; la synthèse
et la revue utilisent le client Albert partagé existant.

L’adaptateur de télémétrie est optionnel. Un bootstrap de confiance charge le
registre approuvé, configure le SDK, puis appelle
`create_app(settings, observability=True)`. Sans SDK ou avec un provider
désactivé, la réponse métier reste disponible. Les paramètres de requête ne
peuvent pas choisir un profil, un exporteur, un UUID ou une politique de collecte.
Seul le contexte W3C typé est accepté pour la propagation. Aucun bootstrap OTel
implicite n’est ajouté au lancement historique de l’application.

La recette locale ne contacte aucun service réel :

```sh
.runtime/ci/observability-server-venv/bin/python -B core/observability/multiapplication/qualify_incidents.py
```

Elle exécute les vraies requêtes HTTP sur un serveur Uvicorn éphémère, le moteur
incidents, ses calculs et ses lecteurs. Seules les réponses HTTP des sources et
d’Albert sont simulées. Les preuves sont sous `.runtime/ci/observability-f2/`.
La collecte de traces d’exécution de l’agent ne signifie pas que les équipements
réseau disposent de traces distribuées.

## Retours documentaires approuvés — étape 8

Les vérifications de `analysis.verifications[]` sont accompagnées d’un
`recommendation_context` fermé : diagnostic et préconisation identifiés,
citations, sources, requête documentaire réellement utilisée et versions du
service, du prompt et du corpus. Une release utilisée participe à l’empreinte
du corpus. Sans synthèse disponible, aucune préconisation n’est créée à partir
des seuls tableaux ou d’un commentaire utilisateur.

Le parcours privé de revue est fourni par
[le domaine des incidents agentiques](../agentic-incidents/README.md).
Après retour structuré, revue par un autre compte désigné et comparaison
documentaire, le propriétaire peut publier et exporter une release JSON.
La publication dans cet atelier reste privée par propriétaire ; elle ne modifie
pas automatiquement le runtime Incidents partagé.

Pour raccorder une release à ce runtime, l’administrateur installe explicitement
le fichier approuvé comme configuration de confiance lisible par le service,
sans droit d’écriture du connecteur, puis renseigne les deux paramètres :

```text
OBS_RECOMMENDATION_RELEASE_FILE=/CHEMIN/PRIVE/recommendation-release.json
OBS_RECOMMENDATION_RELEASE_SHA256=EMPREINTE_SHA256_DES_OCTETS_EXPORTES
```

Le chargeur refuse un lien symbolique, un fichier trop grand, un schéma invalide
ou une empreinte différente. L’empreinte attendue doit correspondre aux octets
installés ; modifier le format du fichier change cette empreinte. Le SHA-256
ne prouve ni l’identité du relecteur ni son expertise.

Les fiches ne sont recherchées qu’après réussite de `Sources.documents`, sous
les ACL documentaires existantes. Un refus d’accès ou une indisponibilité de
cette source ne déclenche pas un recours au fichier. La sélection reprend la
requête documentaire observée et exige que tout le périmètre d’équipements de
la fiche soit inclus dans celui de l’investigation. Documents d’origine et
ajouts restent bornés à huit.

Les ajouts portent leur provenance `approved_feedback`, l’identifiant de release
et des citations dans le rapport. Ils enrichissent le contexte documentaire
comme données historiques ; ils ne remplacent ni `SYSTEM`, ni `REVIEW`, ni le
modèle. Le moteur ne fabrique pas de lien OpenSearch pour une fiche locale.
Une release invalide est signalée comme source supplémentaire indisponible,
sans supprimer les documents natifs déjà lus ni masquer le diagnostic partiel.

Dans un service commun, ce fichier installé est visible aux lecteurs autorisés
de ce service. Il ne transporte pas automatiquement les droits du propriétaire
OpenWebUI qui l’a exporté. Son installation est donc un acte administratif
distinct du corpus privé de l’atelier.

Le rejeu compare la sélection documentaire, conserve les cas antérieurs et
teste des holdouts de périmètre et de requête. Il n’évalue pas la justesse d’une
génération LLM, une cause réseau, une efficacité opérationnelle ou les coûts
Albert. Le [bilan étape 8](../../../docs/observability/RIE-OBS-AGENTIC-INCIDENTS-STEP8-RESULTS.md)
et le [plan manuel](../../../docs/observability/RIE-OBS-AGENTIC-INCIDENTS-STEP8-VALIDATION.md)
conservent cette distinction. Le déploiement des UC PDL et Incidents avec leurs
ACL, puis la recette d’installation par un tiers, constituent le chantier suivant.

## Recettes navigateur avec panne contrôlée

Les conversations et leurs questions sont conservées. Une recette de neuf ou
dix tours exige maintenant `--stop-command` et `--start-command` : fournir les
commandes exactes du déploiement pour arrêter puis reprendre **uniquement le
connecteur testé**. Les arguments sont séparés sans shell, aucune commande
d’arrêt n’est déduite de la plateforme. Les tours sans injection de panne peuvent
être limités avec `--turns 8`. Les recettes appellent Albert et restent explicites.

Pour la recette des vues, `--without-portal-during-turns` exige aussi
`--portal-stop-command` et `--portal-start-command`, visant uniquement le portail.
Le nettoyage et les tests unitaires ne lancent aucune de ces commandes.
