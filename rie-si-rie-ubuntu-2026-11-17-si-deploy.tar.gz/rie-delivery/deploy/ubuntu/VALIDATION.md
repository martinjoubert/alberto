# Bilan de la livraison Ubuntu

Le **bilan canonique unique** est
[Qualification : résultats, scénarios et limites](../../docs/si-rie/08-qualification.md).
Il conserve les versions, mesures et preuves ; ce fichier évite une deuxième
copie de ces tableaux. Le [journal du 6 novembre](../../docs/si-rie/11-installation-log.md)
explique les défauts rencontrés et les reprises humaines.

Les [rapports de tests](../../docs/si-rie/13-test-reports.md) décrivent le
catalogue NiceGUI et la remise des rapports Allure produits en qualification
ou en CI. La présentation d'un reçu historique ne constitue pas un nouveau test.

## Revue du 7 novembre 2026 — revalidation technique réussie

Le candidat C2 a réussi les installations scriptées neuves Ubuntu 24.04/26.04
(douze contrôles techniques et six services sains par VM), les ACL source par
source (126 contrôles par VM), les seize parcours navigateur de chaque VM,
neuf critères d'exploitation/restauration et une charge courte de 60 secondes.
Le détail, les compteurs et les manifestes sont conservés une seule fois dans
le bilan canonique. Le premier candidat C1 échoué reste identifié séparément.

Le runtime/opérateur est séparé du portail NiceGUI et de la qualification.
Les droits UC2 comprennent désormais deux index et deux ressources explicites ;
une ancienne politique n'est jamais ouverte automatiquement. Les contrôles
hors réseau, PDL et Incidents sont identifiés dans le reçu de cette révision.

Le portail C3 a ensuite passé **dix-sept contrôles navigateur sur chaque VM**,
y compris le lien interpage vers une section réellement visible. Les manifestes
et configurations d'exécution du runtime restent identiques à C2 ; l'index OCI
variable d'attestation n'est pas confondu avec une modification du moteur.
Les reçus finaux identifient les paquets et l'arrêt effectif des VM avec volumes
conservés. La validation humaine du déploiement reste à réaliser avec la fiche
vierge ; les tests automatiques ne la remplacent pas.

Les deux heures et les conversations Albert du 6 novembre demeurent historiques.
Aucune nouvelle endurance de deux heures ni génération Albert n'est revendiquée
pour les images réduites. Les limites ARM64 et sources SI réelles sont conservées.

## Rejouer les contrôles

Depuis le **dépôt complet**, utiliser le runner Ubuntu et le workflow GitHub
qui sélectionnent les suites ACL, Ubuntu et métier et bloquent le réseau pour
les tests déterministes. La définition CI et les suites de développement ne
sont pas copiées seules dans l'archive opérateur.

Depuis une archive extraite, suivre le manuel puis ses recettes `check` et,
en mode `demo`, `acceptance`. Une recette locale sans génération n'est pas une
validation Albert. Ne pas lancer de seed ou recette fictive sur les sources SI.

Les preuves brutes de travail, sous `.runtime/ci/`, restent privées : elles
peuvent contenir des jetons ou conversations. Les archives opérateur et wiki
n'emportent que le code et les documents publics autorisés.
