# Déployer PDL, Incidents et les ACL sur Ubuntu

Cette livraison fournit les deux moteurs et les accès individuels. **Open WebUI
reste sur chaque poste utilisateur.** La simulation utilise de vrais services
OpenSearch, VictoriaMetrics et LDAP, avec données fictives et snapshot ITSM
explicitement simulé. Observabilité, Dify et n8n restent hors déploiement.

Pour le déployeur SI-RIE, commencer par le
**[guide pas à pas en douze étapes](../../docs/si-rie/24-deploy-walkthrough.md)** :
commandes, résultats attendus, conversations Albert et reprise sont regroupés.
Faire compléter auparavant la [fiche de raccordement](../../docs/si-rie/26-si-connection-sheet.md).
Le [manuel de référence](../../docs/si-rie/01-installation.md) conserve les
variantes `demo`/`external`, scriptées ou manuelles. Choisir un seul parcours.

Pour les sources réelles du **SI-RIE**, suivre `external` et préparer avec les
responsables les comptes, droits et exemples métier. Ce mode ne crée ni les
comptes fictifs dans le LDAP, ni les données des tutoriels dans les sources.
Le corpus `demo` sert à un apprentissage reproductible après initialisation ;
son exécution ne valide pas le raccordement aux données du SI.

| Besoin | Document |
| --- | --- |
| Déployer dans le SI-RIE, du début à la fin | **[Déroulé unique](../../docs/si-rie/24-deploy-walkthrough.md)** |
| Préparer les accès, images et contrats des données | [Fiche de raccordement à compléter](../../docs/si-rie/26-si-connection-sheet.md) |
| Refaire le même parcours dans la sandbox | [Paramètres fictifs et limites](../../docs/si-rie/22-external-sandbox.md) |
| Adapter le parcours et retrouver les variantes | [Manuel de référence](../../docs/si-rie/01-installation.md) |
| Renseigner les sources, secrets et Open WebUI local | [Configuration](../../docs/si-rie/02-configuration.md) ; modèles publics dans `examples/` |
| Comprendre composants et flux | [Architecture](../../docs/si-rie/03-architecture.md) |
| Définir, vérifier et approuver les correspondances PDL | **Mappings PDL** dans NiceGUI (`/admin-mappings`) ; [parcours guidé et alternative CLI](../../docs/si-rie/24-deploy-walkthrough.md#8-revoir-et-approuver-les-mappings-pdl) |
| Administrer les index et sources UC2 | [ACL](../../docs/si-rie/06-acl.md) |
| Connecter chaque utilisateur sans copier de jeton MCP | [Connexion LDAP et OAuth](../../docs/si-rie/25-user-access.md) |
| Lire les logs, arrêter, sauvegarder, restaurer et mettre à jour | [Exploitation](../../docs/si-rie/07-operations.md) |
| Examiner les résultats et limites réels | [Qualification canonique](../../docs/si-rie/08-qualification.md) |
| Préparer la réception sur le SI réel et attribuer les vérifications restantes | [Recette SI-RIE](../../docs/si-rie/14-si-rie-acceptance.md) |
| Consulter Allure dans NiceGUI et importer un rapport de CI | [Rapports de tests](../../docs/si-rie/13-test-reports.md) |
| Jouer les questions avec les sources et les identités du SI | [Tutoriel PDL](../../docs/si-rie/16-pdl-tutorial.md#utiliser-vos-sources-si-rie) ; [Tutoriel Incidents](../../docs/si-rie/17-incidents-tutorial.md#utiliser-vos-sources-si-rie) |
| Jouer les trois démos et exporter vers le wiki | [Démonstrations](../../docs/si-rie/09-demonstrations.md) ; [Wiki.js](../../docs/si-rie/10-wikijs.md) |

**Exemple pour une simulation `demo` uniquement**, après vérification du paquet,
sur un Ubuntu neuf, avec un chemin privé absolu :

```bash
sudo bash deploy/ubuntu/install.sh --instance /home/dinum/.local/share/dinum-rie-demo --mode demo --install-prerequisites
```

Adapter le compte et le chemin. Ajouter `--with-demo-ui` seulement si NiceGUI est
souhaité ; `--dry-run` affiche les phases sans les exécuter. Sur un hôte déjà
équipé, omettre l'installation des prérequis. Une relance conserve l'instance,
ses secrets, données, mappings et règles. Pour `external`, remplir les modèles
avant démarrage et donner `--username IDENTIFIANT_INTERNE` ; aucun seed fictif.

Le runtime PDL/Incidents et l'opérateur partagent une image minimale. Le portail
facultatif utilise une image dérivée avec NiceGUI et les documents. Les outils
de charge et d'injection de panne nécessitent une troisième cible explicite :
`manage.py build INSTANCE --with-qualification`. Ils ne sont pas des outils MCP
métier et ne sont pas chargés dans le runtime ordinaire.

Le dépôt complet porte le workflow GitHub et les suites de développement.
L'archive opérateur sert à installer et exploiter : elle conserve les tests
ACL/Ubuntu et recettes locales utiles, sans prétendre être un dépôt CI autonome.
Les manifestes identifient la version et les fichiers, sans publier le code.

Les ports 19910 (PDL), 19950 (Incidents) et, si activé, 18090 (NiceGUI) sont liés
à la boucle locale. Utiliser le tunnel SSH et des jetons individuels. Aucun
compte utilisateur partagé ou serveur Open WebUI central n'est requis.
