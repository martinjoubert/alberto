"""Isolated two-use-case delivery. Host dependencies: Python >=3.10, Docker Compose.

No host package, firewall, Docker daemon or existing Open WebUI is modified.
Secrets stay in the private instance. Docker commands never print interpolated config.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import subprocess
import sys
import tempfile
import uuid
from urllib.parse import urlsplit
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SERVICES = {'pdl', 'incidents', 'portal', 'operator', 'initialize', 'opensearch', 'victoriametrics', 'ldap'}
VOLUMES = ('runtime', 'opensearch', 'metrics', 'ldap')
OPENSEARCH_IMAGE = 'opensearchproject/opensearch@sha256:fafe3fc3587088674669235575aa166228c48bdb940294a8cdbbc1da75236a40'
METRICS_IMAGE = 'victoriametrics/victoria-metrics@sha256:86ca5fdb6d87d56ba047b044039019ba2bd9042b36e35f6ea34e437b6c825cef'
MAX_INPUT_BYTES = 1024 * 1024


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as stream:
        stream.write(value)


def save_env(instance, values):
    if any('\n' in str(v) or not re.fullmatch(r'[A-Za-z0-9_./:@+,-]*', str(v)) for v in values.values()):
        raise ValueError('Use plain values without shell interpolation in .env')
    temp = instance/'.env.tmp'
    write_new(temp, ''.join(k+'='+str(v)+'\n' for k, v in values.items()))
    temp.replace(instance/'.env')


def load(instance):
    if instance.is_relative_to(ROOT) or not instance.is_absolute():
        raise ValueError('The private instance must be outside the checkout')
    values = dict(line.split('=', 1) for line in (instance/'.env').read_text().splitlines() if line and not line.startswith('#'))
    if values.get('RIE_INSTANCE_DIR') != str(instance) or not re.fullmatch(r'rie-[a-f0-9]{12}', values.get('RIE_PROJECT', '')):
        raise ValueError('Instance path/project mismatch; do not copy .env between instances')
    if not re.fullmatch(r'[a-f0-9]{32}', values.get('RIE_INSTANCE_ID', '')) or values.get('RIE_MODE') not in {'demo', 'external'}:
        raise ValueError('Invalid instance identity/mode')
    return values


def run(argv, *, capture=False, **kwargs):
    kwargs.setdefault('stdout', subprocess.PIPE if capture else None)
    # Prevent Docker from swallowing the remaining commands of an SSH/bash script.
    if 'input' not in kwargs:
        kwargs.setdefault('stdin', subprocess.DEVNULL)
    return subprocess.run(argv, check=True, text=True, **kwargs)


def docker(*args, capture=False, **kwargs):
    return run([os.getenv('RIE_DOCKER', 'docker'), *args], capture=capture, **kwargs)


def compose(instance, values, *args, **kwargs):
    # Compose gives shell environment precedence over --env-file. Pin instance values.
    env = dict(os.environ)
    env.update(values)
    for key, default in (('RIE_SIMULATED_ALBERT', 'false'), ('RIE_LOAD_QUALIFICATION', 'false'),
                         ('INCIDENTS_DOCS_INDEX', 'obs-network-docs'), ('DINUM_DIALOGUE_MAX_STATES', '8192'),
                         ('RIE_PORTAL_IMAGE', values['RIE_IMAGE']), ('RIE_QUALIFICATION_IMAGE', values['RIE_IMAGE'])):
        env[key] = values.get(key, default)
    files = ['--file', str(HERE/'compose.yaml')]
    if qualification_enabled(values):
        files += ['--file', str(HERE/'compose.qualification.yaml')]
    return docker('compose', '--project-name', values['RIE_PROJECT'], '--env-file', str(instance/'.env'),
                  *files, *args, env=env, **kwargs)


def guard(instance, values):
    """Refuse foreign volumes/containers before any lifecycle operation."""
    identity = docker('info', '--format', '{{.ID}}', capture=True).stdout.strip()
    receipt = instance/'docker-id'
    if receipt.exists() and receipt.read_text().strip() != identity:
        raise ValueError('Docker engine changed; select the original context')
    for suffix in VOLUMES:
        name = values['RIE_PROJECT']+'-'+suffix
        found = docker('volume', 'ls', '--filter', 'name=^'+name+'$', '--format', '{{.Name}}', capture=True).stdout.strip()
        if found:
            labels = json.loads(docker('volume', 'inspect', name, '--format', '{{json .Labels}}', capture=True).stdout) or {}
            if labels.get('rie.instance') != values['RIE_INSTANCE_ID']:
                raise ValueError('Foreign volume: '+name)
    ids = docker('ps', '-aq', '--filter', 'label=com.docker.compose.project='+values['RIE_PROJECT'], capture=True).stdout.split()
    if ids:
        containers = json.loads(docker('inspect', *ids, capture=True).stdout)
        for container in containers:
            labels = container['Config'].get('Labels') or {}
            if labels.get('rie.instance') != values['RIE_INSTANCE_ID']:
                raise ValueError('Foreign container in this project')
            if labels.get('com.docker.compose.service') not in SERVICES:
                raise ValueError('Unknown service in this project')
    if not receipt.exists():
        write_new(receipt, identity+'\n')


def operation_environment():
    """Pass live CLI helpers without relying on an importlib module registry."""
    return SimpleNamespace(ROOT=ROOT, HERE=HERE, VOLUMES=VOLUMES, docker=docker, compose=compose,
                           tool=tool, write_new=write_new, save_env=save_env, guard=guard)


def bootstrap(instance, mode):
    if instance.is_relative_to(ROOT):
        raise ValueError('Choose a private instance outside the checkout')
    if instance.exists() and any(instance.iterdir()):
        raise ValueError('Instance already exists; edit it explicitly, never reinitialize')
    instance.mkdir(parents=True, mode=0o700, exist_ok=True)
    instance.chmod(0o700)
    ident = uuid.uuid4().hex
    values = {'RIE_PROJECT': 'rie-'+ident[:12], 'RIE_INSTANCE_ID': ident, 'RIE_INSTANCE_DIR': str(instance),
              'RIE_MODE': mode, 'RIE_IMAGE': 'dinum/rie-delivery:unbuilt-'+ident[:12],
              'RIE_PORTAL_IMAGE': '', 'RIE_QUALIFICATION_IMAGE': '',
              'RIE_LDAP_IMAGE': 'dinum/rie-ldap:'+ident[:12], 'PDL_PORT': '19910', 'INCIDENTS_PORT': '19950',
              'RIE_ENABLE_DEMO_UI': 'false', 'PORTAL_PORT': '18090',
              'DINUM_DIALOGUE_MAX_STATES': '8192',
              'OBS_MIN_TURN_INTERVAL_SECONDS': '60',
              'OPENSEARCH_URL': 'http://opensearch:9200' if mode == 'demo' else 'https://OPENSEARCH.invalid',
              'OPENSEARCH_USER': '', 'VICTORIAMETRICS_URL': 'http://victoriametrics:8428' if mode == 'demo' else 'https://METRICS.invalid',
              'INCIDENTS_LOGS_INDEX': 'pdl-zabbix-observability-demo',
              'INCIDENTS_DOCS_INDEX': 'obs-network-docs',
              'INCIDENTS_MANIFEST': '/data/incidents/corpus.json' if mode == 'demo' else '/data/config/incidents-corpus.json',
              'ALBERT_URL': 'https://albert.api.etalab.gouv.fr/v1', 'ALBERT_MODEL': 'gemma-4-31b-it',
              'OBS_MODEL_GPTOSS': 'gemma-4-31b-it', 'OBS_DIALOGUE_MODEL': 'gpt-oss-120b',
              'OBS_REVIEW_MODEL': 'gpt-oss-120b', 'SOURCE_CA_FILE': ''}
    for folder in ('config', 'secrets', 'access', 'clients', 'backups'):
        (instance/folder).mkdir(mode=0o700)
    for name in ('incident_service_token', 'session-signing.key'):
        write_new(instance/'secrets'/name, secrets.token_urlsafe(48)+'\n')
    for name in ('albert_key', 'opensearch_password', 'victoria_token', 'reader.password'):
        write_new(instance/'secrets'/name, 'demo-not-a-credential\n' if name == 'albert_key' else '\n')
    access = json.loads((ROOT/'core/access-control/config.example.json').read_text())
    access.update(allow_webui_assertions=False, user_tokens_directory='/data/access/user-tokens',
                  state_directory='/data/access', session_key_file='/data/secrets/session-signing.key',
                  administration_url='', recovery_subjects={})
    access.pop('webui_key_file', None)
    access['ldap'].update(bind_password_file='/data/secrets/reader.password', ca_file='/data/config/ldap-ca.crt',
                          attribute_for_subject='entryUUID')
    if mode == 'demo':
        ldap = module(ROOT/'simulation-rie/ldap-demo/manage.py', 'ldap_delivery')
        ldap.prepare(instance/'ldap-fixture')
        directory = instance/'ldap-fixture/directory'
        # This is newly generated synthetic TLS material, never an existing directory.
        extension = instance/'ldap-fixture/private/server.ext'
        extension.write_text(extension.read_text().replace('DNS:localhost,', 'DNS:ldap,DNS:localhost,'))
        ldap.run(['openssl', 'x509', '-req', '-in', str(instance/'ldap-fixture/private/server.csr'),
                  '-CA', str(directory/'ca.crt'), '-CAkey', str(instance/'ldap-fixture/private/ca.key'),
                  '-CAserial', str(instance/'ldap-fixture/private/ca.srl'), '-days', '365', '-sha256',
                  '-extfile', str(extension), '-out', str(directory/'server.crt')])
        config_dir = instance/'config/ldap'
        shutil.copytree(directory, config_dir)
        config = (config_dir/'slapd.conf').read_text().replace('/run/directory/', '/data/config/ldap/')
        (config_dir/'slapd.conf').write_text(config)
        shutil.copyfile(directory/'ca.crt', instance/'config/ldap-ca.crt')
        profile = ldap.profile()
        access['ldap'].update({k: profile[k] for k in ('app_dn', 'search_base', 'attribute_for_username', 'attribute_for_mail', 'attribute_for_groups')})
        access['ldap'].update(host='ldap', port=1636,
                              group_dns={k: 'cn='+v+','+profile['group_base'] for k, v in profile['groups'].items()},
                              administrator_group_dns=profile['administrator_group_dns'])
        accounts = json.loads((instance/'ldap-fixture/private/accounts.json').read_text())
        (instance/'secrets/reader.password').write_text(accounts['reader_password']+'\n')
    policy = {'version': 1, 'revision': 1, 'default': 'blocked', 'indices': {}, 'resources': {}}
    patterns = []
    if mode == 'demo':
        patterns = ['rie-pfs-fixture', 'rie-bb-fixture', 'rie-pfaing-fixture', 'rie-tacacs-fixture']
        policy['indices'] = {name: 'authenticated' for name in patterns}
        policy['indices'].update({'pdl-zabbix-observability-demo': 'internal', 'obs-network-docs': 'internal'})
        policy['resources'] = {'incidents.metrics': 'internal', 'incidents.tickets': 'internal'}
    pdl = {'version': 1, 'server': {'mcp_host': '0.0.0.0', 'mcp_port': 9910, 'admin_host': '127.0.0.1', 'admin_port': 8090,
                                   'public_admin_url': ''},
           'storage': {'data_dir': '/data/pdl'},
           'discovery': {'allowed_index_patterns': patterns, 'required_index_patterns': patterns,
                         'refresh_seconds': 3600, 'max_indices': 20, 'max_fields_per_index': 500},
           'limits': {'max_rows': 100, 'max_buckets': 100, 'max_time_range_days': 31,
                      'max_identity_documents': 1000, 'max_context_bytes': 1048576},
           'albert': {'url': '${ALBERT_API_BASE_URL}', 'model': '${ALBERT_MODEL}', 'api_key_file': '/data/secrets/albert_key', 'tls': {'verify': True, 'ca_file': '${CA_BUNDLE}'}},
           'sources': {'opensearch': {'enabled': True, 'url': '${OPENSEARCH_URL}', 'username': '${OPENSEARCH_USER}',
                                     'password_file': '/data/secrets/opensearch_password', 'tls': {'verify': True, 'ca_file': '${CA_BUNDLE}'}},
                       'zabbix': {'enabled': False, 'url': 'https://disabled.invalid'},
                       'grafana': {'enabled': False, 'url': 'https://disabled.invalid'}}}
    for path, value in ((instance/'config/access.json', access), (instance/'config/pdl.yaml', pdl), (instance/'access/policy.json', policy)):
        write_new(path, json.dumps(value, indent=2)+'\n')
    for name in ('metric-mapping.json', 'itsm-tickets.json'):
        shutil.copyfile(ROOT/'use-cases/incidents/observability-demo/fixtures'/name, instance/'config'/name)
    if mode == 'external':
        write_new(instance/'config/ldap-ca.crt', 'REPLACE_WITH_THE_DIRECTORY_CA\n')
        write_new(instance/'config/incidents-corpus.json', '{"requires_operator_configuration": true}\n')
        for name in ('itsm-tickets.json', 'metric-mapping.json'):
            (instance/'config'/name).write_text('{"requires_operator_configuration": true}\n')
    save_env(instance, values)
    for path in instance.rglob('*'):
        path.chmod(0o700 if path.is_dir() else 0o600)
    print('Instance prepared:', instance, 'mode='+mode, '(no service started)')


def qualification_enabled(values):
    return values.get('RIE_SIMULATED_ALBERT') == 'true' or values.get('RIE_LOAD_QUALIFICATION') == 'true'


def read_private_file(path, *, limit=2 * 1024 * 1024):
    """Bound configuration reads and reject links before any lifecycle mutation."""
    path = Path(path)
    for component in (path, *path.parents):
        if component.is_symlink():
            raise ValueError('Private configuration symlinks are forbidden.')
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(descriptor, 'rb') as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError('Private inputs must be regular files.')
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('Private configuration file exceeds its size limit.')
    try:
        return raw.decode('utf-8')
    except UnicodeDecodeError:
        raise ValueError('Private text configuration must use UTF-8.') from None


def private_document(path, *, yaml_allowed=False):
    text = read_private_file(path)
    try:
        value = json.loads(text)
    except ValueError:
        if not yaml_allowed:
            raise ValueError('Invalid JSON private configuration: ' + Path(path).name) from None
        try:
            import yaml
        except ImportError:
            raise ValueError('Use the documented JSON subset in pdl.yaml, or validate legacy YAML with an installed PyYAML.') from None
        try:
            value = yaml.safe_load(text)
        except yaml.YAMLError:
            raise ValueError('Invalid PDL YAML configuration.') from None
    if not isinstance(value, dict):
        raise ValueError('Private configuration documents must be objects.')
    return value


def required_images(values):
    """Resolve new split images while retaining old monolithic instance receipts."""
    images = {'runtime': values.get('RIE_IMAGE', '')}
    if values.get('RIE_ENABLE_DEMO_UI') == 'true':
        images['portal'] = values.get('RIE_PORTAL_IMAGE', values.get('RIE_IMAGE', ''))
    if qualification_enabled(values):
        images['qualification'] = values.get('RIE_QUALIFICATION_IMAGE', values.get('RIE_IMAGE', ''))
    if values['RIE_MODE'] == 'demo':
        images.update(ldap=values.get('RIE_LDAP_IMAGE', ''), opensearch=OPENSEARCH_IMAGE, victoriametrics=METRICS_IMAGE)
    return images


def preflight_up(instance, values):
    """All configuration and local image checks precede stop, copy and guard writes."""
    validate_instance(instance, values)
    for role, reference in required_images(values).items():
        if not reference or any(c.isspace() for c in reference):
            suffix = ' --with-qualification' if role == 'qualification' else ''
            raise ValueError('Missing ' + role + ' image; run build' + suffix + ' first.')
        try:
            docker('image', 'inspect', reference, capture=True)
        except subprocess.CalledProcessError:
            raise ValueError('Local ' + role + ' image is unavailable; build or pull it before up.') from None
    if values.get('RIE_ENABLE_DEMO_UI') == 'true':
        directory = instance/'qualification'
        if directory.is_symlink() or directory.exists() and not directory.is_dir():
            raise ValueError('Qualification reports must be a regular directory.')


def prepare_report_directory(instance):
    """An empty read-only portal bind; host parent remains private."""
    directory = instance/'qualification'
    if directory.is_symlink() or directory.exists() and not directory.is_dir():
        raise ValueError('Qualification reports must be a regular directory.')
    directory.mkdir(mode=0o755, exist_ok=True)
    directory.chmod(0o755)


def validate_instance(instance, values):
    """Fail before startup on placeholders, unknown modes or inconsistent ports.

    The generated pdl.yaml is JSON (a YAML subset), keeping host preparation
    dependency-free. The runtime remains responsible for full schema validation.
    """
    from urllib.parse import urlsplit
    oauth_path = values.get('DINUM_OAUTH_CONFIG', '')
    if oauth_path:
        if oauth_path != '/data/config/oauth.json':
            raise ValueError('Use /data/config/oauth.json for client authentication')
        oauth_configuration(instance/'config/oauth.json')
    try:
        interval=float(values.get('OBS_MIN_TURN_INTERVAL_SECONDS','60'))
    except (TypeError,ValueError):
        raise ValueError('OBS_MIN_TURN_INTERVAL_SECONDS must be between 0 and 86400.') from None
    if not math.isfinite(interval) or not 0<=interval<=86400:
        raise ValueError('OBS_MIN_TURN_INTERVAL_SECONDS must be between 0 and 86400.')
    for key in ('ALBERT_MODEL','OBS_MODEL_GPTOSS','OBS_MODEL_GEMMA','OBS_MODEL_DEEPSEEK','OBS_DIALOGUE_MODEL','OBS_REVIEW_MODEL'):
        value=values.get(key)
        if value is not None and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,127}',value):
            raise ValueError(key+' must be a plain model identifier of at most 128 characters.')
    capacity=values.get('DINUM_DIALOGUE_MAX_STATES','8192')
    if not isinstance(capacity,str) or not re.fullmatch(r'[1-9][0-9]{0,4}',capacity) or not 1<=int(capacity)<=32768:
        raise ValueError('DINUM_DIALOGUE_MAX_STATES must be an integer between 1 and 32768.')
    try:
        ports = [int(values[key]) for key in ('PDL_PORT', 'INCIDENTS_PORT')]
        if values.get('RIE_ENABLE_DEMO_UI') == 'true':
            ports.append(int(values.get('PORTAL_PORT', '18090')))
    except (KeyError, ValueError, TypeError):
        raise ValueError('Service ports must be distinct integers between 1024 and 65535.') from None
    if any(not 1024 <= port <= 65535 for port in ports) or len(set(ports)) != len(ports):
        raise ValueError('Service ports must be distinct and between 1024 and 65535.')
    for key in ('OPENSEARCH_URL', 'VICTORIAMETRICS_URL', 'ALBERT_URL'):
        parsed = urlsplit(values[key])
        if parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('Source URLs require HTTP(S), a hostname and no embedded credentials.')
    for folder in ('config', 'secrets', 'access'):
        for path in [instance/folder, *(instance/folder).rglob('*')]:
            if path.is_symlink():
                raise ValueError('Private configuration symlinks are forbidden.')
    # Verify every copied input, including empty optional credentials, before stop.
    for name in ('incident_service_token', 'session-signing.key', 'albert_key', 'opensearch_password', 'victoria_token', 'reader.password'):
        raw = read_private_file(instance/'secrets'/name, limit=65536)
        if name in {'incident_service_token', 'session-signing.key'} and len(raw.strip()) < 32:
            raise ValueError('The internal service/signing secret is missing or too short.')
    read_private_file(instance/'config/ldap-ca.crt')
    if values['RIE_MODE'] == 'demo':
        for name in ('slapd.conf', 'seed.ldif', 'server.crt', 'server.key', 'ca.crt'):
            if not read_private_file(instance/'config/ldap'/name).strip():
                raise ValueError('A synthetic LDAP configuration/TLS input is empty.')
    source_ca = values.get('SOURCE_CA_FILE', '')
    if source_ca.startswith('/data/config/'):
        relative = Path(source_ca).relative_to('/data/config')
        if '..' in relative.parts:
            raise ValueError('The configured source CA must stay in the private config directory.')
        read_private_file(instance/'config'/relative)
    access = private_document(instance/'config/access.json')
    policy = private_document(instance/'access/policy.json')
    pdl = private_document(instance/'config/pdl.yaml', yaml_allowed=True)
    for name in ('metric-mapping.json', 'itsm-tickets.json'):
        private_document(instance/'config'/name)
    if access.get('allow_webui_assertions') is not False:
        raise ValueError('User-owned Open WebUI clients require individual authentication, never a shared signing key.')
    if access.get('version') != 1 or not isinstance(access.get('ldap'), dict):
        raise ValueError('An explicit version1 LDAP access configuration is required.')
    admin_groups=access['ldap'].get('administrator_group_dns',[])
    classification=access['ldap'].get('group_dns',{})
    classified={value.casefold() for value in classification.values() if isinstance(value,str)} if isinstance(classification,dict) else set()
    if (not isinstance(admin_groups,list) or len(admin_groups)>32
            or any(not isinstance(value,str) or not value.strip() or len(value)>2048 or value.casefold() in classified for value in admin_groups)):
        raise ValueError('Administrator LDAP groups must be explicit, bounded and distinct from classification groups.')
    visibilities = {'blocked', 'internal', 'authenticated'}
    indices = policy.get('indices')
    resources = policy.get('resources', {})
    if (policy.get('version') != 1 or type(policy.get('revision')) is not int or policy['revision'] < 1
            or policy.get('default') != 'blocked' or not isinstance(indices, dict)
            or any(not isinstance(k, str) or not re.fullmatch(r'[a-z0-9][a-z0-9_.-]{0,254}', k)
                   or not isinstance(v, str) or v not in visibilities for k, v in indices.items())
            or not isinstance(resources, dict)
            or any((k not in {'incidents.metrics', 'incidents.tickets'} and not re.fullmatch(
                       r'(?:pdl\.zabbix\.host\.[1-9][0-9]{0,19}|pdl\.grafana\.dashboard\.[A-Za-z0-9_-]{1,40})', k))
                   or not isinstance(v, str) or v not in visibilities
                   for k, v in resources.items())):
        raise ValueError('Access policy requires exact indices, known resources, valid visibility and default blocked.')
    if not isinstance(pdl.get('discovery'), dict) or not isinstance(pdl['discovery'].get('allowed_index_patterns'), list):
        raise ValueError('PDL discovery must contain an explicit allowed_index_patterns list.')
    discovery = pdl['discovery']
    for name in ('allowed_index_patterns', 'required_index_patterns'):
        patterns = discovery.get(name, [])
        if (not isinstance(patterns, list) or any(not isinstance(pattern, str) or
                not re.fullmatch(r'[a-z0-9][a-z0-9._*-]{0,254}', pattern) or '..' in pattern for pattern in patterns)):
            raise ValueError('PDL ' + name + ' must be a list of valid index patterns.')
    limits = pdl.get('limits', {})
    if not isinstance(limits, dict):
        raise ValueError('PDL limits must be an object.')
    for section, name, default, maximum in ((discovery, 'max_indices', 20, 200),
            (discovery, 'max_fields_per_index', 500, 10000), (limits, 'max_identity_documents', 1000, 10000),
            (limits, 'max_context_bytes', 1048576, 1048576)):
        value = section.get(name, default)
        if type(value) is not int or not 1 <= value <= maximum:
            raise ValueError('PDL ' + name + ' must be an integer between 1 and ' + str(maximum) + '.')
    if any(not isinstance(pdl.get(key), dict) for key in ('server', 'storage', 'albert', 'sources')):
        raise ValueError('PDL server, storage, albert and sources sections must be objects.')
    for name in ('INCIDENTS_LOGS_INDEX', 'INCIDENTS_DOCS_INDEX'):
        index = values.get(name, 'obs-network-docs' if name == 'INCIDENTS_DOCS_INDEX' else '')
        if not re.fullmatch(r'[a-z0-9][a-z0-9_.-]{0,254}', index):
            raise ValueError('Incidents source indices must be exact names without patterns.')
    if values.get('RIE_ENABLE_DEMO_UI', 'false') not in {'true', 'false'}:
        raise ValueError('RIE_ENABLE_DEMO_UI must be true or false.')
    if values.get('OBS_ITSM_HISTORY_CONFIG'):
        if values['OBS_ITSM_HISTORY_CONFIG']!='/data/config/itsm-history.json':
            raise ValueError('ITSM history requires the private config path')
        history=private_document(instance/'config/itsm-history.json')
        if history.get('version')!=1 or history.get('target_version')!='1.6.17' or history.get('provider') not in {'itsm-ng','fixture'}:
            raise ValueError('Invalid ITSM history configuration')
        from zoneinfo import ZoneInfo
        ZoneInfo(history.get('timezone','Europe/Paris'))
        if history['provider']=='fixture':
            if values['RIE_MODE']!='demo':raise ValueError('ITSM fixture requires demo mode')
        else:
            for name in ('api_url','public_url'):
                parsed=urlsplit(history.get(name,''))
                if parsed.scheme!='https' or not parsed.hostname or parsed.hostname.endswith(('.invalid','.example')) or parsed.username or parsed.password or parsed.query or parsed.fragment:
                    raise ValueError('Configure real HTTPS ITSM endpoints')
            if not urlsplit(history['api_url']).path.endswith('/apirest.php') or history.get('credentials_file')!='/data/secrets/itsm-users.json':
                raise ValueError('Invalid ITSM endpoint or private credential path')
            credentials=private_document(instance/'secrets/itsm-users.json')
            if not isinstance(credentials.get('users'),dict) or not credentials['users']:
                raise ValueError('Provision at least one individual ITSM user before startup')
            for subject,record in credentials['users'].items():
                if (not re.fullmatch(r'ldap:[a-f0-9]{64}',subject) or not isinstance(record,dict)
                        or type(record.get('itsm_user_id')) is not int or not 1<=record['itsm_user_id']<=10**15
                        or not isinstance(record.get('user_token'),str) or not re.fullmatch(r'[A-Za-z0-9_-]{20,256}',record['user_token'])):
                    raise ValueError('Invalid individual ITSM credential binding')
    if qualification_enabled(values) and values['RIE_MODE'] != 'demo':
        raise ValueError('Qualification images are reserved for synthetic demo instances.')
    if values.get('RIE_LOAD_QUALIFICATION') == 'true' and values.get('RIE_SIMULATED_ALBERT') != 'true':
        raise ValueError('The load instance requires its explicitly simulated provider.')
    if values.get('RIE_SIMULATED_ALBERT') == 'true' and values['ALBERT_URL'] != 'http://127.0.0.1:8123/v1':
        raise ValueError('The qualification provider requires its exact loopback endpoint.')
    if values['RIE_MODE'] == 'demo':
        if values['OPENSEARCH_URL'] != 'http://opensearch:9200' or values['VICTORIAMETRICS_URL'] != 'http://victoriametrics:8428':
            raise ValueError('Demo mode requires its dedicated source services.')
        return
    # External sources are explicitly configured and must not use demo identities.
    for key in ('OPENSEARCH_URL', 'VICTORIAMETRICS_URL'):
        host = urlsplit(values[key]).hostname
        if host.endswith(('.invalid', '.example')) or host in {'opensearch', 'victoriametrics'}:
            raise ValueError('Replace external source URL placeholders before startup.')
    ldap = access['ldap']
    if (ldap.get('use_tls') is not True or ldap.get('validate_cert') is not True
            or not ldap.get('attribute_for_subject') or not ldap.get('group_dns')
            or not isinstance(ldap.get('host'), str) or not ldap['host'].strip()
            or ldap['host'].endswith(('.invalid', '.example'))
            or type(ldap.get('port')) is not int or not 1 <= ldap['port'] <= 65535):
        raise ValueError('Configure a real verified LDAP directory and stable identity attribute.')
    for name in ('incidents-corpus.json', 'metric-mapping.json', 'itsm-tickets.json'):
        raw = (instance/'config'/name).read_text()
        if 'requires_operator_configuration' in raw:
            raise ValueError('Replace the external Incidents configuration marker in '+name+'.')
        json.loads(raw)
    contracts=module(ROOT/'use-cases/incidents/observability-demo/obs_poc/contracts.py','incident_deployment_contracts')
    corpus=contracts.validate_manifest(private_document(instance/'config/incidents-corpus.json'))
    contracts.validate_metric_mapping(private_document(instance/'config/metric-mapping.json'),corpus['hosts'])
    if 'REPLACE_' in (instance/'config/ldap-ca.crt').read_text():
        raise ValueError('Replace the LDAP CA placeholder.')
    if not (instance/'secrets/reader.password').read_text().strip():
        raise ValueError('The read-only LDAP credential is required.')
    if not policy.get('indices') or policy.get('default') != 'blocked':
        raise ValueError('Review a nonempty exact-index, default-deny policy before external startup.')
    for name in ('access.json', 'pdl.yaml'):
        raw = read_private_file(instance/'config'/name)
        if 'requires_operator_configuration' in raw or 'REPLACE_' in raw:
            raise ValueError('Replace external configuration placeholders in ' + name + '.')
    if 'requires_operator_configuration' in read_private_file(instance/'access/policy.json') or 'REPLACE_' in json.dumps(policy):
        raise ValueError('Replace external policy placeholders.')
    if not pdl.get('discovery', {}).get('allowed_index_patterns'):
        raise ValueError('An explicitly approved PDL index scope is required.')


def oauth_configuration(path):
    """Validate public OAuth settings using the stdlib-only shared contract."""
    sys.path.insert(0, str(ROOT/'core/access-control/src'))
    try:
        from dinum_access.oauth_store import configuration
        return configuration(path)
    finally:
        sys.path.pop(0)


# These lists define the files allowed into business images. Qualification and
# browser/VM helpers remain source tools and cannot enter by adding a new *.py.
PDL_RUNTIME = (
    '__init__.py', 'acceptance.py', 'acceptance_equipment_reference.py', 'adapters.py',
    'config.py', 'documents.py', 'equipment.py', 'http.py', 'identity_extractors.py', 'inventory.py',
    'maintenance.py', 'mappings.py', 'mcp_app.py', 'natural_dates.py', 'opensearch.py',
    'openwebui_dialogue.py', 'operator_mappings.py', 'planner.py', 'service.py', 'store.py', 'telemetry.py',
    'templates.yaml', 'reference_profiles.yaml', 'fixtures/pdl_portable.json', 'fixtures/equipment_reference.json',
)
ACCESS_RUNTIME = ('__init__.py', 'security.py', 'user_tokens.py', 'oauth.py', 'oauth_store.py')
ALBERT_RUNTIME = ('__init__.py', 'client.py', 'dialogue.py', 'natural_dates.py', 'recommendation_release.py')
INCIDENT_RUNTIME = (
    '__init__.py', 'agent_observability.py', 'assistant.py', 'clients.py', 'config.py',
    'contracts.py', 'domain.py', 'focused_answer.py', 'grafana_frames.py', 'opensearch_links.py', 'itsm_history.py', 'precedents.py',
    'recommendation_context.py', 'recommendation_demo.py', 'server.py', 'service.py', 'telemetry.py',
)
RUNTIME_TOOLS = ('initialize.py', 'runtime_cli.py', 'seed_incidents.py')
QUALIFICATION_TOOLS = ('runtime_entry.py', 'simulated_provider.py', 'qualification.py', 'load_seed.py')
PORTAL_TOOLS = ('__init__.py', 'app.py', 'backend.py', 'documents.py', 'reports.py', 'mapping_admin.py', 'mapping_ui.py')


def runtime_copies():
    copies = [(HERE/'Dockerfile', Path('Dockerfile')),
              (HERE/'requirements-runtime.lock', Path('requirements-runtime.lock'))]
    for source, target, names in (
        (ROOT/'use-cases/pdl/agentic-pdl/rie_agent', 'rie_agent', PDL_RUNTIME),
        (ROOT/'core/access-control/src/dinum_access', 'dinum_access', ACCESS_RUNTIME),
        (ROOT/'core/albert-client/src/dinum_albert', 'dinum_albert', ALBERT_RUNTIME),
        (ROOT/'use-cases/incidents/observability-demo/obs_poc', 'incidents/obs_poc', INCIDENT_RUNTIME),
        (HERE, 'delivery', RUNTIME_TOOLS)):
        copies.extend((source/name, Path(target)/name) for name in names)
    copies.extend((ROOT/'use-cases/incidents/observability-demo/fixtures'/name, Path('incidents/fixtures')/name)
                  for name in ('metric-mapping.json', 'itsm-tickets.json', 'itsm-history.json'))
    copies += [(ROOT/'use-cases/incidents/observability-demo/corpus-documents.json', Path('incidents/corpus-documents.json')),
               (ROOT/'core/access-control/tokens.py', Path('delivery/tokens.py')),
               (ROOT/'deploy/ubuntu/seed_pdl.py', Path('delivery/demo.py'))]
    return copies


def context(destination, target='runtime'):
    """Copy exactly one target's public inputs; runtime hashes exclude documentation."""
    if target not in {'runtime', 'portal', 'qualification'}:
        raise ValueError('Choose runtime, portal or qualification build target.')
    destination = Path(destination)
    copies = runtime_copies()
    if target == 'qualification':
        copies.extend((HERE/name, Path('qualification')/name) for name in QUALIFICATION_TOOLS)
    if target == 'portal':
        copies.append((HERE/'requirements-portal.lock', Path('requirements-portal.lock')))
        copies.append((HERE/'wiki_export.py', Path('portal-delivery/wiki_export.py')))
        copies.append((HERE/'qualification_reports.py', Path('portal-delivery/qualification_reports.py')))
        copies.extend((HERE/'portal'/name, Path('portal')/name) for name in PORTAL_TOOLS)
        documents = ROOT/'docs/si-rie'
        for source in sorted(documents.rglob('*')):
            if source.is_symlink():
                raise ValueError('Public documentation links are forbidden in build contexts.')
            if source.is_file() and source.suffix.lower() in {'.md', '.drawio', '.svg', '.png', '.mmd', '.puml'}:
                copies.append((source, Path('documentation')/source.relative_to(documents)))
        if not (documents/'README.md').is_file():
            raise ValueError('The optional portal requires the canonical documentation index.')
    # Check the complete allowlist before deleting a previous generated context.
    for source, _ in copies:
        for component in (source, *source.parents):
            if component.is_symlink():
                raise ValueError('Runtime links forbidden')
            if component == ROOT:
                break
        if not source.is_file():
            raise ValueError('Missing public build input: ' + source.relative_to(ROOT).as_posix())
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    manifest = []
    for source, relative in copies:
        dest = destination/relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        data = source.read_bytes()
        dest.write_bytes(data)
        manifest.append({'path': relative.as_posix(), 'sha256': hashlib.sha256(data).hexdigest()})
    (destination/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    for path in [destination, *destination.rglob('*')]:
        path.chmod(0o755 if path.is_dir() else 0o644)
    return hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()[:20]


def tool(instance, values, *args, capture=False, interactive_input=False, input_text=None):
    options = {'capture': capture}
    if input_text is not None:
        options['input'] = input_text
    else:
        options['stdin'] = None if interactive_input else subprocess.DEVNULL
    return compose(instance, values, 'run', '--rm', '--no-deps', '--pull', 'never', '-T',
                   '--interactive=' + ('true' if interactive_input or input_text is not None else 'false'),
                   'operator', *args, **options)



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['prepare', 'build', 'pull', 'up', 'stop', 'status', 'seed', 'check', 'acceptance',
                                          'issue-token', 'list-tokens', 'revoke-token', 'policy', 'pdl', 'backup', 'restore', 'validate', 'configure-ui',
                                          'demo-credentials', 'logs', 'storage', 'import-report', 'configure-itsm-history', 'itsm-user',
                                          'configure-client-auth', 'list-client-sessions', 'revoke-client-session'])
    parser.add_argument('instance', type=Path)
    parser.add_argument('--mode', choices=['demo', 'external'], default='demo')
    parser.add_argument('--username', default='alice.martin')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--id')
    parser.add_argument('--days', type=int, default=30)
    parser.add_argument('--backup', type=Path)
    parser.add_argument('--enable-demo-ui', action='store_true')
    parser.add_argument('--with-qualification', action='store_true')
    parser.add_argument('--input', type=Path)
    parser.add_argument('--service', choices=sorted(SERVICES - {'operator', 'initialize'}), default='pdl')
    parser.add_argument('--tail', type=int, default=100)
    parser.add_argument('arguments', nargs='*')
    argv = sys.argv[1:]
    separator = argv.index('--') if '--' in argv else len(argv)
    args = parser.parse_intermixed_args(argv[:separator])
    args.arguments.extend(argv[separator + 1:])
    if args.arguments and args.command not in {'pdl', 'policy'}:
        parser.error('Additional arguments are supported only by pdl and policy')
    mapping_input = args.command == 'pdl' and args.arguments and args.arguments[0] in {'validate-mappings', 'load-mappings'}
    if args.input is not None and not mapping_input and args.command not in {'import-report', 'configure-itsm-history', 'itsm-user', 'configure-client-auth'}:
        parser.error('--input is reserved for mappings, report, ITSM or client authentication imports')
    if args.with_qualification and args.command != 'build':
        parser.error('--with-qualification is reserved for build')
    if not 1 <= args.tail <= 10000:
        parser.error('--tail must be between 1 and 10000')
    input_text = read_private_file(args.input.expanduser().absolute(), limit=MAX_INPUT_BYTES) if mapping_input and args.input is not None else None
    os.umask(0o077)
    instance = args.instance.expanduser().resolve()
    if args.command == 'prepare':
        bootstrap(instance, args.mode)
        return
    if args.command == 'restore':
        if not args.backup:
            raise ValueError('--backup is required for restore')
        recovery = module(HERE/'backup_restore.py', 'delivery_backup_restore')
        print(json.dumps(recovery.restore_backup(instance, args.backup.expanduser().absolute(), operation_environment())))
        return
    values = load(instance)
    if args.command == 'configure-client-auth':
        if args.input is None:
            raise ValueError('--input requires a private reviewed OAuth settings file')
        path = args.input.expanduser().absolute()
        document = oauth_configuration(path)
        target = instance/'config/oauth.json'
        if target.is_symlink():
            raise ValueError('OAuth configuration links are forbidden')
        temporary = instance/'config'/('oauth-'+uuid.uuid4().hex+'.tmp')
        write_new(temporary, json.dumps(document, indent=2)+'\n')
        temporary.replace(target)
        values['DINUM_OAUTH_CONFIG'] = '/data/config/oauth.json'
        save_env(instance, values)
        print('Individual browser sign-in configured. Run validate then up. No password or token issued.')
        return
    if args.command in {'configure-itsm-history', 'itsm-user'}:
        if args.input is None:raise ValueError('--input is required')
        raw=read_private_file(args.input.expanduser().absolute(),limit=65536)
        document=json.loads(raw)
        if args.command=='configure-itsm-history':
            # Validate the public contract without importing runtime dependencies on the host.
            if (document.get('version')!=1 or document.get('target_version')!='1.6.17'
                    or document.get('provider') not in {'itsm-ng','fixture'}):
                raise ValueError('Explicit ITSM-NG 1.6.17 history configuration required')
            if document['provider']=='fixture' and values['RIE_MODE']!='demo':raise ValueError('Fixture provider requires demo mode')
            if document['provider']=='itsm-ng':
                for key in ('api_url','public_url'):
                    parsed=urlsplit(document.get(key,''))
                    if parsed.scheme!='https' or not parsed.hostname or parsed.hostname.endswith('.invalid') or parsed.username or parsed.password or parsed.query or parsed.fragment:
                        raise ValueError('Replace the ITSM HTTPS endpoint placeholders')
                if not urlsplit(document['api_url']).path.endswith('/apirest.php'):raise ValueError('ITSM api_url must end with /apirest.php')
                if document.get('credentials_file')!='/data/secrets/itsm-users.json':raise ValueError('Use the private per-user credential store')
            target=instance/'config/itsm-history.json'
            if target.is_symlink():raise ValueError('ITSM configuration link forbidden')
            temporary=instance/'config'/('itsm-history-'+uuid.uuid4().hex+'.tmp')
            write_new(temporary,json.dumps(document,indent=2)+'\n');temporary.replace(target)
            values['OBS_ITSM_HISTORY_CONFIG']='/data/config/itsm-history.json';save_env(instance,values)
            print('ITSM history configured; run validate then up to apply. No source contacted.')
        else:
            # Only the trusted host operator can provision another LDAP subject.
            # Native identity is verified again by getFullSession at every read.
            if (set(document)!={'itsm_user_id','user_token'} or type(document['itsm_user_id']) is not int
                    or not 1<=document['itsm_user_id']<=10**15 or not re.fullmatch(r'[A-Za-z0-9_-]{20,256}',document['user_token'])):
                raise ValueError('Input requires itsm_user_id and individual user_token')
            result=tool(instance,values,'python','/delivery/runtime_cli.py','itsm-subject','--username',args.username,capture=True)
            subject=json.loads(result.stdout)['subject']
            if not re.fullmatch(r'ldap:[a-f0-9]{64}',subject):raise ValueError('Stable LDAP subject required')
            target=instance/'secrets/itsm-users.json'
            store=json.loads(read_private_file(target)) if target.exists() else {'users':{}}
            store['users'][subject]=document
            temporary=instance/'secrets'/('itsm-users-'+uuid.uuid4().hex+'.tmp')
            write_new(temporary,json.dumps(store,indent=2)+'\n');temporary.replace(target)
            print('Individual ITSM credential provisioned privately; run up to apply. Token not displayed.')
        return
    if args.command == 'import-report':
        if args.input is None:
            raise ValueError('--input is required for import-report')
        reports = module(HERE/'qualification_reports.py', 'delivery_qualification_reports')
        print(json.dumps(reports.import_report(instance, args.input.expanduser().absolute())))
        return
    if args.command == 'demo-credentials':
        operations = module(HERE/'host_operations.py', 'delivery_host_operations')
        operations.run(args.command, instance, values, operation_environment(), username=args.username, output=args.output)
        return
    if args.command == 'validate':
        validate_instance(instance, values)
        print('Private instance configuration validated; no generation performed.')
        return
    if args.command == 'configure-ui':
        values['RIE_ENABLE_DEMO_UI'] = 'true' if args.enable_demo_ui else 'false'
        values.setdefault('PORTAL_PORT', '18090')
        prepare_report_directory(instance)
        save_env(instance, values)
        print('Optional NiceGUI portal:', values['RIE_ENABLE_DEMO_UI'])
        return
    if args.command == 'up':
        preflight_up(instance, values)
    guard(instance, values)
    if args.command in {'logs', 'storage'}:
        operations = module(HERE/'host_operations.py', 'delivery_host_operations')
        operations.run(args.command, instance, values, operation_environment(), service=args.service, tail=args.tail)
    elif args.command == 'build':
        targets = ['runtime']
        if values.get('RIE_ENABLE_DEMO_UI') == 'true':
            targets.append('portal')
        if args.with_qualification:
            if values['RIE_MODE'] != 'demo':
                raise ValueError('Build qualification only for the dedicated synthetic instance.')
            targets.append('qualification')
        values.setdefault('RIE_PORTAL_IMAGE', '')
        values.setdefault('RIE_QUALIFICATION_IMAGE', '')
        receipts = []
        for role in targets:
            target = ROOT/'.runtime/ci/ubuntu-context'/values['RIE_PROJECT']/role
            digest = context(target, role)
            key = {'runtime': 'RIE_IMAGE', 'portal': 'RIE_PORTAL_IMAGE', 'qualification': 'RIE_QUALIFICATION_IMAGE'}[role]
            image = {'runtime': 'dinum/rie-delivery:runtime-', 'portal': 'dinum/rie-portal:',
                     'qualification': 'dinum/rie-qualification:'}[role] + digest
            docker('build', '--target', role, '--tag', image, str(target))
            values[key] = image
            receipts.append((role, digest, image))
        if values['RIE_MODE'] == 'demo':
            docker('build', '--tag', values['RIE_LDAP_IMAGE'], str(ROOT/'simulation-rie/ldap-demo'))
        save_env(instance, values)
        for role, digest, image in receipts:
            receipt = instance/('build-' + role + '-' + digest + '.json')
            if not receipt.exists():
                write_new(receipt, json.dumps({'target': role, 'image': image, 'context_sha256_prefix': digest}) + '\n')
    elif args.command == 'pull':
        if values['RIE_MODE'] == 'demo':
            compose(instance, values, '--profile', 'demo', 'pull', 'opensearch', 'victoriametrics')
    elif args.command == 'up':
        if values.get('RIE_ENABLE_DEMO_UI') == 'true':
            prepare_report_directory(instance)
        # Stop consumers before replacing their configuration and secret files.
        # This also ensures existing processes reload files on a repeated up.
        compose(instance, values, '--profile', 'demo', '--profile', 'demo-ui', 'stop', 'pdl', 'incidents', 'ldap', 'portal')
        compose(instance, values, 'run', '--rm', '--no-deps', '--pull', 'never', '-T', '--interactive=false', 'initialize')
        if values['RIE_MODE'] == 'demo':
            # BuildKit attestations can change an image index while its layers stay
            # cached. Recreate LDAP explicitly so cold backups capture the selected image.
            compose(instance, values, '--profile', 'demo', 'up', '-d', '--pull', 'never', '--no-build', '--force-recreate', 'ldap')
            compose(instance, values, '--profile', 'demo', 'up', '-d', '--pull', 'never', '--no-build', 'opensearch', 'victoriametrics')
        compose(instance, values, 'up', '-d', '--wait', '--wait-timeout', '180', '--pull', 'never', '--no-build', '--force-recreate', 'pdl', 'incidents')
        if values.get('RIE_ENABLE_DEMO_UI') == 'true':
            compose(instance, values, '--profile', 'demo-ui', 'up', '-d', '--wait', '--wait-timeout', '120', '--pull', 'never', '--no-build', '--force-recreate', 'portal')
    elif args.command == 'stop':
        compose(instance, values, '--profile', 'demo', '--profile', 'demo-ui', '--profile', 'tools', 'stop')
        print('Stopped. All volumes and private inputs retained.')
    elif args.command == 'status':
        compose(instance, values, '--profile', 'demo', '--profile', 'demo-ui', 'ps', '-a')
    elif args.command in {'check', 'seed', 'acceptance', 'policy', 'pdl'}:
        if args.command in {'seed', 'acceptance'} and values['RIE_MODE'] != 'demo':
            raise ValueError('Synthetic writes/acceptance forbidden for external sources')
        tool(instance, values, 'python', '/delivery/runtime_cli.py', args.command, '--username', args.username, *args.arguments,
             interactive_input=bool(mapping_input), input_text=input_text)
    elif args.command in {'issue-token', 'list-tokens', 'revoke-token'}:
        base = ['python', '/delivery/tokens.py', '--config', '/data/config/access.json']
        if args.command == 'list-tokens':
            tool(instance, values, *base, 'list')
        elif args.command == 'revoke-token':
            if not args.id:
                raise ValueError('--id required')
            tool(instance, values, *base, 'revoke', '--id', args.id)
        else:
            output = args.output.expanduser().resolve() if args.output else instance/'clients'/(args.username+'.token')
            if output.exists() or not output.parent.is_dir() or output.is_relative_to(ROOT):
                raise ValueError('Choose a new token output file outside Git in an existing private directory')
            # Issue into runtime state; copy through the live service without exposing bytes in logs.
            remote = '/data/access/issued-'+uuid.uuid4().hex+'.token'
            compose(instance, values, 'exec', '-T', 'pdl', *base, 'issue', '--username', args.username, '--output', remote, '--days', str(args.days))
            fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            os.close(fd)
            try:
                compose(instance, values, 'cp', 'pdl:'+remote, str(output))
                output.chmod(0o600)
            finally:
                compose(instance, values, 'exec', '-T', 'pdl', 'python', '-c', 'from pathlib import Path; Path('+repr(remote)+').unlink()')
            print('Individual token file:', output, '(share only with its owner)')
    elif args.command in {'list-client-sessions', 'revoke-client-session'}:
        if args.command == 'revoke-client-session' and not args.id:
            raise ValueError('--id required')
        arguments = ['--id', args.id] if args.id else []
        tool(instance, values, 'python', '/delivery/runtime_cli.py', args.command,
             '--username', args.username, *arguments)
    elif args.command == 'backup':
        if not args.output:
            raise ValueError('--output is required for backup')
        recovery = module(HERE/'backup_restore.py', 'delivery_backup_restore')
        print(json.dumps(recovery.create_backup(instance, values, args.output.expanduser().resolve(), operation_environment())))



if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, TypeError, subprocess.CalledProcessError) as error:
        print('ERROR:', str(error) if not isinstance(error, subprocess.CalledProcessError) else 'Docker operation failed; see service status.', file=sys.stderr)
        raise SystemExit(2)
