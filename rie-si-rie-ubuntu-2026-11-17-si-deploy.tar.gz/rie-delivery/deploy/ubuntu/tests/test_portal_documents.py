"""Portal documentation routes only link files accepted by the public exporter."""
from pathlib import Path
from html.parser import HTMLParser
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'deploy/ubuntu'))
from portal import documents


class FakeExporter:
    def list_documents(self, root):
        return [{'id': '01-installation', 'title': 'Installer', 'path': '01-installation.md'},
                {'id': '04-pdl', 'title': 'PDL', 'path': '04-pdl.md'}]

    def public_file(self, root, relative):
        path = root / relative
        if relative not in {'01-installation.md', '04-pdl.md', 'assets/diagrams/03-pdl-flow.svg',
                            'diagrams/03-pdl-flow.drawio'} or not path.is_file() or path.is_symlink():
            raise ValueError('Unknown public file')
        return path

    def export_bundle(self, root, output):
        output.write_bytes(b'public-test-archive')
        return {'files': 4}


class PortalDocumentTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        for relative, value in [('01-installation.md', '# Installer'), ('04-pdl.md', '# PDL'),
                                ('assets/diagrams/03-pdl-flow.svg', '<svg/>'),
                                ('diagrams/03-pdl-flow.drawio', '<mxfile/>')]:
            path = self.root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(value)
        self.patches = [patch.object(documents, 'root', return_value=self.root),
                        patch.object(documents, 'exporter', return_value=FakeExporter())]
        for item in self.patches:
            item.start()

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.temporary.cleanup()

    def test_document_ids_cannot_become_arbitrary_filesystem_paths(self):
        self.assertEqual(documents.document('04-pdl').read_text(), '# PDL')
        for identifier in ('../secrets', '/etc/passwd', 'missing', '04-pdl.md'):
            with self.subTest(identifier=identifier), self.assertRaises(documents.DocumentationError):
                documents.document(identifier)

    def test_bookmarked_pages_and_downloads_resolve_only_to_renamed_public_documents(self):
        import wiki_export
        source = ROOT / 'docs/si-rie'
        pairs = (
            ('07-exploitation', '07-operations'),
            ('11-journal-installation', '11-installation-log'),
            ('12-recette-manuelle', '12-manual-acceptance'),
            ('13-rapports-tests', '13-test-reports'),
            ('14-recette-si-rie', '14-si-rie-acceptance'),
            ('16-tutoriel-pdl', '16-pdl-tutorial'),
            ('17-tutoriel-incidents', '17-incidents-tutorial'),
        )
        with patch.object(documents, 'root', return_value=source), \
             patch.object(documents, 'exporter', return_value=wiki_export):
            ids = {row['id'] for row in documents.catalog()}
            for previous, current in pairs:
                with self.subTest(previous=previous):
                    self.assertNotIn(previous, ids)
                    self.assertIn(current, ids)
                    self.assertFalse((source / (previous + '.md')).exists())
                    self.assertEqual(documents.document(previous), source / (current + '.md'))
                    self.assertEqual(documents.markdown(previous), documents.markdown(current))
            for identifier in ('../07-exploitation', '07-exploitation.md', '07-exploitation/../secrets'):
                with self.subTest(identifier=identifier), self.assertRaises(documents.DocumentationError):
                    documents.markdown(identifier)

    def test_portal_links_use_canonical_document_and_asset_routes(self):
        source = '[Installer](01-installation.md#etape) ![Flux](assets/diagrams/03-pdl-flow.svg) [Source](https://example.org/ref) [Ancre](#ici)'
        rendered = documents.rewrite_markdown(source, '04-pdl.md')
        self.assertIn('[Installer](/documentation/01-installation#etape)', rendered)
        self.assertIn('![Flux](/documentation/files/assets/diagrams/03-pdl-flow.svg)', rendered)
        self.assertIn('[Source](https://example.org/ref)', rendered)
        self.assertIn('[Ancre](#ici)', rendered)

    def test_unlisted_paths_and_unsafe_schemes_do_not_become_download_links(self):
        rendered = documents.rewrite_markdown('[Secret](../secrets/albert_key) [Script](javascript:alert) [Remote](//example.org/x)', '04-pdl.md')
        self.assertNotIn('/secrets/', rendered)
        self.assertNotIn('javascript:', rendered)
        self.assertNotIn('//example.org', rendered)
        for relative in ('../../secrets/albert_key', 'private.json', r'..\secrets\password'):
            with self.subTest(relative=relative), self.assertRaises(documents.DocumentationError):
                documents.public_file(relative)

    def test_zip_only_uses_public_root_and_temporary_output(self):
        self.assertEqual(documents.wiki_zip(), b'public-test-archive')
        self.assertFalse((self.root / 'si-rie-documentation.zip').exists())

    def test_rendered_heading_targets_preserve_unicode_duplicates_and_fenced_examples(self):
        class Anchors(HTMLParser):
            def __init__(self):
                super().__init__();self.identifiers=[]
            def handle_starttag(self, tag, attributes):
                if tag == 'a' and 'id' in dict(attributes):self.identifiers.append(dict(attributes)['id'])
        source = '# Préparer la séance\n## Préparer la séance\n```md\n# Exemple uniquement\n```\n'
        rendered = documents.section_anchors(source)
        parser = Anchors();parser.feed(rendered)
        self.assertEqual(parser.identifiers, ['préparer-la-séance', 'préparer-la-séance-1'])
        self.assertIn('```md\n# Exemple uniquement\n```', rendered)

    def test_display_anchors_do_not_modify_the_exported_source(self):
        source = '# PDL\n## Lire les données\n[Lire](#lire-les-données)\n'
        (self.root/'04-pdl.md').write_text(source)
        rendered = documents.markdown('04-pdl')
        self.assertIn('id="lire-les-données"', rendered)
        self.assertIn('[Lire](#lire-les-données)', rendered)
        self.assertEqual(documents.document('04-pdl').read_text(), source)


if __name__ == '__main__':
    unittest.main()
