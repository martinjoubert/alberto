"""Public wiki exports remain portable, editable and isolated from private data."""
from __future__ import annotations

import hashlib
import base64
import importlib.util
import json
from pathlib import Path
import re
import stat
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile
import zlib
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[3]
SPEC = importlib.util.spec_from_file_location('rie_wiki_export', ROOT/'deploy/ubuntu/wiki_export.py')
wiki = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(wiki)


def drawing():
    return b'<mxfile><diagram><mxGraphModel><root><mxCell id="0"/><mxCell id="1" parent="0"/><mxCell id="a" parent="1" vertex="1"/><mxCell id="b" parent="1" vertex="1"/><mxCell id="e" parent="1" edge="1" source="a" target="b"/></root></mxGraphModel></diagram></mxfile>'


class ExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.docs = self.base/'docs'
        (self.docs/'assets').mkdir(parents=True)
        (self.docs/'diagrams').mkdir()
        (self.docs/'README.md').write_text('# Accueil\n\n[Suite](01-suite.md)\n![Figure](assets/test.svg)\n[Modèle](diagrams/test.drawio)\n')
        (self.docs/'01-suite.md').write_text('# Suite\n\n[Accueil](README.md#lecture)\n[Source](https://docs.requarks.io/s/editors)\n')
        (self.docs/'assets/test.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"><rect width="10" height="10"/></svg>')
        (self.docs/'diagrams/test.drawio').write_bytes(drawing())

    def tearDown(self):
        self.temp.cleanup()

    def test_archive_has_portable_links_wiki_paths_and_verified_manifest(self):
        output = self.base/'public.zip'
        report = wiki.export_bundle(self.docs, output, '/rie/docs')
        self.assertEqual(report['pages'], 2)
        self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o600)
        with zipfile.ZipFile(output) as archive:
            self.assertIsNone(archive.testzip())
            self.assertIn(b'(01-suite.md)', archive.read('portable/README.md'))
            self.assertIn(b'(/rie/docs/01-suite)', archive.read('wikijs/README.md'))
            self.assertIn(b'(/rie/docs/assets/test.svg)', archive.read('wikijs/README.md'))
            self.assertIn(b'(/rie/docs#lecture)', archive.read('wikijs/01-suite.md'))
            manifest = json.loads(archive.read('DOCUMENTATION-MANIFEST.json'))
            for item in manifest['files']:
                self.assertEqual(hashlib.sha256(archive.read(item['path'])).hexdigest(), item['sha256'])
            archive.extractall(self.base/'extracted')
        extracted = self.base/'extracted/portable'
        names = wiki._files(extracted)
        for path in extracted.glob('*.md'):
            wiki.rewrite_markdown(path.read_text(), path.name, names)
        self.assertEqual([x['id'] for x in wiki.list_documents(extracted)], ['README', '01-suite'])

    def test_native_wikijs_tree_preserves_the_editable_embedded_model(self):
        svg = ET.Element('svg', xmlns='http://www.w3.org/2000/svg', content=drawing().decode())
        ET.SubElement(svg, 'rect', width='10', height='10')
        (self.docs/'assets/test.svg').write_bytes(ET.tostring(svg))
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)/'native.zip'
            wiki.export_bundle(self.docs, output)
            with zipfile.ZipFile(output) as archive:
                native = archive.read('wikijs-native/README.md').decode()
                self.assertIn('```diagram\n', native)
                encoded = re.search(r'```diagram\n([^\n]+)\n```', native)[1]
                embedded = ET.fromstring(base64.b64decode(encoded)).get('content')
                self.assertEqual(ET.tostring(ET.fromstring(embedded)), ET.tostring(ET.fromstring(drawing())))
                self.assertIn(b'![Figure]', archive.read('portable/README.md'))
                self.assertIn(b'![Figure]', archive.read('wikijs/README.md'))

    def test_standard_compressed_drawio_remains_editable_and_equivalent(self):
        model = ET.fromstring(drawing()).find('.//mxGraphModel')
        model.set('dx', '1200')
        payload = quote(ET.tostring(model, encoding='unicode'), safe='').encode()
        compressor = zlib.compressobj(wbits=-15)
        encoded = base64.b64encode(compressor.compress(payload)+compressor.flush()).decode()
        compressed = ('<mxfile agent="local editor"><diagram>'+encoded+'</diagram></mxfile>').encode()
        self.assertEqual(wiki.canonical_models(compressed), wiki.canonical_models(drawing()))
        wiki._validate_asset('diagrams/compressed.drawio', compressed)
        for invalid in ('not-a-base64-value!', base64.b64encode(b'not a deflate stream').decode()):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                wiki.drawio_models(('<mxfile><diagram>'+invalid+'</diagram></mxfile>').encode())

    def test_path_traversal_absolute_paths_and_private_formats_are_refused(self):
        for relative in ('../secret.md', '/tmp/secret.md', 'assets/../README.md', 'assets/secret.key', '.env', 'unknown/x.md', 'assets\\test.svg'):
            with self.subTest(relative=relative), self.assertRaises(ValueError):
                wiki.public_file(self.docs, relative)

    def test_symlink_directory_is_refused_before_opening_outside_data(self):
        outside = self.base/'outside'
        outside.mkdir()
        (outside/'private.md').write_text('Never export')
        (self.docs/'assets/outside').symlink_to(outside, target_is_directory=True)
        output = self.base/'symlink.zip'
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            wiki.export_bundle(self.docs, output)
        self.assertFalse(output.exists())
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            wiki.public_file(self.docs, 'assets/outside/private.md')

    def test_missing_or_escaping_document_links_fail_before_creating_archive(self):
        for target in ('missing.md', '../outside.md', 'assets/%2e%2e/%2e%2e/outside.md'):
            (self.docs/'README.md').write_text('# Index\n\n[Broken]('+target+')\n')
            output = self.base/'bad-links.zip'
            with self.subTest(target=target), self.assertRaises(ValueError):
                wiki.export_bundle(self.docs, output)
            self.assertFalse(output.exists())

    def test_existing_or_source_tree_output_is_preserved(self):
        output = self.base/'existing.zip'
        output.write_bytes(b'keep')
        with self.assertRaises(ValueError):
            wiki.export_bundle(self.docs, output)
        self.assertEqual(output.read_bytes(), b'keep')
        with self.assertRaises(ValueError):
            wiki.export_bundle(self.docs, self.docs/'nested/export.zip')

    def test_active_external_svg_and_flattened_drawio_are_refused(self):
        path = self.docs/'assets/test.svg'
        for data in ('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>',
                     '<svg xmlns="http://www.w3.org/2000/svg"><image href="https://external.example/track"/></svg>',
                     '<!DOCTYPE svg [<!ENTITY x SYSTEM "file:///secret">]><svg/>'):
            path.write_text(data)
            with self.assertRaises(ValueError):
                wiki.export_bundle(self.docs, self.base/'bad-svg.zip')
        path.write_text('<svg xmlns="http://www.w3.org/2000/svg"/>')
        (self.docs/'diagrams/test.drawio').write_text('<mxfile><diagram>flattened image</diagram></mxfile>')
        with self.assertRaisesRegex(ValueError, 'editable'):
            wiki.export_bundle(self.docs, self.base/'flat.zip')

    def test_obvious_secret_is_rejected_without_showing_its_value(self):
        secret = 'ghp_'+'X'*32
        (self.docs/'01-suite.md').write_text('# Suite\n'+secret)
        with self.assertRaises(ValueError) as error:
            wiki.export_bundle(self.docs, self.base/'secret.zip')
        self.assertNotIn(secret, str(error.exception))
        self.assertFalse((self.base/'secret.zip').exists())

    def test_prefix_and_source_url_are_validated(self):
        for prefix in ('https://wiki.example', '../rie', '/rie/../secret', '/rie//docs', '/RIE'):
            with self.subTest(prefix=prefix), self.assertRaises(ValueError):
                wiki.export_bundle(self.docs, self.base/'prefix.zip', prefix)
        with self.assertRaises(ValueError):
            wiki.export_bundle(self.docs, self.base/'source.zip', source_base_url='https://user:password@git.example/repo')

    def test_packaged_delivery_import_has_no_repository_depth_assumption(self):
        source = (ROOT/'deploy/ubuntu/wiki_export.py').read_text()
        command = ('from pathlib import Path; scope={"__file__":"/delivery/wiki_export.py",'
                   '"__name__":"packaged_wiki"}; exec(compile('+repr(source)+
                   ',"/delivery/wiki_export.py","exec"),scope); '
                   'assert scope["DEFAULT_DOCS"] == Path("/documentation")')
        subprocess.run([sys.executable, '-I', '-c', command], check=True,
                       capture_output=True, text=True, env={'PATH': __import__('os').environ.get('PATH', '')})
        shallow = self.base/'short'
        shallow.mkdir()
        target = shallow/'wiki_export.py'
        target.write_text(source)
        command = ('import importlib.util; s=importlib.util.spec_from_file_location("wiki_short",'+
                   repr(str(target))+'); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); '
                   'assert str(m.DEFAULT_DOCS)=='+repr(str(self.docs)))
        subprocess.run([sys.executable, '-I', '-c', command], check=True,
                       capture_output=True, text=True,
                       env={'PATH': __import__('os').environ.get('PATH', ''), 'RIE_DOCS_DIR': str(self.docs)})


class RealDocumentationTests(unittest.TestCase):
    def test_canonical_pages_and_every_link_export_without_network(self):
        docs = ROOT/'docs/si-rie'
        pages = wiki.list_documents(docs)
        identifiers = {page['id'] for page in pages}
        self.assertTrue({'README', '01-installation', '06-acl', '07-operations',
                         '08-qualification', '11-installation-log', '12-manual-acceptance'}.issubset(identifiers))
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)/'documentation.zip'
            report = wiki.export_bundle(docs, output)
            self.assertGreaterEqual(report['files'], 70)
            with zipfile.ZipFile(output) as archive:
                self.assertIn('portable/diagrams/01-deployment.drawio', archive.namelist())
                self.assertIn('wikijs/10-wikijs.md', archive.namelist())
                self.assertIn('wikijs/11-installation-log.md', archive.namelist())
                self.assertIn('wikijs/12-manual-acceptance.md', archive.namelist())

    def test_twelve_diagrams_have_editable_cells_connectors_and_matching_svg_models(self):
        docs = ROOT/'docs/si-rie'
        models = sorted((docs/'diagrams').glob('*.drawio'))
        self.assertEqual(len(models), 12)
        for path in models:
            with self.subTest(diagram=path.name):
                model = ET.fromstring(path.read_bytes())
                cells = model.findall('.//mxCell')
                ids = {c.get('id') for c in cells}
                self.assertGreaterEqual(sum(c.get('vertex') == '1' for c in cells), 6)
                self.assertGreaterEqual(sum(c.get('edge') == '1' for c in cells), 6)
                for cell in cells:
                    if cell.get('edge') == '1':
                        self.assertIn(cell.get('source'), ids)
                        self.assertIn(cell.get('target'), ids)
                svg = docs/'assets/diagrams'/path.with_suffix('.svg').name
                svg_model = ET.fromstring(svg.read_bytes()).get('content')
                self.assertEqual(ET.tostring(ET.fromstring(svg_model)), ET.tostring(model))
                png = docs/'assets/diagrams'/path.with_suffix('.png').name
                self.assertTrue(png.read_bytes().startswith(b'\x89PNG\r\n\x1a\n'))
                self.assertGreater(png.stat().st_size, 10000)


if __name__ == '__main__':
    unittest.main()
