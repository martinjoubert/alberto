# Livraison PDL, Incidents et ACL

**Déployeur SI-RIE : commencer par [le guide pas à pas en douze étapes](docs/si-rie/24-deploy-walkthrough.md).**
Faire compléter [la fiche de raccordement](docs/si-rie/26-si-connection-sheet.md) avant l'installation.
Les variantes scriptée/demo sont dans [le manuel de référence](deploy/ubuntu/README.md) ; ne pas les enchaîner au guide principal.
Pour le laboratoire, [la fiche sandbox](docs/si-rie/22-external-sandbox.md) conserve ses paramètres fictifs.

Le dossier conserve les chemins du code source pour les commandes du guide.
Les images serveur approuvées proviennent de la registry GitLab indiquée par le SI.
Open WebUI reste installé sur chaque poste utilisateur. L'observabilité et les
autres démonstrateurs ne font pas partie de cette livraison.

DELIVERY-MANIFEST.json fournit la référence Git, l'état modifié ou non du checkout
et l'empreinte SHA-256 de chaque fichier. Comparer au reçu de livraison.
Le packaging n'atteste aucune qualification Ubuntu, Albert, LDAP ou SI-RIE.
