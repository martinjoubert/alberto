"""Preparation has no source access; imports cannot alter an existing instance."""
from contextlib import ExitStack, redirect_stdout
from datetime import datetime, timedelta, timezone
import importlib.util
import hashlib
import io
import json
from pathlib import Path
import socket
import ssl
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile
import warnings

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
import deployment_setup as setup
spec=importlib.util.spec_from_file_location('deployment_setup_manage',HERE/'manage.py');manage=importlib.util.module_from_spec(spec);spec.loader.exec_module(manage)


def sample():
    v=setup.defaults()
    v.update(environment='Qualification isolée',contact='Équipe SI',admin_login='operateur',
             runtime_image='registry.site.test/rie/runtime@sha256:'+'a'*64,
             portal_image='registry.site.test/rie/portal@sha256:'+'b'*64,
             ldap_host='ldap.site.test',reader_dn='cn=reader,dc=site,dc=test',search_base='ou=people,dc=site,dc=test',
             internal_group='cn=internal,dc=site,dc=test',external_group='cn=external,dc=site,dc=test',
             admin_groups='cn=admins,dc=site,dc=test',opensearch_url='https://search.site.test',
             pdl_indices='site-pfs\nsite-bb',logs_index='site-logs',docs_index='site-docs',
             victoria_url='https://metrics.site.test',albert_url='https://albert.site.test/v1')
    corpus=json.loads((HERE/'examples/incidents-corpus.json').read_text());corpus.pop('requires_operator_configuration')
    corpus.update(status='ready',synthetic=True,anchor_date='2026-09-28',start='2026-09-28T10:00:00+02:00',end='2026-09-28T12:00:00+02:00',
                  hosts=[{'equipment':'SITE-R1','scope':'SITE','hostid':'1','interface':'uplink0','allowed':True}])
    metrics=json.loads((HERE/'examples/metric-mapping.json').read_text());metrics.pop('requires_operator_configuration');metrics['provenance']='Qualification fictive'
    for key,specification in metrics['metrics'].items():specification['name']='site_'+key
    tickets={'simulator':'ITSM-NG','schema':'dinum-demo-ticket-v1','complete':True,'tickets':[],'provenance':'Export fictif de test'}
    return v,{'incidents-corpus.json':setup._json(corpus),'metric-mapping.json':setup._json(metrics),'itsm-tickets.json':setup._json(tickets)}


class PreparationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        key=ec.generate_private_key(ec.SECP256R1());name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Deployment test CA')]);now=datetime.now(timezone.utc)
        cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number())
              .not_valid_before(now-timedelta(days=1)).not_valid_after(now+timedelta(days=1)).add_extension(x509.BasicConstraints(ca=True,path_length=None),critical=True).sign(key,hashes.SHA256()))
        cls.ca=cert.public_bytes(serialization.Encoding.PEM)

    def setUp(self):
        self.v,self.files=sample();self.files['ldap-ca.crt']=self.ca
        stack=ExitStack();self.addCleanup(stack.close)
        for owner,name in ((socket,'getaddrinfo'),(socket,'create_connection'),(socket.socket,'connect')):
            stack.enter_context(patch.object(owner,name,side_effect=AssertionError('Preparation must stay offline')))

    def bundle(self):return setup.export(self.v,self.files,reviewed=True)

    def test_export_regenerates_closed_configuration_without_secrets_or_network(self):
        result=setup.read_bundle(self.bundle())
        self.assertEqual(result['environment']['ALBERT_MODEL'],'gemma-4-31b-it')
        policy=json.loads(result['files']['access/policy.json']);self.assertEqual(policy['default'],'blocked');self.assertEqual(set(policy['indices'].values()),{'blocked'})
        access=json.loads(result['files']['config/access.json']);self.assertIs(access['allow_webui_assertions'],False);self.assertEqual(access['ldap']['host'],'ldap.site.test')
        self.assertFalse(any(name.startswith('secrets/') for name in result['files']))
        self.assertIn('Lancer validate', ' '.join(result['remaining']))

    def test_missing_values_files_and_review_are_actionable(self):
        with self.assertRaises(setup.PreparationError) as caught:setup.prepare(setup.defaults(),{})
        self.assertTrue(any('Revue' in item for item in caught.exception.issues));self.assertTrue(any('fichier à fournir' in item for item in caught.exception.issues))

    def test_common_external_configuration_errors_are_rejected_without_echo(self):
        for key,value in [('ldap_host','ldaps://ldap.site.test'),('ldap_port','70000'),('ldap_port','9'*6000),('runtime_image','registry/image:latest'),('opensearch_url','https://user:secret@search.site.test'),('albert_url','http://albert.site.test'),('admin_groups',self.v['internal_group']),('pdl_indices','site-*'),('albert_model','$(command)'),('tickets_visibility','public')]:
            with self.subTest(key=key),self.assertRaises(setup.PreparationError) as caught:setup.prepare({**self.v,key:value},self.files,reviewed=True)
            self.assertNotIn('user:secret',str(caught.exception))

    def test_upload_format_limits_private_keys_and_credentials_are_rejected(self):
        for name,raw in [('unknown.json',b'{}'),('ldap-ca.crt',b'not a certificate'),('ldap-ca.crt',b'-----BEGIN PRIVATE '+b'KEY-----'),('itsm-tickets.json',b'{"user_token":"do-not-upload"}'),('metric-mapping.json',b'[]'),('metric-mapping.json',b'{"scale":NaN}'),('metric-mapping.json',b'x'*(setup.MAX_FILE_BYTES+1))]:
            with self.subTest(name=name),self.assertRaises(setup.PreparationError):setup.uploaded(name,raw)
        self.assertEqual(setup.uploaded('ldap-ca.crt',self.ca),self.ca)

    def test_metric_semantics_and_inventory_use_runtime_validators(self):
        wrong=json.loads(self.files['metric-mapping.json']);wrong['metrics']['cpu']['scale']=-1
        with self.assertRaises(setup.PreparationError):setup.prepare(self.v,{**self.files,'metric-mapping.json':setup._json(wrong)},reviewed=True)
        wrong=json.loads(self.files['incidents-corpus.json']);wrong['hosts'][0]['allowed']=False
        with self.assertRaises(setup.PreparationError):setup.prepare(self.v,{**self.files,'incidents-corpus.json':setup._json(wrong)},reviewed=True)

    def test_conflicting_visibility_on_shared_index_is_rejected(self):
        with self.assertRaises(setup.PreparationError):setup.prepare({**self.v,'logs_index':'site-pfs','logs_visibility':'internal'},self.files,reviewed=True)

    def test_optional_oauth_reuses_exact_runtime_contract(self):
        self.v.update(oauth_issuer='https://pdl.site.test',pdl_resource='https://pdl.site.test/mcp',incidents_resource='https://incidents.site.test/gptoss/assistant/mcp',callbacks='http://127.0.0.1:8080/oauth/clients/mcp:dinum-pdl-agent/callback\nhttp://127.0.0.1:8080/oauth/clients/mcp:obs-gptoss/callback')
        self.assertIn('config/oauth-candidate.json',setup.read_bundle(self.bundle())['files'])
        self.assertNotIn('DINUM_OAUTH_CONFIG',setup.read_bundle(self.bundle())['environment'])
        self.v['callbacks']='https://evil.site.test/wildcard/*'
        with self.assertRaises(setup.PreparationError):self.bundle()

    def test_draft_roundtrip_and_unknown_or_secret_fields(self):
        self.assertEqual(setup.read_draft(setup.draft(self.v)),self.v)
        for raw in (b'[]',b'null',setup._json({'version':1,'values':{**self.v,'password':'secret'}})):
            with self.assertRaises(setup.PreparationError):setup.read_draft(raw)

    def test_corruption_traversal_symlink_and_duplicate_archives_are_rejected(self):
        for name,mode in [('../private.txt',0o100600),('config/ldap-ca.crt',0o120777),('connection-form.json',0o100600)]:
            buffer=io.BytesIO()
            with warnings.catch_warnings(),zipfile.ZipFile(io.BytesIO(self.bundle())) as original,zipfile.ZipFile(buffer,'w') as archive:
                warnings.simplefilter('ignore',UserWarning)
                for item in original.infolist():
                    if item.filename == name and mode == 0o120777:continue
                    archive.writestr(item,original.read(item.filename))
                entry=zipfile.ZipInfo(name);entry.external_attr=mode<<16;archive.writestr(entry,b'bad')
            with self.subTest(name=name),self.assertRaises(setup.PreparationError):setup.read_bundle(buffer.getvalue())
        with self.assertRaises(setup.PreparationError):setup.read_bundle(b'not a zip')

    def test_changed_configuration_is_refused_even_with_recomputed_manifest(self):
        with zipfile.ZipFile(io.BytesIO(self.bundle())) as archive:
            contents={item.filename:archive.read(item.filename) for item in archive.infolist()}
            metadata={item.filename:item for item in archive.infolist()}
        contents['config/access.json']=setup._json({'allow_webui_assertions':True})
        manifest=json.loads(contents['MANIFEST.json']);manifest['files']['config/access.json']=hashlib.sha256(contents['config/access.json']).hexdigest();contents['MANIFEST.json']=setup._json(manifest)
        buffer=io.BytesIO()
        with zipfile.ZipFile(buffer,'w') as archive:
            for name,raw in contents.items():archive.writestr(metadata[name],raw)
        with self.assertRaises(setup.PreparationError):setup.read_bundle(buffer.getvalue())

    def prepared_instance(self):
        folder=tempfile.TemporaryDirectory();self.addCleanup(folder.cleanup);base=Path(folder.name).resolve();instance=base/'instance'
        with redirect_stdout(io.StringIO()):manage.bootstrap(instance,'external')
        archive=base/'connection.zip';archive.write_bytes(self.bundle());archive.chmod(0o600)
        return instance,archive

    def test_host_import_preserves_generated_secrets_identity_and_private_permissions(self):
        instance,archive=self.prepared_instance();before={p.name:p.read_bytes() for p in (instance/'secrets').iterdir()};ident=manage.load(instance)['RIE_INSTANCE_ID']
        with patch.object(manage,'docker',side_effect=AssertionError('Import must not contact Docker')),redirect_stdout(io.StringIO()):manage.configure_connection(instance,manage.load(instance),archive)
        self.assertEqual(ident,manage.load(instance)['RIE_INSTANCE_ID']);self.assertEqual(before,{p.name:p.read_bytes() for p in (instance/'secrets').iterdir()})
        for p in instance.rglob('*'):self.assertEqual(p.stat().st_mode&0o777,0o700 if p.is_dir() else 0o600)
        (instance/'secrets/reader.password').write_text('test-only-reader')
        manage.validate_instance(instance,manage.load(instance))
        with self.assertRaises(ValueError):manage.configure_connection(instance,manage.load(instance),archive)

    def test_host_refuses_public_archive_or_prior_docker_binding_before_writes(self):
        instance,archive=self.prepared_instance();before={p.relative_to(instance):p.read_bytes() for p in instance.rglob('*') if p.is_file()}
        archive.chmod(0o644)
        with self.assertRaises(ValueError):manage.configure_connection(instance,manage.load(instance),archive)
        archive.chmod(0o600);(instance/'docker-id').write_text('existing-engine')
        with self.assertRaises(ValueError):manage.configure_connection(instance,manage.load(instance),archive)
        self.assertEqual(before,{p.relative_to(instance):p.read_bytes() for p in instance.rglob('*') if p.is_file() and p.name!='docker-id'})

    def test_failed_copy_rolls_back_all_prepared_files(self):
        instance,archive=self.prepared_instance();before={p.relative_to(instance):p.read_bytes() for p in instance.rglob('*') if p.is_file()};original=Path.replace
        def failure(path,target):
            if str(path).endswith('/config/access.json'):raise OSError('injected full disk')
            return original(path,target)
        with patch.object(Path,'replace',failure),self.assertRaises(OSError):manage.configure_connection(instance,manage.load(instance),archive)
        self.assertEqual(before,{p.relative_to(instance):p.read_bytes() for p in instance.rglob('*') if p.is_file()})

    def test_pre_ldap_launcher_has_no_instance_mount_or_ambient_secret(self):
        with patch.object(manage,'docker') as docker,redirect_stdout(io.StringIO()):manage.deployment_ui('registry.site.test/portal:qualified',18091)
        args=docker.call_args_list[1].args
        self.assertIn('127.0.0.1:18091:8090',args);self.assertIn('RIE_DEPLOYMENT_ONLY=true',args);self.assertNotIn('--volume',args);self.assertNotIn('--env-file',args)
        self.assertIn('--read-only',args);self.assertIn('never',args)
        with self.assertRaises(ValueError):manage.deployment_ui('$(command)',18091)
