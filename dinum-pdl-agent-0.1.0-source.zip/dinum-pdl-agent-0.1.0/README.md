# Moteur PDL V1 local

> **Déploiement RIE hors ligne :** le runtime conteneurisé, distinct de la
> démonstration Windows décrite ci-dessous, est documenté dans
> [`docs-rie/README.md`](docs-rie/README.md). Il fournit une image Linux amd64,
> un serveur MCP, l'administration minimale des mappings et un catalogue actif
> initialement vide.

Question française → Planner Albert → plan métier validé → orchestrateur → adapters → Evidence → préparation déterministe → synthèse Albert → critique.

Le préparateur calcule et explicite les totaux, unités, sommes par groupe, filtres, périodes et limites des preuves. Sa fiche est conservée dans `review.preparation`, avec une version et une empreinte des preuves. La synthèse, le critique et la correction reçoivent cette même fiche **avec les preuves originales**. Aucun appel LLM supplémentaire n'est nécessaire ; les erreurs, troncatures et écarts de comptage restent visibles. [Fonctionnement et recette](../recette/lot-02/PREPARATEUR.md).

La synthèse passe désormais par un **critique Albert séparé**, configurable via `ALBERT_CRITIC_MODEL` dans `agentic-pdl/.env`. La configuration finale utilise `gpt-oss-120b` pour le plan, la synthèse, la critique et l'éventuelle correction. Sans configuration de critique, le code utilise le modèle principal. Le critique reçoit la question, les preuves, leur évaluation, les conclusions de complétude calculées et le brouillon ; il n'a aucun outil ni accès supplémentaire aux sources.

Six contrôles sont obligatoires : chiffres/unités, périmètre, période, complétude, causalité et réponse à la question. Chaque problème doit nommer l'un de ces critères et rendre le contrôle correspondant non réussi. Le parseur réconcilie explicitement un éventuel désaccord et conserve cette normalisation dans `review.critique_normalizations`. Des gardes déterministes rejettent aussi deux contradictions connues : annoncer un TOP incomplet quand la preuve est complète, ou étendre un résultat filtré à tout le réseau. Un verdict accepté exige six contrôles réussis et aucun problème. Le critique utilise une température de 0 ; ce réglage n'apporte aucune garantie de justesse. Le rapport conserve les modèles, une empreinte des prompts et les contraintes calculées pour rendre les essais comparables.

Le verdict structuré vaut `accepted`, `correction_required` ou `insufficient_evidence`. Une seule correction de la synthèse est autorisée, suivie d'une nouvelle critique. Une erreur d'API, un JSON invalide, une référence de preuve inconnue ou un désaccord persistant laisse la réponse **non validée**. Le critique ne peut pas rendre valides des preuves en erreur. La validation concerne uniquement la fidélité aux preuves fournies ; elle ne certifie pas la réalité du SI ni l'absence d'erreur du modèle.

Une investigation habituelle consomme **3 appels Albert** (plan, synthèse, critique), **5 maximum** avec correction. Aucun appel supplémentaire n'est ajouté à `--no-synthesis` ou `--plan-only`. Le statut du critique est distinct de l'évaluation des preuves. Codes de sortie : 0 pour une exécution réussie, 2 pour des preuves en erreur/partielles/non exécutées, 3 pour une synthèse non validée avec preuves réussies ; les autres erreurs de CLI restent en code 1 ou celui d'argparse.

Les investigations avec synthèse créent automatiquement un rapport daté sous `artifacts/investigations/` si `--output` est absent. Un rapport existant est refusé. `review.attempts` conserve brouillon(s), critiques brutes et structurées ; `review.calls` conserve les phases, statuts et dates des appels de restitution. Le champ public `answer` reste vide tant que la réponse n'est pas validée. Chaque étape est sauvegardée avant l'appel suivant, même si cet appel échoue. Les rapports restent des preuves locales, pas un mécanisme de replanification.

Le moteur Python tourne nativement sous Windows. OpenSearch et OpenWebUI du premier POC restent en place. Une VM Linux locale, autorisée pour Zabbix, est stockée entièrement sur D:. Le lot 7 ajoute une interface MCP locale au moteur existant ; aucun Docker, WSL, LangChain, LiteLLM, RAG ou système multi-agents n'est installé par ce projet.

Les données sont **entièrement synthétiques**. Les mappings PFAING et BB sont des exemples réalistes, pas les mappings DINUM/PDL réels.

## Découverte versionnée des schémas

Le lot 11 ajoute un inventaire distinct du catalogue métier statique. Sa configuration administrée se trouve dans `registry/schema_discovery.yaml` et autorise uniquement le motif synthétique `pdl-*-test`. Le modèle ne peut ni modifier ce périmètre ni fournir un endpoint OpenSearch.

```powershell
# Quatrième index non standardisé, réservé à la recette :
..\prepare-schema-demo.ps1 -Version 1

# Inventaire sans appel distant :
..\discover-pdl-schemas.ps1 -NoAlbert

# Nouvelle version du mapping, puis proposition Albert candidate :
..\prepare-schema-demo.ps1 -Version 2
..\discover-pdl-schemas.ps1
```

Chaque passage lit `_mapping`, `_alias` et `_field_caps`, puis profile au maximum 12 champs agrégeables et cinq valeurs par champ. Les réponses sont limitées à 2 Mo, le nombre d’index à 20 et le nombre de champs à 500 par index. Les instantanés sont conservés dans `artifacts/schema-catalog/` avec une empreinte SHA-256 déterministe.

Albert reçoit uniquement les noms, types, capacités et valeurs synthétiques bornées. Sa sortie est validée contre les index, champs et concepts autorisés. Toutes les correspondances portent `status=candidate` et `approved=false`. Une erreur Albert n’annule pas l’inventaire technique et ne crée aucune connaissance approuvée. Le registre approuvé et la validation humaine sont prévus au lot 13.

Le quatrième index `pdl-edge-web-test` démontre l’adaptation sans modification du code d’inventaire. Sa version 1 contient notamment `gateway.label` et `policy.result`. Sa version 2 les remplace par `node.asset_name` et `decision`, et ajoute `network.transport`. Le comparateur marque alors l’index `stale` et conserve les champs ajoutés et supprimés.

## Boucle automatique d’hypothèses DSL

Le lot 12 utilise l’inventaire vivant du lot 11 pour tester au maximum cinq traductions concurrentes d’une question. Albert ne peut proposer qu’une intention commune et des correspondances `index + concept + champ` structurées. Il ne fournit jamais de DSL. Le validateur contrôle l’existence et le type des champs, leur capacité de recherche ou d’agrégation, les bornes temporelles, les valeurs profilées, la pertinence de la source et le budget. Le compilateur construit ensuite le DSL exact.

Cette étape est nécessaire parce qu’un modèle généraliste ne peut pas déduire de façon fiable la signification d’index non standardisés à partir du seul mapping technique. Les essais Agentic Search du lot 10 montrent des choix de champs variables et des conclusions erronées après un résultat vide. Le mapping sémantique relie donc les mots métier aux identifiants physiques ; le compilateur traduit ensuite ce mapping dans le langage natif de la source.

Le besoin vaut aussi hors OpenSearch. Grafana demande une datasource, une période, des métriques ou champs et le modèle de requête du plugin ; Zabbix demande des hôtes, items ou triggers et des méthodes JSON-RPC ; une base relationnelle demande tables, colonnes et SQL paramétré. La couche commune est le catalogue sémantique et ses validations. Chaque adapter possède ensuite son propre compilateur : DSL OpenSearch, requête Grafana, appel Zabbix, SQL ou contrat HTTP.

```powershell
..\run-hypothesis-loop.ps1 'Quels équipements edge ont le plus de décisions bloquées au cours des deux dernières heures ?'

# Rejeu déterministe sans appel Albert :
..\run-hypothesis-loop.ps1 'Quels équipements edge ont le plus de décisions bloquées au cours des deux dernières heures ?' `
  -Proposal 'tests\fixtures\hypothesis_edge_clear.json'
```

La configuration `registry/hypothesis_loop.yaml` limite la boucle à cinq essais, 20 documents, 10 groupes, une réponse de 1 Mo, 10 secondes par requête et 120 secondes au total. L’exécuteur ne sait appeler que `POST /<index autorisé>/_search`. Les résultats sont classés comme `invalid`, `error`, `empty`, `truncated` ou `exploitable`.

Le score combine validation technique, période, confiance de chaque concept, pertinence lexicale de l’index, présence de la valeur métier dans le profil borné, résultat quantitatif et contrôles négatifs. Un résultat non vide obtenu via un champ trop faible reste inéligible. Si deux hypothèses éligibles restent dans la marge de 0,08, le moteur s’abstient. Une recommandation porte toujours `status=candidate`, `approved=false` et `not_validated_by_expert` ; elle n’alimente aucun catalogue approuvé.

Les rapports sont conservés dans `artifacts/hypothesis-loops/`. Ils contiennent l’intention, chaque hypothèse, le DSL compilé, le résultat borné, les contrôles, le score, les motifs de rejet, le budget, le nombre d’appels Albert et les durées. Une fixture structurée suit exactement le même validateur, compilateur et exécuteur ; son coût indique explicitement zéro appel Albert.

## Utilisation

Depuis ce répertoire, après démarrage d'OpenSearch avec le script du premier POC :

```powershell
# Préparation commune explicite : 4 index synthétiques et capteurs Zabbix.
# OpenSearch et Zabbix doivent être disponibles ; aucun appel Albert.
..\prepare-demo.ps1 -Reset

.\run.ps1 'Combien de logs PFS refusés avons-nous sur les deux dernières heures ?'
.\run.ps1 'Quels équipements ont le plus de refus PFS sur les deux dernières heures ?'
.\run.ps1 'Les équipements avec le plus de refus PFS ont-ils aussi des événements BB sur les deux dernières heures ? Corrèle par équipement.' --output artifacts\investigation.json

# Sans Albert : plan déterministe pré-écrit.
.\run.ps1 --plan tests\expected\correlate.json --no-synthesis

# Inspection séparée : registre métier / vérification des mappings physiques.
.\run.ps1 --registry
.\run.ps1 --verify-catalog
```

`--plan-only` demande un plan à Albert puis le valide, sans requête de données. `--debug` ajoute la requête compilée au rapport local ; elle est retirée des preuves transmises à Albert. `--context` fournit un contexte métier explicite. `--output` sauvegarde le plan, les preuves, l'évaluation et la réponse. Les preuves sont écrites avant la synthèse, même si Albert devient indisponible.

Les paramètres Albert viennent de `../albert-openwebui-poc/.env` : `ALBERT_API_BASE_URL`, `ALBERT_MODEL`, `ALBERT_API_KEY`. Les paramètres Zabbix viennent de `agentic-pdl/.env`. Les variables d'environnement explicites ont priorité. Aucun secret n'est incorporé aux plans, aux tools ou aux rapports.

La CLI reste disponible et inchangée. Le Workspace Tool `pfs_search` du premier POC OpenWebUI reste utilisable séparément ; il ne représente pas cette orchestration multi-sources.

## Interface MCP contrôlée et assistant OpenWebUI unique

Depuis la racine du dépôt, après démarrage des sources :

```powershell
.\start-agentic-mcp.ps1
.\configure-controlled-demo.ps1
.\prepare-demo.ps1 -Reset
```

Le serveur écoute uniquement sur `http://127.0.0.1:9910/mcp` et expose un seul tool, `investigate_pdl`. Son entrée contient seulement une question métier de 2 000 caractères maximum. Le chat ne peut fournir ni DSL, ni index, ni champ physique, ni URL. Le Planner produit un `InvestigationPlan` sémantique ; le moteur valide tout le plan avant le premier appel aux sources et réutilise directement les adapters OpenSearch et Zabbix. Après exécution, chaque preuve OpenSearch contient la requête exacte, un bloc prêt à coller dans Dev Tools et un lien local de reprise sans secret.

Le preset principal **Albert PDL** appelle le tool une fois et transmet `mode=automatic` ou `mode=supervised`. `assistant_service.py` route les sources connues vers le catalogue administré, réutilise les mappings approuvés compatibles avec l’empreinte du schéma, ou lance la boucle bornée du lot 12. Une source, une période ou un concept métier indéterminé produit une demande de précision sans requête. Le preset historique **Albert PDL — moteur contrôlé** reste disponible pour la démonstration pédagogique.

Une exécution contrôlée réussie consomme habituellement trois appels Albert internes : planification, synthèse et critique ; une correction porte le maximum à cinq. L’exploration d’un index découvert utilise un appel de proposition avant validation et compilation. Chaque appel est limité à 60 secondes et l'investigation à 180 secondes. Les autres limites restent celles du moteur : huit étapes, 31 jours pour OpenSearch, 7 jours pour Zabbix, cent lignes ou groupes par étape.

La page <http://127.0.0.1:8090/assistant> explique les routes et fournit le corpus de recette. Le contrat et les essais reproductibles sont documentés dans [recette/lot-14](../recette/lot-14/VALIDATION.md).

La sortie structurée distingue `complete`, `empty`, `truncated` et `source_error`. Elle contient le plan validé, les preuves normalisées, l'évaluation, le contrôle de la synthèse, le nombre d'appels Albert et un chemin `artifact`. Les rapports sont écrits sans secret dans `artifacts/mcp/` et apparaissent dans la page **Rapports** de NiceGUI. Si une preuve est en erreur, partielle ou non exécutée, aucune réponse métier n'est publiée. Une dépendance vide bloque sa descendante sans élargir la recherche.

```powershell
# Inventaire du serveur sans appel Albert
.\mcp-opensearch-demo\.venv\Scripts\python.exe -B .\agentic-pdl\mcp_probe.py

# Recette explicite PFS/Zabbix, avec appels Albert
.\mcp-opensearch-demo\.venv\Scripts\python.exe -B .\agentic-pdl\mcp_probe.py --question "Les équipements qui ont subi le plus de refus PFS au cours des deux dernières heures présentent-ils aussi des problèmes Zabbix ouverts créés pendant cette période ? Corrèle les résultats par équipement."

# Arrêt du serveur lancé par le dépôt
.\stop-agentic-mcp.ps1
```

## Sources et jeu de démonstration

| Capability | Stockage | Jeu initial |
|---|---|---|
| `logs.pfs` | `pdl-pfs-test` | 12 logs, dont 7 refus : FW-01=4, FW-02=2, FW-03=1 |
| `logs.pfaing` | `pdl-pfaing-test` | 13 accès Internet, dont 3 refus vers `blocked.example` et 3 pour l’IP de test `1.2.3.4` |
| `logs.bb` | `pdl-bb-test` | 8 événements d'équipements, dont 3 pour FW-01/FW-02 et 2 pour `abc` du 15 au 26 septembre 2026 |
| `monitoring.zabbix` | API de la VM locale | FW-01, FW-02, FW-03 ; CPU fictifs 95%, 88%, 20% |

`prepare-demo.ps1 -Reset` recrée les quatre index de démonstration, dont `pfs-logs-test` du premier POC. Il vérifie d'abord le cluster local et le périmètre des trois hôtes Zabbix ; il fait repasser leurs CPU synthétiques à 20%, attend la résolution des anciens problèmes, puis injecte 95/88/20 et attend deux nouveaux problèmes ouverts. Les identifiants des hôtes/capteurs/triggers restent stables. Les observations de récupération et problèmes résolus sont conservés dans l'historique ; ils ne sont pas des problèmes ouverts supplémentaires.

La préparation enregistre une référence UTC commune, une fenêtre de deux heures et les dates réellement observées. Rejouer la démo dans les **60 minutes** suivantes pour conserver tous les résultats de référence des questions « deux dernières heures ». Ensuite, relancer la préparation. Une erreur interrompt la préparation avec un rapport `failed` ; les écritures déjà réalisées ne sont pas annulées automatiquement. Corriger la cause puis rejouer avant de présenter.

Les rapports sont créés sans écrasement sous `artifacts/preparations/`, sur D:. `artifacts/prepare-latest.json` pointe sur le dernier état ; `artifacts/seed.json` reste la référence des tests OpenSearch déterministes. Un dossier de sortie existant est refusé. La préparation ne crée aucun hôte supplémentaire et n'est appelée ni par le moteur ni par le contrôle de santé. Le seed historique `tests/seed_demo.py --reset` ne prépare que les trois index du moteur ; il ne suffit donc pas pour la démo multi-sources.

`registry/semantic_catalog.yaml` porte les correspondances physiques et les valeurs métier reconnues : par exemple « refus » = `deny`. Un catalogue est administré, pas inventé par Albert. `_mapping` et `_field_caps` vérifient les types et la compatibilité des champs déclarés.

## VM Zabbix sur D:

Appliance officielle **Zabbix 7.4.14**, Rocky Linux 8.10, disque QCOW2 ; **QEMU 11.1.0**, 2 vCPU et 4 Gio de RAM. QEMU et le disque sont dans `.runtime/zabbix/` sur D:. La virtualisation matérielle est désactivée dans le firmware de cette machine ; QEMU utilise **TCG**, sans Hyper-V ni WSL. Le premier démarrage doit créer et remplir MySQL : il est beaucoup plus lent qu'une VM accélérée matériellement.

```powershell
# Installation déjà effectuée ; script conservé pour reproduction.
.\setup\install-zabbix-vm.ps1
.\setup\start-zabbix-vm.ps1

# Attendre la fin de l'initialisation de l'appliance, puis configurer les fixtures.
..\albert-openwebui-poc\.venv\Scripts\python.exe setup\configure_zabbix.py

# Arrêt propre (ACPI), sans service Windows.
..\albert-openwebui-poc\.venv\Scripts\python.exe setup\stop-zabbix-vm.py
```

Interface : <http://127.0.0.1:8081>. Utilisateur `Admin`, mot de passe généré dans `agentic-pdl/.env` après provisionnement. L'adapter utilise un token du compte dédié `pdl-reader`, limité au groupe synthétique et aux méthodes de lecture. Le script de provisionnement possède volontairement les droits d'écriture nécessaires pour créer ces fixtures ; il n'est jamais appelé par l'orchestrateur.
Le mot de passe système `root` de la VM installée a aussi été remplacé et conservé sous `ZABBIX_ROOT_PASSWORD` dans ce fichier local.

Les redirections QEMU sont liées exclusivement à `127.0.0.1` : 8081 vers le frontend, 2222 vers SSH ; QMP 4444 et console série 4445 restent locaux. Pas de bridge réseau. L'appliance utilise temporairement le port interne 8080 pendant son installation puis le port 80 ; seul le port final est redirigé. Une erreur API `replace_user` pendant le premier démarrage signifie que son initialisation n'est pas terminée.

Sources : [appliance Zabbix](https://www.zabbix.com/documentation/7.4/en/manual/appliance), [archive officielle 7.4.14](https://cdn.zabbix.com/zabbix/appliances/stable/7.4/7.4.14/), [QEMU Windows](https://www.qemu.org/download/), [binaire Windows référencé par QEMU](https://qemu.weilnetz.de/w64/2026/). L'installateur est extrait sans installation globale avec le 7-Zip déjà présent. SHA-256 de l'appliance et SHA-512 de QEMU sont vérifiés avant extraction.

## Contrats et limites

- Le Planner ne reçoit que des capabilities et concepts métier, jamais les mappings physiques, URLs, tokens ou syntaxes natives.
- `InvestigationPlan` interdit les propriétés inconnues, valide les types, les références, les projections et le graphe avant les appels de données.
- Les adapters implémentent `capabilities`, `validate`, `output_columns`, `compile`, `execute`, `normalize`. Zabbix a été ajouté par son adapter et son enregistrement dans `main.py` ; l'orchestrateur et les schémas communs restent génériques.
- OpenSearch : `search`, `count`, `aggregate` et `timeseries`. Un regroupement et une métrique `count` maximum ; 100 lignes/buckets, fenêtre de 31 jours maximum, timeout HTTP 10 s et timeout de recherche 3 s. TOP_N par comptage décroissant peut être approximatif sur plusieurs shards : les avertissements de la source sont conservés.
- Zabbix : `hosts`, `problems`, `metrics`. Jusqu'à 20 équipements et 100 résultats, 7 jours maximum, timeout 15 s par appel. `problems` couvre les problèmes encore ouverts créés dans la fenêtre ; `hosts` retourne la configuration actuelle, pas une preuve de disponibilité ; `metrics` lit les observations du capteur CPU synthétique déclaré. Aucun historique de problèmes résolus n'est promis.
- Le moteur n'accepte aucune requête native libre. Les adapters n'exposent que des méthodes de lecture autorisées. Les scripts sous `setup/` et le seed sont des opérations administratives explicites, hors runtime.
- Un input vide ne provoque pas une recherche sans filtre. Une dépendance en erreur ou partielle bloque ses descendants. Une sortie tronquée limite explicitement le périmètre de la corrélation.
- `metadata.total_unit` distingue événements, problèmes et observations. Pour un TOP_N, `total` compte les événements, tandis que les lignes représentent les groupes. Une limite de 10 n'impose pas l'existence de 10 équipements.
- `correlate` conserve les équipements de gauche sans correspondance ; `compare` compare les totaux ou les groupes ; `intersect` conserve les groupes communs. Une corrélation ne démontre pas une cause.
- L'évaluation signale les preuves limitées. La replanification automatique reste désactivée. Un plan invalide est rejeté, sans auto-réparation cachée.
- L'interface MCP applique en plus un budget de cinq appels Albert, un délai total de 180 secondes et une réponse structurée. Elle ne réduit ni ne contourne les limites de la CLI et des adapters.

Le compte Zabbix est limité côté serveur. OpenSearch reste sans authentification, conformément au premier POC, lié à localhost : la restriction de lecture est donc applicative et ne remplace pas des droits serveur dans un futur environnement réel.

## Revue humaine des mappings et des modèles DSL

Le lot 13 ajoute `schema_review.py`. Une session reprend la question, l’intention, tous les essais du rapport, l’empreinte du rapport et celle du schéma. L’expert choisit l’essai actif puis prend l’une des quatre décisions : valider, rejeter, corriger ou conserver l’incertitude. Un rejet ou une correction porte une qualification structurée (`index`, `field`, `canonical_value`, `period`, `aggregation`, `incomplete_result` ou `other`).

Une correction ne contient pas de DSL libre. Elle peut seulement ajuster l’index autorisé, les correspondances, les valeurs canoniques, la période ou le concept de regroupement. Le moteur revalide l’intention et tous les champs, compile le DSL puis exécute une recherche OpenSearch en lecture seule avec les mêmes limites que le lot 12. Le nombre de nouveaux essais ne peut pas dépasser le budget restant de la session.

```powershell
# Créer une session depuis le rapport de référence et ouvrir l’URL affichée.
.\prepare-schema-review.ps1

# Après une évolution des mappings, invalider les connaissances incompatibles.
.\refresh-approved-catalog.ps1

# Export explicite ; un fichier existant n’est jamais écrasé.
.\export-approved-catalog.ps1 -Output .\exports\catalogue-2026-09-23.json

# Révocation explicite d’une connaissance ; l’événement antérieur reste dans le journal.
.\revoke-approved-entry.ps1 -EntryId mapping-0123456789abcdef -Author noc.local -Reason 'Correction métier'
```

Le mapping et le modèle de requête sont approuvés séparément. Chaque entrée porte l’index, l’empreinte exacte du schéma, l’auteur local, la date, la session et la décision. La résolution d’un mapping exige une égalité exacte de l’empreinte. `refresh-approved-catalog.ps1` marque une entrée `stale` si l’index disparaît ou si son empreinte change. Révocations et invalidations sont des événements supplémentaires dans `approved-catalog-events.jsonl` ; elles ne réécrivent pas l’historique. Les sessions et le catalogue opérationnel restent dans `artifacts/` sur D: et sont exclus de Git.

La page NiceGUI <http://127.0.0.1:8090/schema-review> liste les sessions et les statuts. La page de détail montre types, correspondances, DSL, résultat et contrôles avant d’activer les décisions. Le journal de recette versionné est dans [recette/lot-13](../recette/lot-13/VALIDATION.md).

## Benchmark des évolutions de schéma

Le lot 15 ajoute un corpus indépendant de huit situations : schéma stable, nouvel index, champ renommé, champ supprimé, type modifié, alias déplacé, résultat vide et valeur plausible dans le mauvais champ. Le runner compare `automatic`, `supervised` et `approved_profile` sur 24 tentatives. Il mesure séparément exactitude technique, exactitude sémantique, couverture, abstentions correctes, profils périmés bloqués, erreurs acceptées, corrections humaines et appels Albert simulés.

```powershell
..\run-schema-evolution-benchmark.ps1
..\backup-approved-catalog.ps1
```

Le rapport porte `albert_mode=simulated_deterministic`. Cette simulation remplace uniquement la proposition du LLM lorsque le quota Albert est indisponible ; elle ne produit aucune approbation implicite. Les détails d’installation, de sauvegarde, de récupération et de transposition vers un PDL réel se trouvent dans [OPERATIONS_SCHEMA_EVOLUTION.md](OPERATIONS_SCHEMA_EVOLUTION.md). La synthèse présentateur est disponible sur <http://127.0.0.1:8090/benchmark>.

## Vérifications

```powershell
..\albert-openwebui-poc\.venv\Scripts\python.exe -B -m unittest tests.test_engine tests.test_zabbix tests.test_preparation tests.test_live_report tests.test_review tests.test_review_cli -v
..\albert-openwebui-poc\.venv\Scripts\python.exe -B -m unittest tests.test_schema_review -v
$env:PDL_LIVE_TESTS='1'
..\albert-openwebui-poc\.venv\Scripts\python.exe -m unittest tests.test_opensearch_live -v
$env:PDL_ZABBIX_LIVE_TESTS='1'
..\albert-openwebui-poc\.venv\Scripts\python.exe -m unittest tests.test_zabbix_live -v

# Vrais appels Albert : exécution explicite, consomme le quota API.
..\albert-openwebui-poc\.venv\Scripts\python.exe tests\run_albert_live.py
```

Les questions sont dans `tests/questions/scenarios.json` et les attentes indépendantes dans `tests/questions/reference.json`. Chaque recette Albert crée un dossier daté dans `artifacts/albert-runs/`, avec un `summary.json`, la préparation et les preuves de chaque scénario. `--output-dir <nouveau-dossier>` permet de choisir l'emplacement sans écraser une recette précédente. Le lanceur refuse les identifiants inconnus et une préparation trop ancienne avant les appels. Trois à cinq appels Albert sont nécessaires par scénario avec critique, avec une pause de 30 secondes entre scénarios.

Pour éprouver le critique sur des réponses enregistrées et des erreurs volontairement introduites, sans requête OpenSearch/Zabbix : `..\albert-openwebui-poc\.venv\Scripts\python.exe -B tests\run_critic_live.py --output-dir <nouveau-dossier>`. Ce test fait de vrais appels Albert ; ses preuves sont explicitement historiques.

Pour le jury expérimental de trois GPT-OSS : `..\albert-openwebui-poc\.venv\Scripts\python.exe -B tests\run_jury_live.py --output-dir <nouveau-dossier> --rounds 2`. Cette recette effectue jusqu'à 72 appels Albert sur douze réponses historiques, sans modifier le moteur. Elle s'arrête à la première erreur de transport/API ; `--resume-from <dossier-précédent>` permet une reprise explicite des seuls appels sans réponse, en conservant tout avis reçu. [Résultats et limites](../recette/lot-02/JURY.md).

Pour revérifier un rapport de jury à partir de ses sorties brutes enregistrées, sans nouvel appel Albert : `..\albert-openwebui-poc\.venv\Scripts\python.exe -B tests\revalidate_jury_report.py <dossier>`. L'outil applique le contrat et les gardes de la version courante, réécrit les votes structurés et indique toute normalisation.

Les assertions vérifient les comptes, le classement 4/2/1, les tranches temporelles, les corrélations et les ressources OpenSearch reproductibles. Elles ne garantissent pas à elles seules la qualité de chaque phrase générée : relire aussi les synthèses. Pour vérifier les neuf preuves sauvegardées sans appel Albert : `..\albert-openwebui-poc\.venv\Scripts\python.exe tests\verify_live_report.py <dossier-recette> --output <nouveau-rapport.json>`.
Le scénario Zabbix nécessite la VM configurée. Pour ne rejouer qu'un cas : `tests\run_albert_live.py pfs_count`, `tests\run_albert_live.py pfaing_ip`, `tests\run_albert_live.py bb_equipment_dates` ou `tests\run_albert_live.py zabbix_correlate`. Le corpus de généralisation OpenWebUI contient 15 formulations dans `tests/questions/generalization.json` et se rejoue avec `openwebui_generalization.py`. Le compte rendu de l'installation et des validations est dans [VALIDATION.md](VALIDATION.md).

Sur cette machine, les seuils de remplissage par défaut d'OpenSearch bloquaient la création des nouveaux index sur C:. `setup/configure-local-opensearch.ps1` conserve la protection disque et fixe des seuils absolus adaptés au POC : bas 2 Gio, haut 1 Gio, critique 512 Mio. Il ne fait pas partie du runtime de lecture.

`.env`, `.runtime/` (disques, téléchargements, logs), `artifacts/`, `.venv/` et caches Python sont exclus par `.gitignore`. Ne pas publier ces répertoires ni les clés.
