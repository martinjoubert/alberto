# Architecture technique

```mermaid
flowchart LR
  U[Utilisateur NOC] --> OW[OpenWebUI<br/>Albert PDL RIE]
  OW -->|investigate_pdl question| MCP[Agent MCP<br/>port 9910]
  MCP --> A[Albert API<br/>gpt-oss-120b]
  MCP --> C[Catalogue approuvé<br/>et empreintes]
  MCP --> O[OpenSearch PDL<br/>lecture seule]
  E[Expert] --> UI[NiceGUI administration<br/>port 8090]
  UI --> I[Inventaires et revues]
  UI --> C
  MCP -. désactivé initialement .-> Z[Zabbix JSON-RPC]
  MCP -. désactivé initialement .-> G[Grafana MCP officiel]
```

Le LLM ne reçoit pas un accès OpenSearch libre. Il produit une intention JSON à partir
des seuls champs inventoriés. Le compilateur déterministe transforme cette intention
en DSL, puis l'adapter limite l'index, la taille et les constructions acceptées.

```mermaid
sequenceDiagram
  actor N as NOC
  participant W as OpenWebUI
  participant M as Agent MCP
  participant A as Albert API
  participant O as OpenSearch
  participant H as Expert NiceGUI
  N->>W: Question en langage naturel
  W->>M: investigate_pdl(question)
  M->>A: Question + inventaire/catalogue borné
  A-->>M: Intention JSON, sans DSL
  M->>M: Validation + compilation DSL
  M->>O: _search en lecture seule
  O-->>M: Résultat et métadonnées
  alt mapping approuvé et empreinte inchangée
    M-->>W: success + preuves + DSL exact
  else mapping inconnu
    M->>M: Crée une revue, masque le résultat métier
    M-->>W: awaiting_human + URL de revue
    H->>M: Corrige ou approuve
    N->>W: Rejoue la question
    M-->>W: success après nouveau contrôle
  end
```

Le volume persistant contient inventaires, catalogue, revues, rapports et audit. Les
configurations, certificats et secrets sont trois montages distincts en lecture seule.

