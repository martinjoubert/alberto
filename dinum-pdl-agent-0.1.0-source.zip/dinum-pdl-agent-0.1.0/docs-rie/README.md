# Agent PDL conteneurisé — dossier de livraison RIE

Cette livraison installe uniquement l'agent Python. OpenSearch, OpenWebUI, Zabbix,
Grafana et Albert API restent les services déjà exploités dans le SI. La même image
`dinum/pdl-agent:0.1.0` exécute deux processus isolés : le serveur MCP sur `9910` et
l'administration minimale NiceGUI sur `8090`.

Ordre de lecture :

1. [Installation hors ligne](INSTALLATION_HORS_LIGNE.md)
2. [Configuration des sources et du TLS](CONFIGURATION.md)
3. [Architecture technique](ARCHITECTURE_TECHNIQUE.md)
4. [Adaptation et validation des mappings](MAPPINGS.md)
5. [Configuration et utilisation OpenWebUI](UTILISATION_OPENWEBUI.md)
6. [Exploitation, sauvegarde et évolution](EXPLOITATION.md)

Le démarrage est fermé par défaut : il exige au moins un motif d'index explicite.
Les modèles PFS, PFAING et Backbone livrés sont inactifs. Même si leurs champs
correspondent exactement, un expert doit les approuver dans NiceGUI.

