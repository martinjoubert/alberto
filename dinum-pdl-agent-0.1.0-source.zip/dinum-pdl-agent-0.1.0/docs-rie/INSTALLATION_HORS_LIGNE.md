# Installation hors ligne

## 1. Construire le bundle sur une machine connectée

Pré-requis : Docker avec le plugin Compose et une architecture capable de construire
une image Linux `amd64`.

```bash
cd agentic-pdl/deploy/rie
./build-offline-bundle.sh 0.1.0
```

Le script construit l'image en utilisateur non-root `10001:10001`, vérifie son
architecture, l'exporte avec `docker save` et produit `SHA256SUMS` et `MANIFEST.txt`.
Copier le répertoire `bundle/pdl-agent-0.1.0-linux-amd64` sur un support autorisé.

## 2. Préparer le bundle sur le RIE

Dans `deploy/` :

- copier `.env.example` vers `.env` et renseigner les URL ;
- remplacer `allowed_index_patterns: []` dans `config/config.yaml` ;
- déposer `rie-ca.pem` dans `certs/` ;
- créer les secrets requis dans `secrets/`, propriétaire `10001:10001` et droits `0400`.

Ne placer aucun secret dans `.env`, Compose ou le YAML.

## 3. Charger et démarrer sans téléchargement

```bash
chmod +x *.sh
./install-offline.sh
```

Le script contrôle toutes les sommes, exécute `docker load`, valide Compose et lance
`docker compose up --pull never -d`. Aucun registre ni dépôt Python n'est contacté.

## 4. Recette initiale OpenSearch seul

Ouvrir `http://hote-rie:8090`, rafraîchir l'inventaire et vérifier que seuls les
index autorisés apparaissent. Les modèles restent inactifs. Créer une revue,
inspecter champs, types et essais DSL, puis approuver explicitement. Enfin lancer :

```bash
./check.sh
```

Le endpoint `/readyz` ne répond `200` qu'après un inventaire réussi d'au moins un index.
