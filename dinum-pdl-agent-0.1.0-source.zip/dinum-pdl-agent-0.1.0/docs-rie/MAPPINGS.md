# Adaptation et validation des mappings

Les mappings PFS, PFAING et Backbone de la démonstration étaient corrects pour les
index synthétiques. Ils sont donc livrés comme **modèles initiaux inactifs**, sans les
noms `pdl-*-test`. Chaque modèle décrit des concepts et plusieurs champs candidats.

Au démarrage puis au plus toutes les 60 minutes, l'agent résout seulement les motifs
autorisés, lit mappings, aliases et `field_caps`, puis calcule une empreinte. NiceGUI
classe chaque correspondance : `compatible`, `missing`, `type_mismatch` ou `ambiguous`.

```mermaid
flowchart TD
  I[Inventaire réel] --> C{Comparaison au modèle}
  C -->|exact| R[Revue humaine obligatoire]
  C -->|renommé ou absent| K[Correction proposée puis revue]
  C -->|ambigu| K
  R --> A[Catalogue actif versionné]
  K --> T[Essai DSL en lecture seule]
  T --> R
  A --> H{Empreinte inchangée ?}
  H -->|oui| Q[Requête publiable]
  H -->|non| X[Approbation invalidée]
```

Pour une question sans mapping approuvé, Albert propose des champs parmi l'inventaire.
Le code vérifie existence, type, capacité de recherche et d'agrégation, compile et teste
le DSL, puis crée une revue. Le résultat de l'essai n'est pas publié. Après approbation,
le NOC rejoue la question. Toute évolution d'empreinte désactive automatiquement l'entrée.

