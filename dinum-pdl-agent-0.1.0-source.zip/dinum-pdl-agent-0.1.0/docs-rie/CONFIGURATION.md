# Configuration des sources, certificats et secrets

La configuration est montée en lecture seule dans `/config/config.yaml`. Les valeurs
`${NOM}` sont développées depuis l'environnement Compose. Les secrets sont lus dans
des fichiers distincts sous `/run/secrets`.

## OpenSearch

OpenSearch est activé pour la première recette. Le compte doit disposer uniquement de
`resolve index`, `get mapping`, `field caps`, `get aliases` et `search` sur les motifs
autorisés. L'agent refuse les index hors liste, les scripts, les runtime fields et les
opérations d'écriture. Utiliser des motifs étroits comme `logs-pfs-rie-*`, jamais `*`.

## Albert API

Configurer l'URL compatible Chat Completions, monter la clé dans
`/run/secrets/albert_api_key` et conserver `gpt-oss-120b` avec température zéro.
Albert propose une intention et des correspondances ; le code contrôle les champs et
compile lui-même le DSL.

## TLS

Monter l'autorité du RIE dans `/certs/rie-ca.pem`. Pour du TLS mutuel, renseigner
`client_cert_file` et `client_key_file`. `verify: false` est réservé à un diagnostic
temporaire et ne doit pas être livré.

## Zabbix et Grafana

Ils sont implémentés mais `enabled: false`. Zabbix n'autorise que `host.get`,
`problem.get`, `trigger.get`, `item.get` et `history.get`. Grafana appelle le serveur
MCP officiel avec une liste fermée d'outils de lecture. Leur activation fait l'objet
d'une recette séparée après celle d'OpenSearch.

