# Configuration et utilisation OpenWebUI

## Configuration automatique idempotente

Depuis l'image chargée, avec un fichier contenant le mot de passe administrateur :

```bash
docker run --rm --network host \
  -v "$PWD/openwebui-admin-password:/run/secrets/owui:ro" \
  -v "$PWD/deploy/certs:/certs:ro" \
  dinum/pdl-agent:0.1.0 python -m rie_agent.openwebui_setup \
  --url https://openwebui.rie --email admin@rie.local \
  --password-file /run/secrets/owui \
  --mcp-url http://pdl-agent.rie:9910/mcp --ca-file /certs/rie-ca.pem
```

Le script vérifie que le serveur expose exactement `investigate_pdl`, conserve les
autres connexions OpenWebUI et crée ou met à jour `Albert PDL RIE` avec
`gpt-oss-120b`, température zéro et appels natifs.

## Configuration manuelle

Dans l'administration OpenWebUI, ajouter un serveur MCP HTTP à l'URL `/mcp`. Filtrer
les fonctions sur `investigate_pdl`. Créer ensuite un modèle basé sur `gpt-oss-120b`,
température `0`, function calling `native`, sans outil intégré ni autre tool server.
Copier le system prompt de `rie_agent/openwebui_setup.py`.

## Comportement attendu

- `success` : afficher preuves, DSL exact, limites et rapport ;
- `awaiting_human` : ouvrir `review_url`, ne publier aucun résultat métier ;
- `needs_clarification` : répondre à la seule question demandée ;
- `error` : transmettre l'erreur à l'exploitant.

Les questions sont toujours formulées en langage naturel. L'utilisateur ne fournit ni
index, ni champ, ni DSL à l'outil MCP.

