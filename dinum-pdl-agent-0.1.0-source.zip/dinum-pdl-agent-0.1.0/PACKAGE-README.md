# DINUM PDL Agent 0.1.0 — source RIE

Cette archive contient le runtime Python, Dockerfile, Compose, scripts hors ligne,
configuration exemple, tests et documentation du lot 18. Elle ne contient aucun
secret, certificat réel, service tiers ni image Docker exportée.

Commencer par `docs-rie/README.md`. Sur une machine connectée disposant de Docker,
exécuter `bash deploy/rie/build-offline-bundle.sh 0.1.0` pour produire le bundle
Linux amd64 avec l'image exportée par `docker save`.
