"""Tests hors ligne du runtime RIE."""
