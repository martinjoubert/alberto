from __future__ import annotations

from pathlib import Path
import shutil
import unittest
import yaml

from rie_agent.adapters import GrafanaMCPReadOnlyAdapter, ZabbixReadOnlyAdapter
from rie_agent.config import AlbertConfig, Settings, SourceConfig
from rie_agent.inventory import OpenSearchInventory, compare_template, load_templates
from rie_agent.config import load_settings
from rie_agent.openwebui_setup import configure
from rie_agent.opensearch import ReadOnlyOpenSearch
from rie_agent.service import RIEAgentService
from rie_agent.store import Store


def settings(root: Path) -> Settings:
    disabled = SourceConfig(False, 'https://disabled.invalid')
    return Settings(root, ('rie-*',), 3600, 'http://admin:8090', '127.0.0.1', 9910,
                    '127.0.0.1', 8090, AlbertConfig('https://albert.invalid/v1', 'gpt-oss-120b',
                    str(root / 'albert.key')), SourceConfig(True, 'https://opensearch.invalid'), disabled, disabled)


def field(kind, searchable=True, aggregatable=True):
    return {'type': kind, 'types': [kind], 'searchable': searchable, 'aggregatable': aggregatable}


PFS_FIELDS = {
    '@timestamp': field('date'), 'observer.name': field('keyword'), 'source.ip': field('ip'),
    'destination.ip': field('ip'), 'observer.virtual_domain': field('keyword'),
    'rule.id': field('keyword'), 'rule.name': field('keyword'), 'event.action': field('keyword'),
    'action.name': field('keyword'), 'action.outcome': field('keyword'),
}

TEST_TMP = Path(__file__).resolve().parent / '.tmp'
TEST_TMP.mkdir(exist_ok=True)


def reset_root(name: str) -> Path:
    root = TEST_TMP / name
    if root.exists():
        shutil.rmtree(root)
    root.mkdir()
    return root


class MappingComparisonTests(unittest.TestCase):
    def setUp(self):
        self.template = next(item for item in load_templates() if item['id'] == 'pfs')

    def test_exact_mapping_is_compatible_but_inactive(self):
        result = compare_template(self.template, PFS_FIELDS, 'rie-pfs-2026')
        self.assertTrue(result['compatible'])
        self.assertFalse(result['active'])
        self.assertEqual(result['concepts']['action']['selected'], 'event.action')

    def test_renamed_missing_and_type_changed_are_rejected(self):
        renamed = {**PFS_FIELDS, 'observer.device': PFS_FIELDS['observer.name']}
        renamed.pop('observer.name')
        self.assertEqual(compare_template(self.template, renamed, 'x')['concepts']['equipment']['status'], 'missing')
        wrong = {**PFS_FIELDS, 'source.ip': field('keyword')}
        self.assertEqual(compare_template(self.template, wrong, 'x')['concepts']['source_ip']['status'], 'type_mismatch')
        missing = dict(PFS_FIELDS); missing.pop('@timestamp')
        self.assertEqual(compare_template(self.template, missing, 'x')['concepts']['timestamp']['status'], 'missing')

    def test_ambiguous_candidates_require_review(self):
        template = {'id': 'x', 'title': 'x', 'concepts': {'equipment': {
            'candidates': ['host.name', 'observer.name'], 'types': ['keyword']}}}
        fields = {'host.name': field('keyword'), 'observer.name': field('keyword')}
        result = compare_template(template, fields, 'rie-x')
        self.assertEqual(result['concepts']['equipment']['status'], 'ambiguous')
        self.assertFalse(result['compatible'])

    def test_three_reference_templates_match_their_validated_mappings(self):
        templates = {item['id']: item for item in load_templates()}
        pfaing = {'@timestamp': field('date'), 'observer.hostname': field('keyword'),
                   'client.ip': field('ip'), 'server.ip': field('ip'), 'url.domain': field('keyword'),
                   'url.original': field('keyword'), 'event.action': field('keyword')}
        backbone = {'@timestamp': field('date'), 'host.name': field('keyword'),
                    'event.code': field('keyword'), 'event.severity': field('long')}
        self.assertTrue(compare_template(templates['pfaing'], pfaing, 'rie-pfaing')['compatible'])
        self.assertTrue(compare_template(templates['backbone'], backbone, 'rie-bb')['compatible'])


class FakeInventory:
    def __init__(self, value): self.value = value
    def ensure_fresh(self): return self.value


class FakePlanner:
    def __init__(self, proposal): self.proposal = proposal
    def propose(self, question, inventory, approved): return self.proposal


class FakeSearch:
    def __init__(self): self.calls = []
    def search(self, index, body):
        self.calls.append((index, body))
        return {'timed_out': False, '_shards': {'failed': 0},
                'hits': {'total': {'value': 1, 'relation': 'eq'}, 'hits': [{'_id': '1', '_source': {'observer': {'name': 'FW-01'}}}]}}


class FakeResponse:
    status_code = 200
    def __init__(self, value): self.value = value
    def json(self): return self.value


class FakeInventorySession:
    def request(self, method, url, **kwargs):
        path = url.removeprefix('https://opensearch.invalid')
        if path.startswith('/_resolve/index/'):
            return FakeResponse({'indices': [{'name': 'rie-pfs-2026'}, {'name': 'outside-index'}]})
        if path.endswith('/_mapping'):
            return FakeResponse({'rie-pfs-2026': {'mappings': {'properties': {
                '@timestamp': {'type': 'date'}, 'observer': {'properties': {
                    'name': {'type': 'keyword'}, 'virtual_domain': {'type': 'keyword'}}},
                'source': {'properties': {'ip': {'type': 'ip'}}},
                'destination': {'properties': {'ip': {'type': 'ip'}}},
                'rule': {'properties': {'id': {'type': 'keyword'}, 'name': {'type': 'keyword'}}},
                'event': {'properties': {'action': {'type': 'keyword'}}},
                'action': {'properties': {'name': {'type': 'keyword'}, 'outcome': {'type': 'keyword'}}},
            }}}})
        if path.endswith('/_field_caps'):
            return FakeResponse({'fields': {name: {spec['type']: {
                'searchable': spec['searchable'], 'aggregatable': spec['aggregatable']}}
                for name, spec in PFS_FIELDS.items()}})
        if path.endswith('/_alias'):
            return FakeResponse({'rie-pfs-2026': {'aliases': {'pfs-current': {}}}})
        if path.endswith('/_search'):
            body = kwargs['json']
            return FakeResponse({'aggregations': {name: {'buckets': [{'key': 'sample', 'doc_count': 1}]}
                                                   for name in body['aggs']}})
        raise AssertionError((method, path))


class InventoryTests(unittest.TestCase):
    def test_refresh_stays_in_scope_profiles_values_and_keeps_template_inactive(self):
        root = reset_root('inventory')
        (root / 'albert.key').write_text('x', encoding='utf-8')
        store = Store(root)
        inventory = OpenSearchInventory(settings(root), store)
        inventory.session = FakeInventorySession()
        result = inventory.refresh()
        self.assertEqual(set(result['indices']), {'rie-pfs-2026'})
        entry = result['indices']['rie-pfs-2026']
        self.assertEqual(entry['aliases'], ['pfs-current'])
        self.assertTrue(entry['bounded_values'])
        self.assertTrue(entry['template_comparisons'][0]['compatible'])
        self.assertFalse(entry['template_comparisons'][0]['active'])
        self.assertEqual(store.catalog(), [])


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.root = reset_root('workflow')
        (self.root / 'albert.key').write_text('x', encoding='utf-8')
        self.settings = settings(self.root)
        self.inventory = {'created_at': '2026-09-24T00:00:00+00:00', 'indices': {'rie-pfs-2026': {
            'schema_hash': 'hash-v1', 'fields': PFS_FIELDS, 'aliases': [], 'template_comparisons': []}}}
        self.mapping = {'timestamp': {'field': '@timestamp', 'type': 'date'},
                        'equipment': {'field': 'observer.name', 'type': 'keyword'}}
        self.proposal = {'index': 'rie-pfs-2026', 'operation': 'search',
                         'time_range': {'gte': 'now-2h', 'lt': 'now'}, 'filters': [],
                         'group_by': None, 'select': ['equipment'], 'limit': 20,
                         'proposed_mapping': self.mapping, 'route_reason': 'PFS', 'clarification': None}

    def service(self):
        return RIEAgentService(self.settings, planner=FakePlanner(self.proposal),
                               inventory=FakeInventory(self.inventory), search=FakeSearch())

    def test_unknown_mapping_never_publishes_candidate_result(self):
        service = self.service()
        result = service.investigate('Montre les refus PFS')
        self.assertEqual(result['status'], 'awaiting_human')
        self.assertIsNone(result['evidence'])
        self.assertTrue(result['limits']['result_not_published'])
        self.assertIn('/reviews/', result['review_url'])

    def test_approval_allows_replay_and_schema_change_invalidates(self):
        service = self.service()
        first = service.investigate('Montre les refus PFS')
        review_id = first['review_url'].rsplit('/', 1)[1]
        service.store.approve(review_id, 'hash-v1')
        replay = service.investigate('Montre les refus PFS')
        self.assertEqual(replay['status'], 'success')
        self.assertEqual(replay['validation_level'], 'human_approved')
        self.assertEqual(replay['evidence']['total'], 1)
        invalidated = service.store.invalidate({'rie-pfs-2026': 'hash-v2'})
        self.assertTrue(invalidated)
        self.assertFalse(service.store.catalog()[0]['active'])

    def test_hypothesis_loop_records_rejected_and_valid_trials(self):
        proposal = {**self.proposal, 'hypotheses': [
            {'confidence': 0.9, 'proposed_mapping': {
                'timestamp': {'field': '@timestamp', 'type': 'date'},
                'equipment': {'field': 'observer.renamed', 'type': 'keyword'}}},
            {'confidence': 0.7, 'proposed_mapping': self.mapping},
        ]}
        service = RIEAgentService(self.settings, planner=FakePlanner(proposal),
                                  inventory=FakeInventory(self.inventory), search=FakeSearch())
        result = service.investigate('Montre les refus PFS')
        self.assertEqual(result['status'], 'awaiting_human')
        review = service.store.review(result['review_url'].rsplit('/', 1)[1])
        self.assertEqual([item['status'] for item in review['dsl_trials']], ['rejected', 'valid'])
        self.assertEqual(result['limits']['hypotheses_tested'], 2)


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.root = reset_root('security')
        (self.root / 'albert.key').write_text('x', encoding='utf-8')
        self.settings = settings(self.root)
        self.client = ReadOnlyOpenSearch(self.settings)

    def test_index_writes_and_scripts_are_rejected(self):
        with self.assertRaises(ValueError): self.client.validate_dsl('secret-index', {'size': 0, 'query': {'match_all': {}}})
        with self.assertRaises(ValueError): self.client.validate_dsl('rie-pfs', {'size': 0, 'script': {'source': 'x'}})
        with self.assertRaises(ValueError): self.client.validate_dsl('rie-pfs', {'size': 1000, 'query': {'match_all': {}}})

    def test_disabled_sources_and_grafana_allowlist(self):
        with self.assertRaises(RuntimeError): ZabbixReadOnlyAdapter(self.settings.zabbix).call('host.get', {})
        with self.assertRaises(ValueError): ZabbixReadOnlyAdapter(SourceConfig(True, 'https://z.invalid')).call('host.create', {})
        with self.assertRaises(ValueError): GrafanaMCPReadOnlyAdapter(
            SourceConfig(True, 'https://g.invalid', allowed_tools=('create_dashboard',)))


class ConfigurationAndDeliveryTests(unittest.TestCase):
    def test_empty_index_scope_is_refused(self):
        path = TEST_TMP / 'invalid-config.yaml'
        path.write_text('''
server: {}
storage: {data_dir: ./data}
discovery: {allowed_index_patterns: []}
albert: {url: https://a.invalid/v1, model: gpt-oss-120b, api_key_file: key}
sources:
  opensearch: {enabled: true, url: https://o.invalid}
  zabbix: {enabled: false, url: https://z.invalid}
  grafana: {enabled: false, url: https://g.invalid}
''', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, "motif d'index"):
            load_settings(path)

    def test_compose_contains_only_two_local_services(self):
        root = Path(__file__).resolve().parents[1]
        compose = yaml.safe_load((root / 'deploy/rie/compose.yaml').read_text(encoding='utf-8'))
        self.assertEqual(set(compose['services']), {'agent', 'admin'})
        for service in compose['services'].values():
            self.assertEqual(service['image'], 'dinum/pdl-agent:0.1.0')
            self.assertEqual(service['pull_policy'], 'never')
            self.assertEqual(service['user'], '10001:10001')
            self.assertTrue(service['read_only'])
        dockerfile = (root / 'Dockerfile').read_text(encoding='utf-8')
        self.assertIn('USER 10001:10001', dockerfile)
        self.assertIn('mcp==2.2.0', (root / 'requirements-rie.lock.txt').read_text(encoding='utf-8'))

    def test_documentation_contains_mermaid_and_offline_commands(self):
        root = Path(__file__).resolve().parents[1]
        architecture = (root / 'docs-rie/ARCHITECTURE_TECHNIQUE.md').read_text(encoding='utf-8')
        install = (root / 'docs-rie/INSTALLATION_HORS_LIGNE.md').read_text(encoding='utf-8')
        self.assertGreaterEqual(architecture.count('```mermaid'), 2)
        self.assertIn('docker load', install)
        self.assertIn('--pull never', install)


class FakeOpenWebUI:
    def __init__(self): self.calls = []
    def request(self, path, method='GET', token=None, payload=None):
        self.calls.append((path, method, payload))
        if path == '/api/v1/auths/signin': return {'token': 'token'}
        if path == '/api/v1/configs/tool_servers/verify': return {'specs': [{'name': 'investigate_pdl'}]}
        if path == '/api/v1/configs/tool_servers': return {'TOOL_SERVER_CONNECTIONS': []}
        if path == '/api/models': return {'data': [{'id': 'gpt-oss-120b'}]}
        if path.startswith('/api/v1/models/model?'): raise RuntimeError('OpenWebUI HTTP 404')
        if path == '/api/v1/models/create': return {'id': 'albert-pdl-rie'}
        return {}


class OpenWebUISetupTests(unittest.TestCase):
    def test_preset_has_one_tool_native_calls_and_zero_temperature(self):
        client = FakeOpenWebUI()
        result = configure(client, 'admin@example.test', 'secret', 'http://agent:9910/mcp')
        self.assertEqual(result['tools'], ['investigate_pdl'])
        connection = next(payload for path, method, payload in client.calls
                          if path == '/api/v1/configs/tool_servers' and method == 'POST')['TOOL_SERVER_CONNECTIONS'][0]
        self.assertEqual(connection['config']['function_name_filter_list'], 'investigate_pdl')
        preset = next(payload for path, method, payload in client.calls if path == '/api/v1/models/create')
        self.assertEqual(preset['base_model_id'], 'gpt-oss-120b')
        self.assertEqual(preset['params']['temperature'], 0)
        self.assertEqual(preset['params']['function_calling'], 'native')
        self.assertEqual(preset['meta']['toolIds'], ['server:mcp:dinum-pdl-agent'])


if __name__ == '__main__':
    unittest.main()
