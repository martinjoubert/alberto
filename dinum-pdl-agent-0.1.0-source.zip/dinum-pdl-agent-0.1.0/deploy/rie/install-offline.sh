#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
sha256sum --check SHA256SUMS
IMAGE_TAR="$(find . -maxdepth 1 -name 'pdl-agent-*.tar' -print -quit)"
test -n "$IMAGE_TAR"
docker load --input "$IMAGE_TAR"
mkdir -p deploy/config deploy/certs deploy/secrets
test -f deploy/.env || cp deploy/.env.example deploy/.env
IMAGE="$(sed -n 's/^image=//p' MANIFEST.txt)"
test -n "$IMAGE"
docker run --rm --env-file deploy/.env -e PDL_CONFIG=/config/config.yaml \
  -v "$ROOT/deploy/config:/config:ro" "$IMAGE" \
  python -c 'from rie_agent.config import load_settings; load_settings(); print("Configuration valide")'
(cd deploy && docker compose config --quiet && docker compose up --pull never -d)
"$ROOT/check.sh"
