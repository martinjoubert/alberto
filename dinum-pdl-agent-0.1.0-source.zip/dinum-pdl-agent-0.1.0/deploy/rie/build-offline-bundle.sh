#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd -- "$SCRIPT_DIR/../.." && pwd)"
VERSION="${1:-0.1.0}"
IMAGE="dinum/pdl-agent:${VERSION}"
BUNDLE="$SCRIPT_DIR/bundle/pdl-agent-${VERSION}-linux-amd64"
rm -rf -- "$BUNDLE"
mkdir -p -- "$BUNDLE/deploy/config" "$BUNDLE/deploy/certs" "$BUNDLE/deploy/secrets" "$BUNDLE/docs"
docker build --platform linux/amd64 --build-arg "APP_VERSION=$VERSION" -t "$IMAGE" "$PROJECT_DIR"
docker image inspect "$IMAGE" --format '{{.Architecture}} {{.Config.User}}' | grep -qx 'amd64 10001:10001'
docker save --output "$BUNDLE/pdl-agent-${VERSION}.tar" "$IMAGE"
cp "$SCRIPT_DIR/compose.yaml" "$SCRIPT_DIR/.env.example" "$BUNDLE/deploy/"
cp "$SCRIPT_DIR/config/config.yaml" "$BUNDLE/deploy/config/"
cp "$SCRIPT_DIR/certs/README.md" "$BUNDLE/deploy/certs/"
cp "$SCRIPT_DIR/secrets/README.md" "$BUNDLE/deploy/secrets/"
cp "$SCRIPT_DIR"/{install-offline.sh,check.sh,backup.sh,restore.sh,update.sh} "$BUNDLE/"
cp "$PROJECT_DIR"/docs-rie/*.md "$BUNDLE/docs/"
if [ "$VERSION" != "0.1.0" ]; then
  sed -i "s#dinum/pdl-agent:0.1.0#dinum/pdl-agent:${VERSION}#g" \
    "$BUNDLE/deploy/compose.yaml" "$BUNDLE"/{check.sh,backup.sh,restore.sh}
fi
(
  cd "$BUNDLE"
  find . -type f ! -name SHA256SUMS ! -name MANIFEST.txt -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  {
    echo "image=$IMAGE"
    echo "platform=linux/amd64"
    echo "built_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    docker image inspect "$IMAGE" --format 'image_id={{.Id}}'
  } > MANIFEST.txt
  sha256sum MANIFEST.txt >> SHA256SUMS
)
echo "Bundle créé : $BUNDLE"
