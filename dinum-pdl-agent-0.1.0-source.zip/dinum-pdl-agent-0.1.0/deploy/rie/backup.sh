#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEST="${1:-$ROOT/backups}"
mkdir -p "$DEST"
(cd "$ROOT/deploy" && docker compose stop agent admin)
docker run --rm --user 10001:10001 -v dinum-pdl-agent_pdl-data:/data:ro -v "$DEST:/backup" \
  dinum/pdl-agent:0.1.0 python -m rie_agent.maintenance backup
(cd "$ROOT/deploy" && docker compose up --pull never -d)
