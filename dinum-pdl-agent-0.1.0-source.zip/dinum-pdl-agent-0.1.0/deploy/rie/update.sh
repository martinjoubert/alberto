#!/usr/bin/env bash
set -euo pipefail
test $# -eq 1 || { echo "Usage: $0 nouveau-bundle" >&2; exit 2; }
NEW="$(cd -- "$1" && pwd)"
(cd "$NEW" && sha256sum --check SHA256SUMS)
IMAGE_TAR="$(find "$NEW" -maxdepth 1 -name 'pdl-agent-*.tar' -print -quit)"
docker load --input "$IMAGE_TAR"
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cp "$NEW/deploy/compose.yaml" "$ROOT/deploy/compose.yaml"
cp "$NEW"/{check.sh,backup.sh,restore.sh,update.sh} "$ROOT/"
(cd "$ROOT/deploy" && docker compose up --pull never -d)
"$ROOT/check.sh"
