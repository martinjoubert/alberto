#!/usr/bin/env bash
set -euo pipefail
test $# -eq 1 || { echo "Usage: $0 sauvegarde.zip" >&2; exit 2; }
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE="$(cd -- "$(dirname -- "$1")" && pwd)/$(basename -- "$1")"
(cd "$ROOT/deploy" && docker compose down)
docker volume rm dinum-pdl-agent_pdl-data 2>/dev/null || true
docker volume create dinum-pdl-agent_pdl-data >/dev/null
docker run --rm --user 10001:10001 -v dinum-pdl-agent_pdl-data:/data -v "$(dirname "$SOURCE"):/backup:ro" \
  dinum/pdl-agent:0.1.0 python -m rie_agent.maintenance restore --source "/backup/$(basename "$SOURCE")"
(cd "$ROOT/deploy" && docker compose up --pull never -d)
