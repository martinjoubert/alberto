#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT/deploy"
docker compose ps
test "$(docker image inspect dinum/pdl-agent:0.1.0 --format '{{.Architecture}} {{.Config.User}}')" = "amd64 10001:10001"
curl --fail --silent --show-error http://127.0.0.1:9910/healthz
curl --fail --silent --show-error http://127.0.0.1:9910/readyz
curl --fail --silent --show-error http://127.0.0.1:8090/healthz
echo "Contrôle RIE terminé."
