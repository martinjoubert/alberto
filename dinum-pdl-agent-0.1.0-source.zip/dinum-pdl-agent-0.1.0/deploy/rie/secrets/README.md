# Secrets attendus

Créer ici les fichiers nécessaires, avec le propriétaire numérique `10001:10001`
et les droits `0400` afin que le conteneur non-root puisse les lire :

- `albert_api_key` ;
- `opensearch_password` ;
- `zabbix_token` uniquement avant activation de Zabbix ;
- `grafana_mcp_token` uniquement avant activation de Grafana.

Ne jamais ajouter leur contenu dans Git, Compose ou `config.yaml`.
