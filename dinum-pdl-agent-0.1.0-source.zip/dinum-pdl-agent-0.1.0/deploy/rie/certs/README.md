# Certificats attendus

Déposer la chaîne de confiance du RIE dans `rie-ca.pem`. Si une source exige un
certificat client, monter également son certificat et sa clé puis renseigner les
chemins `client_cert_file` et `client_key_file` dans `config/config.yaml`.

