from __future__ import annotations

from typing import Annotated, Any

from mcp.server.mcpserver import MCPServer
from pydantic import Field
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route
import uvicorn

from .config import load_settings
from .service import RIEAgentService


INSTRUCTIONS = """Serveur MCP de lecture du PDL. Un seul outil reçoit une question métier.
Il retourne le plan validé, les preuves, le DSL exact et le lien de revue. Un résultat awaiting_human
ne contient jamais de réponse métier publiable. Aucun index, champ ou DSL libre n'est accepté en entrée."""

settings = load_settings()
service = RIEAgentService(settings)
server = MCPServer(name="dinum-pdl-agent", title="Agent PDL RIE", description="Traduction contrôlée des questions PDL.",
                   instructions=INSTRUCTIONS, version="0.1.0", log_level="INFO")


@server.tool(name="investigate_pdl", title="Investiguer le PDL", structured_output=True,
             description="Traduit une question métier, exécute uniquement des lectures approuvées et renvoie preuves et DSL.")
def investigate_pdl(question: Annotated[str, Field(min_length=1, max_length=2000)]) -> dict[str, Any]:
    return service.investigate(question)


async def healthz(_: Request) -> JSONResponse:
    return JSONResponse(service.health())


async def readyz(_: Request) -> JSONResponse:
    body, status = service.readiness()
    return JSONResponse(body, status_code=status)


def create_app():
    app = server.streamable_http_app(streamable_http_path="/mcp", json_response=True, stateless_http=True,
                                     max_request_body_size=16_384, max_sessions=50,
                                     session_idle_timeout=120, host=settings.mcp_host)
    app.routes.extend([Route("/healthz", healthz), Route("/readyz", readyz)])
    return app


def main() -> None:
    try:
        service.inventory_service.refresh()
    except Exception as exc:
        service.store.audit("startup.inventory_failed", {"type": type(exc).__name__, "message": str(exc)[:500]})
    uvicorn.run(create_app(), host=settings.mcp_host, port=settings.mcp_port, log_level="info")


if __name__ == "__main__":
    main()

