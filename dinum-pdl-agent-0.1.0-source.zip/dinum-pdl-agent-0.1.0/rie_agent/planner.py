from __future__ import annotations

import json
from typing import Any

from .config import Settings
from .http import session_for


SYSTEM = """Tu traduis une question métier PDL en intention JSON bornée.
Tu n'écris jamais de DSL OpenSearch. Tu choisis exclusivement un index et des champs présents dans le contexte.
Si un catalogue approuvé est fourni, utilise ses concepts sans changer leur sens. Sinon propose une correspondance
concept -> champ physique qui devra être approuvée par un humain. Opérations autorisées: search, count, aggregate.
Opérateurs autorisés: eq, in, exists. Période maximale: 31 jours. Réponds uniquement avec un objet JSON:
{"source":"opensearch|zabbix|grafana","index":"...","operation":"search|count|aggregate","time_range":{"gte":"...","lt":"..."},
"filters":[{"concept":"...","operator":"eq","value":"..."}],"group_by":null,
"select":[],"limit":20,"proposed_mapping":{"timestamp":{"field":"@timestamp","type":"date"},...},
"external_call":{"name":"méthode ou outil autorisé","arguments":{}},
"route_reason":"...","clarification":null,"hypotheses":[]} Le proposed_mapping est vide si un catalogue approuvé
est utilisé. Pour un schéma sans catalogue approuvé, hypotheses peut contenir jusqu'à cinq objets de même forme,
ordonnés du plus plausible au moins plausible, avec confidence entre 0 et 1.
Si la question est réellement ambiguë, renseigne clarification et ne suppose pas de source."""


def _json_object(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1].rsplit("```", 1)[0]
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError("Albert n'a pas renvoyé un objet JSON.")
    return value


class AlbertPlanner:
    def __init__(self, settings: Settings):
        self.settings, self.config = settings, settings.albert
        self.session = session_for(self.config.tls, bearer=self.config.api_key)

    def propose(self, question: str, inventory: dict, approved: list[dict]) -> dict:
        safe_inventory = {name: {"fields": item["fields"], "aliases": item.get("aliases", []),
                                 "bounded_values": item.get("bounded_values", {})}
                          for name, item in inventory.get("indices", {}).items()}
        active_sources = ["opensearch"]
        if self.settings.zabbix.enabled:
            active_sources.append("zabbix")
        if self.settings.grafana.enabled:
            active_sources.append("grafana")
        context = {"question": question, "active_sources": active_sources,
                   "approved_catalog": approved, "inventory": safe_inventory}
        response = self.session.post(
            self.config.url.rstrip("/") + "/chat/completions",
            json={"model": self.config.model, "temperature": 0, "response_format": {"type": "json_object"},
                  "messages": [{"role": "system", "content": SYSTEM},
                               {"role": "user", "content": json.dumps(context, ensure_ascii=False)}]},
            timeout=60, allow_redirects=False,
        )
        if response.status_code != 200:
            raise RuntimeError(f"Albert API indisponible : HTTP {response.status_code}")
        return _json_object(response.json()["choices"][0]["message"]["content"])


def validate_proposal(proposal: dict, inventory: dict, approved: list[dict]) -> tuple[dict | None, dict]:
    if proposal.get("clarification"):
        return None, proposal
    index = proposal.get("index")
    entry = inventory.get("indices", {}).get(index)
    if not entry:
        raise ValueError("Albert a sélectionné un index absent de l'inventaire autorisé.")
    active = next((item for item in approved if item.get("active") and item["index"] == index and
                   item["schema_hash"] == entry["schema_hash"]), None)
    mapping = active["concepts"] if active else proposal.get("proposed_mapping")
    if not isinstance(mapping, dict) or "timestamp" not in mapping:
        raise ValueError("La proposition ne contient pas de mapping temporel exploitable.")
    for concept, spec in mapping.items():
        if not isinstance(spec, dict) or set(spec) - {"field", "type", "values"}:
            raise ValueError(f"Mapping invalide pour {concept}.")
        field = spec.get("field")
        discovered = entry["fields"].get(field)
        if not discovered or discovered["type"] != spec.get("type") or not discovered["searchable"]:
            raise ValueError(f"Champ proposé incompatible : {concept}/{field}.")
        if proposal.get("operation") == "aggregate" and concept == proposal.get("group_by") and not discovered["aggregatable"]:
            raise ValueError(f"Champ non agrégeable : {field}.")
    for criterion in proposal.get("filters", []):
        if criterion.get("concept") not in mapping:
            raise ValueError("Un filtre utilise un concept non validé.")
    return active, {**proposal, "mapping": mapping}
