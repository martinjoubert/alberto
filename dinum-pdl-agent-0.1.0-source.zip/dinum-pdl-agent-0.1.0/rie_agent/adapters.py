from __future__ import annotations

import asyncio
from typing import Any, Callable

from .config import SourceConfig
from .http import session_for


class ZabbixReadOnlyAdapter:
    ALLOWED = {"host.get", "problem.get", "trigger.get", "item.get", "history.get"}

    def __init__(self, config: SourceConfig):
        self.config, self.session = config, session_for(config)

    def call(self, method: str, params: dict) -> dict:
        if not self.config.enabled:
            raise RuntimeError("Zabbix est désactivé.")
        if method not in self.ALLOWED:
            raise ValueError("Méthode Zabbix interdite.")
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        if self.config.token:
            payload["auth"] = self.config.token
        response = self.session.post(self.config.url, json=payload, timeout=15, allow_redirects=False)
        if response.status_code != 200:
            raise RuntimeError(f"Zabbix indisponible : HTTP {response.status_code}")
        body = response.json()
        if "error" in body:
            raise RuntimeError("Zabbix a rejeté la lecture.")
        return body["result"]


class GrafanaMCPReadOnlyAdapter:
    SAFE_TOOLS = {"search_dashboards", "get_dashboard_summary", "get_dashboard_panel_queries",
                  "list_datasources", "check_datasources_health", "query_elasticsearch",
                  "generate_deeplink", "user_info"}

    def __init__(self, config: SourceConfig, caller: Callable[[str, dict], Any] | None = None):
        self.config, self._caller = config, caller
        configured = set(config.allowed_tools or self.SAFE_TOOLS)
        if not configured <= self.SAFE_TOOLS:
            raise ValueError("La liste Grafana contient un outil non autorisé.")
        self.allowed = configured

    async def _mcp_call(self, name: str, arguments: dict):
        import httpx2
        from mcp import ClientSession
        from mcp.client.streamable_http import streamable_http_client
        headers = {"Authorization": f"Bearer {self.config.token}"} if self.config.token else None
        tls = self.config.tls
        verify = tls.ca_file if tls.ca_file else tls.verify
        cert = ((tls.client_cert_file, tls.client_key_file) if tls.client_cert_file and tls.client_key_file
                else tls.client_cert_file)
        async with httpx2.AsyncClient(headers=headers, verify=verify, cert=cert, trust_env=False,
                                      timeout=15, follow_redirects=False) as client:
            async with streamable_http_client(self.config.url, http_client=client) as (read, write, _):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    return await session.call_tool(name, arguments)

    def call(self, name: str, arguments: dict) -> Any:
        if not self.config.enabled:
            raise RuntimeError("Grafana est désactivé.")
        if name not in self.allowed:
            raise ValueError("Outil Grafana interdit.")
        return self._caller(name, arguments) if self._caller else asyncio.run(self._mcp_call(name, arguments))
