from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import Settings, load_settings
from .adapters import GrafanaMCPReadOnlyAdapter, ZabbixReadOnlyAdapter
from .inventory import OpenSearchInventory
from .opensearch import ReadOnlyOpenSearch, compile_plan, summarize
from .planner import AlbertPlanner, validate_proposal
from .store import Store, now_iso


class RIEAgentService:
    def __init__(self, settings: Settings | None = None, *, planner=None, inventory=None, search=None,
                 zabbix=None, grafana=None):
        self.settings = settings or load_settings()
        self.store = Store(self.settings.data_dir)
        self.inventory_service = inventory or OpenSearchInventory(self.settings, self.store)
        self.search = search or ReadOnlyOpenSearch(self.settings)
        self.planner = planner or AlbertPlanner(self.settings)
        self.zabbix = zabbix or ZabbixReadOnlyAdapter(self.settings.zabbix)
        self.grafana = grafana or GrafanaMCPReadOnlyAdapter(self.settings.grafana)

    def health(self) -> dict:
        return {"status": "ok", "version": "0.1.0", "at": now_iso()}

    def readiness(self) -> tuple[dict, int]:
        inventory = self.store.inventory()
        ready = bool(self.settings.allowed_index_patterns and inventory.get("indices"))
        return ({"status": "ready" if ready else "not_ready", "inventory_at": inventory.get("created_at"),
                 "indices": len(inventory.get("indices", {})), "active_mappings": sum(
                     bool(item.get("active")) for item in self.store.catalog())}, 200 if ready else 503)

    def _persist_report(self, report: dict) -> str:
        name = now_iso().replace(":", "").replace("+00:00", "Z") + ".json"
        path = self.settings.data_dir / "reports" / name
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)

    def investigate(self, question: str) -> dict[str, Any]:
        question = question.strip()
        if not question or len(question) > 2000:
            return {"status": "error", "question": question, "route": None, "validation_level": "none",
                    "plan": None, "evidence": None, "dsl": None, "limits": {}, "review_url": None,
                    "report": None, "error": {"code": "invalid_question", "message": "Question vide ou trop longue."}}
        try:
            inventory = self.inventory_service.ensure_fresh()
            approved = self.store.catalog()
            proposal = self.planner.propose(question, inventory, approved)
            source = proposal.get("source", "opensearch")
            if source in {"zabbix", "grafana"}:
                if source == "zabbix" and not self.settings.zabbix.enabled:
                    raise ValueError("Source Zabbix non activée.")
                if source == "grafana" and not self.settings.grafana.enabled:
                    raise ValueError("Source Grafana non activée.")
                call = proposal.get("external_call") or {}
                evidence = (self.zabbix.call(call.get("name", ""), call.get("arguments") or {}) if source == "zabbix"
                            else self.grafana.call(call.get("name", ""), call.get("arguments") or {}))
                result = {"status": "success", "question": question, "route": source,
                          "validation_level": "adapter_allowlist", "plan": proposal, "evidence": evidence,
                          "dsl": None, "limits": {"source_enabled": True}, "review_url": None}
                result["report"] = self._persist_report(result)
                return result
            if source != "opensearch":
                raise ValueError("Source proposée inconnue ou non exposée.")
            hypotheses = proposal.get("hypotheses") or []
            if hypotheses:
                if not isinstance(hypotheses, list) or len(hypotheses) > 5:
                    raise ValueError("Nombre d'hypothèses hors limite.")
                attempts, valid = [], []
                root = {key: value for key, value in proposal.items() if key != "hypotheses"}
                for position, hypothesis in enumerate(hypotheses, 1):
                    candidate = {**root, **hypothesis, "source": "opensearch"}
                    try:
                        active_candidate, checked = validate_proposal(candidate, inventory, approved)
                        if valid and checked["index"] != valid[0][1]["index"]:
                            raise ValueError("Une session de revue ne peut pas mélanger plusieurs index.")
                        dsl = compile_plan(checked, {"concepts": checked["mapping"]}, self.settings)
                        raw = self.search.search(checked["index"], dsl)
                        summary = summarize(raw, checked["operation"])
                        attempt = {"position": position, "status": "valid", "confidence": hypothesis.get("confidence"),
                                   "dsl": dsl, "result_summary": summary}
                        attempts.append(attempt)
                        valid.append((active_candidate, checked, dsl, summary))
                    except Exception as exc:
                        attempts.append({"position": position, "status": "rejected", "confidence": hypothesis.get("confidence"),
                                         "error": {"type": type(exc).__name__, "message": str(exc)[:500]}})
                if not valid:
                    raise ValueError("Toutes les hypothèses de mapping ont été rejetées par les contrôles.")
                active, validated, body, evidence = valid[0]
                if not active:
                    candidates = [{"proposed_mapping": checked["mapping"],
                                   "plan": {key: value for key, value in checked.items() if key != "mapping"},
                                   "dsl": dsl, "result_summary": summary}
                                  for _, checked, dsl, summary in valid]
                    review = self.store.create_review({
                        "kind": "discovered_mapping", "question": question, "index": validated["index"],
                        "schema_hash": inventory["indices"][validated["index"]]["schema_hash"],
                        "proposed_mapping": validated["mapping"], "plan": candidates[0]["plan"],
                        "candidates": candidates, "dsl_trials": attempts,
                    })
                    result = {"status": "awaiting_human", "question": question, "route": validated["index"],
                              "validation_level": "candidate", "plan": review["plan"], "evidence": None,
                              "dsl": body, "limits": {"result_not_published": True, "hypotheses_tested": len(attempts)},
                              "review_url": f"{self.settings.public_admin_url}/reviews/{review['id']}"}
                    result["report"] = self._persist_report(result)
                    return result
                result = {"status": "success", "question": question, "route": validated["index"],
                          "validation_level": "human_approved", "plan": {key: value for key, value in validated.items() if key != "mapping"},
                          "evidence": evidence, "dsl": body, "limits": {"hypotheses_tested": len(attempts)}, "review_url": None}
                result["report"] = self._persist_report(result)
                return result
            active, validated = validate_proposal(proposal, inventory, approved)
            if validated.get("clarification"):
                result = {"status": "needs_clarification", "question": question, "route": None,
                          "clarification": validated["clarification"], "validation_level": "none",
                          "plan": None, "evidence": None, "dsl": None, "limits": {}, "review_url": None}
                result["report"] = self._persist_report(result)
                return result
            body = compile_plan(validated, {"concepts": validated["mapping"]}, self.settings)
            raw = self.search.search(validated["index"], body)
            evidence = summarize(raw, validated["operation"])
            if not active:
                review = self.store.create_review({
                    "kind": "discovered_mapping", "question": question, "index": validated["index"],
                    "schema_hash": inventory["indices"][validated["index"]]["schema_hash"],
                    "proposed_mapping": validated["mapping"], "plan": {key: value for key, value in validated.items() if key != "mapping"},
                    "dsl_trials": [{"dsl": body, "result_summary": evidence}],
                })
                result = {"status": "awaiting_human", "question": question, "route": validated["index"],
                          "validation_level": "candidate", "plan": review["plan"], "evidence": None,
                          "dsl": body, "limits": {"result_not_published": True},
                          "review_url": f"{self.settings.public_admin_url}/reviews/{review['id']}"}
            else:
                result = {"status": "success", "question": question, "route": validated["index"],
                          "validation_level": "human_approved", "plan": {key: value for key, value in validated.items() if key != "mapping"},
                          "evidence": evidence, "dsl": body, "limits": {"max_rows": self.settings.max_rows,
                          "max_buckets": self.settings.max_buckets}, "review_url": None}
            result["report"] = self._persist_report(result)
            return result
        except Exception as exc:
            self.store.audit("investigation.error", {"type": type(exc).__name__, "message": str(exc)[:500]})
            result = {"status": "error", "question": question, "route": None, "error": {
                "code": type(exc).__name__, "message": str(exc)[:500]}, "validation_level": "none",
                "plan": None, "evidence": None, "dsl": None, "limits": {}, "review_url": None}
            try:
                result["report"] = self._persist_report(result)
            except OSError:
                result["report"] = None
            return result
