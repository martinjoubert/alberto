from __future__ import annotations

import json

from nicegui import app, ui

from .config import load_settings
from .inventory import OpenSearchInventory
from .opensearch import ReadOnlyOpenSearch, compile_plan, summarize
from .store import Store


settings = load_settings()
store = Store(settings.data_dir)
inventory_service = OpenSearchInventory(settings, store)
search = ReadOnlyOpenSearch(settings)


def shell(title: str):
    ui.colors(primary='#000091', secondary='#6a6af4', accent='#e1000f')
    with ui.header().classes('items-center'):
        ui.label('Agent PDL — administration RIE').classes('text-h6')
        ui.space()
        for label, path in [('Inventaire', '/'), ('Revues', '/reviews'), ('Catalogue', '/catalog'), ('Audit', '/audit')]:
            ui.link(label, path).classes('text-white')
    ui.label(title).classes('text-h4 text-primary mt-6')
    ui.label("Interface réservée au réseau d'administration du RIE. Aucun secret n'est affiché.").classes('text-caption')


@app.get('/healthz')
def healthz():
    return {'status': 'ok', 'service': 'pdl-agent-admin'}


@ui.page('/')
def inventory_page():
    shell('Inventaire OpenSearch')
    status = ui.label()

    def refresh():
        try:
            value = inventory_service.refresh()
            status.set_text(f"Inventaire rafraîchi : {len(value['indices'])} index autorisé(s).")
            ui.navigate.reload()
        except Exception as exc:
            ui.notify(str(exc), type='negative')

    ui.button('Rafraîchir maintenant', on_click=refresh, icon='refresh')
    inventory = store.inventory()
    ui.label(f"Dernier inventaire : {inventory.get('created_at', 'jamais')}")
    for index, entry in inventory.get('indices', {}).items():
        with ui.expansion(index, icon='storage').classes('w-full'):
            ui.label(f"Empreinte : {entry['schema_hash']}").classes('font-mono text-xs')
            ui.label(f"{len(entry['fields'])} champs — alias : {', '.join(entry.get('aliases', [])) or 'aucun'}")
            for comparison in entry.get('template_comparisons', []):
                color = 'positive' if comparison['compatible'] else 'warning'
                with ui.card().classes('w-full'):
                    ui.label(f"Modèle initial : {comparison['title']}").classes(f'text-{color} font-bold')
                    rows = [{'concept': name, 'état': item['status'], 'champ': item.get('selected') or '—'}
                            for name, item in comparison['concepts'].items()]
                    ui.table(columns=[{'name': key, 'label': key.title(), 'field': key} for key in ('concept', 'état', 'champ')], rows=rows)
                    if comparison['compatible']:
                        def create_review(template_id=comparison['template_id'], selected_index=index):
                            review = inventory_service.review_for_template(template_id, selected_index)
                            ui.navigate.to(f"/reviews/{review['id']}")
                        ui.button('Créer une revue (sans activer)', on_click=create_review)


@ui.page('/reviews')
def reviews_page():
    shell('Sessions de revue')
    rows = [{'id': item['id'], 'type': item['kind'], 'index': item['index'], 'statut': item['status'],
             'créée': item['created_at']} for item in store.reviews()]
    table = ui.table(columns=[{'name': key, 'label': key.title(), 'field': key} for key in ('id', 'type', 'index', 'statut', 'créée')], rows=rows)
    table.on('rowClick', lambda event: ui.navigate.to(f"/reviews/{event.args[1]['id']}"))


@ui.page('/reviews/{review_id}')
def review_page(review_id: str):
    shell(f'Revue {review_id}')
    try:
        review = store.review(review_id)
    except (KeyError, ValueError):
        ui.label('Revue introuvable.').classes('text-negative')
        return
    ui.label(f"Index : {review['index']} — état : {review['status']}")
    ui.label(f"Empreinte : {review['schema_hash']}").classes('font-mono text-xs')
    ui.label("Mapping proposé").classes('text-h6')
    mapping_editor = ui.textarea(value=json.dumps(review['proposed_mapping'], ensure_ascii=False, indent=2)).props('outlined autogrow').classes('w-full font-mono')
    if review.get('dsl_trials'):
        ui.label('Essais DSL en lecture seule').classes('text-h6')
        ui.code(json.dumps(review['dsl_trials'], ensure_ascii=False, indent=2), language='json').classes('w-full')
    if review['status'] == 'pending':
        reason = ui.input('Motif du rejet').classes('w-full')

        def validated_mapping():
            mapping = json.loads(mapping_editor.value)
            entry = store.inventory()['indices'][review['index']]
            for concept, spec in mapping.items():
                field = entry['fields'].get(spec.get('field'))
                if not field or field['type'] != spec.get('type'):
                    raise ValueError(f"Champ incompatible pour {concept}.")
            return mapping

        if len(review.get('candidates', [])) > 1:
            ui.label('Choisir une autre hypothèse testée').classes('text-h6')
            with ui.row():
                for position, candidate in enumerate(review['candidates'], 1):
                    def select_candidate(selected=candidate):
                        mapping_editor.set_value(json.dumps(selected['proposed_mapping'], ensure_ascii=False, indent=2))
                        store.update_review(review_id, {'proposed_mapping': selected['proposed_mapping'],
                                                        'plan': selected['plan']})
                        ui.notify('Hypothèse sélectionnée ; vérifier puis approuver.', type='positive')
                    ui.button(f'Hypothèse {position}', on_click=select_candidate)

        def save_mapping():
            try:
                store.update_review(review_id, {'proposed_mapping': validated_mapping()})
                ui.notify('Mapping corrigé et enregistré.', type='positive')
            except Exception as exc:
                ui.notify(str(exc), type='negative')

        def approve():
            try:
                mapping = validated_mapping()
                current = inventory_service.refresh()['indices'][review['index']]['schema_hash']
                updates = {'proposed_mapping': mapping}
                if review.get('plan'):
                    dsl = compile_plan(review['plan'], {'concepts': mapping}, settings)
                    result = summarize(search.search(review['index'], dsl), review['plan']['operation'])
                    updates['dsl_trials'] = [*review.get('dsl_trials', []), {'dsl': dsl, 'result_summary': result,
                                                                             'expert_revalidation': True}]
                store.update_review(review_id, updates)
                store.approve(review_id, current)
                ui.notify('Mapping approuvé. Le rejeu peut maintenant publier un résultat.', type='positive')
                ui.navigate.reload()
            except Exception as exc:
                ui.notify(str(exc), type='negative')

        def reject():
            store.reject(review_id, reason.value or 'Rejet expert')
            ui.navigate.reload()

        with ui.row():
            ui.button('Enregistrer la correction', on_click=save_mapping)
            ui.button('Approuver après revalidation', on_click=approve, color='positive')
            ui.button('Rejeter', on_click=reject, color='negative')


@ui.page('/catalog')
def catalog_page():
    shell('Catalogue approuvé')
    catalog = store.catalog()
    if not catalog:
        ui.label('Le catalogue actif est vide. C’est l’état initial attendu avant validation experte.')
    for entry in catalog:
        with ui.card().classes('w-full'):
            ui.label(f"{entry['id']} — {entry['index']}").classes('text-h6')
            ui.badge('actif' if entry.get('active') else 'invalidé', color='positive' if entry.get('active') else 'negative')
            ui.label(entry['schema_hash']).classes('font-mono text-xs')
            ui.code(json.dumps(entry['concepts'], ensure_ascii=False, indent=2), language='json')


@ui.page('/audit')
def audit_page():
    shell('Journal d’audit')
    path = settings.data_dir / 'audit' / 'events.jsonl'
    records = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()] if path.exists() else []
    ui.code(json.dumps(records[-200:][::-1], ensure_ascii=False, indent=2), language='json').classes('w-full')


def main() -> None:
    try:
        inventory_service.refresh()
    except Exception as exc:
        store.audit('startup.inventory_failed', {'type': type(exc).__name__, 'message': str(exc)[:500]})
    ui.run(host=settings.admin_host, port=settings.admin_port, title='Agent PDL — administration', reload=False, show=False)


if __name__ in {'__main__', '__mp_main__'}:
    main()
