from __future__ import annotations

from datetime import datetime, timezone
import fnmatch
from pathlib import Path
import re
from typing import Any

import yaml

from .config import Settings
from .http import session_for
from .store import Store, canonical_hash, now_iso


INDEX_RE = re.compile(r"[a-z0-9][a-z0-9._-]{0,254}")


def flatten_mapping(properties: dict, prefix: str = "") -> dict[str, str]:
    fields: dict[str, str] = {}
    for name, spec in properties.items():
        path = prefix + name
        if "type" in spec:
            fields[path] = spec["type"]
        fields.update(flatten_mapping(spec.get("properties", {}), path + "."))
        for sub_name, sub_spec in spec.get("fields", {}).items():
            if "type" in sub_spec:
                fields[f"{path}.{sub_name}"] = sub_spec["type"]
    return fields


def load_templates(path: Path | None = None) -> list[dict]:
    path = path or Path(__file__).with_name("templates.yaml")
    return (yaml.safe_load(path.read_text(encoding="utf-8")) or {}).get("templates", [])


def compare_template(template: dict, fields: dict[str, dict], index: str) -> dict:
    concepts, compatible = {}, True
    for concept, spec in template["concepts"].items():
        matches = []
        for candidate in spec["candidates"]:
            cap = fields.get(candidate)
            if cap:
                matches.append({"field": candidate, "type": cap["type"], "searchable": cap["searchable"],
                                "aggregatable": cap["aggregatable"],
                                "compatible": cap["type"] in spec["types"] and cap["searchable"] and cap["aggregatable"]})
        valid = [item for item in matches if item["compatible"]]
        preferred = spec.get("preferred")
        if preferred and any(item["field"] == preferred for item in valid):
            status, selected = "compatible", preferred
        elif len(valid) == 1:
            status, selected = "compatible", valid[0]["field"]
        elif len(valid) > 1:
            status, selected = "ambiguous", None
        elif matches:
            status, selected = "type_mismatch", None
        else:
            status, selected = "missing", None
        compatible &= status == "compatible"
        concepts[concept] = {"status": status, "selected": selected, "matches": matches,
                             "expected_types": spec["types"], **({"values": spec["values"]} if "values" in spec else {})}
    return {"template_id": template["id"], "title": template["title"], "index": index,
            "compatible": compatible, "concepts": concepts, "active": False}


class OpenSearchInventory:
    def __init__(self, settings: Settings, store: Store):
        self.settings, self.store = settings, store
        self.source = settings.opensearch
        self.session = session_for(self.source)
        self.base_url = self.source.url.rstrip("/")
        self.templates = load_templates()

    def _request(self, method: str, path: str, **kwargs) -> Any:
        allowed_get = method == "GET" and (path.startswith("/_resolve/index/") or re.fullmatch(
            r"/[a-z0-9][a-z0-9._-]{0,254}/_(mapping|field_caps|alias)", path))
        allowed_profile = method == "POST" and re.fullmatch(r"/[a-z0-9][a-z0-9._-]{0,254}/_search", path)
        if not (allowed_get or allowed_profile):
            raise ValueError("Endpoint de découverte interdit.")
        response = self.session.request(method, self.base_url + path, timeout=15, allow_redirects=False, **kwargs)
        if response.status_code != 200:
            raise RuntimeError(f"Découverte OpenSearch impossible : HTTP {response.status_code}")
        return response.json()

    def _profile(self, index: str, fields: dict[str, dict]) -> dict[str, list[dict]]:
        selected = [name for name, cap in sorted(fields.items())
                    if cap["type"] in {"keyword", "ip"} and cap["aggregatable"]][:20]
        if not selected:
            return {}
        body = {"size": 0, "timeout": "5s", "aggs": {
            f"f{position}": {"terms": {"field": name, "size": 20, "shard_size": 40}}
            for position, name in enumerate(selected)}}
        raw = self._request("POST", f"/{index}/_search", json=body)
        return {name: [{"value": bucket["key"], "count": bucket["doc_count"]}
                       for bucket in raw.get("aggregations", {}).get(f"f{position}", {}).get("buckets", [])]
                for position, name in enumerate(selected)}

    def _allowed(self, index: str) -> bool:
        return bool(INDEX_RE.fullmatch(index)) and any(fnmatch.fnmatchcase(index, pattern) for pattern in self.settings.allowed_index_patterns)

    def resolve_indices(self) -> list[str]:
        indices = set()
        for pattern in self.settings.allowed_index_patterns:
            result = self._request("GET", f"/_resolve/index/{pattern}", params={"expand_wildcards": "open"})
            indices.update(item["name"] for item in result.get("indices", []) if self._allowed(item["name"]))
        return sorted(indices)

    @staticmethod
    def _caps(raw: dict, mapping: dict[str, str]) -> dict[str, dict]:
        fields = {}
        for name, by_type in raw.get("fields", {}).items():
            kinds = sorted(by_type)
            fields[name] = {
                "type": mapping.get(name, kinds[0] if len(kinds) == 1 else "conflict"),
                "types": kinds,
                "searchable": all(bool(item.get("searchable")) for item in by_type.values()),
                "aggregatable": all(bool(item.get("aggregatable")) for item in by_type.values()),
            }
        return fields

    def refresh(self) -> dict:
        inventory = {"created_at": now_iso(), "allowed_patterns": list(self.settings.allowed_index_patterns), "indices": {}}
        for index in self.resolve_indices():
            mapping_raw = self._request("GET", f"/{index}/_mapping")
            entry = mapping_raw.get(index) or next(iter(mapping_raw.values()))
            mapping = flatten_mapping(entry.get("mappings", {}).get("properties", {}))
            caps_raw = self._request("GET", f"/{index}/_field_caps", params={"fields": "*"})
            aliases_raw = self._request("GET", f"/{index}/_alias")
            fields = self._caps(caps_raw, mapping)
            fingerprint_payload = {"mapping": mapping, "field_caps": fields}
            comparisons = []
            for template in self.templates:
                if fnmatch.fnmatchcase(index, template["index_pattern_hint"]):
                    comparisons.append(compare_template(template, fields, index))
            inventory["indices"][index] = {
                "schema_hash": canonical_hash(fingerprint_payload), "mapping": mapping, "fields": fields,
                "aliases": sorted((aliases_raw.get(index) or {}).get("aliases", {})),
                "bounded_values": self._profile(index, fields), "template_comparisons": comparisons,
            }
        self.store.save_inventory(inventory)
        hashes = {name: item["schema_hash"] for name, item in inventory["indices"].items()}
        inventory["invalidated_catalog_ids"] = self.store.invalidate(hashes)
        self.store.save_inventory(inventory)
        self.store.audit("inventory.refreshed", {"indices": sorted(inventory["indices"]), "invalidated": inventory["invalidated_catalog_ids"]})
        return inventory

    def stale(self) -> bool:
        inventory = self.store.inventory()
        if not inventory.get("created_at"):
            return True
        created = datetime.fromisoformat(inventory["created_at"])
        return (datetime.now(timezone.utc) - created).total_seconds() >= self.settings.refresh_seconds

    def ensure_fresh(self) -> dict:
        return self.refresh() if self.stale() else self.store.inventory()

    def review_for_template(self, template_id: str, index: str) -> dict:
        inventory = self.ensure_fresh()
        entry = inventory.get("indices", {}).get(index)
        if not entry:
            raise ValueError("Index absent de l'inventaire autorisé.")
        comparison = next((item for item in entry["template_comparisons"] if item["template_id"] == template_id), None)
        if not comparison:
            raise ValueError("Ce modèle initial ne correspond pas au motif de l'index.")
        if not comparison["compatible"]:
            raise ValueError("Le modèle contient des champs absents, ambigus ou incompatibles.")
        proposed = {name: {"field": spec["selected"], "type": entry["fields"][spec["selected"]]["type"],
                           **({"values": spec["values"]} if "values" in spec else {})}
                    for name, spec in comparison["concepts"].items()}
        return self.store.create_review({
            "kind": "initial_template", "template_id": template_id, "index": index,
            "schema_hash": entry["schema_hash"], "proposed_mapping": proposed,
            "comparison": comparison, "dsl_trials": [],
        })
