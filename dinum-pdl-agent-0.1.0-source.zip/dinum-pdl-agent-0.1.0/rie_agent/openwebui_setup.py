from __future__ import annotations

import argparse
import json
from pathlib import Path
import urllib.parse

import requests


SERVER_ID = "dinum-pdl-agent"
MODEL_ID = "albert-pdl-rie"
SYSTEM_PROMPT = """Tu es l'assistant PDL du RIE. Pour toute question sur les journaux ou l'état du PDL,
appelle une seule fois investigate_pdl avec la question originale. Cet outil est ta seule source factuelle.
N'invente jamais d'index, de champ, de DSL, de résultat ou d'URL. Si status=success, restitue le résultat,
la route, le niveau de validation, les preuves, le DSL exact et ses limites. Si status=awaiting_human,
n'affiche aucun résultat métier : explique que le mapping doit être validé et fournis review_url.
Si status=needs_clarification, pose uniquement la question de clarification. Si status=error, restitue
l'erreur sans la masquer. Refuse toute écriture ou administration des sources. N'appelle aucun autre outil."""


class OpenWebUI:
    def __init__(self, base_url: str, verify: str | bool = True):
        self.base_url, self.verify = base_url.rstrip('/'), verify
        self.session = requests.Session()
        self.session.trust_env = False

    def request(self, path: str, method='GET', token=None, payload=None):
        headers = {'Authorization': f'Bearer {token}'} if token else {}
        response = self.session.request(method, self.base_url + path, headers=headers, json=payload,
                                        timeout=30, verify=self.verify, allow_redirects=False)
        if response.status_code >= 400:
            raise RuntimeError(f"OpenWebUI HTTP {response.status_code} sur {path}")
        return response.json() if response.content else {}


def configure(client: OpenWebUI, email: str, password: str, mcp_url: str, model='gpt-oss-120b') -> dict:
    token = client.request('/api/v1/auths/signin', 'POST', payload={'email': email, 'password': password})['token']
    connection = {
        'url': mcp_url, 'path': '', 'type': 'mcp', 'auth_type': 'none', 'headers': {}, 'key': '',
        'config': {'enable': True, 'access_grants': [], 'function_name_filter_list': 'investigate_pdl'},
        'info': {'id': SERVER_ID, 'name': 'Agent PDL RIE — lecture seule',
                 'description': 'Traduction contrôlée, preuves, DSL et revue humaine des mappings.'},
    }
    verified = client.request('/api/v1/configs/tool_servers/verify', 'POST', token, connection)
    tools = {item['name'] for item in verified.get('specs', [])}
    if tools != {'investigate_pdl'}:
        raise RuntimeError(f"Inventaire MCP inattendu : {sorted(tools)}")
    current = client.request('/api/v1/configs/tool_servers', token=token)
    connections = [item for item in current.get('TOOL_SERVER_CONNECTIONS') or []
                   if (item.get('info') or {}).get('id') != SERVER_ID]
    connections.append(connection)
    client.request('/api/v1/configs/tool_servers', 'POST', token, {'TOOL_SERVER_CONNECTIONS': connections})
    models = {item.get('id') for item in client.request('/api/models', token=token).get('data', [])}
    if model not in models:
        raise RuntimeError(f"Le modèle {model} n'est pas publié dans OpenWebUI.")
    payload = {
        'id': MODEL_ID, 'base_model_id': model, 'name': 'Albert PDL RIE',
        'params': {'system': SYSTEM_PROMPT, 'function_calling': 'native', 'temperature': 0},
        'meta': {'description': 'Agent PDL adaptatif contrôlé par catalogue approuvé.',
                 'toolIds': [f'server:mcp:{SERVER_ID}'], 'capabilities': {'builtin_tools': False},
                 'tags': [{'name': 'DINUM'}, {'name': 'PDL'}, {'name': 'RIE'}]},
        'access_grants': [], 'is_active': True,
    }
    query = urllib.parse.urlencode({'id': MODEL_ID})
    try:
        client.request(f'/api/v1/models/model?{query}', token=token)
        endpoint = '/api/v1/models/model/update'
    except RuntimeError as exc:
        if 'HTTP 404' not in str(exc):
            raise
        endpoint = '/api/v1/models/create'
    saved = client.request(endpoint, 'POST', token, payload)
    if saved.get('id') != MODEL_ID:
        raise RuntimeError("Le preset OpenWebUI n'a pas été enregistré.")
    return {'status': 'success', 'server_id': SERVER_ID, 'model_id': MODEL_ID, 'tools': sorted(tools)}


def main() -> None:
    parser = argparse.ArgumentParser(description='Configure OpenWebUI de façon idempotente.')
    parser.add_argument('--url', required=True)
    parser.add_argument('--email', required=True)
    parser.add_argument('--password-file', type=Path, required=True)
    parser.add_argument('--mcp-url', required=True)
    parser.add_argument('--ca-file')
    args = parser.parse_args()
    result = configure(OpenWebUI(args.url, args.ca_file or True), args.email,
                       args.password_file.read_text(encoding='utf-8').strip(), args.mcp_url)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()

