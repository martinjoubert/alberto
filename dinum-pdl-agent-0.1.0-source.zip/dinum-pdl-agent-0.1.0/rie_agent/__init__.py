"""Runtime conteneurisé de l'agent PDL pour le RIE."""

__version__ = "0.1.0"

