from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import tempfile
import os
import time
from typing import Any
from contextlib import contextmanager


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical_hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


class Store:
    def __init__(self, root: Path):
        self.root = root
        for name in ("inventory", "reviews", "reports", "catalog", "audit"):
            (root / name).mkdir(parents=True, exist_ok=True)

    def _write(self, path: Path, value: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            temp = Path(handle.name)
        temp.replace(path)

    def _read(self, path: Path, default: Any) -> Any:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default

    @contextmanager
    def _lock(self):
        lock = self.root / ".write-lock"
        deadline = time.monotonic() + 10
        while True:
            try:
                os.mkdir(lock)
                break
            except FileExistsError:
                try:
                    if time.time() - lock.stat().st_mtime > 60:
                        os.rmdir(lock)
                        continue
                except (FileNotFoundError, OSError):
                    pass
                if time.monotonic() >= deadline:
                    raise RuntimeError("Le stockage partagé est verrouillé.")
                time.sleep(0.05)
        try:
            yield
        finally:
            os.rmdir(lock)

    def audit(self, event: str, details: dict[str, Any]) -> None:
        record = {"at": now_iso(), "event": event, "details": details}
        with (self.root / "audit" / "events.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    def save_inventory(self, value: dict) -> None:
        self._write(self.root / "inventory" / "latest.json", value)

    def inventory(self) -> dict:
        return self._read(self.root / "inventory" / "latest.json", {})

    def create_review(self, value: dict) -> dict:
        review_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(4)
        value = {**value, "id": review_id, "status": "pending", "created_at": now_iso()}
        self._write(self.root / "reviews" / f"{review_id}.json", value)
        self.audit("review.created", {"review_id": review_id, "schema_hash": value.get("schema_hash")})
        return value

    def reviews(self) -> list[dict]:
        return sorted((self._read(path, {}) for path in (self.root / "reviews").glob("*.json")),
                      key=lambda item: item.get("created_at", ""), reverse=True)

    def review(self, review_id: str) -> dict:
        if not review_id.replace("-", "").isalnum():
            raise ValueError("Identifiant de revue invalide.")
        value = self._read(self.root / "reviews" / f"{review_id}.json", None)
        if value is None:
            raise KeyError(review_id)
        return value

    def update_review(self, review_id: str, updates: dict) -> dict:
        review = self.review(review_id)
        if review["status"] != "pending":
            raise ValueError("Cette revue a déjà été traitée.")
        review.update(updates)
        review["updated_at"] = now_iso()
        self._write(self.root / "reviews" / f"{review_id}.json", review)
        self.audit("review.updated", {"review_id": review_id, "fields": sorted(updates)})
        return review

    def catalog(self) -> list[dict]:
        return self._read(self.root / "catalog" / "approved.json", [])

    def approve(self, review_id: str, current_hash: str) -> dict:
        with self._lock():
            review = self.review(review_id)
            if review["status"] != "pending":
                raise ValueError("Cette revue a déjà été traitée.")
            if review["schema_hash"] != current_hash:
                raise ValueError("Le schéma a changé : rafraîchir et recommencer la revue.")
            catalog = self.catalog()
            catalog_key = review.get("template_id") or review_id
            version = 1 + max((int(item.get("version", 0)) for item in catalog
                               if item.get("catalog_key", item.get("id")) == catalog_key), default=0)
            for previous in catalog:
                if previous.get("catalog_key", previous.get("id")) == catalog_key and previous.get("active"):
                    previous["active"] = False
                    previous["superseded_at"] = now_iso()
            entry = {
                "id": f"{catalog_key}:v{version}", "catalog_key": catalog_key, "version": version,
                "index": review["index"], "schema_hash": current_hash,
                "concepts": review["proposed_mapping"], "approved_at": now_iso(),
                "approved_from_review": review_id, "active": True,
            }
            catalog.append(entry)
            self._write(self.root / "catalog" / "approved.json", catalog)
            review["status"], review["decided_at"] = "approved", now_iso()
            self._write(self.root / "reviews" / f"{review_id}.json", review)
        self.audit("mapping.approved", {"review_id": review_id, "catalog_id": entry["id"], "schema_hash": current_hash})
        return entry

    def reject(self, review_id: str, reason: str) -> None:
        review = self.review(review_id)
        review.update(status="rejected", decided_at=now_iso(), decision_reason=reason[:1000])
        self._write(self.root / "reviews" / f"{review_id}.json", review)
        self.audit("mapping.rejected", {"review_id": review_id, "reason": reason[:1000]})

    def invalidate(self, hashes: dict[str, str]) -> list[str]:
        with self._lock():
            catalog, invalidated = self.catalog(), []
            for entry in catalog:
                if entry.get("active") and hashes.get(entry["index"]) != entry["schema_hash"]:
                    entry["active"] = False
                    entry["invalidated_at"] = now_iso()
                    entry["invalidated_reason"] = "schema_changed"
                    invalidated.append(entry["id"])
            if invalidated:
                self._write(self.root / "catalog" / "approved.json", catalog)
        if invalidated:
            self.audit("mapping.invalidated", {"catalog_ids": invalidated})
        return invalidated
