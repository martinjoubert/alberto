from __future__ import annotations

from datetime import datetime, timezone
import fnmatch
import re
from typing import Any

from .config import Settings
from .http import session_for


FORBIDDEN_DSL_KEYS = {"script", "script_fields", "runtime_mappings", "update", "delete", "delete_by_query"}


def _time_value(value: str, now: datetime) -> datetime:
    relative = re.fullmatch(r"now(?:-(\d+)([mhd]))?", value)
    if relative:
        amount = int(relative.group(1) or 0)
        seconds = amount * {"m": 60, "h": 3600, "d": 86400}.get(relative.group(2), 0)
        from datetime import timedelta
        return now - timedelta(seconds=seconds)
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Une borne temporelle absolue doit inclure son fuseau.")
    return parsed.astimezone(timezone.utc)


def validate_time_range(period: dict, settings: Settings) -> None:
    if set(period) - {"gte", "lt"} or "gte" not in period or "lt" not in period:
        raise ValueError("La période doit contenir uniquement gte et lt.")
    now = datetime.now(timezone.utc)
    start, end = _time_value(str(period["gte"]), now), _time_value(str(period["lt"]), now)
    seconds = (end - start).total_seconds()
    if seconds <= 0 or seconds > settings.max_time_range_days * 86400:
        raise ValueError("Période vide, inversée ou supérieure à la limite.")


def _walk(value: Any):
    if isinstance(value, dict):
        for key, nested in value.items():
            yield key
            yield from _walk(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from _walk(nested)


class ReadOnlyOpenSearch:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.source = settings.opensearch
        self.session = session_for(self.source)
        self.base_url = self.source.url.rstrip("/")

    def index_allowed(self, index: str) -> bool:
        return bool(re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,254}", index)) and any(
            fnmatch.fnmatchcase(index, pattern) for pattern in self.settings.allowed_index_patterns)

    def validate_dsl(self, index: str, body: dict) -> None:
        if not self.index_allowed(index):
            raise ValueError("Index hors de la liste autorisée.")
        forbidden = FORBIDDEN_DSL_KEYS.intersection(_walk(body))
        if forbidden:
            raise ValueError(f"DSL interdit : {sorted(forbidden)}")
        if set(body) - {"size", "track_total_hits", "timeout", "query", "aggs", "_source", "sort"}:
            raise ValueError("Clé DSL non autorisée.")
        if int(body.get("size", 0)) > self.settings.max_rows:
            raise ValueError("Nombre de lignes supérieur à la limite.")

    def search(self, index: str, body: dict) -> dict:
        self.validate_dsl(index, body)
        response = self.session.post(f"{self.base_url}/{index}/_search", json=body, timeout=15, allow_redirects=False)
        if response.status_code != 200:
            raise RuntimeError(f"Recherche OpenSearch impossible : HTTP {response.status_code}")
        return response.json()


def compile_plan(plan: dict, catalog: dict, settings: Settings) -> dict:
    concepts = catalog["concepts"]
    timestamp = concepts.get("timestamp", {}).get("field")
    if not timestamp:
        raise ValueError("Le mapping approuvé ne déclare pas le temps.")
    period = plan.get("time_range") or {"gte": "now-2h", "lt": "now"}
    validate_time_range(period, settings)
    filters = [{"range": {timestamp: {"gte": period.get("gte", "now-2h"), "lt": period.get("lt", "now")}}}]
    for criterion in plan.get("filters", []):
        concept = criterion.get("concept")
        if concept not in concepts or concept == "timestamp":
            raise ValueError(f"Concept non approuvé : {concept}")
        field, value = concepts[concept]["field"], criterion.get("value")
        declared_values = concepts[concept].get("values")
        checked_values = value if isinstance(value, list) else [value]
        if declared_values and any(item not in declared_values for item in checked_values):
            raise ValueError(f"Valeur non approuvée pour le concept {concept}.")
        op = criterion.get("operator", "eq")
        if op == "eq":
            filters.append({"term": {field: value}})
        elif op == "in" and isinstance(value, list) and value:
            filters.append({"terms": {field: value}})
        elif op == "exists":
            filters.append({"exists": {"field": field}})
        else:
            raise ValueError("Opérateur non autorisé.")
    operation = plan.get("operation", "search")
    body: dict[str, Any] = {"size": 0, "track_total_hits": True, "timeout": "5s", "query": {"bool": {"filter": filters}}}
    if operation == "search":
        body["size"] = min(int(plan.get("limit", 20)), settings.max_rows)
        selected = plan.get("select") or list(concepts)
        if any(name not in concepts for name in selected):
            raise ValueError("Projection non approuvée.")
        body["_source"] = sorted({concepts[name]["field"] for name in selected})
        body["sort"] = [{timestamp: "desc"}]
    elif operation == "count":
        pass
    elif operation == "aggregate":
        group = plan.get("group_by")
        if group not in concepts:
            raise ValueError("Regroupement non approuvé.")
        group_field = concepts[group]["field"]
        body["aggs"] = {"groups": {"terms": {"field": group_field,
                                                  "size": min(int(plan.get("limit", 10)), settings.max_buckets),
                                                  "order": [{"_count": "desc"}, {"_key": "asc"}],
                                                  "show_term_doc_count_error": True}},
                        "missing_group": {"missing": {"field": group_field}}}
    else:
        raise ValueError("Opération non autorisée.")
    return body


def summarize(raw: dict, operation: str) -> dict:
    total = raw.get("hits", {}).get("total", {})
    total_value = total.get("value", 0) if isinstance(total, dict) else int(total or 0)
    result = {"total": total_value, "total_relation": total.get("relation", "eq") if isinstance(total, dict) else "eq",
              "timed_out": bool(raw.get("timed_out")), "failed_shards": raw.get("_shards", {}).get("failed", 0)}
    if operation == "search":
        result["rows"] = [{"id": hit.get("_id"), "source": hit.get("_source", {})} for hit in raw.get("hits", {}).get("hits", [])]
    elif operation == "aggregate":
        groups = raw.get("aggregations", {}).get("groups", {})
        result["rows"] = [{"key": bucket["key"], "count": bucket["doc_count"]}
                          for bucket in groups.get("buckets", [])]
        result["visible_sum"] = sum(item["count"] for item in result["rows"])
        result["missing_group_count"] = raw.get("aggregations", {}).get("missing_group", {}).get("doc_count", 0)
        result["sum_other_doc_count"] = groups.get("sum_other_doc_count", 0)
        result["doc_count_error_upper_bound"] = groups.get("doc_count_error_upper_bound", 0)
        result["complete_for_query"] = (result["total_relation"] == "eq" and not result["timed_out"] and
                                         not result["failed_shards"] and not result["sum_other_doc_count"] and
                                         not result["doc_count_error_upper_bound"] and
                                         result["visible_sum"] + result["missing_group_count"] == result["total"])
    return result
