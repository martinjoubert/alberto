from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
import re
from typing import Any

import yaml


def _secret(path: str | None) -> str | None:
    if not path:
        return None
    value = Path(path).read_text(encoding="utf-8").strip()
    if not value:
        raise ValueError(f"Secret vide : {path}")
    return value


@dataclass(frozen=True)
class TLSConfig:
    ca_file: str | None = None
    client_cert_file: str | None = None
    client_key_file: str | None = None
    verify: bool = True


@dataclass(frozen=True)
class SourceConfig:
    enabled: bool
    url: str
    username: str | None = None
    password_file: str | None = None
    token_file: str | None = None
    tls: TLSConfig = field(default_factory=TLSConfig)
    allowed_tools: tuple[str, ...] = ()

    @property
    def password(self) -> str | None:
        return _secret(self.password_file)

    @property
    def token(self) -> str | None:
        return _secret(self.token_file)


@dataclass(frozen=True)
class AlbertConfig:
    url: str
    model: str
    api_key_file: str
    tls: TLSConfig = field(default_factory=TLSConfig)

    @property
    def api_key(self) -> str:
        return _secret(self.api_key_file) or ""


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    allowed_index_patterns: tuple[str, ...]
    refresh_seconds: int
    public_admin_url: str
    mcp_host: str
    mcp_port: int
    admin_host: str
    admin_port: int
    albert: AlbertConfig
    opensearch: SourceConfig
    zabbix: SourceConfig
    grafana: SourceConfig
    max_rows: int = 100
    max_buckets: int = 100
    max_time_range_days: int = 31

    def validate(self) -> None:
        if not self.allowed_index_patterns:
            raise ValueError("Au moins un motif d'index OpenSearch autorisé est obligatoire.")
        for pattern in self.allowed_index_patterns:
            if not re.fullmatch(r"[a-z0-9][a-z0-9._*-]{0,254}", pattern) or '..' in pattern:
                raise ValueError(f"Motif d'index interdit : {pattern!r}")
        if not self.opensearch.enabled:
            raise ValueError("OpenSearch doit être activé pour la recette RIE initiale.")
        for source in (self.opensearch, self.zabbix, self.grafana):
            if source.enabled and not source.url.startswith(("http://", "https://")):
                raise ValueError("Chaque source activée doit utiliser une URL HTTP(S).")
        if self.refresh_seconds < 60 or self.max_rows not in range(1, 1001):
            raise ValueError("Limites de découverte ou de résultats invalides.")


def _tls(value: dict[str, Any] | None) -> TLSConfig:
    return TLSConfig(**(value or {}))


def _source(value: dict[str, Any] | None) -> SourceConfig:
    value = dict(value or {})
    value["tls"] = _tls(value.get("tls"))
    value["allowed_tools"] = tuple(value.get("allowed_tools") or ())
    return SourceConfig(**value)


def load_settings(path: str | Path | None = None) -> Settings:
    path = Path(path or os.getenv("PDL_CONFIG", "/etc/pdl-agent/config.yaml"))
    raw = yaml.safe_load(os.path.expandvars(path.read_text(encoding="utf-8"))) or {}
    server = raw.get("server", {})
    limits = raw.get("limits", {})
    discovery = raw.get("discovery", {})
    sources = raw.get("sources", {})
    albert_raw = dict(raw.get("albert") or {})
    albert_raw["tls"] = _tls(albert_raw.get("tls"))
    settings = Settings(
        data_dir=Path(os.getenv("PDL_DATA_DIR", raw.get("storage", {}).get("data_dir", "/var/lib/pdl-agent"))),
        allowed_index_patterns=tuple(discovery.get("allowed_index_patterns") or ()),
        refresh_seconds=int(discovery.get("refresh_seconds", 3600)),
        public_admin_url=str(server.get("public_admin_url", "http://127.0.0.1:8090")).rstrip("/"),
        mcp_host=str(server.get("mcp_host", "0.0.0.0")), mcp_port=int(server.get("mcp_port", 9910)),
        admin_host=str(server.get("admin_host", "0.0.0.0")), admin_port=int(server.get("admin_port", 8090)),
        albert=AlbertConfig(**albert_raw),
        opensearch=_source(sources.get("opensearch")),
        zabbix=_source(sources.get("zabbix")),
        grafana=_source(sources.get("grafana")),
        max_rows=int(limits.get("max_rows", 100)), max_buckets=int(limits.get("max_buckets", 100)),
        max_time_range_days=int(limits.get("max_time_range_days", 31)),
    )
    settings.validate()
    return settings
