from __future__ import annotations

import requests

from .config import SourceConfig, TLSConfig


def session_for(config: SourceConfig | TLSConfig, *, bearer: str | None = None) -> requests.Session:
    session = requests.Session()
    session.trust_env = False
    source = config if isinstance(config, SourceConfig) else None
    tls = source.tls if source else config
    session.verify = tls.ca_file if tls.ca_file else tls.verify
    if tls.client_cert_file:
        session.cert = (tls.client_cert_file, tls.client_key_file) if tls.client_key_file else tls.client_cert_file
    if source and source.enabled:
        if source.username:
            session.auth = (source.username, source.password or "")
        if source.token:
            session.headers["Authorization"] = f"Bearer {source.token}"
    if bearer:
        session.headers["Authorization"] = f"Bearer {bearer}"
    session.headers["User-Agent"] = "dinum-pdl-agent/0.1.0"
    return session
